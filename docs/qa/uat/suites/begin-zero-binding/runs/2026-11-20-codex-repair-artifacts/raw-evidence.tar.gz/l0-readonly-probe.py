import importlib.util,pathlib,json
root=pathlib.Path(__file__).resolve().parents[2];p=root/'inbox/p1-60-repair/worktree/scripts/uat/verify-begin-zero-binding.py'
spec=importlib.util.spec_from_file_location('zb',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=m.Rig('project-lucy:p1-60-3b69470e-final-v2',root/'inbox/p1-60-repair/l0-cause-v2','l0-cause','L0')
try:
 r.start();r.restart()
 ident='uat_zb_a|'+('sha256:'+m.sha(r.tokens['a']))[:19]
 code='(async()=>{const s=await import("/app/webui/server/proxy/caliber-binding-session.ts");const r=await import("/app/webui/server/proxy/caliber-binding-registry.ts");const c=await import("/app/webui/server/proxy/caliber-binding.ts");const scope=s.bindingScopeKey('+json.dumps(ident)+',"legacy");console.log(JSON.stringify({scope,session:await s.readBindingSession(scope),participation:await r.classifyCaliberParticipation({scopeKey:scope}),gate:await c.checkCaliberBindingGate({identity:{},identityKey:'+json.dumps(ident)+',sessionId:"legacy",toolName:"lucy_query",args:{}})}));})()'
 proof=m.run(['docker','exec',r.app,'/app/webui/node_modules/.bin/tsx','-e',code]);r.save('direct-production-reader',proof)
 begin=r.call('forced','lucy_begin_question',{},session='legacy');q=r.call('query','lucy_query',{'connectionId':m.CONN,'measures':[m.SOURCE+'.order_count',m.SOURCE+'.amount_sum']},session='legacy')
 r.save('cause',{'begin':begin,'query':q,'direct':proof});print(proof,flush=True)
 r.save('session-files',m.run(['docker','exec',r.app,'sh','-c','cat /data/lucy/.ktx-ui/caliber-binding/sessions/*.json']))
finally:r.close()
