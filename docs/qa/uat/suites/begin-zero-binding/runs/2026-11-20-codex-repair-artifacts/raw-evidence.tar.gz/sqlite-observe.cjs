// Test-only observation; no parameters, credentials, SQL text or behavior changes.
const DB = require('/app/webui/node_modules/better-sqlite3');
const prepare = DB.prototype.prepare;
const report = (error, operation) => console.error('[uat-sqlite-observe]', JSON.stringify({operation, code:error.code, message:error.message}));
DB.prototype.prepare = function(sql) {
  let statement;
  try { statement=prepare.call(this,sql); } catch(error) { report(error,'prepare'); throw error; }
  for(const operation of ['get','all','run']) {
    const original=statement[operation];
    statement[operation]=function(...args) { try { return original.apply(this,args); } catch(error) { report(error,operation); throw error; } };
  }
  return statement;
};
