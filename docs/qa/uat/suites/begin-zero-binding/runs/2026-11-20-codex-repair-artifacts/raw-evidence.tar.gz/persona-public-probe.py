import importlib.util,pathlib,json,hashlib
root=pathlib.Path(__file__).resolve().parents[2];p=root/'scripts/uat/verify-begin-zero-binding.py'
spec=importlib.util.spec_from_file_location('zb',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=m.Rig('project-lucy:p1-60-3b69470e-final-v2',root/'inbox/p1-60-repair/persona-public-v2','persona-public')
result={'case':'UAT-ZB-08','runnerSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'status':'RUNNING'}
try:r.start();proof=r.public_persona_tasks();result.update(status='PASS',attributionCounts=proof['attributionCounts'])
except Exception as e:result.update(status='FAIL',error=m.scrub(str(e)))
finally:r.save('task-result',result);r.close()
print(json.dumps(result),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
