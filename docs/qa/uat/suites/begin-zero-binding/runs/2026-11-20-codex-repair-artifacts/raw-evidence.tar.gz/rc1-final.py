import importlib.util,pathlib,json,hashlib
root=pathlib.Path(__file__).resolve().parents[2];p=root/'inbox/p1-60-repair/runner-delivery-77e2ad84.py'
spec=importlib.util.spec_from_file_location('zb',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from pathlib import Path
import re,os,subprocess
pathlib=__import__('pathlib');require=m.require;run=m.run;scrub=m.scrub

def real_client(rig):
    cli=pathlib.Path('/opt/homebrew/Caskroom/codex/0.165.0/bin/codex')
    require(cli.is_file() and hashlib.sha256(cli.read_bytes()).hexdigest()=='a45099154d7fb4a5ed8a56f40966a95deb938e508bab23e6985035c709e9a85a','RC1 pinned client unavailable')
    client_dir=rig.private/'client';client_dir.mkdir()
    config=pathlib.Path.home()/'.codex/config.toml';names=[]
    if config.is_file():names=re.findall(r'^\[mcp_servers\.([^].]+)\]',config.read_text(),re.M)
    cmd=[str(cli),'exec','--json','--skip-git-repo-check','-C',str(client_dir),'-s','read-only']
    for name in names:cmd+=['-c','mcp_servers.'+name+'.enabled=false']
    for approved_tool in ['lucy_catalog','lucy_read_source','lucy_query']:
        cmd+=['-c','mcp_servers.zb_uat.tools.'+approved_tool+'.approval_mode="approve"']
    cmd+=['-c','mcp_servers.zb_uat.url='+json.dumps(rig.mcp+'/mcp'),'-c','mcp_servers.zb_uat.bearer_token_env_var="ZB_UAT_TOKEN"','--output-last-message',str(client_dir/'answer.txt'),'仅使用 zb_uat MCP 查询测试订单数和总金额。先确认可见 source，必须真实查数；不要使用 shell、文件或其他服务。遵守可见工具，不尝试隐藏工具；若收到 begin_not_available，直接继续查询。最终仅输出 JSON：{"order_count":实际值,"amount_sum":实际值}。']
    env=dict(os.environ);env['ZB_UAT_TOKEN']=rig.tokens['a']
    last_audit=rig.audit('SELECT COALESCE(MAX(id),0) AS id FROM access_log')[0]['id']
    actual=subprocess.run(cmd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=300)
    rig.save('r12-client-trace',actual.stdout);rig.save('r12-client-stderr',actual.stderr)
    require(actual.returncode==0,'RC1 execution failed '+scrub(actual.stderr[-1000:]))
    answer=(client_dir/'answer.txt').read_text();rig.save('r12-final-answer',answer)
    parsed=json.loads(answer.strip().removeprefix('```json').removesuffix('```').strip());require(parsed.get('order_count') is not None and parsed.get('amount_sum') is not None,'RC1 did not return numeric facts; inspect actual tool admission/execution trace');require(float(parsed['order_count'])==4 and float(parsed['amount_sum'])==100,'RC1 final fact mismatch')
    events=[json.loads(line) for line in actual.stdout.splitlines() if line.startswith('{')]
    calls=[event.get('item',{}) for event in events if event.get('type')=='item.completed' and event.get('item',{}).get('type')=='mcp_tool_call']
    actual_queries=[item for item in calls if item.get('server')=='zb_uat' and item.get('tool')=='lucy_query' and not item.get('error')]
    require(actual_queries,'RC1 lacks a completed real MCP query event')
    require(not any(event.get('item',{}).get('type')=='command_execution' for event in events),'RC1 used shell instead of pure MCP')
    persisted=rig.audit('SELECT id,tool,outcome,response_row_count,trace_id,lucy_session_id FROM access_log WHERE id>'+str(last_audit)+" AND user_id='uat_zb_a' ORDER BY id")
    require(any(row['tool']=='lucy_query' and row['outcome']=='ok' and row['response_row_count']==1 for row in persisted),'RC1 query has no matching persisted actual result')
    begin_calls=[row for row in persisted if row['tool']=='lucy_begin_question']
    require(len(begin_calls)<=1,'RC1 retried the hidden begin repeatedly')
    rig.save('r12-persisted-proof',{'events':calls,'audit':persisted,'clientVersion':run([str(cli),'--version'])})
    return {'client':'Codex CLI 0.165.0','actualAnswer':parsed,'hiddenBeginCallObserved':bool(begin_calls),'approvedTools':['lucy_catalog','lucy_read_source','lucy_query']}

rig=m.Rig('project-lucy:p1-60-77e2ad84-final',root/'inbox/p1-60-repair/77e2ad84-client','rc1-only')
result={'case':'UAT-ZB-12','runnerSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'status':'RUNNING'}
try:
 rig.start();rig.hidden('rc1-protocol-precheck',session='rc1-precheck');detail=real_client(rig);result.update(status='PASS',**detail)
except Exception as e:result.update(status='FAIL',error=scrub(str(e)))
finally:rig.save('case-result',result);rig.close()
print(json.dumps(result,ensure_ascii=False),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
