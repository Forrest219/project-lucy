import importlib.util,pathlib,json,hashlib
root=pathlib.Path(__file__).resolve().parents[2];p=root/'inbox/p1-60-repair/runner-final-77e2ad84.py'
spec=importlib.util.spec_from_file_location('zb',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
label='77e2ad84-performance';out=root/'inbox/p1-60-repair'/label;rigs=[]
result={'case':'UAT-ZB-10','runnerSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'status':'RUNNING'}
try:
 for name,image in [('baseline','project-lucy:p1-60-base-c1cd67a0'),('candidate','project-lucy:p1-60-77e2ad84-final')]:
  rig=m.Rig(image,out/name,label+'-'+name);rigs.append(rig);rig.start()
 perf=rigs[1].compare_performance(rigs[0],rigs[1]);result.update(status=perf['status'],successes=perf['successes'],denominatorPerGroup=300,warmupFailures=len(perf['warmupFailures']))
except Exception as e:result.update(status='FAIL',error=m.scrub(str(e)))
finally:
 for rig in reversed(rigs):
  if 'app' in rig.created:rig.save('final-container-log',m.run(['docker','logs','--tail','120',rig.app],check=False))
  rig.close()
 out.mkdir(parents=True,exist_ok=True);(out/'case-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
