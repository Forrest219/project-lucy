import importlib.util,pathlib,json,os
p=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('zb',p.parent.parent/'scripts/uat/verify-begin-zero-binding.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
os.environ['ZB_SQLITE_DIAGNOSTIC']=str(p/'sqlite-observe.cjs')
r=m.Rig('project-lucy:p1-60-base-c1cd67a0',p/'budget-baseline-probe','budget-base')
result={'scope':'unmodified baseline image with test-only SQLite observation; no budget/ACL bypass','status':'RUNNING'}
try:
 r.start()
 for i in range(400):
  session='native-budget-'+str(i)
  r.call(session+'-catalog','lucy_catalog',{},session=session,save=False)
  source=r.call(session+'-source','lucy_read_source',{'connectionId':m.CONN,'sourceName':m.SOURCE},session=session,save=False)
  if not m.successful(source):r.save(session+'-source-failure',source);raise RuntimeError('baseline source failure '+json.dumps(source))
  r.query(session+'-query',session=session,save=False)
  result['completedProblems']=i+1
 result['status']='NOT_REPRODUCED'
except Exception as e:result.update(status='REPRODUCED',error=m.scrub(str(e)))
finally:
 if 'app' in r.created:r.save('sqlite-observation-log',m.run(['docker','logs',r.app],check=False))
 r.save('probe-result',result);r.close()
print(json.dumps(result),flush=True)
