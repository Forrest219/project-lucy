# 最终77e2ad84证据索引

- [制品manifest](artifact-manifest.json)：最终镜像a794f7e0…、5个运行文件及原预算writer hash。
- [逐例结果](case-results.json)：13必做，12 PASS／1 FAIL，无NOT RUN。
- [早段](77e2ad84-early/summary.json)：R0／01–05与公开审计补偿。
- [后段](77e2ad84-late/summary.json)：06–09、I0–I4／L0；保留旧强状态前置不成立的失败。
- [旧强状态与T0补验](77e2ad84-strong-client/summary.json)：L1／U0／T0真实恢复；保留首次RC1客户端准入失败。
- [RC1最终实际答案和判定](77e2ad84-client/case-result.json)、[真实工具与审计](77e2ad84-client/r12-persisted-proof.json)。
- [完整性能](77e2ad84-performance/candidate/r10-performance.json)：两组各300问、三轮、13次实际预算拒绝，全部样本保留。
- [清理核对](cleanup-summary.json)：24个最终夹具。
- [历史资格跑次](qualification-history.json)、[中间原始失败](qualification/)。
- [完整性](SHA256SUMS.json)：全部附件SHA256；[最终治理检查](final-governance-check.json)。

原四项代码修复已复核；完整合同保持FAIL与未收口。预算按委托人裁决另处理，未纳入此镜像。未推送、未发布。
