# P1-70 r3：post-wait 当前语义目录窄修

状态：代码冻结供非作者复核及最终CodeCLI重审，**不得将上一轮REQUEST CHANGES写为APPROVED**。原r5镜像、346/346整合阶段、r5短cal FAIL和原始自然窗数据均由M保留；本报告不代签新候选Docker、正式30分钟或上线。

## 已证缺陷与有效先红

最终CodeCLI指出post-wait revalidation沿用60秒published ambiguity缓存。先红位于 `postwait-catalog-cache-red.log`，真实HTTP、真实临时目录、注册真实WAL与deferred writer，非缺export或装配错误：

1. 初始明确ACL/启用表已允许funds和other_funds；只有funds的Manifest声明campaign_id列，prime真实60秒缓存时只产生funds这一列目录候选。
2. 原问题使用funds.fund_count与未限定来源的campaign_id维度，先通过原前置门禁，确实进入registered owner的read_wait。
3. writer实际修改Manifest，给另一可读来源other_funds新增同名campaign_id列，持久files_saved后结束阶段。
4. 对同一原问题，真实fresh目录已明确给出ambiguous_field；TTL目录仍allow；旧HTTP却返回成功/isError缺失。只取该实际行为为产品红。

初次测试语法错误与wildcard夹具被更早SAG拒绝分别保存在fixture日志，不冒充缓存产品红。最终采用明确可读的两表，避免“根本没进入等待”的无效反例。

## 最小修复

仅改 `webui/server/proxy/mcp-proxy.ts` 的post-wait revalidation：使用既有导出loadAmbiguityCatalogFromDir，针对当前loadContentPaths与projectRoot得出的semanticLayer直接加载。原普通请求继续loadPublishedAmbiguityCatalog；**不重置/失效共享TTL、不改query-guardrails.ts或新增API**。仅额外一个既有函数import和当前路径fresh load。

WAL/owner/20秒资格、原ticket120/elapsed/settled预算、单次consume、参数重写、barrier/TERM/cancel的统一优先出口、capture-before-end检查原样保留。其余三runtime与新typed边界测试、A的phase测试hash不变。

## 绿与回归

`postwait-catalog-cache-green.log`：原反例1/1通过；HTTP返回ambiguous_field，业务调用0、原预算calls/attempts1、有效审计唯一行。测试同时断言共享TTL仍是旧funds缓存，而实际fresh目录为funds+other_funds，证实修复仅绕过post-wait这一次缓存。

cwd为隔离worktree/webui，实际命令：

```sh
npx vitest run --maxWorkers=1 server/__tests__/semantic-read-write-settle.test.ts server/__tests__/semantic-batch-recovery.test.ts server/__tests__/semantic-batch-journal-lifecycle.test.ts server/__tests__/mcp-proxy-execution-stale.test.ts server/__tests__/mcp-reload-inflight.test.ts server/__tests__/question-budget-settlement.test.ts server/__tests__/question-budget-window-mode.test.ts server/__tests__/query-guardrails.test.ts
npm run typecheck
```

`directed-frozen-r3.log`：8文件 **95/95 PASS**，7.16秒；`typecheck-frozen-r3.log`：exit0。真实HTTP仅已授权随机回环／合成项目，没有Docker或外部SQL。原取消/TERM/deadline/预算及双gate回归均保留；HTTP文件原15例增加实际changed-Manifest缓存例为16。query-guardrails原13例全保留。

精确argv/hash/原红绿在 `implementation-manifest-r3.json`；相对旧r2差异 `implementation-cache-r2-r3.diff`；旧r2源码在 `implementation-r2-source-snapshot/` 原样归档。

冻结proxy SHA256：`281b430efaeb7e518b4e1ac5c82add323baf59de9c170505e3620812cbe2c353`。新HTTP test SHA256：`b292d8863ca7d15d854694f2d4025b5354121444685508767e91117cd57c2486`。

当前无测试/监听/子进程在途，CPU窗口归M。等待A具名finding关闭、M相关整合/最终CodeCLI和新镜像，SC真实Docker与30分钟组合仍待M调度；原r5 cal已经跑过120秒自然窗的事实不能改成“未自然开始”。
