# P1-70 功能合同出口与现有证据

本表为只读复核，不是状态变更或预签收口。现行状态以正式 Spec 头部为准。源仍为 r6 AE0 镜像，proxy `281b430e…`；本次仅读小摘要/治理正文，未运行测试/Docker/SQL，未改 Spec、共享镜像或运行源码。B五项已实际齐备，均SCOPED PASS WITH GAP且全清理：**7normal、7deadline、8revoke、10failure、11term**。当前为 **provisional实际证据齐，A独立SQL/预算/审计待核**，不把producer摘要当非作者独立验收。

## 出口层级

依据正式 [Spec](../../../../.worktrees/core-availability-followup-20261120/docs/specs/lucy-20261120-semantic-read-write-settle-spec.md)「闭口层级」：本条是**功能合同**；出口为 **SC-01–07 所需局部真实目录/HTTP/MCP、真实写阶段、deadline、权限/TERM及同身份补偿证据**。SC-08独立登记新候选组合依赖及真实结果；不把整套发布旅程纳入本功能合同。

全系统 Agent 旅程、任意发布入口全覆盖、多副本、客户拓扑、全部故障演练、整库 R-CAV、可上线均不在本条出口。不应为了 P170 收口新增这些验收义务；同样不能用组合长跑或 P169 directCLI 通过替代本条具体 SC。**本条收口不表示整套 UAT PASS 或可上线。**

## 已有证据层与适用范围

- **E1 定向95/95 + typecheck0**：`implementation-manifest-r3.json`、`directed-frozen-r3.log`、`typecheck-frozen-r3.log`。8文件，含真实临时目录/WAL、受控 deferred/时钟、真实回环HTTP/SQLite及上游组件。95 是对应集合总数，不是95个P170新用例，不是真实KTX/MySQL。
- **E2 整合360/360、28文件**：`../07-checks/integrated-p170-r3-invocation.json` 与 `vitest-integrated-p170-r3.log`；前后源hash一致。涵盖 E1 及原预算、发布协调、故障恢复、授权流、process-drain、query guard、P169和catalog-assets原路线。不是额外360个独立场景，不能与95相加作覆盖分母。
- **E3 SC04真实文件阶段8/8**：`sc04-tests/red.log` 原7FAIL/1PASS、`green-attempt-1.log` 原8项全绿；测试hash `aa0f72bc…` 未减断言。实际上传函数/目录/镜像/WAL与故障注入，非仅测试替身宣布 phase 成功。完整文件又纳入 E2。
- **E4 代码审查**：独立stage/proxy/cache具名审查、`../07-checks/final-cli-review-p170-r2-result.md` APPROVED、`G3-p170.json`。说明指定缺陷关闭和候选资格，不代签真实运行；旧 REQUESTCHANGES/红日志均保留。
- **E5 历史真实与本轮组合**：原r4 semantic错误FAIL保留；r6旧版normal实际checker FAIL与三工具阶段GAP保留。r6正式30min及其独立严格结果见下文SC08。P169 core10/25、directCLI-v4有自己的真实范围报告，不是P170真实写阶段替代品。
- **E6 P170五项实际（provisional）**：`docker-driver/r6-revision7/{normal,deadline}/summary.json`、`r6-revision8/revoke/summary.json`、`r6-revision10/failure/summary.json`、`r6-revision11/term/summary.json`。均真实AE0/Node22、原冻结四runtime/1883规模及原预算，cleanupComplete/allHostOperationsSettled=true；先前各FAIL不覆盖。summary里的`independentBudgetAudit`是driver内读库闭包字段名，不能代替A正在准备的standalone SQL verifier及非作者实际读DB结论。

## SC-01–07 必要不变量与实际出口差集

| SC | 必须保持的不变量 | 已有可用证据 | 本轮真实补齐项 / 独立待核 |
| --- | --- | --- | --- |
| **01** | 所有blocker均精确匹配同进程正常Manifest真实holder/project/journal/release；绑定先于WAL持久化。write/mirror未结束不发SQL；双gate均适用；醒来权威重查。query=4/100+SQL1；read_source=授权元数据+业务SQL0；explain=plan_only/executed:false+业务SQL0；原票据/各自有效审计一次。 | E1真实WAL `waits on a real live WAL…`、`binds the exact real holder before the WAL is visible…`；真实HTTP参数化三工具，单budget calls/attempts1、唯一有效audit；E4缓存反例prime→实际changedManifest→fresh目录拒绝ambiguous_field/业务0。 | **E6 7normal实际已补（独立audit待核）**：三工具串行各独立真实registered→wait→files_saved→end，真实KTX工具oracle、SQL1/0/0和原身份/预算/审计闭包。旧normal未命中阶段的FAIL/GAP保留，不回写。 |
| **02** | 固定入口20s包括前置耗时；只取原更紧ticket ABS120/elapsed MAX_WALL；settled不发明墙钟、最后合法call不误拒；不重复consume、不重置socket30 inactivity。reader截止不退/取消writer，无SQL，真实结束后同身份可显式恢复。 | E1 `uses the original ingress cutoff…`、`tightens the one original ticket…`、`exposes the original fixed ingress deadline…`、晚快照已过资格反例；原window/settlement回归；HTTP单票据。无budget只有等待阶段，不伪称原有端到端30秒。 | **E6 7deadline实际已补（独立audit待核）**：固定20s有效截止、writerStillHeldAtReadTerminal、原query无执行，真实writer后来结清并同身份显式恢复。按原票据计费，未套P169零预算。ABS/elapsed/settled/最后call仍为具名确定性组件证据，无需伪称Docker逐项注入。 |
| **03** | 孤儿/旧无绑定/PID仅存活/未知/损坏/不可读/recovery_required及mirror/mark失败继续关闭；实际故障修复后纯MCP原身份可用，无Lucy重启前置。 | E1 orphan新例与原semantic-batch-recovery/D3断言；真实HTTP首次WAL已登记后持久化失败→failed/guard关闭，无正式写；E3 mirror/digest/mark失败。不因正常等待删除guard或豁免semantic错误。 | **E6 10failure实际已补（独立audit待核）**：真实mirror失败/guard拒绝、实际owner结清、既有受控恢复函数、原Node身份保持及原Token/session/问题成交；未删WAL/清latch。7deadline亦有故障结清补偿。其余具名故障已有真实目录组件，不要求文件系统故障Docker全集。 |
| **04** | 真实目标+必要mirror字节/digest及files_saved持久成功后才结束写阶段；files_saved/open非confirmed。mark失败/返回空不默许；后续reload/append/terminal失败保持已保存真值，startup恢复不错误回滚。 | E3：deferred静态reload/历史append期间已files_saved/open；mirror failed1、failed0但真实bytes错、mark失败关闭；后续reload/append/closeContentBatch失败保留open/files_saved/unconfirmed，真实recoverPendingRecoveryJournals不误回滚。E2保留原catalog31路由及8项新例。 | **E6 7normal/10failure实际已补（独立audit待核）**：正常真实目标/mirror预期digest/files_saved与故障原保存真值/恢复分列；不把FIFO→EINVAL称files_saved成功。八个真实文件负例是有效组件层，不新增逐项Docker重演出口。 |
| **05** | 等待/醒来/发送/响应均以当前授权和配置为准；吊销优先；当前ACL/行约束/source-map/配置纯重裁决；不重复谓词改写/consume、不靠旧目录TTL或旧barrier。合法身份仍可成交，已吊销身份仍拒绝。 | E1真实HTTP等待中narrowAuthorization→canonical403/业务0；changedManifest fresh catalog拒绝旧缓存允许的输入；重核验/lateTERM各await出口反例。E2保留admin revoke、access writer/流发送屏障及query-guard原断言。三工具正常合法输入单票据成交。 | **E6 8revoke实际已补（独立audit待核）**：真实路由revoke200、原RPC精确403/-32003 authorization_revoked、匹配owner/RPC的end(cancelled)、无原SQL；真实修复后旧Token仍拒绝、合法b成交。事件标签裁定见revoke-event-contract-assessment.md，不是cancelled通用豁免。无全部授权变更组合的新增出口。 |
| **06** | 等写阶段而非整个publish，避免publish→reload自等；真实MCP/response gate全部settle才退票；正常body close不误取消；已断/TERM/原budget截止不得迟到SQL；TERM不重开且原20/40/45、reload20/60不扩大。 | E1 `wakes at actual files-saved while the publish owner is still pending…`；正常body close/socket timeout区分；真实HTTP disconnect/已知server close后deferred resolver/lateTERM→SQL0、TERM503；真实工作票据/response gate回归在E2，原预算/生命周期不改。 | **E6 11term实际已补（独立audit待核）**：真实wait→TERM/end(term)→canonical503、writer结清、exit143/1.377s/无OOM；仅撤已证夹具备份且WAL不变后原app同volume/Token启动恢复。7normal/deadline支持无自等与reader不假退writer。旧8/10 TERM FAIL保留；不将其未验部分回写PASS，不要求P169全部阶段重测成P170出口。 |
| **07** | 发布WAL前绑定；绑定失败无WAL、首次持久失败真settle；固定原owner集合，不追后继WAL、不串root/release/target，不因迟到/timeout释放他人；scope/round/window失配关闭；无未处理rejection/监听泄漏。 | E1同步绑定失败无WAL、首次持久化失败、错root/release/target、后继WAL重读、owner已结束/旧快照与晚截止race、window变化；reader取消不终结writer、终态登记清理。E2协调/原恢复回归；E4独立逐链审查。 | **E6五项实际已齐（独立audit待核）**：原holder/journal/release/RPC真实关联、正常与失败终态和同身份补偿；不能仅以endOutcome推业务成功。后继owner/跨window等确定性反例仍归已有组件，不增无穷竞争组合。 |

SC05表中的保留回归不等于已逐一运行所有行约束/source-map/config变更组合；若最终评审指出某个原SC必要输入确未被现有组件/HTTP证明，应具名补该反例。不能以笼统“所有矩阵”无期限扩充出口，也不能用B一次revoke冒充全部配置分支。

## B 五项已实际齐备：独立审计核对项

当前采用E6五个精确revision/out，不把后续revision的通过追签前次FAIL。normal为**三个工具串行独立正常写阶段**：query/read_source/explain各一次原RPC、独立真实lease/owner/WAL/files_saved/wait及general_log delta1/0/0；不是旧单次自然写碰巧错过阶段的normal。实际hash/argv在各source-freeze和actual-invocation中；A的standalone verifier与独立读库尚待完成，不能沿用producer自述作独立结论。

| 已实际项（均SCOPED PASS WITH GAP） | 独立复核应锁定的核心证据 | 必须拒绝的替代说法 |
| --- | --- | --- |
| 7normalserial | SC01三工具及SC04/07真实正常阶段；每工具独立稳定原身份，regular-file真实写/mirror正常完成，精确事件闭包、WAL/files_saved、实际SQL1/0/0和预算/有效审计。 | regular-lease仅控制正常慢写重叠，不是自然性能数据；不以一个query代另外两工具，不以最终成功代实际wait。 |
| 7deadline | SC02及SC06/07：固定入口20秒到期、writer仍真实持有/未settle、不启动原SQL、后来真实终态与同身份补偿。 | FIFO是真pending→失败分支，不是正常写成功；读者到期不代表writer完成，也不退还伪造预算。 |
| 8revoke | SC05：真实等待中持久吊销/当前拒绝，无原问题执行；旧身份仍拒绝，未受影响合法身份可恢复。 | 新发Token不是被吊销身份恢复；普通semantic错误或任意cancelled不是授权拒绝证明。 |
| 11term | SC06：真实等待中TERM、canonical终态、无迟到SQL/重开、实际writer与进程终态、原卷补偿。辅助restore严格限已证原backup/自有注入且WAL不变。 | transport失证不能猜canonical503；TERM场景的按原卷重启不能拿来代SC03不重启修复。 |
| 10failure | SC03/04/07：真实mirror故障→原guard拒绝→真实owner结清→既有受控修复→同Node原身份成交；保存/未确认事实不伪造。 | 不删WAL/改预算/清process latch，不用另Node的私有Map证明app绑定，不拿恢复函数返回值冒充完整发布审计。 |

当前五项真实原路径闭包及合法补偿已具备producer原始输出，**剩余是A的非作者SQL/预算/有效审计独立核验及M/A逐SC裁定**，不是五项还未运行。各summary所列budget模式/更紧截止/config代次/后继owner等已有具名组件/HTTP证据，不自动成为新的Docker必跑分母；完整发布审计/整套UAT/上线在本条出口外。若独立复核发现缺失或假阳性，必须具名对应SC并保留FAIL/GAP，不因producer五项通过就预签。

## SC-08 独立组合结果：保留 strict FAIL

r6同候选已实际完成1800秒/150秒周期/12轮，源与镜像身份不变。记录来源：`../08-soak/r6-1800/`、`../09-review/r6-1800-independent.json`，现有独立结论 **integrityVerdict=VALID、strictAcceptanceVerdict=FAIL**。M/B已确认主MCP328成功+32精确owner绑定拒绝及各同身份恢复/预算/审计有效；严格失败为audit-progress一次deadline及两次missed，必须保留。生产者摘要的PASS WITH GAP不能覆盖独立strict FAIL，也不能把该错误豁免成预期reload。

因此：正式30分钟测试台不能写UAT PASS。SC08的义务包含按原门槛完整执行、保存分母/非503失败/原始记录并**登记真实结果**；当前可以登记“已执行、严格FAIL及具体差集”，不能写“组合验收通过”。依据本Spec「闭口层级」，它不自动将范围外全系统发布旅程变成SC01–07新增出口；五项也不能凭组合已跑过跳过独立核验。P170功能合同能否在独立局部SC证据齐全后收口，须由M/A按该层级和已记录SC08结果明确裁定，本表不代裁。

## CI 条件：原文、接入事实与可用措辞

规则正文仍只有DEVELOPMENT，不从其它案例另建治理口径：

- `docs/governance/DEVELOPMENT.md:131`：功能合同使用能证伪本条承诺的检查，真实进程不变量/局部故障注入仍属于本合同；同时原文明确“**证据等级（本机 / CI / 客户环境）归发布取证**”。`:133`又规定发布失败只打回被证伪的那条功能合同，不把整批模块重新打开。
- 同文`:137–147`标题为“证据等级门槛：本机＋CI即可”，正文为“功能合同收口的验收证据以**本机自动化**（单元／组件／接口测试、真实进程内自动化）与 **CI job** 两级为准”；又要求“**证据等级要逐条标注，不得把不同等级混写**”。这里列了两级来源，未写“每条功能必须同次远端CI job已绿”或“没push不得本机功能收口”。结合前项把等级归发布取证的明确边界，本复核的解释是：可凭实际本机证据裁定功能合同，必须如实保留未执行CI这一证据等级限制，不能伪写CI通过。
- `docs/governance/test-layers-and-release-gates.md:290–298`的CI表头为“**Recommended CI jobs**”；`spec-and-unit`推荐命令含`cd webui && npm test`，真实Docker soak/diagnostic则明确人工、当前无CI job。它没有要求P170另开专用job或把全部Docker矩阵搬进PR CI。DEVELOPMENT:328的硬要求是新增命令/CI job在测试门禁文档登记，不能反推本次必须新增job。
- 现有实际接入链：`.github/workflows/lucy-ci.yml:46–83`的`spec-and-webui`运行`webui/npm test`；`webui/package.json:12`为`vitest run --maxWorkers=1`；`webui/vitest.config.ts` include `server/**/*.test.ts`。P170新`semantic-read-write-settle.test.ts`和修改的HTTP/catalog测试均匹配默认选择器，没有只存在本机命令、被CI选择器排除的新增产品测试。CI文档推荐名与实际job名不同，本表以真实workflow为准，不把它说成新专用job。
- 该workflow虽有PR/push/workflow_dispatch入口，**本轮没有远程CI运行记录**，也没有commit/push授权。本表不触发、不申请额外权限、不更改workflow；“已接入现有CI默认选择器”只证明未来会被选中，绝不等于“CI PASS”。本机集成Node24.13.1与真实Docker Node22.23.5分别标注，不冒充Ubuntu CI Node22全套已跑。

**当前建议准确状态（待M/A裁定，不直接更新Spec）：**

> 实现、95项定向/360项整合及终审通过；P170五项真实Docker局部证据已齐且全清，独立SQL/预算/有效审计复核待完成，暂不主张功能合同收口。测试已接入既有CI默认选择器，远程CI未执行。SC08正式30分钟严格FAIL独立保留；不入核心分母；≠整套UAT PASS；≠可上线。

**若A非作者独立核验五项全部有效、M/A确认SC01–07各必要不变量无剩余缺口，建议可采用：**

> P170功能合同收口；证据等级为本机自动化、真实HTTP/文件与同候选真实Docker局部验收。已接入现有CI默认选择器，远程CI未执行；SC08正式30分钟严格FAIL及其差集独立登记，不改写为UAT PASS；不入核心分母；本条收口不表示整套UAT PASS或可上线。

这是依据正式出口层级的建议，**不是提前宣布独立审计通过或已经收口**。若独立验证证伪某一SC，先具体修该承诺/证据，不用泛化发布旅程新增出口。远程CI没跑本身不应被发明为“必须先commit/push再来审批”的额外功能前置，但后续合入/发布仍应按其实际授权和CI/发布门禁取证，不能跳过或宣称已完成。

## 后续裁定只需要核这些差集

1. A独立读取五项原DB/原始SQL/请求/身份关联并运行自己的standalone verifier，核原ticket结算/有效审计/实际SQL及清理闭包；producer五项已跑不等于该独立步骤已通过。
2. 对出现的具体FAIL判断产品/夹具并保留原跑次；若新增必要反例，指明SC及缺失不变量，不以范围外任意入口/交付矩阵延伸合同。
3. M/A分别决定P170功能合同出口、SC08严格组合结果、整套UAT与上线状态；维持原r4/r5及各夹具FAIL历史。此文件仅工程过程材料，不更新现值镜像。
