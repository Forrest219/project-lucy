# P1-70 non-author implementation review r2

**APPROVED for integration; CR-70-A-01, CR-70-A-02 and CR-70-A-03 CLOSED.** No remaining P1/P2 found in the reviewed corrective seams. The original REQUEST CHANGES report and red evidence remain unchanged.

Reviewed proxy SHA256 `4fddc08f8a97b58b6e1676ad68267086293b321bf0a86b560f814ca7a18e8202` matches `implementation-manifest-r2.json`. Coordinator `c81c2f4d…`, recovery journal `a5863c17…`, catalog upload `65d323fa…` are byte-identical to the prior three-file review. All four exact hashes/matches are in `independent-proxy-review-r2-identity.json`. Reviewer wrote none of these product files. This was read-only: no test process, listener, Docker or new load was started.

## Finding closure

| Finding | Corrected implementation and reviewed evidence | Verdict |
| --- | --- | --- |
| CR-70-A-01: owner completed before snapshot matching bypasses the fixed wait deadline | The observed-block/no-stage fallback now invokes the same interruption check both before and after the awaited authoritative WAL reread. Deadline is the original effective context deadline; matching-stage behavior remains intact. The new deterministic real-WAL snapshot case advances mono beyond the fixed deadline after actual owner completion; the preserved red shows null instead of the required semantic denial, and the r2 directed suite includes the corrected case. | CLOSED |
| CR-70-A-02: TERM during async revalidation becomes semantic HTTP200 | The wrapper's common priority check runs after guard resolution, after awaited revalidation (covering its early-return outcomes), and in its catch (covering late throws). Current authorization barrier precedes lifecycle, preserving canonical revocation handling; lifecycle produces SERVICE_DRAINING for either gate to emit HTTP503. The actual HTTP case defers the second real aclCheck, enters drain, then releases it. Preserved red is 200 versus503. | CLOSED |
| CR-70-A-03: budget-off known client close after wait still dispatches SQL | Upstream capture now synchronously reads the actual ingress abort signal, lifecycle and original budget deadline/currentness, independently of the budget settlement disconnect callback. The forwarder registers real upstream work and invokes capture before end(body); destroying there prevents the business RPC bytes being sent while preserving actual close-based retirement. The HTTP test turns budget off, defers the actual non-Hive route/config result, aborts the client, waits for actual server response.close, then releases the route. Preserved red counts one actual business call; r2 requires zero and the original MCP work retires. | CLOSED |

## Adjacent boundaries checked

The same capture seam also handles late TERM. Its actual error now retains canonical503 for a request that entered this wait path, instead of passing through the generic upstream HTTP200 error. The additional real HTTP term-before-dispatch red/green is appropriate evidence. This does not claim an already-started business call never executed: audit still reports the actual upstream error, without inventing notExecuted.

The new `budgetDeadlineMonoMs` is kept separate from `waitDeadlineMonoMs`: it derives only from the original ticket start+ABS120s and (elapsed mode only) original state.startedAt+MAX_WALL, converted using the original clocks; only min/tightening is used. Dispatch capture checks this original budget deadline/current ticket, never the 20-second wait qualification. Thus a no-block request does not become an overall20-second RPC, and an eligible wait that completed normally does not acquire a new execution-wide20-second limit. Budget-off dispatch remains allowed when the actual client is live and lifecycle serving; there is no invented budget deadline. No timer, consume, identity, session, question or existing upstream timeout is restarted.

The three earlier reviewed writer files remain unchanged, so pre-WAL binding, first-WAL failure actual failed-settle, real mirror/digest/persisted phase order and saved/open recovery truth retain the prior conclusion. The proxy still uses both shared gates, current original-barrier checks and original-input/current-ACL rebuilding without duplicate forced predicates; no recursive handler, second budget consume or fresh process work ticket is introduced. Writer handles alone settle their stage, and original ALS work still owns real response commit/upstream close. Reader cancellation does not retire or rewrite the Manifest writer.

## Evidence limits

Read source/tests/diffs and preserved true assertion-failure logs: snapshot late deadline, revalidation lateTERM, known server-close before dispatch, and capture lateTERM response. Read author `directed-frozen-r2.log` (7files81/81) and typecheck exit0; these were not rerun by this reviewer. The true server-close witness removes timing ambiguity from the cancellation test. Earlier test API scope/identity and the original SC04 bytes remain unchanged.

This approval closes the specific code-review findings. It does not sign Docker F70, full integration, the new same-candidate short calibration, the30-minute/12-cycle combination, or release/UAT. Those remain M-owned acceptance work.
