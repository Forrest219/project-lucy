import { createHash, randomUUID } from "node:crypto";
import { readFile, stat } from "node:fs/promises";
import { createServer, request as httpRequest, type ClientRequest, type IncomingMessage, type ServerResponse } from "node:http";
import { admitMcpProcessWork, mcpReloadAdmissionError, trackMcpResponseCommit, trackMcpUpstreamWork } from "../runtime/mcp-process-work.js";
import { getProcessLifecyclePhase, SERVICE_DRAINING, SERVICE_DRAINING_MESSAGE } from "../runtime/process-drain.js";
import path from "node:path";
import { identifyRequestDetailed, setSessionClient, type Identity } from "./identity.js";
import { admitMcpRequest, MCP_UPSTREAM_PATH, type AdmissionAudit, type AdmittedRequest } from "./admission.js";
import {
  AuthorizationRevokedError,
  beginGuardedRequest,
  currentAuthorizationSequence,
  currentBarrierHandle,
  runWithBarrier
} from "./authorization-barrier.js";
import { assertSkillsPassthroughPolicy, skillsPassthroughRequested } from "../auth/deployment-mode.js";
import { ReleaseLedger, type ReleaseOperationContext } from "../security/ledger.js";
import { beginGatedResponse, type ResponseCommitConfig } from "../security/response-commit.js";
import { getSecurityStore } from "../security/instance.js";
import {
  allocateIngressIdentity,
  appendIngressReceived,
  buildCorrelationHeaders,
  runStartupRecoveryScan
} from "./ingress-registry.js";
import {
  clearUpstreamSession,
  getUpstreamSession,
  ownsUpstreamSession,
  setUpstreamSession,
  upstreamSessionKeepaliveEnabled,
  upstreamSessionOwner
} from "./upstream-session.js";
import { extractRequestClientMeta, resolveClientIdentity, resolveClientIpEvidence } from "./request-client-meta.js";
import { ensureSkillAuditReady, writeLog, writeAccessLogSources, writeConversationTurn, purgeExpiredConversationTurns, bindPriorSessionCalls, loadBudgetState, saveBudgetState, listBudgetScopes, type AccessLogSourceRecord } from "./audit.js";
import { setLedgerSeqResolver } from "./audit-reconcile.js";
import { absoluteDenyOrUnclassifiedReason, allowedToolNames, authorizeAndRewrite, check as aclCheck, effectivePermissions, getPolicyRuntimeStatus, extractTables, extractSourceRefs, formatIdentityCompilerReason, resolveSourceRefsForTables, kxCatalog, lucyCatalog, permissionSnapshot, type SourceRef } from "./acl.js";
import {
  redactQuestionText,
  summarizeArgsForAudit,
  summarizeFilters,
  extractQueryTables,
  questionPreviewMaxChars,
  storeQuestionPreviewEnabled,
  buildQueryPreview,
  QUERY_PREVIEW_MAX_CODEPOINTS
} from "./audit-privacy.js";
import { PREVIEW_VERSION_V2P5, executionEvidenceFromObservation } from "./audit-classification.js";
import { buildAccessLogAuditMeta } from "./audit-meta.js";
import { canAccessWikiKey, canonicalWikiKey, searchAccessibleWikiPages } from "./wiki-acl.js";
import { CONTEXT_NOT_AVAILABLE, CONTEXT_ROLE_REQUIRED } from "./context-acl.js";
import { loadAllSkillsFresh, getSkillByUri, getSkillByName } from "../skills/loader.js";
import type { SkillAsset } from "../skills/types.js";
import { canAccessSkill, filterAccessibleSkills, type SkillAclDecision, type SkillAclAction } from "./skill-acl.js";
import { readProject, resolveProjectRoot } from "../project.js";
import { semanticReadHintsFromArgs, semanticRecoveryReadBlock } from "../semantic-recovery-journal.js";
// L25-16 — 控制面工具由代理**本地**服务，绝不转发给 KTX。
// 工具名单与描述来自 `ops/control-plane.ts`（单一事实源）。
import { isControlPlaneTool } from "../ops/control-plane.js";
import { invokeOpsTool, opsToolDescriptors } from "../ops/ops-tools.js";
import { listSources } from "../semantic-layer.js";
import { loadContentPaths } from "../paths.js";
import {
  firstConnectionIdFromArgs,
  resolveAndMaybeServeHiveTool
} from "../hive/proxy-hook.js";
import type { HiveExecutionTool } from "../hive/execution.js";
import {
  requestWouldHitUpstreamSemanticExecution,
  trackUpstreamSemanticEnter,
  trackUpstreamSemanticLeave
} from "./field-exposure.js";
import {
  isOpsEvidenceGovernanceSource,
  OPS_EVIDENCE_CONNECTION_ID,
  OPS_EVIDENCE_GOVERNANCE_UNREADY
} from "../ops-evidence/contract.js";
import {
  applyStrippedGovFilters,
  isGovFilterError,
  parseAndStripGovFilters
} from "../ops-evidence/gov-filters.js";
import {
  bindGovernanceMaterialization,
  digestGovFiltersForKey,
  GovernanceSnapshotUnreadyError,
  injectSnapshotIdFilter,
  rebuildGovernanceSnapshotAtomic,
  releaseGovernanceMaterializationBind
} from "../ops-evidence/governance-snapshot.js";
import { readAccessYamlVersion } from "../admin/access-config.js";
import { readKtxYamlDigest, recordExecutionRuntimeObservation } from "../mcp-runtime-state.js";
import {
  recordMcpToolsCall,
  purgeTraceEvidence,
  TRACE_RETENTION_DAYS,
  type PolicyDecisionMetadata,
  type LucySpanStatus
} from "../trace/evidence.js";
import { getAuditDb as getAdminAuditDb } from "../admin/audit.js";
import { extractSqlFromToolResult, mergeIncludeSql } from "../audit/query-artifact-capture.js";
import { canonicalizeLucyQueryArgs } from "./lucy-query-normalization.js";
import { recallObservedToolNames, rememberObservedToolNames } from "./observed-tool-names.js";
import { REPEAT_REJECTION_HINT, computeRejectionFingerprint, repeatRejections } from "./rejection-guard.js";
import { applyLucyQueryForcedFilters, buildExplainForcedPredicateDiagnostics, isScopeIntersectionEmpty } from "./row-policy.js";
import { TurnCorrelationRegistry } from "./turn-correlation.js";
import { beginAuditWrite, completeAuditWrite, failAuditWrite } from "./audit-write-health.js";
import { TraceRequestContext, currentTrace, currentTraceContext, runWithTrace } from "./audit-trace-context.js";
import { TraceRecorder, completeTrace, mapReasonCode, type SpanHandle, type TraceStage } from "./audit-trace-span.js";
import {
  buildEmptyResultNextStep,
  classifyFailure,
  denialAllowList,
  filterPushdownGuardEnabled,
  isEmptyResult,
  isFilterPushdownText,
  isQuestionDataTool,
  isSlowCall,
  lookupPublishedVersion,
  publishedSourceName,
  questionBudget,
  questionBudgetEnabled,
  questionBudgetScopeMode,
  questionBudgetBypassEnabled,
  budgetIdentityKey,
  budgetScopeKey,
  QUESTION_BUDGET_ABS_EXEC_MS,
  QUESTION_BUDGET_MAX_BUSY_MS,
  QUESTION_BUDGET_MAX_CALLS,
  installBudgetPersistence,
  type BudgetPersistence,
  type NextStep,
  registerPublishedVersion,
  repairHint,
  buildRepairClosure,
  evaluateRepairTarget,
  resolveAppliedVersion,
  resolveResponseTruncated,
  TRUNCATION_REPAIR_HINT,
  type RepairTargetEvidence,
  isBudgetUnavailable,
  type BudgetSnapshot,
} from "./question-experience.js";
import { bindQuestionBudgetSettlement } from "./question-budget-lifecycle.js";
import { applyLucyCallGuard, countWithoutSourceBeforeAcl, loadPublishedAmbiguityCatalog, queryGuardrailsEnabled } from "./query-guardrails.js";
import {
  lookupReportTemplate,
  resolveCertifiedRoute,
} from "./certified-route.js";
// P0-1 问题类型口径绑定（Spec v0.9 D3–D12／O1／O2）。
import {
  bindingScopeKey,
  checkCaliberBindingGate,
  prepareCaliberBindingActivation,
  withCaliberBindingRegistryExclusion,
  withCaliberBindingScopeLock,
  type CaliberBindingDenial,
} from "./caliber-binding.js";
import {
  beginBindingSessionPreparation,
  commitBindingSession,
  readBindingSession,
  restorePriorBindingSession,
} from "./caliber-binding-session.js";
import {
  classifyCaliberParticipation,
  currentCaliberBindingRegistry,
  registrySyncPending,
  verifyCurrentBindingContentAndDependencies,
} from "./caliber-binding-registry.js";
// P0-4 答复可核对块（REQ-030-022／Spec v0.4-draft）。
import {
  ANSWER_VERIFIABILITY_INSTRUCTION_LINES,
  applyAnswerVerifiabilityToLucyQuery,
  buildAnswerVerifiabilityErrorEnvelope,
  extractLucy018PreserveFields,
  captureRequestPinnedCaliberEvidence,
  deepCopyJson,
  extractSseJsonRpcResponseRaw,
  systemConstraintsFromForcedFilters,
  type RequestPinnedCaliberEvidence,
} from "./answer-verifiability.js";
// P0-3 表级歧义门闩（REQ-030-024／Spec v0.5）。
import {
  ASK_FIRST_SECTION,
  ambiguityScopeKey,
  attestSourceConfirmation,
  buildMatchableSourcesForGate,
  checkSourceAmbiguityGate,
  admitHostConfirmRequest,
  LUCY_HOST_ATTESTATION_HEADER,
  repairEvidenceIdentityKey,
  sourceAmbiguityGateAppliesToTool,
  upsertJourneyOnBegin,
  type GateSchemaProbe,
  type SourceAmbiguityDenial,
  type SourceIdentity,
} from "./source-ambiguity-gate.js";
import { SOURCE_COUNT_CAP, toSelectionDisclosure, type SourceSelectionDisclosure } from "./source-selection-tolerance.js";

export { registerPublishedVersion };
export {
  admitHostConfirmRequest,
  attestSourceConfirmation,
  hostConfirmCallerAllowed,
  LUCY_HOST_ATTESTATION_HEADER
} from "./source-ambiguity-gate.js";

/** 宿主 attested 确认提交（非 tools/call；§4.4 层 B／sourceChannel=host_confirm_api）。 */
export const SOURCE_AMBIGUITY_CONFIRM_PATH = "/mcp/host/source-ambiguity/confirm";

const KTX_HOST = process.env.LUCY_PROXY_UPSTREAM_HOST ?? "127.0.0.1";
const KTX_PORT = Number(process.env.LUCY_PROXY_UPSTREAM_PORT ?? 7878);
// V5 multi-upstream: lucy-skills is a parallel MCP server (skills catalog + SKILL.md content).
// Routed under `/mcp/skills` to keep the existing `/mcp` KTX path unchanged.
const LUCY_SKILLS_HOST = process.env.LUCY_PROXY_LUCY_SKILLS_HOST ?? "127.0.0.1";
const LUCY_SKILLS_PORT = Number(process.env.LUCY_PROXY_LUCY_SKILLS_PORT ?? 7881);
// Spec 144: governed skills are served through the ACL-enforced interceptions on `/mcp`.
// The legacy lucy-skills upstream has no auth or per-skill ACL of its own, so the
// passthrough stays disabled unless explicitly enabled for local development
// (`LUCY_DEPLOYMENT_MODE=development`); customer mode refuses to start with it on.
const MAX_BODY_BYTES = Number(process.env.LUCY_PROXY_MAX_BODY_BYTES ?? 1_048_576);
const UPSTREAM_TIMEOUT_MS = Number(process.env.LUCY_PROXY_UPSTREAM_TIMEOUT_MS ?? 30_000);
const QUERY_KEY_RE = /^(?:sql|query)$/i;
const LUCY_QUERY_DEFAULT_LIMIT = Number(process.env.LUCY_QUERY_DEFAULT_LIMIT ?? 100);
const LUCY_QUERY_MAX_LIMIT = Number(process.env.LUCY_QUERY_MAX_LIMIT ?? 1000);
const LUCY_QUERY_MAX_INFLIGHT = Number(process.env.LUCY_QUERY_MAX_INFLIGHT ?? 4);
const UPSTREAM_PROTOCOL_VERSION = process.env.LUCY_PROXY_UPSTREAM_PROTOCOL_VERSION ?? "2024-11-05";
const UPSTREAM_HANDSHAKE_CLIENT_VERSION = "1.0";

function getInternalToken(): string {
  return process.env.KTX_INTERNAL_TOKEN ?? "";
}

const lucyQueryInflight = new Map<string, number>();

function reportedTurnWindowMs(): number {
  return Number(process.env.LUCY_REPORTED_TURN_ATTACH_WINDOW_MS ?? 600_000);
}

const reportedTurns = new TurnCorrelationRegistry(reportedTurnWindowMs);

function queryConcurrencyKey(identity: Identity): string {
  return `${identity.userId}:${identity.tokenHashPrefix}`;
}

function queryConcurrencyLimit(): number {
  if (!Number.isFinite(LUCY_QUERY_MAX_INFLIGHT)) return 4;
  return Math.max(1, Math.floor(LUCY_QUERY_MAX_INFLIGHT));
}

function acquireLucyQuerySlot(identity: Identity): { allowed: true; release: () => void; active: number; max: number } | { allowed: false; active: number; max: number } {
  const key = queryConcurrencyKey(identity);
  const active = lucyQueryInflight.get(key) ?? 0;
  const max = queryConcurrencyLimit();
  if (active >= max) return { allowed: false, active, max };
  lucyQueryInflight.set(key, active + 1);
  let released = false;
  return {
    allowed: true,
    active: active + 1,
    max,
    release: () => {
      if (released) return;
      released = true;
      const current = lucyQueryInflight.get(key) ?? 0;
      if (current <= 1) lucyQueryInflight.delete(key);
      else lucyQueryInflight.set(key, current - 1);
    }
  };
}

function releaseOnResponseEnd(res: ServerResponse, release: () => void): void {
  let released = false;
  const once = () => {
    if (released) return;
    released = true;
    release();
  };
  res.once("finish", once);
  res.once("close", once);
}

class BodyTooLargeError extends Error {
  statusCode = 413;
  constructor() {
    super("Request body too large");
  }
}

function readBody(req: IncomingMessage): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    let total = 0;
    let rejected = false;
    req.on("data", (chunk: Buffer) => {
      if (rejected) return;
      total += chunk.byteLength;
      if (total > MAX_BODY_BYTES) {
        rejected = true;
        reject(new BodyTooLargeError());
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => {
      if (!rejected) resolve(Buffer.concat(chunks));
    });
    req.on("error", reject);
  });
}

/** P1-36：在当前请求的 trace 上登记一个上游阶段 span；无请求上下文（后台、passthrough）时原样执行。 */
async function withUpstreamSpan<T extends IncomingMessage | string | undefined>(
  stage: TraceStage,
  run: () => Promise<T>,
  options: { parent?: SpanHandle; attrs?: Record<string, unknown> } = {}
): Promise<T> {
  const trace = currentTrace();
  if (!trace) return run();
  const span = trace.start(stage, options.parent);
  try {
    const result = await run();
    const statusCode = typeof result === "object" && result !== null ? result.statusCode : undefined;
    span.end({
      status: "ok",
      reasonCode: "allowed",
      attrs: { ...options.attrs, ...(statusCode !== undefined ? { upstream_status: statusCode } : {}) }
    });
    return result;
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    const mapped = mapReasonCode({
      decisionReason: /timeout/i.test(message) ? "timeout" : "upstream_error",
      outcome: "error"
    });
    span.end({ status: "error", reasonCode: mapped.code, reasonParam: mapped.param, errorCategory: mapped.errorCategory, attrs: options.attrs });
    throw err;
  }
}

function forwardToKtx(
  method: string,
  url: string,
  incomingHeaders: IncomingMessage["headers"],
  body?: Buffer,
  sessionId?: string,
  onRequest?: (request: ClientRequest) => void
): Promise<IncomingMessage> {
  return forwardToUpstream({ host: KTX_HOST, port: KTX_PORT }, method, url, incomingHeaders, body, "KTX", sessionId, onRequest);
}

function forwardToUpstream(
  target: { host: string; port: number },
  method: string,
  url: string,
  incomingHeaders: IncomingMessage["headers"],
  body: Buffer | undefined,
  label: string,
  sessionId?: string,
  onRequest?: (request: ClientRequest) => void
): Promise<IncomingMessage> {
  return new Promise((resolve, reject) => {
    // T04-3: no upstream call is started for a request a narrowing already covers.
    const barrier = currentBarrierHandle();
    if (barrier && !barrier.isCurrent()) {
      reject(new AuthorizationRevokedError());
      return;
    }
    const headers: Record<string, string | string[]> = {};
    for (const [k, v] of Object.entries(incomingHeaders)) {
      if (v === undefined) continue;
      const lower = k.toLowerCase();
      if (!["content-type", "mcp-session-id", "mcp-protocol-version"].includes(lower)) continue;
      headers[k] = v;
    }
    // Only supply the gateway-held session when the client did not send one;
    // native clients that retain `Mcp-Session-Id` keep their own session.
    if (sessionId && !Object.keys(headers).some((key) => key.toLowerCase() === "mcp-session-id")) {
      headers["mcp-session-id"] = sessionId;
    }
    headers["accept"] = "application/json, text/event-stream";
    const internalToken = getInternalToken();
    if (internalToken) headers["authorization"] = `Bearer ${internalToken}`;
    if (body) headers["content-length"] = String(body.byteLength);

    const upstream = httpRequest(
      { hostname: target.host, port: target.port, path: url, method, headers },
      resolve
    );
    trackMcpUpstreamWork(upstream);
    // Spec 162 §6.2 / SC-13：把在途请求句柄交给调用方，客户端断开时可以取消上游。
    onRequest?.(upstream);
    upstream.setTimeout(UPSTREAM_TIMEOUT_MS, () => {
      upstream.destroy(new Error(`${label} upstream timeout after ${UPSTREAM_TIMEOUT_MS}ms`));
    });
    upstream.on("error", reject);
    barrier?.trackUpstream(upstream);
    if (body) upstream.end(body);
    else upstream.end();
  });
}

/**
 * T04-2 — the client's `Mcp-Session-Id` is only honoured when this (Agent,
 * Token) was issued it. Anything else is dropped before forwarding, so a
 * borrowed id cannot reach another caller's KTX session; the gateway then
 * supplies the caller's own default session instead.
 */
function headersWithOwnedSession(
  identity: Identity,
  headers: IncomingMessage["headers"]
): IncomingMessage["headers"] {
  const owner = upstreamSessionOwner(identity);
  if (ownsUpstreamSession(owner, normalizeHeader(headers["mcp-session-id"]))) return headers;
  const scoped: IncomingMessage["headers"] = { ...headers };
  for (const key of Object.keys(scoped)) {
    if (key.toLowerCase() === "mcp-session-id") delete scoped[key];
  }
  return scoped;
}

/** Session id to send upstream for a non-`initialize` request, or none. */
function resolveOutboundSession(identity: Identity, headers: IncomingMessage["headers"]): string | undefined {
  const owner = upstreamSessionOwner(identity);
  const clientSessionId = normalizeHeader(headers["mcp-session-id"]);
  if (ownsUpstreamSession(owner, clientSessionId)) return clientSessionId;
  return upstreamSessionKeepaliveEnabled() ? getUpstreamSession(owner) : undefined;
}

function readUpstreamBody(upstream: IncomingMessage): Promise<string> {
  return (async () => {
    const chunks: Buffer[] = [];
    for await (const chunk of upstream as AsyncIterable<Buffer>) {
      chunks.push(chunk);
    }
    return Buffer.concat(chunks).toString();
  })();
}

/**
 * Establish a KTX transport session on the gateway's own behalf.
 *
 * Sends a complete `initialize` (`protocolVersion`, `capabilities` and
 * `clientInfo` are all required — KTX rejects a partial one with the same
 * plain-text 400 as missing session traffic), then the `notifications/initialized`
 * the protocol requires before session traffic is accepted.
 */
/** P1-37 U3a：恢复握手的显式结果。任何异常都落成结果，不依赖异常路径。 */
export type RecoveryFailureCause =
  | "initialize_failed"
  | "no_session_id"
  | "invalid_initialize_response"
  | "initialized_failed"
  | "handshake_threw";
export type RecoveryResult = { ok: true; sessionId: string } | { ok: false; cause: RecoveryFailureCause };

async function handshakeUpstreamSession(identity: Identity, parent?: SpanHandle): Promise<RecoveryResult> {
  try {
    return await handshakeUpstreamSessionUnsafe(identity, parent);
  } catch {
    return { ok: false, cause: "handshake_threw" };
  }
}

async function handshakeUpstreamSessionUnsafe(identity: Identity, parent?: SpanHandle): Promise<RecoveryResult> {
  const handshakeHeaders = { "content-type": "application/json" } satisfies IncomingMessage["headers"];
  const initializeBody = Buffer.from(JSON.stringify({
    jsonrpc: "2.0",
    id: `lucy-upstream-session-${randomUUID()}`,
    method: "initialize",
    params: {
      protocolVersion: UPSTREAM_PROTOCOL_VERSION,
      capabilities: {},
      clientInfo: { name: "lucy-mcp-proxy", version: UPSTREAM_HANDSHAKE_CLIENT_VERSION }
    }
  }));

  const initializeResponse = await withUpstreamSpan("upstream_handshake", () => forwardToKtx("POST", "/mcp", handshakeHeaders, initializeBody), { parent });
  const initializeResponseBody = await readUpstreamBody(initializeResponse);
  const sessionId = normalizeHeader(initializeResponse.headers["mcp-session-id"]);
  if ((initializeResponse.statusCode ?? 200) >= 400) return { ok: false, cause: "initialize_failed" };
  if (!sessionId) return { ok: false, cause: "no_session_id" };
  if (!isJsonRpcShaped(decodeUpstreamPayload(
    initializeResponseBody,
    String(initializeResponse.headers["content-type"] ?? ""),
    ""
  ))) {
    return { ok: false, cause: "invalid_initialize_response" };
  }

  const initializedBody = Buffer.from(JSON.stringify({ jsonrpc: "2.0", method: "notifications/initialized" }));
  const initializedResponse = await withUpstreamSpan("upstream_handshake", () => forwardToKtx("POST", "/mcp", handshakeHeaders, initializedBody, sessionId), { parent });
  await readUpstreamBody(initializedResponse);
  // U3a：`notifications/initialized` 须被上游以 2xx 接受才算握手成功；否则不缓存新会话。
  const initializedStatus = initializedResponse.statusCode ?? 200;
  if (initializedStatus < 200 || initializedStatus >= 300) return { ok: false, cause: "initialized_failed" };

  setUpstreamSession(upstreamSessionOwner(identity), sessionId);
  return { ok: true, sessionId };
}

/**
 * What happened to the KTX transport session on this request.
 *
 * Carried into the audit row (so the rate of non-conformant clients is
 * measurable) and into `upstream_session_required` error payloads (so a stuck
 * client is told what to fix instead of being handed a bare status code).
 */
type UpstreamSessionState = {
  /** The client sent its own `Mcp-Session-Id`. */
  clientSupplied: boolean;
  /** The gateway filled in a held session because the client sent none. */
  gatewaySupplied: boolean;
  /** A recovery handshake ran after KTX refused the first attempt. */
  handshakeAttempted: boolean;
  /** The handshake produced a session and the single retry was accepted. */
  recovered: boolean;
  /** The handshake ran and the request was still refused. */
  recoveryFailed: boolean;
};

function emptyUpstreamSessionState(clientSupplied = false): UpstreamSessionState {
  return {
    clientSupplied,
    gatewaySupplied: false,
    handshakeAttempted: false,
    recovered: false,
    recoveryFailed: false
  };
}

type SessionAwareUpstream = {
  upstream: IncomingMessage;
  body: string;
  session: UpstreamSessionState;
};

/**
 * Forward a KTX-bound request with the gateway-held session, buffering the
 * response so a `upstream_session_required` refusal can be recovered by
 * re-handshaking and retrying exactly once.
 *
 * Only for buffered paths (`tools/list`, `tools/call`). Streaming passthrough
 * keeps using `forwardToKtx` directly.
 */
async function forwardToKtxWithSession(
  identity: Identity,
  method: string,
  url: string,
  incomingHeaders: IncomingMessage["headers"],
  body: Buffer | undefined,
  onRequest?: (request: ClientRequest) => void
): Promise<SessionAwareUpstream> {
  const keepalive = upstreamSessionKeepaliveEnabled();
  const clientSessionId = normalizeHeader(incomingHeaders["mcp-session-id"]);
  const session = emptyUpstreamSessionState(Boolean(clientSessionId));
  // Lazy on purpose: a client that completed `initialize` already has a cached
  // session, so the normal path costs no extra upstream round-trip. The
  // handshake only runs once KTX actually refuses the request.
  const sessionId = resolveOutboundSession(identity, incomingHeaders);
  session.gatewaySupplied = Boolean(sessionId) && sessionId !== clientSessionId;

  let upstream = await withUpstreamSpan("upstream_call", () => forwardToKtx(method, url, headersWithOwnedSession(identity, incomingHeaders), body, sessionId, onRequest));
  let upstreamBody = await readUpstreamBody(upstream);
  if (!keepalive) return { upstream, body: upstreamBody, session };

  const refused = isSessionRequiredFailure(
    upstream.statusCode,
    String(upstream.headers["content-type"] ?? ""),
    upstreamBody,
    ""
  );
  if (!refused) return { upstream, body: upstreamBody, session };

  if (sessionId) clearUpstreamSession(upstreamSessionOwner(identity), sessionId);
  session.handshakeAttempted = true;
  const recoverSpan = currentTrace()?.start("session_recover");
  const recovery = await handshakeUpstreamSession(identity, recoverSpan);
  if (!recovery.ok) {
    session.recoveryFailed = true;
    recoverSpan?.end({ status: "error", reasonCode: "session_lost", errorCategory: "upstream_failed", attrs: { recovered: false, reason: recovery.cause } });
    return { upstream, body: upstreamBody, session };
  }
  const freshSession = recovery.sessionId;
  recoverSpan?.end({ status: "ok", reasonCode: "upstream_session_recovered", attrs: { recovered: true } });

  // Retry once with the fresh session, dropping the stale client-supplied one.
  const retryHeaders: IncomingMessage["headers"] = { ...incomingHeaders };
  for (const key of Object.keys(retryHeaders)) {
    if (key.toLowerCase() === "mcp-session-id") delete retryHeaders[key];
  }
  upstream = await withUpstreamSpan("upstream_call", () => forwardToKtx(method, url, retryHeaders, body, freshSession, onRequest), { attrs: { retry_count: 1 } });
  upstreamBody = await readUpstreamBody(upstream);
  const stillRefused = isSessionRequiredFailure(
    upstream.statusCode,
    String(upstream.headers["content-type"] ?? ""),
    upstreamBody,
    ""
  );
  session.recovered = !stillRefused;
  session.recoveryFailed = stillRefused;
  return { upstream, body: upstreamBody, session };
}

/** Audit reason for an otherwise-allowed call whose transport session had to be
 * re-established — the measure of how many clients do not retain the header. */
const UPSTREAM_SESSION_RECOVERED_REASON = "upstream_session_recovered";

/** Replaces a plain `allowed` with the session note; real denials keep theirs. */
function withUpstreamSessionNote(reason: string, session: UpstreamSessionState | undefined): string {
  if (!session?.recovered) return reason;
  return reason === "allowed" ? UPSTREAM_SESSION_RECOVERED_REASON : reason;
}

function toSourceRecords(refs: SourceRef[]): AccessLogSourceRecord[] {
  return refs.map((ref) => ({
    connectionId: ref.connectionId,
    schemaName: ref.schema,
    sourceName: ref.sourceName,
    physicalTable: ref.physicalTable,
    extractionMethod: ref.extractionMethod,
    confidence: ref.confidence
  }));
}

/**
 * Spec 173 v0.3 / 2026-10-19 audit-trust: bindOpenSessionTurn is撤销.
 * The function previously re-resolved attribution at write time; v0.3 forbids write-time
 * rewrite of `lucy_turn_id` / association_status / effective_*. Attribution must be frozen
 * at admission (see `reportedTurns.resolve` in the /mcp tools/call handler before
 * `recordAudit`). New code MUST NOT re-introduce this helper.
 */
function _bindOpenSessionTurn_REMOVED_v0_3(
  _entry: Partial<Parameters<typeof writeLog>[0]>,
  _owner: Identity
): void {
  // intentionally empty; the function body is preserved here only as a tombstone to
  // catch accidental re-imports. Do not call.
  return;
}

function finalizeTracedEntry(
  context: TraceRequestContext,
  entry: Parameters<typeof writeLog>[0]
): Parameters<typeof writeLog>[0] {
  const { evidence, root } = completeTrace(context.recorder, {
    tool: entry.tool,
    outcome: entry.outcome,
    decisionReason: entry.decisionReason,
    errorDetail: entry.errorDetail,
    policyVersion: entry.policyVersion,
    isToolCall: context.rpcMethod === "tools/call"
  });
  const finished = context.recorder.finish(root);
  return {
    ...entry,
    traceId: finished.traceId,
    ts: new Date(finished.wallEndMs).toISOString(),
    durationMs: finished.durationMs,
    spans: finished.spans,
    ipSource: context.ipSource,
    trustedSource: context.trustedSource,
    executionEvidence: entry.executionEvidence ?? evidence
  };
}

/**
 * P1-37 U2：登记一次被拒请求并判断是否「相同请求刚被拒绝」。
 * 指纹只对规范化后的入参取 HMAC；密钥不可用时返回无指纹，不影响拒绝响应本身。
 */
async function trackRejection(
  context: TraceRequestContext | undefined,
  reason: string
): Promise<{ fingerprint?: string; repeated: boolean }> {
  const rejection = context?.rejection;
  if (!rejection) return { repeated: false };
  rejection.fingerprint ??= await computeRejectionFingerprint(rejection.args);
  if (!rejection.fingerprint) return { repeated: false };
  const parts = {
    identityId: rejection.identityId,
    sessionScope: rejection.sessionScope,
    tool: rejection.tool,
    fingerprint: rejection.fingerprint,
    reason,
    policyVersion: getPolicyRuntimeStatus().policyVersion
  };
  const repeated = repeatRejections.isRepeated(parts);
  repeatRejections.remember(parts);
  return { fingerprint: rejection.fingerprint, repeated };
}

/** 重复被拒时返回要追加到拒绝文案末尾的提示（含前导空格），否则返回空串。 */
async function repeatRejectionSuffix(context: TraceRequestContext | undefined, reason: string): Promise<string> {
  const tracked = await trackRejection(context, reason);
  return tracked.repeated ? ` ${REPEAT_REJECTION_HINT}` : "";
}

/** 审计出口：被拒行（denied 或入参校验失败）补上指纹，并登记到重复被拒状态。 */
async function withRejectionFingerprint(
  context: TraceRequestContext | undefined,
  entry: Parameters<typeof writeLog>[0]
): Promise<Parameters<typeof writeLog>[0]> {
  const rejection = context?.rejection;
  if (!rejection || entry.tool !== rejection.tool || entry.rejectionFingerprint) return entry;
  const reason = entry.decisionReason ?? entry.errorDetail ?? "";
  if (entry.outcome !== "denied" && !reason.startsWith("invalid_arguments")) return entry;
  const tracked = await trackRejection(context, reason);
  return tracked.fingerprint ? { ...entry, rejectionFingerprint: tracked.fingerprint } : entry;
}

function recordAudit(entry: Parameters<typeof writeLog>[0], sources?: SourceRef[]): void {
  beginAuditWrite();
  // A known User-Agent product replaces an empty name or Lucy's own placeholder.
  // Other self-reported names stay. Unknown agents such as undici are not guessed.
  // `client_ip` stays the socket peer.
  const resolved = resolveClientIdentity({
    client: entry.client,
    clientVersion: entry.clientVersion,
    userAgent: entry.userAgent
  });
  const normalized: Parameters<typeof writeLog>[0] = {
    ...entry,
    client: resolved.client,
    clientVersion: resolved.clientVersion,
    reportedClient: resolved.reportedClient,
    reportedClientVersion: resolved.reportedClientVersion,
    // D-27: this is the JSON-RPC id observed on the actual MCP request. Keep
    // unrelated client/upstream identifiers absent until their real sources exist.
    rpcRequestId: entry.rpcRequestId ?? (
      entry.requestId == null || entry.requestId === "" ? undefined : String(entry.requestId)
    )
  };
  // P1-36：该请求的 trace 由第一行审计行认领；响应发出后再收尾并同事务写入行与 span。
  const traceContext = currentTraceContext();
  const traced = traceContext?.claim(normalized.traceId) === true;
  const ready: Promise<Parameters<typeof writeLog>[0]> = (traced && traceContext
    ? traceContext.settled.then(() => finalizeTracedEntry(traceContext, normalized))
    : Promise.resolve(normalized)
  ).then((finalEntry) => withRejectionFingerprint(traceContext, finalEntry));
  ready
    .then((finalEntry) => writeLog(finalEntry).then((accessLogId) => {
      if (sources && sources.length > 0) {
        return writeAccessLogSources(accessLogId, finalEntry.ts, finalEntry.userId, finalEntry.tool, toSourceRecords(sources));
      }
    }))
    .then(() => {
      completeAuditWrite();
    })
    .catch((err) => {
      failAuditWrite();
      console.error("[lucy-proxy] failed to write audit log", err);
    });
}

function skillAuditFields(skill: SkillAsset, action: SkillAclAction, decision?: SkillAclDecision) {
  return {
    skillUri: skill.uri,
    skillVersion: skill.version,
    skillFileVersion: skill.file_version,
    skillAction: action,
    skillRolesAllowed: skill.roles_allowed,
    matchedRoleId: decision?.matchedRoleId,
    decisionReason: decision?.reason ?? (decision?.allowed ? "allowed" : undefined)
  };
}

/**
 * 202608-01 Trace / Evidence Kernel — best-effort write of `mcp_tools_call`
 * + `policy_decision` events. Errors are swallowed so the MCP request keeps
 * flowing; the verifier counts dropped writes separately. We do NOT touch
 * sensitive metadata: only the snapshot hash, the tool name, and a redacted
 * summary are stored.
 */
function recordMcpTrace(input: {
  traceId: string;
  spanId: string;
  identity: Identity;
  toolName: string;
  status: LucySpanStatus;
  startedAt: string;
  endedAt: string;
  policyDecision: PolicyDecisionMetadata;
  turnId?: string | null;
  sessionId?: string | null;
  requestId?: string | null;
  argsSummary?: Record<string, unknown>;
  resultSnapshot?: {
    rowCount?: number | null;
    columnCount?: number | null;
    responseBytes?: number | null;
    truncated?: boolean | null;
  } | null;
  sourceRefs?: SourceRef[] | null;
}): void {
  getAdminAuditDb()
    .then((db) => {
      try {
        recordMcpToolsCall(db, {
          traceId: input.traceId,
          spanId: input.spanId,
          actorId: input.identity.userId,
          toolName: input.toolName,
          startedAt: input.startedAt,
          endedAt: input.endedAt,
          status: input.status,
          sessionId: input.sessionId ?? null,
          turnId: input.turnId ?? null,
          requestId: input.requestId ?? null,
          policyDecision: input.policyDecision,
          metadata: input.argsSummary,
          resultSnapshot: input.resultSnapshot ?? null,
          sourceRefs: input.sourceRefs ?? null
        });
        // Spec 62 P0 Closure: sampled lazy purge — never blocks the MCP response.
        const sampleRate = Number(process.env.LUCY_TRACE_PURGE_SAMPLE_RATE ?? 0.01);
        if (Math.random() < sampleRate) {
          try {
            purgeTraceEvidence(db, { retentionDays: TRACE_RETENTION_DAYS });
          } catch (purgeErr) {
            console.error("[lucy-proxy] lazy trace purge failed", purgeErr);
          }
        }
      } catch (err) {
        console.error("[lucy-proxy] recordMcpToolsCall threw", err);
      }
    })
    .catch((err) => {
      console.error("[lucy-proxy] failed to write trace event", err);
    });
}

async function buildTracePolicyDecision(
  identity: Identity,
  toolName: string,
  allowed: boolean,
  reason: string | undefined,
  matchedRule: string | undefined
): Promise<PolicyDecisionMetadata> {
  const snapshot = await permissionSnapshot(identity).catch(() => undefined);
  return {
    allowed,
    reason,
    toolName,
    matchedRule,
    source: "access_policy",
    permissionSnapshotHash: snapshot?.hash
  };
}

function normalizedTraceRequestId(requestId: string | number): string | null {
  return requestId === "" ? null : String(requestId);
}

function toolTraceSpanId(toolName: string, traceId: string): string {
  return `mcp_tools_call:${toolName}:${traceId}`;
}

function resultSnapshotFromAuditMeta(
  meta: Partial<Parameters<typeof writeLog>[0]> | undefined
): {
  rowCount?: number | null;
  columnCount?: number | null;
  responseBytes?: number | null;
  truncated?: boolean | null;
} | null {
  if (!meta) return null;
  const rowCount = typeof meta.responseRowCount === "number" ? meta.responseRowCount : null;
  const columnCount = typeof meta.responseColumnCount === "number" ? meta.responseColumnCount : null;
  if (rowCount === null && columnCount === null) return null;
  return {
    rowCount,
    columnCount,
    responseBytes: typeof meta.responseBytes === "number" ? meta.responseBytes : null,
    truncated: meta.responseTruncated === true
  };
}

function recordMcpTraceForTool(input: {
  traceId: string;
  identity: Identity;
  toolName: string;
  status: LucySpanStatus;
  startedAt: string;
  endedAt?: string;
  turnId?: string | null;
  sessionId?: string | null;
  requestId: string | number;
  argsSummary?: Record<string, unknown>;
  allowed: boolean;
  reason?: string;
  matchedRule?: string;
  policySource?: PolicyDecisionMetadata["source"];
  resultSnapshot?: {
    rowCount?: number | null;
    columnCount?: number | null;
    responseBytes?: number | null;
    truncated?: boolean | null;
  } | null;
  sourceRefs?: SourceRef[] | null;
}): void {
  buildTracePolicyDecision(input.identity, input.toolName, input.allowed, input.reason, input.matchedRule)
    .then((policyDecision) => {
      recordMcpTrace({
        traceId: input.traceId,
        spanId: toolTraceSpanId(input.toolName, input.traceId),
        identity: input.identity,
        toolName: input.toolName,
        status: input.status,
        startedAt: input.startedAt,
        endedAt: input.endedAt ?? new Date().toISOString(),
        turnId: input.turnId ?? null,
        sessionId: input.sessionId ?? null,
        requestId: normalizedTraceRequestId(input.requestId),
        argsSummary: input.argsSummary,
        resultSnapshot: input.resultSnapshot ?? null,
        sourceRefs: input.sourceRefs ?? null,
        policyDecision: {
          ...policyDecision,
          source: input.policySource ?? policyDecision.source
        }
      });
    })
    .catch((err) => {
      console.error("[lucy-proxy] failed to build trace policy decision", err);
    });
}

async function auditMeta(
  identity: Identity | null | undefined,
  decisionReason: string,
  extra?: { compilerReason?: string }
): Promise<Partial<Parameters<typeof writeLog>[0]>> {
  const meta = await buildAccessLogAuditMeta(identity, decisionReason);
  if (!identity?.actorId) return extra?.compilerReason ? { ...meta, compilerReason: extra.compilerReason } : meta;
  return {
    ...meta,
    actorId: identity.actorId,
    actorKind: identity.actorKind,
    ...(extra?.compilerReason ? { compilerReason: extra.compilerReason } : {})
  };
}

function correlationMeta(headers: IncomingMessage["headers"]): Partial<Parameters<typeof writeLog>[0]> {
  return {
    lucySessionId: normalizeHeader(headers["x-lucy-session-id"]) || normalizeHeader(headers["mcp-session-id"]),
    lucyPlatform: normalizeHeader(headers["x-lucy-platform"])
  };
}

function findRawQuery(value: unknown, depth = 0): string | undefined {
  if (!value || depth > 4) return undefined;
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = findRawQuery(item, depth + 1);
      if (found) return found;
    }
    return undefined;
  }
  if (typeof value !== "object") return undefined;
  for (const [key, nested] of Object.entries(value as Record<string, unknown>)) {
    if (QUERY_KEY_RE.test(key) && typeof nested === "string") return nested;
    const found = findRawQuery(nested, depth + 1);
    if (found) return found;
  }
  return undefined;
}

function redactQueryPreview(query: string): string {
  return query
    .replace(/'([^']|'')*'/g, "'?'")
    .replace(/"([^"]|"")*"/g, '"?"')
    .replace(/\b(password|passwd|pwd|token|secret|api[-_]?key|authorization|credential)\b\s*[:=]\s*([^,\s;]+)/gi, "$1=[REDACTED]")
    .replace(/\b\d+(?:\.\d+)?\b/g, "?")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Lucy v0.25 / L25-09 B5 / U11 — `query_preview` 由 180 扩展至 **500 码点**。
 *
 * - 先执行既有脱敏（`redactQueryPreview`），再生成有界预览。
 * - 按 Unicode 码点截断，**不切断字符**（emoji / 中文边界）。
 * - 记录 `truncated` 与原始输入 UTF-8 字节长度。
 * - `preview_version=v2p5-1`；历史行保持 180 原值，**不改写历史行**（D7）。
 */
function buildAuditQueryPreview(query: string): {
  queryPreview: string;
  previewVersion: string;
  previewTruncated: boolean;
  previewOriginalBytes: number;
} {
  const redacted = redactQueryPreview(query);
  const built = buildQueryPreview(redacted, {
    maxCodePoints: QUERY_PREVIEW_MAX_CODEPOINTS,
    previewVersion: PREVIEW_VERSION_V2P5
  });
  return {
    queryPreview: built.preview,
    previewVersion: built.previewVersion,
    previewTruncated: built.truncated,
    previewOriginalBytes: built.originalBytes
  };
}

function queryOperation(query: string): string {
  const match = query.trim().match(/^([a-z]+)/i);
  const op = match?.[1]?.toLowerCase();
  if (!op) return "unknown";
  if (["select", "show", "describe", "with"].includes(op)) return op;
  return "unknown";
}

function queryAuditMeta(toolArgs: unknown, toolName?: string): Partial<Parameters<typeof writeLog>[0]> & { queryTables?: string[] } {
  const rawQuery = findRawQuery(toolArgs);
  if (!rawQuery) return {};
  const preview = buildAuditQueryPreview(rawQuery);
  return {
    queryHash: createHash("sha256").update(rawQuery).digest("hex"),
    queryLength: rawQuery.length,
    queryOperation: queryOperation(rawQuery),
    queryPreview: preview.queryPreview,
    previewVersion: preview.previewVersion,
    previewTruncated: preview.previewTruncated,
    previewOriginalBytes: preview.previewOriginalBytes,
    // U11：摘要基于完整的受控规范化输入，digest_kind 区分来源类型。
    // P1-36 D10：wiki_search 的摘要是检索文本，不得标成 sql。
    digestKind: toolName === "wiki_search" ? "search_text" : "sql",
    queryTables: extractQueryTables(rawQuery)
  };
}

function findBooleanFlag(value: unknown, keyName: string, depth = 0): boolean | undefined {
  if (!value || depth > 5) return undefined;
  if (typeof value === "string" && value.trim().startsWith("{")) {
    try {
      return findBooleanFlag(JSON.parse(value), keyName, depth + 1);
    } catch {
      return undefined;
    }
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = findBooleanFlag(item, keyName, depth + 1);
      if (found !== undefined) return found;
    }
    return undefined;
  }
  if (typeof value !== "object") return undefined;
  for (const [key, nested] of Object.entries(value as Record<string, unknown>)) {
    if (key === keyName && typeof nested === "boolean") return nested;
    const found = findBooleanFlag(nested, keyName, depth + 1);
    if (found !== undefined) return found;
  }
  return undefined;
}

function inspectRowsAndColumns(value: unknown, depth = 0): { rows?: number; columns?: number } {
  if (!value || depth > 5) return {};
  if (Array.isArray(value)) {
    const nested = value.map((item) => inspectRowsAndColumns(item, depth + 1));
    return nested.reduce((best, item) => ({
      rows: best.rows ?? item.rows,
      columns: best.columns ?? item.columns
    }), {} as { rows?: number; columns?: number });
  }
  if (typeof value !== "object") return {};
  const record = value as Record<string, unknown>;
  const rows = Array.isArray(record.rows) ? record.rows.length : typeof record.totalRows === "number" ? record.totalRows : undefined;
  const columns = Array.isArray(record.columns) ? record.columns.length : Array.isArray(record.headers) ? record.headers.length : undefined;
  if (rows !== undefined || columns !== undefined) return { rows, columns };
  for (const nested of Object.values(record)) {
    if (typeof nested === "string" && nested.trim().startsWith("{")) {
      try {
        const inspected = inspectRowsAndColumns(JSON.parse(nested), depth + 1);
        if (inspected.rows !== undefined || inspected.columns !== undefined) return inspected;
      } catch {
        // best-effort only
      }
    }
    const inspected = inspectRowsAndColumns(nested, depth + 1);
    if (inspected.rows !== undefined || inspected.columns !== undefined) return inspected;
  }
  return {};
}

function responseAuditMeta(
  body: Buffer,
  contentType: string | string[] | number | undefined,
  options: { toolName?: string; rowCap?: number } = {}
): Partial<Parameters<typeof writeLog>[0]> {
  const meta: Partial<Parameters<typeof writeLog>[0]> = { responseBytes: body.byteLength };
  const type = Array.isArray(contentType) ? contentType.join(",") : String(contentType ?? "");
  if (!type.includes("application/json")) return meta;
  try {
    const parsed = JSON.parse(body.toString());
    const inspected = inspectRowsAndColumns(parsed);
    meta.responseRowCount = inspected.rows;
    meta.responseColumnCount = inspected.columns;
    meta.responseTruncated = findBooleanFlag(parsed, "truncated");
    // Spec 162 §7.5 / SC-10 — a successful lucy_query always writes 0 or 1.
    // Only lucy_query; lucy_freshness / lucy_explain_query keep their own 0.
    if (options.toolName === "lucy_query" && meta.responseTruncated !== true) {
      const resolved = resolveResponseTruncated({
        upstreamTruncated: meta.responseTruncated,
        rowCount: inspected.rows ?? null,
        rowCap: options.rowCap ?? null
      });
      meta.responseTruncated = resolved.responseTruncated === 1;
    }
  } catch {
    // byte size is still useful even when JSON parsing fails.
  }
  return meta;
}

function pipeResponse(upstream: IncomingMessage, res: ServerResponse): void {
  const headers: Record<string, string | string[] | number> = {};
  for (const [k, v] of Object.entries(upstream.headers)) {
    if (v !== undefined) headers[k] = v;
  }
  res.writeHead(upstream.statusCode ?? 200, headers);
  upstream.pipe(res);
}

function kxCatalogTool() {
  return {
    name: "kx_catalog",
    description: "Compatibility catalog. Lists only the sources available to this agent. Prefer lucy_catalog for new clients.",
    inputSchema: {
      type: "object",
      properties: {},
      additionalProperties: false
    }
  };
}

function lucyCatalogTool() {
  return {
    name: "lucy_catalog",
    description: "List only the connections and semantic sources available to this agent, with safe query examples for the visible domain. Call this before choosing a database or source.",
    inputSchema: {
      type: "object",
      properties: {},
      additionalProperties: false
    }
  };
}

function lucyReadSourceTool() {
  return {
    name: "lucy_read_source",
    description: "Read one authorized semantic source through Lucy. This is the stable Lucy wrapper for sl_read_source and is filtered by role/source policy.",
    inputSchema: {
      type: "object",
      properties: {
        connectionId: { type: "string" },
        sourceName: { type: "string" }
      },
      required: ["connectionId", "sourceName"],
      additionalProperties: true
    }
  };
}

function semanticQueryInputProperties() {
  const semanticFieldRef = {
    type: "object",
    properties: {
      field: { type: "string", minLength: 1 },
      granularity: { type: "string" },
      name: { type: "string" }
    },
    required: ["field"],
    additionalProperties: true
  };
  const orderByRef = {
    type: "object",
    properties: {
      field: { type: "string", minLength: 1 },
      direction: { type: "string", enum: ["asc", "desc"] }
    },
    required: ["field"],
    additionalProperties: true
  };
  const measureRef = {
    anyOf: [
      { type: "string", minLength: 1 },
      {
        type: "object",
        properties: {
          expr: { type: "string", minLength: 1 },
          name: { type: "string", minLength: 1 }
        },
        required: ["expr"],
        additionalProperties: true
      }
    ]
  };
  const filterRef = {
    anyOf: [
      { type: "string", minLength: 1 },
      {
        type: "object",
        properties: {
          field: { type: "string", minLength: 1 },
          op: { type: "string" },
          value: {},
          values: { type: "array" }
        },
        required: ["field"],
        additionalProperties: true
      }
    ]
  };

  return {
    connectionId: { type: "string" },
    measures: { type: "array", items: measureRef },
    dimensions: { type: "array", items: semanticFieldRef },
    filters: { anyOf: [filterRef, { type: "array", items: filterRef }] },
    segments: { type: "array", items: { type: "string", minLength: 1 } },
    order_by: { type: "array", items: orderByRef },
    orderBy: { type: "array", items: orderByRef },
    limit: { type: "number", minimum: 1, maximum: LUCY_QUERY_MAX_LIMIT }
  };
}

function lucyQueryTool() {
  return {
    name: "lucy_query",
    description: "Run an authorized semantic query through Lucy guardrails. This is the primary tool for factual data retrieval. Use source-qualified measures, dimensions, filters, segments, and order fields. dimensions/order_by must be arrays of objects, never strings.",
    inputSchema: {
      type: "object",
      properties: semanticQueryInputProperties(),
      required: ["connectionId"],
      additionalProperties: true
    }
  };
}

function lucyExplainQueryTool() {
  return {
    name: "lucy_explain_query",
    description: "Diagnostic tool: explain how Lucy would authorize and guardrail a semantic query without executing it. Use after a query is denied or when debugging permissions/guardrails; do not use as a routine dry-run before simple factual queries. dimensions/order_by must be arrays of objects, never strings.",
    inputSchema: {
      type: "object",
      properties: semanticQueryInputProperties(),
      required: ["connectionId"],
      additionalProperties: true
    }
  };
}

function lucyFreshnessTool() {
  return {
    name: "lucy_freshness",
    description: "Return freshness metadata for one authorized source. R1 reports semantic-layer metadata freshness and leaves physical data freshness explicit when unavailable.",
    inputSchema: {
      type: "object",
      properties: {
        connectionId: { type: "string" },
        sourceName: { type: "string" }
      },
      required: ["connectionId", "sourceName"],
      additionalProperties: false
    }
  };
}

function lucyBeginQuestionTool() {
  return {
    name: "lucy_begin_question",
    description:
      `Recommended at the start of each new user business question. Prefer the user's original wording in \`question\`; always provide \`intentSummary\`. When multiple visible sources may match the same business term, Lucy allows the query but discloses the selection in answer_verifiability.sourceSelection (tell the user which source you used and that it was unconfirmed). source_ambiguity_gate is returned only for hard failures (unresolved refs, catalog health, cross-connection, more than ${SOURCE_COUNT_CAP} sources, or no source-qualified reference at all while the business term matches several sources); then retry as a single-source query using \`source.measure\` keys. Skipping begin does not bypass these hard checks. Do not call for protocol checks or tool discovery only.`,
    inputSchema: {
      type: "object",
      properties: {
        question: { type: "string", maxLength: 2000 },
        intentSummary: { type: "string", maxLength: 500 },
        entities: {
          type: "array",
          items: { type: "string" },
          maxItems: 20
        },
        // P0-1：显式指定生效绑定。优先于触发匹配；不回退触发匹配。
        caliberBindingId: { type: "string", maxLength: 200 }
      },
      required: ["intentSummary"],
      additionalProperties: false
    }
  };
}

function lucyContinueQuestionTool() {
  return {
    name: "lucy_continue_question",
    description:
      "Continue the current question after question_budget_exhausted. Pass the continueToken from that response. This does not start a new question and does not require a database connection.",
    inputSchema: {
      type: "object",
      properties: {
        token: { type: "string" }
      },
      required: ["token"],
      additionalProperties: false
    }
  };
}

function connectionListTool() {
  return {
    name: "connection_list",
    description: "List only the database connections available to this agent. This proxy-local response is already filtered by effective permissions.",
    inputSchema: {
      type: "object",
      properties: {},
      additionalProperties: false
    }
  };
}

function wikiSearchTool() {
  return {
    name: "wiki_search",
    description: "Search only wiki pages this agent is authorized to read. Returned keys are canonical and can be passed directly to wiki_read.",
    inputSchema: {
      type: "object",
      properties: {
        query: { type: "string" },
        q: { type: "string" },
        connectionId: { type: "string" },
        limit: { type: "number", minimum: 1, maximum: 20 }
      },
      additionalProperties: true
    }
  };
}

function wikiReadTool() {
  return {
    name: "wiki_read",
    description: "Read an authorized wiki page by canonical key. Unauthorized pages return a generic access denied response.",
    inputSchema: {
      type: "object",
      properties: {
        key: { type: "string" }
      },
      required: ["key"],
      additionalProperties: true
    }
  };
}

function lucySkillSearchTool() {
  return {
    name: "lucy_skill_search",
    description: "Search available governed Lucy domain skills and SOPs by keyword or business intent.",
    inputSchema: {
      type: "object",
      properties: {
        query: { type: "string", description: "Search keyword or business question" },
        domain: { type: "string", description: "Optional domain filter (e.g. superstore, kx_financial)" }
      },
      required: ["query"],
      additionalProperties: true
    }
  };
}

function lucySkillReadTool() {
  return {
    name: "lucy_skill_read",
    description: "Read the full execution SOP and guidelines of a governed Lucy domain skill.",
    inputSchema: {
      type: "object",
      properties: {
        skill_name: { type: "string", description: "The name or URI of the skill to read (e.g. superstore-profit-breakdown)" }
      },
      required: ["skill_name"],
      additionalProperties: true
    }
  };
}

/**
 * Spec 162 §7.8 / SC-13 — 认证路径. Executes a published route as a
 * role-scoped `lucy_query`; the answer carries `routeId` and its source.
 */
function lucyCertifiedRouteTool() {
  return {
    name: "lucy_certified_route",
    description: "Run a published certified route. The answer reports the route id and source it read. Access still follows this agent's permissions.",
    inputSchema: {
      type: "object",
      properties: {
        routeId: { type: "string", description: "Published certified route id" },
        templateId: { type: "string", description: "Published report template id (pilot: public_cloud_pnl_quarterly)" }
      },
      additionalProperties: false
    }
  };
}

/** Spec 162 §7.8 / SC-19 — single P&L template pilot. */
function lucyReportTemplateTool() {
  return {
    name: "lucy_report_template",
    description: "Run a published report template and get its source plus the applied version. Pilot scope: public_cloud_pnl_quarterly.",
    inputSchema: {
      type: "object",
      properties: {
        templateId: { type: "string" }
      },
      required: ["templateId"],
      additionalProperties: false
    }
  };
}

// Local tools the proxy serves itself (never forwarded to KTX). Each is only injected
// into tools/list when visibleTools allows it — same explicit allow-list gate as any
// other tool (spec 08 §15 decision 2: no derived/bypass condition).
function localToolBuilders(): Array<{ name: string; build: () => Record<string, unknown> }> {
  const builders: Array<{ name: string; build: () => Record<string, unknown> }> = [
    { name: "connection_list", build: connectionListTool },
    { name: "lucy_catalog", build: lucyCatalogTool },
    { name: "lucy_read_source", build: lucyReadSourceTool },
    { name: "lucy_query", build: lucyQueryTool },
    { name: "lucy_explain_query", build: lucyExplainQueryTool },
    { name: "lucy_freshness", build: lucyFreshnessTool },
    { name: "kx_catalog", build: kxCatalogTool },
    { name: "wiki_search", build: wikiSearchTool },
    { name: "wiki_read", build: wikiReadTool },
    { name: "lucy_skill_search", build: lucySkillSearchTool },
    { name: "lucy_skill_read", build: lucySkillReadTool },
    { name: "lucy_certified_route", build: lucyCertifiedRouteTool },
    { name: "lucy_report_template", build: lucyReportTemplateTool }
  ];
  if (process.env.LUCY_ENABLE_QUESTION_TOOL !== "false") {
    builders.push({ name: "lucy_begin_question", build: lucyBeginQuestionTool });
    builders.push({ name: "lucy_continue_question", build: lucyContinueQuestionTool });
  }
  // L25-16 — 控制面工具（`lucy_ops_*`）同样由代理本地服务。可见性只取决于
  // `role.allow.ops`（`allowedToolNames` 的控制面分支），**不要求任何数据面能力**。
  for (const descriptor of opsToolDescriptors()) {
    builders.push({ name: descriptor.name, build: () => descriptor });
  }
  return builders;
}

/**
 * P1-60 (Spec §3 D1–D2): inactive / unknown 下从 visibleTools 移除 lucy_begin_question。
 * 分类读取失败按 unknown 隐藏 begin；其余工具与 continue 保持。
 */
async function shouldHideBeginQuestion(identity: Identity, sessionId: string | null | undefined): Promise<boolean> {
  try {
    const identityKey = budgetIdentityKey(identity.userId, identity.tokenHashPrefix ?? "");
    const scopeKey = sessionId ? bindingScopeKey(identityKey, sessionId) : undefined;
    const participation = await classifyCaliberParticipation({ scopeKey });
    return participation !== "active";
  } catch {
    return true;
  }
}

function numericLimit(value: unknown): number {
  if (typeof value !== "number" || !Number.isFinite(value)) return LUCY_QUERY_DEFAULT_LIMIT;
  return Math.min(LUCY_QUERY_MAX_LIMIT, Math.max(1, Math.floor(value)));
}

function rewriteToolCall(parsed: Record<string, unknown>, upstreamTool: string, args: Record<string, unknown>): Buffer {
  const params = parsed.params && typeof parsed.params === "object" && !Array.isArray(parsed.params)
    ? { ...(parsed.params as Record<string, unknown>) }
    : {};
  return Buffer.from(JSON.stringify({
    ...parsed,
    params: {
      ...params,
      name: upstreamTool,
      arguments: args
    }
  }));
}

function lucyReadSourceUpstreamArgs(args: unknown): Record<string, unknown> {
  const record = args && typeof args === "object" && !Array.isArray(args) ? args as Record<string, unknown> : {};
  return {
    ...record,
    connectionId: record.connectionId ?? record.connection_id ?? record.connection,
    sourceName: record.sourceName ?? record.source_name ?? record.source ?? record.table
  };
}

/** Normalize wiki_search args for KTX: prefer query, else lift q/text/keyword, drop aliases. */
function wikiSearchUpstreamArgs(args: unknown): Record<string, unknown> {
  const record = args && typeof args === "object" && !Array.isArray(args) ? args as Record<string, unknown> : {};
  const { q: _q, text: _text, keyword: _keyword, ...rest } = record;
  const existingQuery = typeof rest.query === "string" && rest.query.trim() ? rest.query : undefined;
  if (existingQuery) return { ...rest, query: existingQuery };
  const aliasQuery = firstStringValue(record, ["q", "text", "keyword"]);
  if (aliasQuery) return { ...rest, query: aliasQuery };
  return rest;
}

function isSafeSemanticFieldRef(value: unknown): value is string {
  if (!hasNonEmptyStringValue(value)) return false;
  return !/[^\p{L}\p{N}_.$]/u.test(String(value).trim());
}

function sqlLiteral(value: unknown): string {
  if (value === null) return "NULL";
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  if (typeof value === "boolean") return value ? "TRUE" : "FALSE";
  return `'${String(value).replaceAll("'", "''")}'`;
}

type LucyFilterOp = "=" | "!=" | ">" | ">=" | "<" | "<=" | "in" | "contains" | "like" | "starts_with" | "ends_with";

function normalizeLucyFilterOp(op: unknown): LucyFilterOp | undefined {
  const raw = op === undefined ? "=" : String(op).trim().toLowerCase().replaceAll("-", "_").replaceAll(" ", "_");
  switch (raw) {
    case "=":
    case "==":
    case "eq":
    case "equals":
    case "equal":
    case "is":
      return "=";
    case "!=":
    case "<>":
    case "ne":
    case "neq":
    case "not_equal":
    case "not_equals":
    case "is_not":
      return "!=";
    case ">":
    case "gt":
      return ">";
    case ">=":
    case "gte":
    case "ge":
      return ">=";
    case "<":
    case "lt":
      return "<";
    case "<=":
    case "lte":
    case "le":
      return "<=";
    case "in":
      return "in";
    case "contains":
    case "include":
    case "includes":
    case "match":
    case "matches":
      return "contains";
    case "like":
      return "like";
    case "starts_with":
    case "startswith":
    case "prefix":
      return "starts_with";
    case "ends_with":
    case "endswith":
    case "suffix":
      return "ends_with";
    default:
      return undefined;
  }
}

function sqlLikeLiteral(value: unknown, mode: "contains" | "like" | "starts_with" | "ends_with"): string {
  const text = String(value).replaceAll("'", "''");
  if (mode === "contains") return `'%${text}%'`;
  if (mode === "starts_with") return `'${text}%'`;
  if (mode === "ends_with") return `'%${text}'`;
  return `'${text}'`;
}

function normalizeLucyFilterForUpstream(item: unknown): unknown {
  if (hasNonEmptyStringValue(item)) return item;
  if (!isPlainRecord(item) || !isSafeSemanticFieldRef(item.field)) return item;

  const field = String(item.field).trim();
  const op = normalizeLucyFilterOp(item.op);
  if (!op) return item;
  if (op === "in") {
    const rawValues = Array.isArray(item.values) ? item.values : Array.isArray(item.value) ? item.value : [];
    return `${field} IN (${rawValues.map(sqlLiteral).join(", ")})`;
  }
  if (op === "contains" || op === "like" || op === "starts_with" || op === "ends_with") {
    const value = Object.prototype.hasOwnProperty.call(item, "value") ? item.value : Array.isArray(item.values) ? item.values[0] : "";
    return `${field} LIKE ${sqlLikeLiteral(value, op)}`;
  }
  const value = Object.prototype.hasOwnProperty.call(item, "value") ? item.value : Array.isArray(item.values) ? item.values[0] : "";
  return `${field} ${op} ${sqlLiteral(value)}`;
}

function normalizeLucyFiltersForUpstream(value: unknown): unknown {
  if (value === undefined) return undefined;
  const items = Array.isArray(value) ? value : [value];
  return items.map(normalizeLucyFilterForUpstream);
}

function lucyQueryUpstreamArgs(args: unknown): Record<string, unknown> {
  const record = args && typeof args === "object" && !Array.isArray(args) ? args as Record<string, unknown> : {};
  const normalized = {
    ...record,
    filters: normalizeLucyFiltersForUpstream(record.filters),
    limit: numericLimit(record.limit)
  };
  // Spec 125: always ask upstream for compiled SQL so hot store can persist generated_sql.
  return mergeIncludeSql(normalized);
}

function generatedSqlAuditFields(
  toolName: string,
  toolResultBody: unknown
): Partial<Parameters<typeof writeLog>[0]> {
  if (toolName !== "lucy_query") return {};
  const sql = extractSqlFromToolResult(toolResultBody);
  if (!sql?.trim()) return {};
  return {
    generatedSql: sql,
    queryHash: createHash("sha256").update(sql).digest("hex"),
    queryLength: sql.length,
    queryOperation: queryOperation(sql),
    // P1-36 D10：lucy_query 的摘要来自上游编译出的 SQL。
    digestKind: "sql"
  };
}

function hasNonEmptyStringField(record: Record<string, unknown>, fields: string[]): boolean {
  return fields.some((field) => typeof record[field] === "string" && String(record[field]).trim().length > 0);
}

function hasNonEmptyArrayField(record: Record<string, unknown>, fields: string[]): boolean {
  return fields.some((field) => Array.isArray(record[field]) && (record[field] as unknown[]).length > 0);
}

function isPlainRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function hasNonEmptyStringValue(value: unknown): boolean {
  return typeof value === "string" && value.trim().length > 0;
}

function invalidObjectArrayFieldReason(toolName: string, record: Record<string, unknown>, field: string, reasonField = field): string | undefined {
  const value = record[field];
  if (value === undefined) return undefined;
  if (!Array.isArray(value)) return `invalid_arguments:${toolName}:${reasonField}_must_be_array`;
  for (const item of value) {
    if (!isPlainRecord(item)) return `invalid_arguments:${toolName}:${reasonField}_items_must_be_objects`;
    if (!hasNonEmptyStringValue(item.field)) return `invalid_arguments:${toolName}:${reasonField}_field_required`;
  }
  return undefined;
}

function invalidOrderByFieldReason(
  toolName: string,
  record: Record<string, unknown>,
  field: "order_by" | "orderBy"
): string | undefined {
  const invalidShape = invalidObjectArrayFieldReason(toolName, record, field, "order_by");
  if (invalidShape) return invalidShape;

  const value = record[field];
  if (value === undefined) return undefined;
  for (const item of value as Array<Record<string, unknown>>) {
    if (!isSafeSemanticFieldRef(item.field)) {
      return `invalid_arguments:${toolName}:order_by_field_unsafe`;
    }
    if (
      item.direction !== undefined
      && (typeof item.direction !== "string" || !["asc", "desc"].includes(item.direction))
    ) {
      return `invalid_arguments:${toolName}:order_by_direction_unsupported`;
    }
  }
  return undefined;
}

function invalidStringArrayFieldReason(toolName: string, record: Record<string, unknown>, field: string): string | undefined {
  const value = record[field];
  if (value === undefined) return undefined;
  if (!Array.isArray(value)) return `invalid_arguments:${toolName}:${field}_must_be_array`;
  if (value.some((item) => !hasNonEmptyStringValue(item))) {
    return `invalid_arguments:${toolName}:${field}_items_must_be_non_empty_strings`;
  }
  return undefined;
}

function invalidFilterFieldReason(toolName: string, record: Record<string, unknown>): string | undefined {
  const value = record.filters;
  if (value === undefined) return undefined;
  const items = Array.isArray(value) ? value : [value];
  for (const item of items) {
    if (hasNonEmptyStringValue(item)) continue;
    if (isPlainRecord(item)) {
      if (!hasNonEmptyStringValue(item.field)) return `invalid_arguments:${toolName}:filters_field_required`;
      if (!isSafeSemanticFieldRef(item.field)) return `invalid_arguments:${toolName}:filters_field_unsafe`;
      const op = normalizeLucyFilterOp(item.op);
      if (!op) {
        return `invalid_arguments:${toolName}:filters_op_unsupported`;
      }
      if (op === "in") {
        const inValues = Array.isArray(item.values) ? item.values : Array.isArray(item.value) ? item.value : [];
        if (inValues.length === 0) return `invalid_arguments:${toolName}:filters_values_required`;
      }
      if (op !== "in" && !Object.prototype.hasOwnProperty.call(item, "value") && !Object.prototype.hasOwnProperty.call(item, "values")) {
        return `invalid_arguments:${toolName}:filters_value_required`;
      }
      continue;
    }
    return `invalid_arguments:${toolName}:filters_items_must_be_strings_or_objects`;
  }
  return undefined;
}

function invalidMeasuresFieldReason(toolName: string, record: Record<string, unknown>): string | undefined {
  const value = record.measures;
  if (value === undefined) return undefined;
  if (!Array.isArray(value)) return `invalid_arguments:${toolName}:measures_must_be_array`;
  for (const item of value) {
    if (hasNonEmptyStringValue(item)) continue;
    if (isPlainRecord(item) && hasNonEmptyStringValue(item.expr)) continue;
    return `invalid_arguments:${toolName}:measures_items_must_be_strings_or_objects`;
  }
  return undefined;
}

function invalidLucyQueryShapeReason(toolName: string, record: Record<string, unknown>): string | undefined {
  return invalidMeasuresFieldReason(toolName, record)
    ?? invalidObjectArrayFieldReason(toolName, record, "dimensions")
    ?? invalidFilterFieldReason(toolName, record)
    ?? invalidStringArrayFieldReason(toolName, record, "segments")
    ?? invalidOrderByFieldReason(toolName, record, "order_by")
    ?? invalidOrderByFieldReason(toolName, record, "orderBy");
}

const LUCY_QUERY_MEASURES_HINT =
  "lucy_query requires a non-empty \"measures\" array, for example {\"connectionId\":\"<connection>\",\"measures\":[\"<source>.<measure>\"],\"dimensions\":[{\"field\":\"<source>.<dimension>\"}]}";

/** P1-37 U2：`measures` 缺失或为空数组＝KTX 必然拒绝的形状（见 O6 取证）。 */
function lucyQueryMeasuresRequiredReason(args: unknown): string | undefined {
  if (!args || typeof args !== "object" || Array.isArray(args)) return undefined;
  const measures = (args as Record<string, unknown>).measures;
  if (Array.isArray(measures) && measures.length > 0) return undefined;
  return "invalid_arguments:lucy_query:measures_required";
}

function validateLucyToolArgs(toolName: string, args: unknown): string | undefined {
  if (
    !toolName.startsWith("lucy_") ||
    toolName === "lucy_catalog" ||
    toolName === "lucy_begin_question" ||
    toolName === "lucy_continue_question" ||
    toolName === "lucy_skill_search" ||
    toolName === "lucy_skill_read" ||
    // L25-16 — 控制面工具的入参形状是 `{ targets: [...] }`，由控制面自己的
    // 适配器校验（`parseTargets`）；数据面的 `connectionId` 规则不适用。
    //
    // 这里按**前缀**豁免（而不是按登记表）：登记表之外的 `lucy_ops_*` 也必须走
    // 分类闸门（ACL → `tool_unclassified:<tool>`）得到准确的原因码，而不是先被
    // 数据面的入参规则拦下、报出误导性的 `connection_required`。
    toolName.startsWith("lucy_ops_") ||
    // P1-37 U2：未登记的工具名先走分类闸门（ACL → `tool_unclassified:<tool>`），
    // 而不是被数据面入参规则先拦下、报出误导性的 `connection_required`。
    absoluteDenyOrUnclassifiedReason(toolName)?.startsWith("tool_unclassified:")
  ) {
    return undefined;
  }
  if (!args || typeof args !== "object" || Array.isArray(args)) {
    return `invalid_arguments:${toolName}:arguments_object_required`;
  }
  const record = args as Record<string, unknown>;
  if (!hasNonEmptyStringField(record, ["connectionId", "connection_id", "connection"])) {
    return `invalid_arguments:${toolName}:connection_required`;
  }

  if (toolName === "lucy_read_source" || toolName === "lucy_freshness") {
    if (!hasNonEmptyStringField(record, ["sourceName", "source_name", "source", "table"])) {
      return `invalid_arguments:${toolName}:source_required`;
    }
  }

  if (toolName === "lucy_query" || toolName === "lucy_explain_query") {
    const hasQueryShape = hasNonEmptyArrayField(record, [
      "measures",
      "dimensions",
      "filters",
      "segments",
      "order_by",
      "orderBy"
    ]) || hasNonEmptyStringField(record, [
      "sourceName",
      "source_name",
      "source",
      "table",
      "query",
      "sql"
    ]);
    if (!hasQueryShape) {
      return `invalid_arguments:${toolName}:query_shape_required`;
    }
    const invalidShape = invalidLucyQueryShapeReason(toolName, record);
    if (invalidShape) return invalidShape;
  }

  return undefined;
}

async function lucyExplainQuery(identity: Identity, args: unknown): Promise<Record<string, unknown>> {
  const sourceRefs = await extractSourceRefs("lucy_explain_query", args, { fresh: true });
  const permissions = await effectivePermissions(identity);
  const requestedLimit = args && typeof args === "object" && !Array.isArray(args)
    ? (args as Record<string, unknown>).limit
    : undefined;

  let requestedSources = sourceRefs.map((ref) => ({
    connectionId: ref.connectionId,
    sourceName: ref.sourceName,
    physicalTable: ref.physicalTable
  }));
  if (requestedSources.length === 0 && permissions.ok) {
    const tables = await extractTables("lucy_explain_query", args).catch(() => [] as string[]);
    for (const table of tables) {
      const cap = permissions.permissions.capabilities.find(
        (item) =>
          (item.tool === "lucy_explain_query" || item.tool === "lucy_query") &&
          item.physicalTable === table
      );
      if (cap) {
        requestedSources.push({
          connectionId: cap.connectionId,
          sourceName: cap.sourceName,
          physicalTable: cap.physicalTable
        });
      }
    }
  }

  const rowPolicy = buildExplainForcedPredicateDiagnostics({
    capabilities: permissions.ok ? permissions.permissions.capabilities : [],
    requestedSources,
    finalRowsBySource: permissions.ok ? permissions.permissions.finalRowsBySource : undefined
  });

  return {
    ...rowPolicy,
    allowed: true,
    executionMode: "plan_only",
    executed: false,
    upstreamTool: "sl_query",
    requestedSources,
    resultRows: null,
    sampleRows: null,
    aggregateResults: null,
    guardrails: {
      rawSqlAllowed: false,
      writeOperationsAllowed: false,
      defaultLimit: LUCY_QUERY_DEFAULT_LIMIT,
      maxLimit: LUCY_QUERY_MAX_LIMIT,
      maxConcurrentQueries: queryConcurrencyLimit(),
      effectiveLimit: numericLimit(requestedLimit),
      resultTruncation: "responses are audited with row/column counts and truncation flags when upstream exposes them"
    },
    policy: permissions.ok
      ? {
          roleIds: permissions.permissions.roleIds,
          connections: permissions.permissions.connections,
          sourceMapVersion: permissions.permissions.sourceMapVersion,
          permissionSnapshotHash: permissions.permissions.snapshotHash,
          capabilityDigest: permissions.permissions.capabilityDigest
        }
      : { error: permissions.reason },
    provenance: {
      decision: "allowed",
      explanation: rowPolicy.executionPath.note
    }
  };
}

async function lucyFreshness(identity: Identity, args: unknown): Promise<Record<string, unknown>> {
  const record = args && typeof args === "object" && !Array.isArray(args) ? args as Record<string, unknown> : {};
  const connectionId = String(record.connectionId ?? record.connection_id ?? record.connection ?? "").trim().toLowerCase();
  const sourceName = String(record.sourceName ?? record.source_name ?? record.source ?? record.table ?? "").trim().toLowerCase();
  const catalog = await lucyCatalog(identity);
  const source = catalog.sources.find((item) => (
    item.connectionId === connectionId && item.sourceName === sourceName
  ));
  if (!source) {
    return {
      sourceName,
      connectionId,
      status: "forbidden_or_unknown",
      freshness: null
    };
  }

  const projectRoot = await resolveProjectRoot();
  const paths = await loadContentPaths();
  const overlayPath = path.join(paths.semanticLayer, source.connectionId, `${source.sourceName}.yaml`);
  const schemaPath = path.join(paths.semanticLayer, source.connectionId, "_schema", `${source.schema}.yaml`);
  const mtimes: string[] = [];
  for (const filePath of [overlayPath, schemaPath]) {
    try {
      mtimes.push((await stat(filePath)).mtime.toISOString());
    } catch {
      // Some sources are manifest-only or overlay-only; missing metadata files are not fatal.
    }
  }
  const semanticLayerUpdatedAt = mtimes.sort().at(-1);
  return {
    connectionId: source.connectionId,
    schema: source.schema,
    sourceName: source.sourceName,
    table: source.table,
    freshness: {
      mode: "metadata_only",
      semanticLayerUpdatedAt: semanticLayerUpdatedAt ?? null,
      physicalDataUpdatedAt: null,
      note: "Physical data freshness is not available from the current source contract; Lucy reports this explicitly instead of inventing a timestamp."
    }
  };
}

async function connectionList(identity: Identity): Promise<{
  connections: string[];
  items: Array<{ id: string; connectionId: string }>;
  filteredBy: "effective_permissions";
}> {
  const resolved = await effectivePermissions(identity);
  let connections = resolved.ok ? resolved.permissions.connections : [];
  // Spec 149 §6 — 运维问数连接未就绪时不列出（目录与连接清单一致）。
  if (connections.some((id) => id === OPS_EVIDENCE_CONNECTION_ID)) {
    const { readOpsEvidenceReadiness } = await import("../ops-evidence/readiness.js");
    const state = await readOpsEvidenceReadiness();
    if (state.readiness !== "current") {
      connections = connections.filter((id) => id !== OPS_EVIDENCE_CONNECTION_ID);
    }
  }
  return {
    connections,
    items: connections.map((connectionId) => ({ id: connectionId, connectionId })),
    filteredBy: "effective_permissions"
  };
}

// ─── InitializeResult.instructions injection (wo-proxy-instructions-injection Task A) ───
//
// Lucy MCP Proxy rewrites upstream `initialize` responses to inject
// `result.instructions` from `webui/config/data-qa-instructions.md`. This is the
// single source of truth for the data-QA guidance that used to live in
// `CLAUDE.md` — it travels with the MCP session so all clients (Codex, Cursor,
// remote Claude Code) see the same instructions, not just Claude Code local
// agents that auto-load CLAUDE.md.
//
// Failure semantics deliberately differ from `writeToolsListResponse`:
// tools/list filter failures return JSON-RPC -32003 (fail-closed — wrong tool
// visibility is a security boundary). instructions injection failures fall
// back to pass-through of the original upstream body (fail-open) — instructions
// are guidance, not a security boundary, and a buggy rewriter must not block
// MCP session establishment for every client.
//
// Loader state for the data-QA guidance injected into MCP `initialize` responses.
// Project file takes precedence over the bundled mirror; on read failure the next
// call retries (a missing or temporarily-unreadable file must not poison the
// proxy for its lifetime). Successes can be cached and tests can call
// `invalidateDataQaInstructionsCache()` to force a re-read.
type DataQaInstructionsSource = "project" | "mirror" | "missing";

interface DataQaInstructionsStatus {
  source: DataQaInstructionsSource;
  /** Bytes trimmed length of the loaded text. 0 when missing / failed. */
  length: number;
  /** Last error message (if any) from a project or mirror read. */
  lastError: string | null;
  /** When the cached value was last successfully loaded. */
  loadedAt: string | null;
}

let cachedDataQaInstructions: string | undefined;
let cachedDataQaInstructionsSource: DataQaInstructionsSource = "missing";
let cachedDataQaInstructionsError: string | null = null;
let cachedDataQaInstructionsLoadedAt: string | null = null;

const DEFAULT_DATA_QA_INSTRUCTIONS_MIRROR = "/app/webui/config/data-qa-instructions.md";
let dataQaInstructionsMirrorOverride: string | null = null;

export function setDataQaInstructionsMirrorPath(mirrorPath: string | null): void {
  dataQaInstructionsMirrorOverride = mirrorPath;
  invalidateDataQaInstructionsCache();
}

export function invalidateDataQaInstructionsCache(): void {
  cachedDataQaInstructions = undefined;
  cachedDataQaInstructionsSource = "missing";
  cachedDataQaInstructionsError = null;
  cachedDataQaInstructionsLoadedAt = null;
}

export function getDataQaInstructionsStatus(): DataQaInstructionsStatus {
  return {
    source: cachedDataQaInstructionsSource,
    length: cachedDataQaInstructions?.length ?? 0,
    lastError: cachedDataQaInstructionsError,
    loadedAt: cachedDataQaInstructionsLoadedAt
  };
}

async function readDataQaInstructionsFile(filePath: string): Promise<string> {
  const text = (await readFile(filePath, "utf-8")).trim();
  if (text.length === 0) throw new Error(`data-qa-instructions.md at ${filePath} is empty`);
  return text;
}

export async function loadDataQaInstructions(): Promise<string | undefined> {
  if (cachedDataQaInstructions && cachedDataQaInstructionsLoadedAt) return cachedDataQaInstructions;
  const projectRoot = await resolveProjectRoot();
  const projectFilePath = path.join(projectRoot, "webui", "config", "data-qa-instructions.md");
  const mirrorFilePath = dataQaInstructionsMirrorOverride ?? DEFAULT_DATA_QA_INSTRUCTIONS_MIRROR;

  // Project file wins; ENOENT falls through to the bundled mirror.
  try {
    const text = await readDataQaInstructionsFile(projectFilePath);
    cachedDataQaInstructions = text;
    cachedDataQaInstructionsSource = "project";
    cachedDataQaInstructionsError = null;
    cachedDataQaInstructionsLoadedAt = new Date().toISOString();
    return cachedDataQaInstructions;
  } catch (err) {
    const projectErr = err instanceof Error ? err.message : String(err);
    if (!isFileNotFound(err)) {
      console.error("[lucy-proxy] failed to read project data-qa-instructions.md", err);
    }
    try {
      const text = await readDataQaInstructionsFile(mirrorFilePath);
      cachedDataQaInstructions = text;
      cachedDataQaInstructionsSource = "mirror";
      cachedDataQaInstructionsError = projectErr;
      cachedDataQaInstructionsLoadedAt = new Date().toISOString();
      return cachedDataQaInstructions;
    } catch (mirrorErr) {
      const message = mirrorErr instanceof Error ? mirrorErr.message : String(mirrorErr);
      if (!isFileNotFound(mirrorErr)) {
        console.error("[lucy-proxy] failed to read mirror data-qa-instructions.md", mirrorErr);
      }
      cachedDataQaInstructions = undefined;
      cachedDataQaInstructionsSource = "missing";
      cachedDataQaInstructionsError = message;
      cachedDataQaInstructionsLoadedAt = null;
      console.error("[lucy-proxy] data-qa-instructions unavailable; initialize will pass through", mirrorErr);
      return undefined;
    }
  }
}

function isFileNotFound(err: unknown): boolean {
  return Boolean(err && typeof err === "object" && (err as { code?: string }).code === "ENOENT");
}

/**
 * D8 / SC-12 — initialize Visible Scope 每行只拼四元组身份字段。
 * 导出供单测直接调用生产拼装路径，避免手写行假绿。
 */
export function formatVisibleScopeSourceLine(source: {
  connectionId: string;
  schema: string;
  sourceName: string;
  table: string;
}): string {
  return `- ${source.connectionId}.${source.schema}.${source.sourceName} -> ${source.table}`;
}

async function buildRoleAwareInstructions(identity: Identity, sessionId?: string | null): Promise<string | undefined> {
  // P1-37 U1 取证：握手阶段计时（P1-36 的 instructions_build 及其下 catalog_resolve / skills_load）。
  const buildSpan = currentTrace()?.start("instructions_build");
  try {
    const text = await buildRoleAwareInstructionsUntimed(identity, buildSpan, sessionId);
    buildSpan?.end({ status: "ok", reasonCode: "allowed", attrs: { cache_hit: false, bytes: text ? Buffer.byteLength(text) : 0 } });
    return text;
  } catch (err) {
    buildSpan?.end({ status: "error", reasonCode: "upstream_error" });
    throw err;
  }
}

async function buildRoleAwareInstructionsUntimed(identity: Identity, buildSpan: SpanHandle | undefined, sessionId?: string | null): Promise<string | undefined> {
  const hideBegin = await shouldHideBeginQuestion(identity, sessionId);
  const rawFallback = await loadDataQaInstructions();
  const fallback = hideBegin && rawFallback
    ? rawFallback.replace(/## 可选问询上报[^\n]*\n[\s\S]*?(?=\n## |$)/u, "")
      .replaceAll("lucy_begin_question", "问询声明")
    : rawFallback;
  try {
    const catalogSpan = currentTrace()?.start("catalog_resolve", buildSpan);
    const catalog = await lucyCatalog(identity);
    catalogSpan?.end({ status: "ok", reasonCode: "allowed" });
    let accessibleSkills: Awaited<ReturnType<typeof filterAccessibleSkills>> = [];
    const skillsSpan = currentTrace()?.start("skills_load", buildSpan);
    try {
      const allSkills = await loadAllSkillsFresh();
      accessibleSkills = await filterAccessibleSkills(identity, allSkills, "discover");
      skillsSpan?.end({ status: "ok", reasonCode: "allowed", attrs: { skill_count: allSkills.length, cache_hit: false } });
    } catch {
      // Best-effort loading of skills for instructions
      skillsSpan?.end({ status: "error", reasonCode: "upstream_error" });
    }

    if (catalog.connections.length === 0 && catalog.sources.length === 0 && accessibleSkills.length === 0) return fallback;
    const visibleTools = new Set(await allowedToolNames(identity));
    // P1-60 D1: inactive / unknown 下不主动曝光 begin（Spec §4 伪代码）。
    if (hideBegin) visibleTools.delete("lucy_begin_question");
    const catalogTool = visibleTools.has("lucy_catalog")
      ? "`lucy_catalog`"
      : visibleTools.has("kx_catalog")
        ? "`kx_catalog`"
        : "the visible catalog tool";
    const sourceLines = catalog.sources.map(formatVisibleScopeSourceLine);
    const exampleLines = catalog.examples.map((example) => `- ${example}`);
    const skillLines = accessibleSkills.map((skill) => (
      `- [${skill.name}] (${skill.uri}): ${skill.title} - ${skill.description}`
    ));
    const skillSection = skillLines.length > 0
      ? [
          "",
          "## Governed Domain Skills (SOPs)",
          "",
          "When analyzing specific business domains, prefer fetching governed SOPs via MCP Resources (`lucy-skill://<domain>/<name>`) or `lucy_skill_read`:",
          ...skillLines
        ]
      : [];
    const questionReportingLines = visibleTools.has("lucy_begin_question")
      ? [
          "- Recommended: at the start of each new user business question, call `lucy_begin_question` once. Prefer the user's original wording in `question` when available; always provide `intentSummary`. Skipping begin does not bypass the source ambiguity gate when a query asserts a source. Do not call it for protocol checks or tool discovery only.",
          ""
        ]
      : [];
    // 与 md「失败预算与交付时限」同一处置：触顶后停止循环；续查通道只在该工具可见时点名。
    const budgetExhaustedLine = visibleTools.has("lucy_continue_question")
      ? "- When a data tool returns `question_budget_exhausted`, stop looping. If `continuable` is true, call `lucy_continue_question` once with the returned `continueToken` and then keep querying; a question can be continued only once. If `continuable` is false, deliver the verified partial results, state the gaps, and do not retry."
      : "- When a data tool returns `question_budget_exhausted`, stop looping, deliver the verified partial results, state the gaps, and do not retry.";
    return [
      "# Lucy Data QA Runtime Instructions",
      "",
      "- Use the Lucy MCP Proxy tool surface only; do not invent data when a data tool fails.",
      `- Call ${catalogTool} before choosing a connection or source unless the route is already explicit in the user request.`,
      "- Only use connections and sources listed in this session's visible scope.",
      "- If a query needs data, call `lucy_query` or `lucy_read_source`; do not answer from wiki-only context when data retrieval failed.",
      "- For simple factual questions, use the shortest verified path: catalog/source confirmation -> `lucy_query` -> answer. Do not call `entity_details` or `lucy_explain_query` before `lucy_query` unless the user asks for entity metadata or permission/guardrail diagnostics.",
      "- A successful `lucy_query` that returns zero fact rows carries a structured `next_step` inside the result JSON (and in `_meta.lucy.next_step`). Read it before retrying: it names the source, the filters you used, and the controlled next calls (`lucy_read_source`, `lucy_freshness`) to verify grain, period and filters. Do not substitute an approximation for the empty result.",
      ...ANSWER_VERIFIABILITY_INSTRUCTION_LINES,
      ...questionReportingLines,
      // D13：与 md 事实源同一 ASK_FIRST 片段（有可见 catalog 时也必须出现）
      ASK_FIRST_SECTION.trimEnd(),
      "",
      "- Answer simple numeric questions directly first, usually as a compact table, then add brief caveats/provenance. Do not turn ordinary fact lookups into long audit reports.",
      "- For multi-metric, multi-period, or multi-scenario questions, build an answerability dependency matrix before querying: numerator, denominator, period/grain, batch/version, actual/forecast/budget scenario, source/measure, and governed business definition. Mark a subquestion unavailable when a required dependency is missing; do not substitute an approximation.",
      "- Budget requires an independent budget measure, source, or governed formula. Never substitute forecast, target, or prior actual for budget. If budget evidence is missing, deliver the answerable parts and state that budget variance is currently unavailable.",
      "- Calculate and label actual, forecast, and budget separately. Any cross-scenario composition must be labeled hybrid with the covered periods for each component; do not assume the current quarter is complete actual without evidence.",
      "- revenue/quantity or revenue/bandwidth is realized unit price and includes mix effects. Do not claim pure price, volume, or mix contribution without a governed decomposition formula and the required grain.",
      "- Distinguish no fact row, NULL/blank source field, and values inferred from cumulative deltas. Do not collapse all three states into `—`.",
      "- If a key data tool call fails, the final answer must say whether a retry succeeded, whether the failure affects the conclusion, and which values remain uncertain. Do not give numeric conclusions when no successful fact data was returned.",
      "- Fingerprint failures by tool, source, normalized reason, and relevant argument shape. Retry the same fingerprint at most once and only with an information-gaining correction; cycling among eq, =, and in is not a correction.",
      // Spec lucy-20261111 SC-T4：数字取自代理实际执行的预算常量，避免与 md／运行时分叉。
      `- Per question, use at most ${QUESTION_BUDGET_MAX_CALLS} data-tool calls or ${QUESTION_BUDGET_MAX_BUSY_MS / 1000} seconds of settled data-processing time (thinking time excluded), whichever comes first. Repeat the same input at most once, do not re-read a successful source, and retry only transient errors once. Protocol methods (question declaration and continuation) do not count toward this budget.`,
      budgetExhaustedLine,
      "- Partial evidence still requires a final response. Give each subquestion an ok, no_data, unavailable, or partial status, plus period, batch/version, scenario, failure impact, and provenance.",
      "- When rows are missing, fields are NULL, a tool failed, or a value is inferred, qualify the answer with phrases such as 基于当前可查询数据 or 按累计差额推算; do not claim the data is complete or fully reconciled.",
      "- For `lucy_query`, use source-qualified semantic keys such as `source.measure`, `source.dimension`, and `source.segment`. Do not shorten them after an error; unqualified keys may be rejected by ACL before reaching the semantic layer.",
      "- In `lucy_query.measures`, use string semantic measure keys when the measure exists. Use `{expr,name}` objects only for ad hoc aggregate expressions.",
      "- In `lucy_query.dimensions` and `lucy_query.order_by`, use object entries such as `{field:\"source.field\"}`; do not use bare string arrays.",
      "- `lucy_query.filters` supports string filters and structured filters such as `{field:\"source.field\",op:\"contains\",value:\"<entity keyword>\"}`. Prefer semantic segments such as `source.segment` for common filters when available.",
      "- Some clients may serialize the whole `filters` value as JSON text; Lucy strictly restores that compatibility shape. Do not generate it deliberately. `orderBy` is accepted only as an alias for canonical `order_by`; conflicting aliases fail closed.",
      "- Interpret POC `DATE` / `DATETIME` values as Asia/Shanghai business dates when the visible source documentation says so.",
      `- Visible Scope below is captured at MCP initialize; call ${catalogTool} before routing if sources may have changed since this session started.`,
      ...skillSection,
      "",
      "## Visible Scope",
      "",
      `Connections: ${catalog.connections.join(", ") || "(none)"}`,
      "",
      "Sources:",
      ...(sourceLines.length > 0 ? sourceLines : ["- (none)"]),
      "",
      "## Query Examples",
      "",
      ...(exampleLines.length > 0 ? exampleLines : ["- Use the visible catalog and `lucy_read_source` to inspect the source before querying."])
    ].join("\n");
  } catch {
    return fallback;
  }
}

function instructionsInjectionEnabled(): boolean {
  return process.env.LUCY_ENABLE_INSTRUCTIONS_INJECTION !== "false";
}

function decodeSseMessages(body: string): unknown[] {
  const messages: unknown[] = [];
  for (const line of body.split(/\r?\n/)) {
    if (!line.startsWith("data: ")) continue;
    try {
      messages.push(JSON.parse(line.slice("data: ".length)));
    } catch {
      // skip malformed SSE data lines
    }
  }
  return messages;
}

/**
 * Pick the JSON-RPC *response* frame from a buffered SSE body.
 * Cursor / Claude Code Streamable HTTP clients often send progressToken;
 * KTX may emit notifications/progress before the id-matched result. Taking the
 * first `data:` line rewrites progress as the final response and clients wait
 * forever for an id-matched frame → MCP -32001 Request timed out.
 */
function decodeSseJsonRpcResponse(body: string, requestId?: string | number): unknown | undefined {
  const messages = decodeSseMessages(body);
  const responses = messages.filter((msg) => {
    if (!msg || typeof msg !== "object" || Array.isArray(msg)) return false;
    const record = msg as Record<string, unknown>;
    return "id" in record && ("result" in record || "error" in record);
  });
  if (requestId !== undefined) {
    const matched = responses.find((msg) => (msg as Record<string, unknown>).id === requestId);
    if (matched) return matched;
  }
  return responses.length > 0 ? responses[responses.length - 1] : undefined;
}

function decodeSseMessage(body: string, requestId?: string | number): unknown | undefined {
  return decodeSseJsonRpcResponse(body, requestId) ?? decodeSseMessages(body).at(-1);
}

/** Headers for a fully-buffered application/json MCP response.
 * Do not inherit KTX SSE framing headers — Streamable HTTP clients may hang
 * on finite SSE bodies. Keep mcp-session-id / protocol version for session affinity. */
function bufferedJsonHeaders(upstream: IncomingMessage): Record<string, string | string[] | number> {
  const headers: Record<string, string | string[] | number> = {
    "content-type": "application/json",
    "cache-control": "no-store"
  };
  const sessionId = upstream.headers["mcp-session-id"];
  const protocolVersion = upstream.headers["mcp-protocol-version"];
  if (sessionId !== undefined) headers["mcp-session-id"] = sessionId;
  if (protocolVersion !== undefined) headers["mcp-protocol-version"] = protocolVersion;
  return headers;
}

function passthroughBodyHeaders(upstream: IncomingMessage): Record<string, string | string[] | number> {
  const headers: Record<string, string | string[] | number> = {};
  for (const [k, v] of Object.entries(upstream.headers)) {
    const lower = k.toLowerCase();
    if (v !== undefined && lower !== "content-length" && lower !== "transfer-encoding" && lower !== "content-type") headers[k] = v;
  }
  headers["content-type"] = upstream.headers["content-type"] ?? "application/json";
  return headers;
}

/**
 * L25-16 — 控制面拒绝码中「**效果未发生**」的集合。
 *
 * 这些拒绝都发生在任何正式效果（文件写 / 幂等终态）之前，审计里必须记
 * `notExecuted` 而不是 `failed`——否则「授权通过但没写成」会被误读成「执行失败」。
 */
const OPS_NO_EFFECT_DENIAL_CODES = new Set<string>([
  "tool_not_control_plane",
  "ops_agent_disabled",
  "ops_idempotency_key_required",
  "ops_plan_id_required",
  "ops_confirm_digest_required",
  "ops_grant_unmatched",
  "ops_owner_delegation_required",
  "ops_target_unresolvable",
  "ops_plan_not_found",
  "ops_plan_expired",
  "ops_plan_digest_mismatch",
  "ops_plan_actor_mismatch",
  "ops_plan_tool_mismatch",
  "ops_confirm_digest_mismatch",
  "ops_plan_blocked",
  "ops_plan_target_set_mismatch",
  "ops_plan_param_target_mismatch",
  "ops_group_subset_incomplete",
  "ops_idempotency_conflict",
  "ops_idempotency_actor_mismatch",
  "ops_operation_recovery_required",
  "ops_operation_pending_activation",
  "ops_operation_in_flight",
  "ops_operation_scope_mismatch",
  "ops_state_corrupt",
  "ops_claim_failed"
]);

async function readSemanticRecoveryDenial(
  toolArgs: unknown
): Promise<{ code: string; message: string } | null> {
  try {
    const projectRoot = await resolveProjectRoot();
    return await semanticRecoveryReadBlock(projectRoot, semanticReadHintsFromArgs(toolArgs));
  } catch {
    return {
      code: "semantic_recovery_unreadable",
      message: "语义恢复日志无法读取，涉及资产的读取和查询已关闭。"
    };
  }
}

function jsonRpcToolResult(requestId: string | number, text: string, options: { isError?: boolean } = {}): string {
  return JSON.stringify({
    jsonrpc: "2.0",
    id: requestId,
    result: {
      ...(options.isError ? { isError: true } : {}),
      content: [{ type: "text", text }]
    }
  });
}

/**
 * Hive bridge 的响应类型（由 `resolveAndMaybeServeHiveTool` 推导，避免与
 * `server/hive/**` 的定义漂移）。
 */
type HiveServeResponse = Extract<
  Awaited<ReturnType<typeof resolveAndMaybeServeHiveTool>>,
  { action: "serve_hive" }
>["response"];

/**
 * Hive bridge 响应 → 可审计的 payload。
 *
 * `HiveMcpBridgeResponse` 有两个分支：`handled:true`（带 `payload`）与
 * `handled:false`（`missing_compiled_sql`，**没有** payload）。后者在编译
 * SQL 为空时真的会返回（`handleHiveMcpTool`），直接读 `.payload` 得到
 * `undefined`，下一行 `payload.ok` 就会抛 TypeError —— 所以这里收窄成与
 * `error` 分支一致的失败 payload。
 */
function hiveBridgePayload(response: HiveServeResponse): Record<string, unknown> {
  if (response.handled) return response.payload;
  return {
    ok: false,
    reason: response.reason,
    detail: "Hive execution requires compiled SQL; none was produced for this call",
    jdbcInvokeCount: 0,
    dialect: "hive"
  };
}

/**
 * L25-10 execution wave — after Lucy ACL, divert Hive connections away from KTX.
 * Returns true when the response was already written.
 */
async function maybeWriteHiveDivertedResponse(input: {
  identity: Identity;
  toolName: HiveExecutionTool;
  toolArgs: unknown;
  requestId: string | number;
  res: ServerResponse;
  start: number;
  requestMeta: Record<string, unknown>;
  argsSummary?: Record<string, unknown>;
  queryMeta: Record<string, unknown>;
  queryTables: string[];
  traceId: string;
  /** P0-4：改写前口径快照与门禁 pin 证据（仅 lucy_query 成功路径消费）。 */
  argsBeforeRewrite?: Record<string, unknown>;
  requestPinnedCaliber?: RequestPinnedCaliberEvidence;
  sourceSelection?: SourceSelectionDisclosure;
  forcedFilters?: unknown;
  /**
   * 审计写入回调 —— 由 `handlePost` 传入。
   *
   * traceId 只在 `rpcMethod === "tools/call"` 时补齐（Spec 173 v0.3 /
   * 2026-10-19 audit-trust），而 `rpcMethod` 只有 `handlePost` 知道；本函数
   * 在模块作用域，拿不到它，因此审计写入必须由调用方回调。
   */
  recordAuditEntry: (entry: Parameters<typeof writeLog>[0]) => void;
}): Promise<boolean> {
  const projectRoot = await resolveProjectRoot();
  const connectionId = firstConnectionIdFromArgs(input.toolArgs);
  const args =
    input.toolArgs && typeof input.toolArgs === "object" && !Array.isArray(input.toolArgs)
      ? (input.toolArgs as Record<string, unknown>)
      : {};
  // Strat-B DRAIN：Hive 分流亦计入上游语义在途，供 beginAdmissionDrain 有界排空。
  const trackHiveUpstream = requestWouldHitUpstreamSemanticExecution(input.toolName);
  if (trackHiveUpstream) trackUpstreamSemanticEnter();
  let decision: Awaited<ReturnType<typeof resolveAndMaybeServeHiveTool>>;
  try {
    decision = await resolveAndMaybeServeHiveTool({
      projectRoot,
      tool: input.toolName,
      connectionId,
      args,
      correlationId: typeof input.requestId === "string" ? input.requestId : String(input.requestId)
    });
  } finally {
    if (trackHiveUpstream) trackUpstreamSemanticLeave();
  }
  if (decision.action === "passthrough_ktx") return false;

  let payload: Record<string, unknown> =
    decision.action === "error"
      ? {
          ok: false,
          reason: decision.reason,
          detail: decision.detail,
          jdbcInvokeCount: 0,
          dialect: "hive"
        }
      : hiveBridgePayload(decision.response);

  // REQ-030-012 / SC-21 — Hive lucy_read_source 成功载荷列裁剪（与 KTX 下行共用 field-exposure-discovery）。
  // 解析／裁剪失败 → fail-closed，禁止原文透传全量 columns（D22）。
  if (input.toolName === "lucy_read_source" && payload.ok !== false) {
    try {
      const { trimDiscoveryPayload } = await import("./field-exposure-discovery.js");
      const sourceName = firstStringValue(args, [
        "sourceName",
        "source_name",
        "source",
        "table"
      ]);
      const trimmed = await trimDiscoveryPayload({
        toolName: "lucy_read_source",
        payload,
        connectionId: connectionId ?? undefined,
        schema: firstStringValue(args, ["schema"]),
        sourceName,
        carrierKind: "hive_columns"
      });
      if (!trimmed.ok) {
        payload = {
          ok: false,
          reason: trimmed.reason,
          detail: "field exposure discovery trim failed",
          jdbcInvokeCount:
            typeof payload.jdbcInvokeCount === "number" ? payload.jdbcInvokeCount : 0,
          dialect: "hive"
        };
      } else if (trimmed.payload && typeof trimmed.payload === "object" && !Array.isArray(trimmed.payload)) {
        payload = trimmed.payload as Record<string, unknown>;
      }
    } catch {
      payload = {
        ok: false,
        reason: "field_exposure_unavailable",
        detail: "field exposure discovery trim failed",
        jdbcInvokeCount:
          typeof payload.jdbcInvokeCount === "number" ? payload.jdbcInvokeCount : 0,
        dialect: "hive"
      };
    }
  }

  const isError = payload.ok === false;
  let responseBody = jsonRpcToolResult(input.requestId, JSON.stringify(payload, null, 2), { isError });
  let hiveAvFailedReason: string | undefined;
  // P0-4／SC-17 — Hive 成功 lucy_query 必须投影可核对块（禁止旁路静默无块）。
  if (!isError && input.toolName === "lucy_query") {
    const sourceRefs = await extractSourceRefs(input.toolName, input.toolArgs).catch(() => []);
    const applied = applyAnswerVerifiabilityToLucyQuery({
      originalEnvelopeWire: responseBody,
      enrichedEnvelope: JSON.parse(responseBody) as unknown,
      requestId: input.requestId,
      sourceRefs,
      argsBeforeRewrite: input.argsBeforeRewrite
        ?? (input.toolArgs && typeof input.toolArgs === "object" && !Array.isArray(input.toolArgs)
          ? input.toolArgs as Record<string, unknown>
          : {}),
      requestPinnedCaliber: input.requestPinnedCaliber ?? { status: "none" },
      systemConstraints: systemConstraintsFromForcedFilters(input.forcedFilters),
      sourceSelection: input.sourceSelection
    });
    if (!applied.ok) {
      hiveAvFailedReason = applied.reason;
      responseBody = buildAnswerVerifiabilityErrorEnvelope({
        requestId: input.requestId,
        reason: applied.reason,
        detail: "detail" in applied ? applied.detail : undefined
      });
    } else {
      responseBody = applied.finalWire;
    }
  }
  input.res.writeHead(200, {
    "content-type": "application/json",
    "content-length": Buffer.byteLength(responseBody)
  });
  input.res.end(responseBody);

  const jdbcInvokeCount =
    typeof payload.jdbcInvokeCount === "number" ? payload.jdbcInvokeCount : 0;
  const hiveOutcomeError = isError || Boolean(hiveAvFailedReason);
  input.recordAuditEntry({
    ts: new Date().toISOString(),
    userId: input.identity.userId,
    client: input.identity.client,
    tool: input.toolName,
    tables: input.queryTables.length > 0 ? input.queryTables : undefined,
    argsSummary: input.argsSummary,
    ...input.queryMeta,
    outcome: hiveOutcomeError ? "error" : "ok",
    decisionReason: hiveAvFailedReason
      ?? (isError && typeof payload.reason === "string" ? payload.reason : undefined),
    errorDetail: hiveAvFailedReason
      ?? (isError && typeof payload.detail === "string" ? payload.detail : undefined),
    executionEvidence: executionEvidenceFromObservation({
      authorizationAllowed: true,
      ...(hiveOutcomeError
        ? jdbcInvokeCount > 0 || hiveAvFailedReason
          ? { failed: true }
          : { notExecuted: true }
        : { executed: true })
    }),
    durationMs: Date.now() - input.start,
    responseBytes: Buffer.byteLength(responseBody),
    requestId: input.requestId,
    ...input.requestMeta,
    ...(await auditMeta(
      input.identity,
      hiveAvFailedReason
        ?? (isError && typeof payload.reason === "string" ? payload.reason : "allowed")
    ))
  });
  recordMcpTraceForTool({
    traceId: input.traceId,
    identity: input.identity,
    toolName: input.toolName,
    status: hiveOutcomeError ? "error" : "ok",
    startedAt: new Date(input.start).toISOString(),
    turnId: (input.requestMeta.lucyTurnId as string | null | undefined) ?? null,
    sessionId: (input.requestMeta.lucySessionId as string | null | undefined) ?? null,
    requestId: input.requestId,
    argsSummary: input.argsSummary,
    allowed: !hiveOutcomeError,
    reason:
      hiveAvFailedReason
      ?? (isError && typeof payload.reason === "string" ? payload.reason : "allowed"),
    policySource: "other"
  });
  return true;
}

function firstStringValue(record: Record<string, unknown> | undefined, keys: string[]): string | undefined {
  if (!record) return undefined;
  for (const key of keys) {
    const value = record[key];
    if (typeof value === "string" && value.trim()) return value;
  }
  return undefined;
}

function wikiKeyFromArgs(args: unknown): string | undefined {
  if (!args || typeof args !== "object" || Array.isArray(args)) return undefined;
  return firstStringValue(args as Record<string, unknown>, ["key", "path", "page", "slug", "uri", "id"]);
}

function wikiQueryFromArgs(args: unknown): { query?: string; limit: number } {
  if (!args || typeof args !== "object" || Array.isArray(args)) return { limit: 10 };
  const record = args as Record<string, unknown>;
  const query = firstStringValue(record, ["query", "q", "text", "keyword"]);
  const rawLimit = record.limit;
  const limit = typeof rawLimit === "number" && Number.isFinite(rawLimit)
    ? Math.min(20, Math.max(1, Math.floor(rawLimit)))
    : 10;
  return { query, limit };
}

function wikiKeyFromResult(item: Record<string, unknown>): string | undefined {
  return firstStringValue(item, ["path", "filePath", "file", "uri", "key", "page", "slug", "id"]);
}

/**
 * Spec 162 §7.7 / SC-11 — recover candidate wiki keys from a prose block so a
 * plain-text `wiki_search` answer is filtered by role instead of rejected as
 * `unparseable_text`.
 */
function extractWikiKeysFromText(text: string): string[] {
  const keys = new Set<string>();
  const pattern = /(?:wiki\/)?(?:global\/)?[\p{L}\p{N}_./-]*[\p{L}\p{N}_-]+\.md/gu;
  for (const match of text.matchAll(pattern)) {
    const raw = match[0].replace(/^wiki\//, "");
    if (raw.length > 3) keys.add(raw);
  }
  return [...keys];
}

async function filterWikiResultArray(identity: Identity, items: unknown[]): Promise<{ items: unknown[]; filtered: number; sawWikiKeys: boolean }> {
  const output: unknown[] = [];
  let filtered = 0;
  let sawWikiKeys = false;
  for (const item of items) {
    if (!item || typeof item !== "object" || Array.isArray(item)) {
      output.push(item);
      continue;
    }
    const record = item as Record<string, unknown>;
    const rawKey = wikiKeyFromResult(record);
    if (!rawKey) {
      output.push(item);
      continue;
    }
    sawWikiKeys = true;
    const { decision, page } = await canAccessWikiKey(identity, rawKey, "discover");
    if (!decision.allowed || !page) {
      filtered += 1;
      continue;
    }
    output.push({ ...record, key: page.key, displayPath: page.key });
  }
  return { items: output, filtered, sawWikiKeys };
}

async function filterWikiSearchObject(identity: Identity, value: unknown): Promise<{ value: unknown; filtered: number; sawWikiKeys: boolean }> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return { value, filtered: 0, sawWikiKeys: false };
  const record = value as Record<string, unknown>;
  const rewritten: Record<string, unknown> = { ...record };
  let filtered = 0;
  let sawWikiKeys = false;
  for (const key of ["results", "items", "pages", "matches", "hits"]) {
    const nested = record[key];
    if (!Array.isArray(nested)) continue;
    const result = await filterWikiResultArray(identity, nested);
    rewritten[key] = result.items;
    filtered += result.filtered;
    sawWikiKeys = sawWikiKeys || result.sawWikiKeys;
  }
  return { value: rewritten, filtered, sawWikiKeys };
}

/** Only a successful, explicitly empty search can use canonical keyword fallback. */
function wikiSearchPayloadIsEmpty(payload: unknown): boolean {
  const rpc = payload as { error?: unknown; result?: Record<string, unknown> } | undefined;
  if (!rpc?.result || rpc.error || rpc.result.isError) return false;
  const sizes: number[] = [];
  const collect = (value: unknown) => {
    if (Array.isArray(value)) { sizes.push(value.length); return; }
    if (!value || typeof value !== "object") return;
    const record = value as Record<string, unknown>;
    for (const key of ["results", "items", "pages", "matches", "hits"]) {
      if (Array.isArray(record[key])) sizes.push((record[key] as unknown[]).length);
    }
  };
  collect(rpc.result);
  collect(rpc.result.structuredContent);
  if (Array.isArray(rpc.result.content)) for (const item of rpc.result.content) {
    if (typeof item?.text !== "string") continue;
    try { collect(JSON.parse(item.text)); } catch { /* Prose is not proof of an empty search. */ }
  }
  return sizes.length > 0 && sizes.every((size) => size === 0);
}

async function filterWikiSearchPayload(identity: Identity, payload: unknown): Promise<{ payload: unknown; filtered: number; failed?: string }> {
  if (!payload || typeof payload !== "object") return { payload, filtered: 0, failed: "wiki_search_filter_failed:non_object_payload" };
  const record = payload as Record<string, unknown>;
  const result = record.result as Record<string, unknown> | undefined;
  if (!result || typeof result !== "object") return { payload, filtered: 0, failed: "wiki_search_filter_failed:missing_result" };

  const rewrittenResult: Record<string, unknown> = { ...result };
  let filtered = 0;
  let sawWikiKeys = false;

  for (const key of ["results", "items", "pages", "matches", "hits"]) {
    const nested = result[key];
    if (!Array.isArray(nested)) continue;
    const arrayResult = await filterWikiResultArray(identity, nested);
    rewrittenResult[key] = arrayResult.items;
    filtered += arrayResult.filtered;
    sawWikiKeys = sawWikiKeys || arrayResult.sawWikiKeys;
  }

  if (Array.isArray(result.content)) {
    const content: unknown[] = [];
    for (const item of result.content) {
      if (!item || typeof item !== "object" || Array.isArray(item)) {
        content.push(item);
        continue;
      }
      const contentRecord = item as Record<string, unknown>;
      if (typeof contentRecord.text !== "string" || !contentRecord.text.trim()) {
        content.push(item);
        continue;
      }
      try {
        const parsedText = JSON.parse(contentRecord.text) as unknown;
        const textResult = Array.isArray(parsedText)
          ? await filterWikiResultArray(identity, parsedText).then((value) => ({ value: value.items, filtered: value.filtered, sawWikiKeys: value.sawWikiKeys }))
          : await filterWikiSearchObject(identity, parsedText);
        filtered += textResult.filtered;
        sawWikiKeys = sawWikiKeys || textResult.sawWikiKeys;
        content.push({ ...contentRecord, text: JSON.stringify(textResult.value, null, 2) });
      } catch {
        // Spec 162 §7.7 / SC-11 — a non-JSON content block is prose, not a
        // parse failure. Scan it for wiki keys the role cannot read; keep the
        // original text and never answer `unparseable_text`.
        const keysInText = extractWikiKeysFromText(contentRecord.text);
        if (keysInText.length === 0) {
          content.push(contentRecord);
          continue;
        }
        const dropped = new Set<string>();
        for (const key of keysInText) {
          const { decision, page } = await canAccessWikiKey(identity, key, "discover");
          if (decision.allowed && page) continue;
          filtered += 1;
          sawWikiKeys = true;
          dropped.add(key);
        }
        if (dropped.size === 0) {
          content.push(contentRecord);
          continue;
        }
        const redacted = [...dropped].reduce(
          (text, key) => text.split(key).join("[wiki_not_authorized]"),
          contentRecord.text
        );
        content.push({ ...contentRecord, text: redacted });
      }
    }
    rewrittenResult.content = content;
  }

  if (result.structuredContent && typeof result.structuredContent === "object" && !Array.isArray(result.structuredContent)) {
    const structured = await filterWikiSearchObject(identity, result.structuredContent);
    rewrittenResult.structuredContent = structured.value;
    filtered += structured.filtered;
    sawWikiKeys = sawWikiKeys || structured.sawWikiKeys;
  }

  if (!sawWikiKeys && filtered === 0) return { payload: { ...record, result: rewrittenResult }, filtered };
  return { payload: { ...record, result: rewrittenResult }, filtered };
}

function rpcErrorResponse(requestId: string | number, message: string, reason: string): Record<string, unknown> {
  return {
    jsonrpc: "2.0",
    id: requestId,
    error: {
      code: -32003,
      message,
      data: { reason }
    }
  };
}

/** Spec §4.4 — identical external text for unauthorized / unknown / draft / deprecated context objects. */
function contextExternalReason(internalReason: string | undefined): string {
  return internalReason === "context_role_required" ? CONTEXT_ROLE_REQUIRED : CONTEXT_NOT_AVAILABLE;
}

function contextUnavailableRpc(requestId: string | number, internalReason: string | undefined): Record<string, unknown> {
  const reason = contextExternalReason(internalReason);
  return rpcErrorResponse(requestId, reason, reason);
}

function upstreamFailureReason(error: unknown): "source_timeout" | "upstream_unavailable" {
  const message = error instanceof Error ? error.message : String(error);
  return /timeout/i.test(message) ? "source_timeout" : "upstream_unavailable";
}

function toolConnectionId(args: unknown): string | undefined {
  if (!args || typeof args !== "object" || Array.isArray(args)) return undefined;
  return firstStringField(args as Record<string, unknown>, ["connectionId", "connection_id", "connection"]);
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function collectTextValues(value: unknown, output: string[], depth = 0): void {
  if (depth > 8 || output.length >= 100) return;
  if (typeof value === "string") {
    output.push(value);
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) collectTextValues(item, output, depth + 1);
    return;
  }
  if (!value || typeof value !== "object") return;
  for (const item of Object.values(value as Record<string, unknown>)) {
    collectTextValues(item, output, depth + 1);
  }
}

function containsConnectionMissingError(body: string, connectionId: string): boolean {
  const escaped = escapeRegExp(connectionId);
  const pattern = new RegExp(`Connection\\s+["']${escaped}["']\\s+is not configured in ktx\\.yaml`, "i");
  const candidates = [body];
  try {
    collectTextValues(JSON.parse(body), candidates);
  } catch {
    for (const payload of decodeSseMessages(body)) collectTextValues(payload, candidates);
  }
  return candidates.some((candidate) => pattern.test(candidate));
}

async function classifyUpstreamToolError(body: string, args: unknown): Promise<string> {
  const connectionId = toolConnectionId(args);
  if (!connectionId || !containsConnectionMissingError(body, connectionId)) return "upstream_error";
  try {
    const projectRoot = await resolveProjectRoot();
    const project = await readProject(projectRoot);
    if (!project.connections.some((connection) => connection.id === connectionId)) {
      return "upstream_error";
    }
    recordExecutionRuntimeObservation({
      connectionId,
      configDigest: await readKtxYamlDigest(projectRoot),
      status: "stale",
      checkedAt: new Date().toISOString(),
      detail: `Connection "${connectionId}" is present on disk but missing from the KTX MCP Runtime.`
    });
    return "execution_config_stale";
  } catch {
    return "upstream_error";
  }
}

async function recordSuccessfulQueryObservation(toolName: string, args: unknown): Promise<void> {
  if (toolName !== "lucy_query") return;
  const connectionId = toolConnectionId(args);
  if (!connectionId) return;
  try {
    const projectRoot = await resolveProjectRoot();
    recordExecutionRuntimeObservation({
      connectionId,
      configDigest: await readKtxYamlDigest(projectRoot),
      status: "ok",
      checkedAt: new Date().toISOString()
    });
  } catch {
    // Runtime acknowledgement is best-effort and must never affect a query response.
  }
}

/** KTX rejects session traffic that arrives before a successful `initialize`
 * with a plain-text 400. Matching the text is the only signal available: the
 * rejection happens in KTX's transport layer, outside the JSON-RPC envelope. */
// P1-37 O6 取证（2026-11-17，KTX 0.16.0 真实重启）：失效会话＝404 `Unknown MCP session: <id>`
// （text/plain，对 tools/list、tools/call、ping、notifications 一致）；无会话＝400 `initialize request is required`。
const UPSTREAM_SESSION_REQUIRED_RE = /initialize request is required|unknown mcp session/i;
const UPSTREAM_BODY_EXCERPT_MAX = 200;

export type UpstreamFailureReason = "upstream_session_required" | "upstream_protocol_error";

type UpstreamFailure = {
  reason: UpstreamFailureReason;
  upstreamStatus: number;
  errorDetail: string;
  responseBody: string;
};

function isJsonRpcShaped(payload: unknown): boolean {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) return false;
  const record = payload as Record<string, unknown>;
  return "result" in record || "error" in record;
}

function decodeUpstreamPayload(body: string, contentType: string, requestId: string | number): unknown | undefined {
  try {
    if (contentType.includes("text/event-stream")) return decodeSseMessage(body, requestId);
    if (contentType.includes("application/json")) return JSON.parse(body);
  } catch {
    return undefined;
  }
  return undefined;
}

/**
 * Turn a session refusal into a self-diagnosing message.
 *
 * A bare status code made callers guess, and the guess observed in the field was
 * "the database cannot be queried" — the session never came up. These say which
 * side is missing the header, since that decides who fixes what.
 */
function sessionRequiredHint(session: UpstreamSessionState | undefined): string {
  if (session?.clientSupplied) {
    return "The Mcp-Session-Id your client sent is not an established upstream session. Re-run initialize and use the Mcp-Session-Id from that response.";
  }
  if (session?.handshakeAttempted) {
    return "Your client did not send Mcp-Session-Id, so Lucy tried to establish the upstream session itself and the upstream refused the handshake. This is an upstream fault, not a client one.";
  }
  return "No upstream MCP session is established. Retain the Mcp-Session-Id header returned by initialize and send it on every later request.";
}

/** The upstream body stays in the audit trail only — client-facing errors carry
 * a reason code, status and session diagnostics, never raw upstream text
 * (Spec 07 §6.1). */
function upstreamErrorResponse(
  requestId: string | number,
  failure: Omit<UpstreamFailure, "responseBody">,
  session: UpstreamSessionState | undefined
): string {
  const sessionRequired = failure.reason === "upstream_session_required";
  return JSON.stringify({
    jsonrpc: "2.0",
    id: requestId,
    error: {
      code: -32003,
      message: "KTX upstream rejected the request",
      data: {
        reason: failure.reason,
        upstreamStatus: failure.upstreamStatus,
        hint: sessionRequired ? sessionRequiredHint(session) : undefined,
        session: sessionRequired && session
          ? {
            clientSuppliedSessionId: session.clientSupplied,
            gatewayHeldSession: session.gatewaySupplied,
            handshakeAttempted: session.handshakeAttempted
          }
          : undefined
      }
    }
  });
}

/**
 * Classify a failed upstream response so it never reaches the client verbatim.
 *
 * KTX signals transport faults as `text/plain` with a 4xx status. Forwarding
 * that status and body unchanged gives MCP clients something they cannot parse
 * as JSON-RPC, and the audit sniff (which only parses JSON) silently recorded
 * the call as `ok`. Returns undefined when the body already carries a usable
 * JSON-RPC envelope — those keep their own error shape.
 */
function classifyUpstreamFailure(
  statusCode: number | undefined,
  contentType: string,
  body: string,
  requestId: string | number,
  session?: UpstreamSessionState
): UpstreamFailure | undefined {
  const upstreamStatus = statusCode ?? 200;
  if (upstreamStatus < 400) return undefined;
  if (isJsonRpcShaped(decodeUpstreamPayload(body, contentType, requestId))) return undefined;
  const bodyExcerpt = body.trim().slice(0, UPSTREAM_BODY_EXCERPT_MAX);
  const reason: UpstreamFailureReason = UPSTREAM_SESSION_REQUIRED_RE.test(body)
    ? "upstream_session_required"
    : "upstream_protocol_error";
  const partial = {
    reason,
    upstreamStatus,
    errorDetail: `${reason}:upstream_status=${upstreamStatus}${bodyExcerpt ? `;body=${bodyExcerpt}` : ""}`
  };
  return { ...partial, responseBody: upstreamErrorResponse(requestId, partial, session) };
}

/** True when KTX refused the request because no upstream session exists. */
function isSessionRequiredFailure(
  statusCode: number | undefined,
  contentType: string,
  body: string,
  requestId: string | number
): boolean {
  return classifyUpstreamFailure(statusCode, contentType, body, requestId)?.reason === "upstream_session_required";
}

function ensureJsonRpcEnvelope(payload: unknown, requestId: string | number): unknown {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) return payload;
  const record = payload as Record<string, unknown>;
  if (!("result" in record) && !("error" in record)) return payload;
  return {
    ...record,
    jsonrpc: typeof record.jsonrpc === "string" ? record.jsonrpc : "2.0",
    id: record.id ?? requestId
  };
}

function firstStringField(record: Record<string, unknown>, fields: string[]): string | undefined {
  for (const field of fields) {
    const value = record[field];
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return undefined;
}

function firstFieldValue(record: Record<string, unknown>, fields: string[]): unknown {
  for (const field of fields) {
    if (record[field] !== undefined) return record[field];
  }
  return undefined;
}

function boundedProvenanceValue(value: unknown, depth = 0): unknown {
  if (value === null || value === undefined) return value;
  if (typeof value === "string") return value.length > 500 ? `${value.slice(0, 500)}...` : value;
  if (typeof value === "number" || typeof value === "boolean") return value;
  if (depth >= 4) return "[omitted]";
  if (Array.isArray(value)) return value.slice(0, 20).map((item) => boundedProvenanceValue(item, depth + 1));
  if (typeof value !== "object") return String(value);
  const output: Record<string, unknown> = {};
  for (const [key, item] of Object.entries(value as Record<string, unknown>).slice(0, 30)) {
    output[key] = boundedProvenanceValue(item, depth + 1);
  }
  return output;
}

function appliedLucyVersion(
  toolName: string,
  argsRecord: Record<string, unknown>,
  sourceRefs: SourceRef[]
): { appliedVersion: string; businessDate: string; valueKind: "实际" | "预测" } | undefined {
  if (toolName !== "lucy_query") return undefined;
  const sourceName = publishedSourceName(argsRecord, sourceRefs[0]?.sourceName);
  const applied = resolveAppliedVersion(
    { version: firstStringField(argsRecord, ["version", "appliedVersion"]) },
    lookupPublishedVersion(sourceName)
  );
  if (!applied) return undefined;
  return {
    appliedVersion: applied.version,
    businessDate: applied.businessDate,
    valueKind: applied.valueKind
  };
}

/** Spec D13／R3 — 先判定再权限／注入；status 必须是实际上游 HTTP。禁止 ?? 200。 */
function isEmptyResultNextStepEligible(input: {
  status: number | undefined;
  result: { isError?: unknown } | null | undefined;
  toolName: string;
  rowCount: number | null | undefined;
}): boolean {
  const { status, result, toolName, rowCount } = input;
  if (typeof status !== "number" || !Number.isFinite(status) || status >= 400) return false;
  if (result?.isError === true) return false;
  if (toolName !== "lucy_query") return false;
  return typeof rowCount === "number" && Number.isFinite(rowCount) && rowCount === 0;
}

/** Walk JSON text and collect number literals outside of strings (D15). */
function extractJsonNumberTokens(text: string): string[] {
  const tokens: string[] = [];
  let i = 0;
  let inString = false;
  let escape = false;
  while (i < text.length) {
    const ch = text[i]!;
    if (inString) {
      if (escape) {
        escape = false;
        i += 1;
        continue;
      }
      if (ch === "\\") {
        escape = true;
        i += 1;
        continue;
      }
      if (ch === "\"") inString = false;
      i += 1;
      continue;
    }
    if (ch === "\"") {
      inString = true;
      i += 1;
      continue;
    }
    const startsNumber =
      (ch >= "0" && ch <= "9")
      || ((ch === "-" || ch === "+") && i + 1 < text.length && text[i + 1]! >= "0" && text[i + 1]! <= "9");
    if (!startsNumber) {
      i += 1;
      continue;
    }
    let j = i;
    if (text[j] === "-" || text[j] === "+") j += 1;
    while (j < text.length && text[j]! >= "0" && text[j]! <= "9") j += 1;
    if (j < text.length && text[j] === ".") {
      j += 1;
      while (j < text.length && text[j]! >= "0" && text[j]! <= "9") j += 1;
    }
    if (j < text.length && (text[j] === "e" || text[j] === "E")) {
      j += 1;
      if (j < text.length && (text[j] === "+" || text[j] === "-")) j += 1;
      while (j < text.length && text[j]! >= "0" && text[j]! <= "9") j += 1;
    }
    tokens.push(text.slice(i, j));
    i = j;
  }
  return tokens;
}

function isNumberTokenFidelitySafe(token: string): boolean {
  const n = Number(token);
  if (!Number.isFinite(n)) return false;
  if (/^[-+]?\d+$/.test(token)) {
    try {
      if (BigInt(token) !== BigInt(Math.trunc(n))) return false;
    } catch {
      return false;
    }
  }
  if (n === 0) {
    const isZeroLiteral = /^[-+]?0(\.0+)?([eE][-+]?0+)?$/.test(token);
    if (!isZeroLiteral) return false;
  }
  return true;
}

function rawNumericTokensFidelitySafe(text: string): boolean {
  return extractJsonNumberTokens(text).every(isNumberTokenFidelitySafe);
}

function originalNumberTokensUnchanged(original: string, candidate: string): boolean {
  const orig = extractJsonNumberTokens(original);
  const cand = extractJsonNumberTokens(candidate);
  let i = 0;
  for (const token of cand) {
    if (i < orig.length && token === orig[i]) i += 1;
  }
  return i === orig.length;
}

/**
 * D15 — insert `"next_step":…` into a JSON object string without rewriting
 * existing number literals. Returns null when the text is not a single object.
 */
function injectNextStepPreservingNumberTokens(text: string, nextStep: NextStep): string | null {
  const trimmedEnd = text.replace(/\s+$/, "");
  const trailingWs = text.slice(trimmedEnd.length);
  const end = trimmedEnd.lastIndexOf("}");
  if (end < 0) return null;
  const open = trimmedEnd.indexOf("{");
  if (open < 0 || open > end) return null;
  const before = trimmedEnd.slice(0, end).replace(/\s+$/, "");
  const inner = before.slice(open + 1).trim();
  const fragment = `"next_step":${JSON.stringify(nextStep)}`;
  return `${before}${inner.length > 0 ? "," : ""}${fragment}}${trailingWs}`;
}

function fidelitySafeStringify(
  parsed: Record<string, unknown>,
  nextStep: NextStep
): string | null {
  try {
    return JSON.stringify({ ...parsed, next_step: nextStep });
  } catch {
    return null;
  }
}

/**
 * P0-4 — 在 Spec 162／018 富化之后投影 answer_verifiability。
 * 仅 HTTP 200 且 `isError !== true` 的成功查数产块（D6／B-OK）；
 * 上游错误／4xx／5xx 不产块（B-UPSTREAM-ERR）；装配失败返回错误信封。
 */
function projectLucyQueryAnswerVerifiability(input: {
  originalEnvelopeWire: string;
  enriched: unknown;
  requestId: string | number;
  sourceRefs: SourceRef[];
  upstreamHttpStatus: number | undefined;
  options: {
    argsBeforeRewrite?: Record<string, unknown>;
    requestPinnedCaliber?: RequestPinnedCaliberEvidence;
    sourceSelection?: SourceSelectionDisclosure;
    forcedFilters?: unknown;
  };
}): string | null {
  // D6：成功查数不变量只约束 HTTP 200；禁止对 4xx／5xx 假造可核对块或改写成装配失败。
  if (input.upstreamHttpStatus !== 200) return null;
  const enriched = input.enriched;
  if (!enriched || typeof enriched !== "object" || Array.isArray(enriched)) return null;
  const result = (enriched as Record<string, unknown>).result;
  if (!result || typeof result !== "object" || Array.isArray(result)) return null;
  if ((result as Record<string, unknown>).isError === true) return null;

  const applied = applyAnswerVerifiabilityToLucyQuery({
    originalEnvelopeWire: input.originalEnvelopeWire,
    enrichedEnvelope: enriched,
    requestId: input.requestId,
    sourceRefs: input.sourceRefs,
    argsBeforeRewrite: input.options.argsBeforeRewrite ?? {},
    requestPinnedCaliber: input.options.requestPinnedCaliber ?? { status: "none" },
    systemConstraints: systemConstraintsFromForcedFilters(input.options.forcedFilters),
    sourceSelection: input.options.sourceSelection
  });
  if (!applied.ok) {
    // P0-5 共存：AV 错误信封必须保留 018 已写入的 next_step／skipped_reason。
    return buildAnswerVerifiabilityErrorEnvelope({
      requestId: input.requestId,
      reason: applied.reason,
      detail: "detail" in applied ? applied.detail : undefined,
      lucy018: extractLucy018PreserveFields(input.enriched)
    });
  }
  return applied.finalWire;
}

/**
 * P0-4／D6／C2 — lucy_query 成功判定路径必须产块或 B-ASSEMBLE；
 * 禁止 `if (originalEnvelopeWire)` 旁路导致静默无块。
 * 错误信封走 `buildAnswerVerifiabilityErrorEnvelope`＋lucy018，与 018 共存兼容。
 */
function applyLucyQueryAnswerVerifiabilityOrFailClosed(input: {
  toolName: string;
  originalEnvelopeWire: string | undefined;
  enriched: unknown;
  requestId: string | number;
  sourceRefs: SourceRef[];
  upstreamHttpStatus: number | undefined;
  options: {
    argsBeforeRewrite?: Record<string, unknown>;
    requestPinnedCaliber?: RequestPinnedCaliberEvidence;
    sourceSelection?: SourceSelectionDisclosure;
    forcedFilters?: unknown;
  };
  currentBody: string;
}): string {
  if (input.toolName !== "lucy_query") return input.currentBody;
  if (input.upstreamHttpStatus !== 200) return input.currentBody;

  const enriched = input.enriched;
  if (enriched && typeof enriched === "object" && !Array.isArray(enriched)) {
    const result = (enriched as Record<string, unknown>).result;
    if (
      result
      && typeof result === "object"
      && !Array.isArray(result)
      && (result as Record<string, unknown>).isError === true
    ) {
      return input.currentBody; // B-UPSTREAM-ERR：不产块
    }
  }

  if (!input.originalEnvelopeWire) {
    return buildAnswerVerifiabilityErrorEnvelope({
      requestId: input.requestId,
      reason: "answer_verifiability_assemble_failed",
      detail: "missing_original_envelope_wire",
      lucy018: extractLucy018PreserveFields(input.enriched)
    });
  }

  const avBody = projectLucyQueryAnswerVerifiability({
    originalEnvelopeWire: input.originalEnvelopeWire,
    enriched: input.enriched,
    requestId: input.requestId,
    sourceRefs: input.sourceRefs,
    upstreamHttpStatus: input.upstreamHttpStatus,
    options: input.options
  });
  if (avBody) return avBody;
  // 成功判定路径上投影器仍返回 null（畸形信封等）→ 禁止静默无块。
  return buildAnswerVerifiabilityErrorEnvelope({
    requestId: input.requestId,
    reason: "answer_verifiability_assemble_failed",
    detail: "answer_verifiability_projection_unavailable",
    lucy018: extractLucy018PreserveFields(input.enriched)
  });
}

function withLucyResultMeta(
  payload: unknown,
  requestId: string | number,
  toolName: string,
  args: unknown,
  sourceRefs: SourceRef[],
  visibleTools: readonly string[] = [],
  originalUserFilters: unknown = undefined,
  scopeIntersectionEmpty = false,
  upstreamHttpStatus: number
): unknown {
  const enveloped = ensureJsonRpcEnvelope(payload, requestId);
  if (!enveloped || typeof enveloped !== "object" || Array.isArray(enveloped)) return enveloped;
  const record = enveloped as Record<string, unknown>;
  const result = record.result;
  if (!result || typeof result !== "object" || Array.isArray(result)) return enveloped;
  const resultRecord = result as Record<string, unknown>;
  const existingMeta = resultRecord._meta && typeof resultRecord._meta === "object" && !Array.isArray(resultRecord._meta)
    ? resultRecord._meta as Record<string, unknown>
    : {};
  const argsRecord = args && typeof args === "object" && !Array.isArray(args) ? args as Record<string, unknown> : {};
  const filters = firstFieldValue(argsRecord, ["filters", "filter", "where"]);
  const segments = firstFieldValue(argsRecord, ["segments"]);
  const orderBy = firstFieldValue(argsRecord, ["orderBy", "order_by"]);
  const inspectedResult = inspectRowsAndColumns(resultRecord);
  const responseTruncated = findBooleanFlag(resultRecord, "truncated");
  // Spec 162 §7.5 — success rows always report 0 or 1; hitting the row cap
  // forces 1 and attaches the aggregate repair hint.
  const truncation = toolName === "lucy_query"
    ? resolveResponseTruncated({
      upstreamTruncated: responseTruncated,
      rowCount: inspectedResult.rows ?? null,
      rowCap: numericLimit(argsRecord.limit)
    })
    : null;
  const effectiveTruncated = truncation ? truncation.responseTruncated === 1 : responseTruncated;

  const provenance = {
    connectionId: firstStringField(argsRecord, ["connectionId", "connection_id", "connection"]) ?? null,
    sourceName: firstStringField(argsRecord, ["sourceName", "source_name", "source", "table"]) ?? sourceRefs[0]?.sourceName ?? null,
    measures: boundedProvenanceValue(firstFieldValue(argsRecord, ["measures"])) ?? null,
    dimensions: boundedProvenanceValue(firstFieldValue(argsRecord, ["dimensions"])) ?? null,
    filters: boundedProvenanceValue(filters) ?? null,
    segments: boundedProvenanceValue(segments) ?? null,
    orderBy: boundedProvenanceValue(orderBy) ?? null,
    sourceResolution: sourceRefs.length > 0 ? "acl_source_map" : "none",
    freshness: {
      status: "not_checked",
      tool: "lucy_freshness",
      note: "Call lucy_freshness for metadata freshness before presenting freshness-sensitive answers."
    },
    truncation: responseTruncated === undefined
      ? "unknown; upstream did not expose a truncated flag"
      : "reported from upstream response"
  };

  // D13／R3：先判定再权限／注入。禁止 (upstreamHttpStatus ?? 200)。
  const eligible = isEmptyResultNextStepEligible({
    status: upstreamHttpStatus,
    result: resultRecord,
    toolName,
    rowCount: inspectedResult.rows
  });

  let lucyNextStep: NextStep | undefined;
  let nextStepSkippedReason: string | undefined;

  if (!eligible) {
    if (resultRecord.isError === true && toolName === "lucy_query" && inspectedResult.rows === 0) {
      nextStepSkippedReason = "result_is_error";
    }
  } else {
    const nextStepProvenance: Record<string, unknown> = { ...provenance };
    delete nextStepProvenance.filters;
    const nextStep = buildEmptyResultNextStep({
      toolName,
      rowCount: inspectedResult.rows ?? null,
      scopeIntersectionEmpty,
      provenance: nextStepProvenance,
      filtersSummary: originalUserFilters === undefined ? null : summarizeFilters(originalUserFilters),
      visibleTools
    });
    if (nextStep) {
      const content = Array.isArray(resultRecord.content) ? resultRecord.content : [];
      const first = content[0] as { type?: string; text?: string } | undefined;
      const originalText = first && typeof first.text === "string" ? first.text : undefined;
      let parsed: Record<string, unknown> | undefined;
      if (originalText !== undefined) {
        try {
          const maybe = JSON.parse(originalText) as unknown;
          if (maybe && typeof maybe === "object" && !Array.isArray(maybe)) {
            parsed = maybe as Record<string, unknown>;
          }
        } catch {
          parsed = undefined;
        }
      }
      const structuredIsObject =
        resultRecord.structuredContent
        && typeof resultRecord.structuredContent === "object"
        && !Array.isArray(resultRecord.structuredContent);
      if (!parsed || originalText === undefined) {
        nextStepSkippedReason = originalText !== undefined
          ? "content_text_not_json_object"
          : "content_text_absent";
      } else if (Object.prototype.hasOwnProperty.call(parsed, "next_step")) {
        nextStepSkippedReason = "upstream_next_step_present";
      } else if (
        structuredIsObject
        && Object.prototype.hasOwnProperty.call(resultRecord.structuredContent as object, "next_step")
      ) {
        nextStepSkippedReason = "upstream_next_step_present";
      } else if (!rawNumericTokensFidelitySafe(originalText)) {
        nextStepSkippedReason = "content_json_number_not_fidelity_safe";
      } else {
        const candidateText =
          injectNextStepPreservingNumberTokens(originalText, nextStep)
          ?? fidelitySafeStringify(parsed, nextStep);
        if (
          candidateText == null
          || !originalNumberTokensUnchanged(originalText, candidateText)
        ) {
          nextStepSkippedReason = "content_json_number_not_fidelity_safe";
        } else {
          first!.text = candidateText;
          if (structuredIsObject) {
            resultRecord.structuredContent = {
              ...(resultRecord.structuredContent as Record<string, unknown>),
              next_step: nextStep
            };
          }
          lucyNextStep = nextStep;
        }
      }
    }
  }

  return {
    ...record,
    result: {
      ...resultRecord,
      _meta: {
        ...existingMeta,
        lucy: {
          contract: "lucy-r1-controlled-data-service",
          tool: toolName,
          upstreamTool: toolName === "lucy_query" ? "sl_query" : "sl_read_source",
          sources: sourceRefs,
          guardrails: {
            rawSqlAllowed: false,
            writeOperationsAllowed: false,
            defaultLimit: LUCY_QUERY_DEFAULT_LIMIT,
            maxLimit: LUCY_QUERY_MAX_LIMIT,
            maxConcurrentQueries: queryConcurrencyLimit(),
            effectiveLimit: toolName === "lucy_query" ? numericLimit(argsRecord.limit) : undefined
          },
          result: {
            rowCount: inspectedResult.rows ?? null,
            columnCount: inspectedResult.columns ?? null,
            truncated: effectiveTruncated ?? null
          },
          ...(truncation?.repair ? { repair: truncation.repair } : {}),
          ...(lucyNextStep ? { next_step: lucyNextStep } : {}),
          ...(nextStepSkippedReason ? { next_step_skipped_reason: nextStepSkippedReason } : {}),
          ...(appliedLucyVersion(toolName, argsRecord, sourceRefs) ?? {}),
          provenance
        }
      }
    }
  };
}

function filterAndAddAllowedTools(payload: unknown, visibleTools: Set<string>, requestId: string | number): unknown {
  if (!payload || typeof payload !== "object") return payload;
  const record = payload as Record<string, unknown>;
  const result = record.result as Record<string, unknown> | undefined;
  if (!result || !Array.isArray(result.tools)) return payload;
  const localTools = localToolBuilders()
    .filter((local) => visibleTools.has(local.name))
    .map((local) => ({ name: local.name, tool: local.build() }));
  const localToolByName = new Map(localTools.map((entry) => [entry.name, entry.tool]));
  const seenNames = new Set<string>();
  const filteredTools = result.tools.flatMap((tool) => {
    if (!tool || typeof tool !== "object") return [];
    const name = (tool as Record<string, unknown>).name;
    if (typeof name !== "string" || !visibleTools.has(name)) return [];
    const localTool = localToolByName.get(name);
    seenNames.add(name);
    return [localTool ?? tool];
  });
  const injected = localTools
    .filter((entry) => !seenNames.has(entry.name))
    .map((entry) => entry.tool);
  const tools = [...filteredTools, ...injected];
  return {
    ...record,
    jsonrpc: typeof record.jsonrpc === "string" ? record.jsonrpc : "2.0",
    id: record.id ?? requestId,
    result: {
      ...result,
      tools
    }
  };
}

/**
 * Emit a classified upstream failure as JSON-RPC and record it as an error.
 *
 * Both were previously wrong for KTX's plain-text 4xx: the raw status and body
 * were forwarded to the client, and the audit sniff only parsed JSON so the
 * call was stored with `outcome=ok` and an `errorDetail` about result
 * enrichment rather than the rejection.
 */
async function writeUpstreamFailureResponse(
  failure: UpstreamFailure,
  context: {
    identity: Identity;
    upstream: IncomingMessage;
    res: ServerResponse;
    requestId: string | number;
    toolName: string;
    start: number;
    requestMeta: Partial<Parameters<typeof writeLog>[0]>;
    argsSummary: Record<string, unknown> | undefined;
    queryMeta: Partial<Parameters<typeof writeLog>[0]>;
    tables: string[];
    sourceRefs: SourceRef[];
    traceId: string;
  }
): Promise<void> {
  const responseBytes = Buffer.byteLength(failure.responseBody);
  context.res.writeHead(200, {
    ...bufferedJsonHeaders(context.upstream),
    "content-length": responseBytes
  });
  context.res.end(failure.responseBody);
  // Spec 173 v0.3 / 2026-10-19 audit-trust: attribution is frozen at admission (line 3004-3014 below).
  // No re-resolution at write time; effective_* and original_* must already be set on requestMeta.
  // bindOpenSessionTurn(...) removed; the binding helpers (bindPriorSessionCalls + the
  // admission-time resolve at /mcp tools/call) own the post-begin binding policy.

  recordAudit({
    ts: new Date().toISOString(),
    userId: context.identity.userId,
    client: context.identity.client,
    tool: context.toolName,
    tables: context.tables.length > 0 ? context.tables : undefined,
    argsSummary: context.argsSummary,
    ...context.queryMeta,
    outcome: "error",
    errorDetail: failure.errorDetail,
    durationMs: Date.now() - context.start,
    responseBytes,
    requestId: context.requestId,
    traceId: context.traceId,
    ...context.requestMeta,
    ...(await auditMeta(context.identity, failure.reason)),
  }, context.sourceRefs);
  recordMcpTraceForTool({
    traceId: context.traceId,
    identity: context.identity,
    toolName: context.toolName,
    status: "error",
    startedAt: new Date(context.start).toISOString(),
    turnId: context.requestMeta.lucyTurnId ?? null,
    sessionId: context.requestMeta.lucySessionId ?? null,
    requestId: context.requestId,
    argsSummary: context.argsSummary,
    allowed: true,
    reason: failure.reason,
    policySource: "other"
  });
}

async function writeLucySemanticResponse(
  identity: Identity,
  upstream: IncomingMessage,
  upstreamBody: string,
  res: ServerResponse,
  requestId: string | number,
  toolName: string,
  toolArgs: unknown,
  start: number,
  requestMeta: Partial<Parameters<typeof writeLog>[0]>,
  argsSummary: Record<string, unknown> | undefined,
  queryMeta: Partial<Parameters<typeof writeLog>[0]>,
  queryTables: string[],
  traceId: string,
  session: UpstreamSessionState | undefined,
  options: {
    scopeIntersectionEmpty?: boolean;
    originalUserFilters?: unknown;
    argsBeforeRewrite?: Record<string, unknown>;
    requestPinnedCaliber?: RequestPinnedCaliberEvidence;
    sourceSelection?: SourceSelectionDisclosure;
    forcedFilters?: unknown;
  } = {}
): Promise<void> {
  const originalBody = upstreamBody;
  const contentType = String(upstream.headers["content-type"] ?? "");
  const sourceRefs = await extractSourceRefs(toolName, toolArgs).catch(() => []);
  // Spec 20261107 D13／R3／N1 — 实际上游 HTTP；必为 number；禁止 ?? 200。
  // status 缺失／非有限 → NaN，使 isEmptyResultNextStepEligible 失败（不得冒充 200）。
  const rawUpstreamStatus = upstream.statusCode;
  const upstreamHttpStatus =
    typeof rawUpstreamStatus === "number" && Number.isFinite(rawUpstreamStatus)
      ? rawUpstreamStatus
      : Number.NaN;
  const upstreamFailure = classifyUpstreamFailure(upstream.statusCode, contentType, originalBody, requestId, session);
  if (upstreamFailure) {
    await writeUpstreamFailureResponse(upstreamFailure, {
      identity,
      upstream,
      res,
      requestId,
      toolName,
      start,
      requestMeta,
      argsSummary,
      queryMeta,
      tables: [...new Set([...sourceRefs.map((ref) => ref.physicalTable), ...queryTables])],
      sourceRefs,
      traceId
    });
    return;
  }
  let body = originalBody;
  let metaFailed: string | undefined;
  let compilerReason: string | undefined;
  let preservedGeneratedSql: string | undefined;
  // Buffered tools/call responses are always normalized to application/json when
  // rewrite succeeds. Re-emitting a finite SSE frame with Content-Length +
  // keep-alive causes Streamable HTTP clients (Cursor / Claude Code) to wait for
  // stream end and surface MCP -32001 Request timed out even though KTX finished.
  let forceJson = false;

  try {
    const enrichWithNextStep = async (payload: unknown): Promise<unknown> => {
      const enveloped = ensureJsonRpcEnvelope(payload, requestId);
      const resultRecord =
        enveloped
        && typeof enveloped === "object"
        && !Array.isArray(enveloped)
        && (enveloped as Record<string, unknown>).result
        && typeof (enveloped as Record<string, unknown>).result === "object"
        && !Array.isArray((enveloped as Record<string, unknown>).result)
          ? ((enveloped as Record<string, unknown>).result as Record<string, unknown>)
          : undefined;
      const inspectedEarly = inspectRowsAndColumns(resultRecord ?? payload);
      // Spec 20261107 D13／D5／R2-02／R3 —— 统一成功判定通过后才求值。
      // 顺序：isEmptyResultNextStepEligible → allowedToolNames → build／注入。
      const shouldResolveVisibleTools = isEmptyResultNextStepEligible({
        status: upstreamHttpStatus,
        result: resultRecord,
        toolName,
        rowCount: inspectedEarly.rows
      });
      const visibleTools = shouldResolveVisibleTools
        ? await allowedToolNames(identity).catch(() => [] as string[])
        : ([] as string[]);
      return withLucyResultMeta(
        payload,
        requestId,
        toolName,
        toolArgs,
        sourceRefs,
        visibleTools,
        options.originalUserFilters,
        options.scopeIntersectionEmpty === true,
        upstreamHttpStatus
      );
    };

    const originalEnvelopeWire = contentType.includes("text/event-stream")
      ? extractSseJsonRpcResponseRaw(originalBody, requestId)
      : contentType.includes("application/json")
        ? originalBody
        : undefined;

    if (contentType.includes("text/event-stream")) {
      const payload = decodeSseMessage(originalBody, requestId);
      if (!payload) throw new Error("missing SSE data frame");
      const enriched = await enrichWithNextStep(payload);
      body = JSON.stringify(enriched);
      forceJson = true;
      // P0-4／SC-21／C2 — SSE 最终写回与 JSON 同一装配合同；缺 raw → B-ASSEMBLE。
      body = applyLucyQueryAnswerVerifiabilityOrFailClosed({
        toolName,
        originalEnvelopeWire,
        enriched,
        requestId,
        sourceRefs,
        upstreamHttpStatus,
        options,
        currentBody: body
      });
    } else if (contentType.includes("application/json")) {
      const enriched = await enrichWithNextStep(JSON.parse(originalBody));
      body = JSON.stringify(enriched);
      forceJson = true;
      body = applyLucyQueryAnswerVerifiabilityOrFailClosed({
        toolName,
        originalEnvelopeWire,
        enriched,
        requestId,
        sourceRefs,
        upstreamHttpStatus,
        options,
        currentBody: body
      });
    } else {
      throw new Error(`unsupported content-type:${contentType || "<missing>"}`);
    }
  } catch (err) {
    metaFailed = `lucy_result_meta_failed:${err instanceof Error ? err.message : String(err)}`;
    // REQ-030-012 / D22 — 发现面裁剪失败路径禁止原文透传；meta 失败时对 read_source 亦 fail-closed。
    if (toolName === "lucy_read_source") {
      body = JSON.stringify({
        jsonrpc: "2.0",
        id: requestId,
        result: {
          isError: true,
          content: [{ type: "text", text: "field_exposure_unavailable" }]
        }
      });
      forceJson = true;
    } else if (toolName === "lucy_query" && upstreamHttpStatus === 200) {
      // P0-4／D6／B-ASSEMBLE — HTTP 200 成功查数路径禁止回落原文静默无块。
      body = buildAnswerVerifiabilityErrorEnvelope({
        requestId,
        reason: "answer_verifiability_assemble_failed",
        detail: metaFailed
      });
      forceJson = true;
    } else {
      body = originalBody;
    }
  }

  // REQ-030-012 — lucy_read_source 下行列裁剪（与 Hive 共用 field-exposure-discovery）。
  if (toolName === "lucy_read_source" && !metaFailed) {
    try {
      const { trimDiscoveryPayload } = await import("./field-exposure-discovery.js");
      const argsRecord = toolArgs && typeof toolArgs === "object" && !Array.isArray(toolArgs)
        ? (toolArgs as Record<string, unknown>)
        : {};
      const primary = sourceRefs[0];
      const parsedBody = JSON.parse(body) as unknown;
      const trimmed = await trimDiscoveryPayload({
        toolName,
        payload: parsedBody,
        connectionId:
          (typeof argsRecord.connectionId === "string" ? argsRecord.connectionId : undefined) ??
          primary?.connectionId,
        schema: primary?.schema,
        sourceName:
          (typeof argsRecord.sourceName === "string"
            ? argsRecord.sourceName
            : typeof argsRecord.source === "string"
              ? argsRecord.source
              : undefined) ?? primary?.sourceName,
        carrierKind: "read_source_columns"
      });
      if (!trimmed.ok) {
        body = JSON.stringify({
          jsonrpc: "2.0",
          id: requestId,
          result: {
            isError: true,
            content: [{ type: "text", text: trimmed.reason }]
          }
        });
        forceJson = true;
      } else {
        body = JSON.stringify(trimmed.payload);
        forceJson = true;
      }
    } catch {
      body = JSON.stringify({
        jsonrpc: "2.0",
        id: requestId,
        result: {
          isError: true,
          content: [{ type: "text", text: "field_exposure_unavailable" }]
        }
      });
      forceJson = true;
    }
  }

  if (toolName === "lucy_query" && filterPushdownGuardEnabled() && isFilterPushdownText(body)) {
    let originalParsed: unknown;
    try {
      originalParsed = JSON.parse(originalBody);
    } catch {
      originalParsed = undefined;
    }
    const sql = extractSqlFromToolResult(originalParsed);
    compilerReason = "filter_pushdown";
    preservedGeneratedSql = sql?.trim() ? sql : undefined;
    const visible = new Set(sourceRefs.map((ref) => ref.sourceName).filter((name): name is string => Boolean(name)));
    // B15：过滤下推的修复提示同样要走可用性闭环 —— 只推荐真实存在、
    // 主体可见、语义可编译且参数形态合法的来源。
    const { evidence: pushdownEvidence } = await collectRepairEvidence({
      toolArgs: (toolArgs ?? undefined) as Record<string, unknown> | undefined,
      candidateSources: [...visible],
      visibleSources: visible,
      callable: true,
      knownExisting: visible
    });
    const pushdownClosure = buildRepairClosure({
      failureDimension: "过滤条件下推",
      candidates: pushdownEvidence,
      availableCandidates: [...visible]
    });
    const hint =
      (pushdownClosure.usableTargets.length > 0
        ? repairHint(
            { failureDimension: "过滤条件下推", suggestedSources: pushdownClosure.usableTargets },
            visible
          )
        : null) ??
      (pushdownClosure.usableTargets.length === 0 && pushdownClosure.rejected.length > 0
        ? pushdownClosure.text
        : null) ??
      "这次过滤条件无法下推。请改成等值、包含或枚举条件后再查。";
    body = JSON.stringify({
      jsonrpc: "2.0",
      id: requestId,
      result: {
        isError: true,
        content: [{ type: "text", text: hint }]
      }
    });
    forceJson = true;
  }

  const headers = forceJson ? bufferedJsonHeaders(upstream) : passthroughBodyHeaders(upstream);
  const responseBytes = Buffer.byteLength(body);
  headers["content-length"] = responseBytes;
  res.writeHead(upstream.statusCode ?? 200, headers);
  res.end(body);

  // A 4xx/5xx that still carries a JSON-RPC envelope keeps its own body, but the
  // audit row must reflect the failure rather than the enrichment outcome.
  const upstreamStatus = upstream.statusCode ?? 200;
  let outcome: "ok" | "error" = upstreamStatus >= 400 ? "error" : "ok";
  let errorDetail = upstreamStatus >= 400
    ? `upstream_status=${upstreamStatus}${metaFailed ? `;${metaFailed}` : ""}`
    : metaFailed;
  let parsedBody: Record<string, unknown> | undefined;
  try {
    const parsed = (!metaFailed || contentType.includes("application/json"))
      ? JSON.parse(body) as Record<string, unknown>
      : decodeSseMessage(body) as Record<string, unknown> | undefined;
    parsedBody = parsed;
    const parsedError = parsed?.error;
    const parsedResult = parsed?.result as Record<string, unknown> | undefined;
    if (parsedError || parsedResult?.isError) {
      outcome = "error";
      errorDetail = errorDetail ?? JSON.stringify(parsedError ?? parsedResult?.content);
    }
  } catch {
    // audit remains best-effort
  }

  const structuredTables = sourceRefs.map((ref) => ref.physicalTable);
  const tables = [...new Set([...structuredTables, ...queryTables])];
  const effectiveRowCap = toolName === "lucy_query"
    ? numericLimit((toolArgs as Record<string, unknown> | undefined)?.limit)
    : undefined;
  const responseMeta = responseAuditMeta(Buffer.from(body), headers["content-type"], {
    toolName,
    rowCap: effectiveRowCap
  });
  const decisionReason = compilerReason
    ? "filter_pushdown"
    : outcome === "ok"
      ? (metaFailed
        ? "lucy_result_meta_failed"
        : (options.scopeIntersectionEmpty ? "scope_intersection_empty" : "allowed"))
      : await classifyUpstreamToolError(originalBody, toolArgs);
  if (outcome === "ok" && !compilerReason) {
    await recordSuccessfulQueryObservation(toolName, toolArgs);
  }
  // Spec 173 v0.3: attribution frozen at admission; no re-resolution at write time.
  const argsRecord = toolArgs && typeof toolArgs === "object" && !Array.isArray(toolArgs) ? toolArgs as Record<string, unknown> : {};
  const applied = compilerReason ? undefined : appliedLucyVersion(toolName, argsRecord, sourceRefs);
  const failureDimension = compilerReason
    ? "过滤条件下推"
    : classifyFailure({ outcome, decisionReason, errorDetail });
  // ─── 执行凭据（D1 / L25-09 §4.3(a) 第 9 行）─────────────────────────────
  // 上游响应**已被真实读取并解析**（上面的 JSON.parse / decodeSseMessage 已
  // 判定 `outcome`），因此这里登记的是观测到的事实，不是由 outcome 反推的
  // 结论：解析成功且无 error 信封 → 执行成功；解析到 error 信封或上游 4xx/5xx
  // → 执行已发生但失败。
  //
  // ⚠️ 编译器改写下推失败（compilerReason）时请求**未真正执行**，因此只记
  // `notExecuted`，不记 `failed` —— 那是入参/语义失败而非执行失败。
  const upstreamExecutionEvidence = executionEvidenceFromObservation(
    compilerReason
      ? { notExecuted: true, authorizationAllowed: true }
      : outcome === "ok"
        ? { executed: true, authorizationAllowed: true }
        : { failed: true, authorizationAllowed: true }
  );
  // Spec 162 §8 / SC-20 — the new slow mark and the empty-result flag are
  // decided at write time so every consumer reads the same verdict.
  const slowVerdict = isSlowCall({ tool: toolName, durationMs: Date.now() - start });
  const baseEntry: Parameters<typeof writeLog>[0] = {
    ts: new Date().toISOString(),
    userId: identity.userId,
    client: identity.client,
    tool: toolName,
    tables: tables.length > 0 ? tables : undefined,
    argsSummary,
    ...queryMeta,
    ...generatedSqlAuditFields(toolName, preservedGeneratedSql ? { result: { sql: preservedGeneratedSql } } : parsedBody),
    outcome,
    errorDetail,
    compilerReason,
    failureDimension: failureDimension || undefined,
    executionEvidence: upstreamExecutionEvidence,
    isSlowCall: slowVerdict.slow,
    slowBasis: slowVerdict.basis ?? undefined,
    resultEmpty: isEmptyResult({ outcome, responseRowCount: responseMeta.responseRowCount ?? null }),
    appliedVersion: applied?.appliedVersion,
    appliedBusinessDate: applied?.businessDate,
    appliedValueKind: applied?.valueKind,
    durationMs: Date.now() - start,
    ...responseMeta,
    requestId,
    traceId,
    ...requestMeta,
    ...(await auditMeta(identity, withUpstreamSessionNote(decisionReason, session))),
  };
  recordAudit(baseEntry, sourceRefs);
  recordMcpTraceForTool({
    traceId,
    identity,
    toolName,
    status: outcome,
    startedAt: new Date(start).toISOString(),
    turnId: requestMeta.lucyTurnId ?? null,
    sessionId: requestMeta.lucySessionId ?? null,
    requestId,
    argsSummary,
    allowed: true,
    reason: withUpstreamSessionNote(decisionReason, session),
    resultSnapshot: resultSnapshotFromAuditMeta(responseMeta),
    sourceRefs: sourceRefs.length > 0 ? sourceRefs : null
  });
}

/**
 * B15：收集 repairHint 的可用性证据。
 *
 * 五项检查：真实 Schema（对象存在性）、主体可见性、编译能力（语义模型
 * 完成度）、参数形态、可调用性。
 *
 * **不发真实数据查询**：只读 Schema 清单与语义完成度元数据。
 * Schema 证据不可得时返回 `schemaEvidenceAvailable=false`，由调用方决定
 * 降级方式（提示是建议性的，不是权限裁决）。
 */
async function collectRepairEvidence(input: {
  toolArgs: Record<string, unknown> | undefined;
  candidateSources: readonly string[];
  visibleSources: ReadonlySet<string>;
  callable: boolean;
  /** 已知存在的候选（由真实查询解析出来的来源）。 */
  knownExisting?: ReadonlySet<string>;
}): Promise<{ evidence: RepairTargetEvidence[]; schemaEvidenceAvailable: boolean }> {
  const evidence: RepairTargetEvidence[] = [];
  let schemaByName: Map<string, { compiled: boolean; measureCount: number }> | null = null;
  try {
    const projectRoot = await resolveProjectRoot();
    const sources = await listSources(projectRoot, { skipAuthorizedCounts: true });
    schemaByName = new Map(
      sources.map((source) => [
        source.table,
        {
          // `done` / `partial` = 语义模型可编译；`not_started` / `validation_failed` = 不可编译。
          compiled: source.completion === "done" || source.completion === "partial",
          measureCount: source.measureCount
        }
      ])
    );
  } catch {
    schemaByName = null;
  }
  const rawMeasures = input.toolArgs?.measures;
  const measures = Array.isArray(rawMeasures)
    ? rawMeasures.filter((item): item is string => typeof item === "string")
    : [];
  for (const target of input.candidateSources) {
    const schema = schemaByName?.get(target);
    const schemaExists =
      schemaByName === null
        ? input.knownExisting?.has(target)
          ? true
          : null
        : schema !== undefined || Boolean(input.knownExisting?.has(target));
    evidence.push({
      target,
      schemaExists,
      visibleToPrincipal: input.visibleSources.has(target),
      compiled: schema?.compiled ?? Boolean(input.knownExisting?.has(target)),
      // 请求了度量时，目标必须真的定义了度量，否则参数形态不合法。
      parameterShapeValid: measures.length === 0 ? true : (schema?.measureCount ?? 0) > 0,
      callable: input.callable
    });
  }
  return { evidence, schemaEvidenceAvailable: schemaByName !== null };
}

function toolsListErrorResponse(requestId: string | number, detail: string): Record<string, unknown> {
  return {
    jsonrpc: "2.0",
    id: requestId,
    error: {
      code: -32003,
      message: "tools/list filtering failed",
      data: { reason: detail }
    }
  };
}

/**
 * Spec 178 / T1 — a role-compile failure must surface on `tools/list` as a
 * 403, not as a successful empty `tools: []` body.
 *
 * The admission gate already rejects ghost / disabled / revoked / expired
 * Agents and roles whose YAML declared body is missing; this matcher only
 * covers the *post-admission* compile failures that `effectivePermissions`
 * reports. Order matches Spec 177's `compileRole` / `effectivePermissions`
 * reasons exactly.
 */
const COMPILE_DENIAL_PREFIXES = [
  "role_resolution_failed",
  "source_map_compile_failed"
] as const;

function isToolsListCompileDenialReason(reason: string | undefined): boolean {
  if (!reason) return false;
  if (reason === "policy_degraded_deny") return true;
  return COMPILE_DENIAL_PREFIXES.some((prefix) => reason.startsWith(prefix));
}

/**
 * Spec 178 §2 — JSON-RPC envelope + HTTP 403. The outward message stays
 * consistent with the admission layer; only `role_resolution_failed` is
 * spelled as a bare class so the existing 403 tests keep matching.
 */
function compileDeniedToolsListEnvelope(
  requestId: string | number,
  reason: string
): { body: string; statusCode: number; message: string } {
  const message = reason.startsWith("role_resolution_failed")
    ? "Access denied: role_resolution_failed"
    : `Access denied: ${reason}`;
  return {
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: requestId,
      error: { code: -32003, message }
    }),
    statusCode: 403,
    message
  };
}

function localInitializePayload(requestId: string | number, instructions: string | undefined): Record<string, unknown> {
  return {
    jsonrpc: "2.0",
    id: requestId,
    result: {
      protocolVersion: "2024-11-05",
      capabilities: {
        tools: { listChanged: false }
      },
      serverInfo: {
        name: "lucy-mcp-proxy",
        version: "local-fallback"
      },
      instructions: instructions ?? "Lucy MCP Proxy is available, but role-aware instructions could not be loaded."
    }
  };
}

async function localToolsListPayload(identity: Identity, requestId: string | number, sessionId?: string | null): Promise<Record<string, unknown>> {
  const visibleTools = new Set(await allowedToolNames(identity));
  // P1-60 D1: inactive / unknown 下不主动曝光 begin（Spec §4 伪代码）。
  if (await shouldHideBeginQuestion(identity, sessionId)) visibleTools.delete("lucy_begin_question");
  const tools = localToolBuilders()
    .filter((local) => visibleTools.has(local.name))
    .map((local) => local.build());
  return {
    jsonrpc: "2.0",
    id: requestId,
    result: { tools }
  };
}

async function writeToolsListResponse(
  identity: Identity,
  upstream: IncomingMessage,
  upstreamBody: string,
  res: ServerResponse,
  requestId: string | number,
  session: UpstreamSessionState | undefined,
  sessionId?: string | null
): Promise<{
  filterFailed: boolean;
  errorDetail?: string;
  responseBytes: number;
  upstreamFailure?: UpstreamFailureReason;
  compileDenied?: boolean;
}> {
  // Spec 178 / T1 — `effectivePermissions` compile failure wins over upstream /
  // filter / empty-list success. Checked first so the cached `result.tools: []`
  // path never reaches the client for a failed identity.
  const compiled = await effectivePermissions(identity).catch(() => null);
  if (compiled && !compiled.ok && isToolsListCompileDenialReason(compiled.reason)) {
    const envelope = compileDeniedToolsListEnvelope(requestId, compiled.reason);
    res.writeHead(envelope.statusCode, {
      "content-type": "application/json",
      "content-length": Buffer.byteLength(envelope.body)
    });
    res.end(envelope.body);
    return {
      filterFailed: true,
      errorDetail: compiled.reason,
      responseBytes: Buffer.byteLength(envelope.body),
      compileDenied: true
    };
  }

  const originalBody = upstreamBody;
  const contentType = String(upstream.headers["content-type"] ?? "");
  const upstreamFailure = classifyUpstreamFailure(upstream.statusCode, contentType, originalBody, requestId, session);
  if (upstreamFailure) {
    const responseBytes = Buffer.byteLength(upstreamFailure.responseBody);
    res.writeHead(200, {
      ...bufferedJsonHeaders(upstream),
      "content-length": responseBytes
    });
    res.end(upstreamFailure.responseBody);
    return {
      filterFailed: true,
      errorDetail: upstreamFailure.errorDetail,
      responseBytes,
      upstreamFailure: upstreamFailure.reason
    };
  }
  const visibleTools = new Set(await allowedToolNames(identity));
  // P1-60 D1: inactive / unknown 下不主动曝光 begin（Spec §4 伪代码）。
  if (await shouldHideBeginQuestion(identity, sessionId)) visibleTools.delete("lucy_begin_question");
  let body = originalBody;
  let filterFailed = false;
  let errorDetail: string | undefined;
  let forceJson = false;
  try {
    if (contentType.includes("text/event-stream")) {
      const payload = decodeSseMessage(originalBody, requestId);
      if (!payload) throw new Error("missing SSE data frame");
      body = JSON.stringify(filterAndAddAllowedTools(payload, visibleTools, requestId));
      forceJson = true;
    } else if (contentType.includes("application/json")) {
      body = JSON.stringify(filterAndAddAllowedTools(JSON.parse(originalBody), visibleTools, requestId));
      forceJson = true;
    } else {
      throw new Error(`unsupported content-type:${contentType || "<missing>"}`);
    }
  } catch (err) {
    filterFailed = true;
    errorDetail = `tools_list_filter_failed:${err instanceof Error ? err.message : String(err)}`;
    body = JSON.stringify(toolsListErrorResponse(requestId, errorDetail));
    forceJson = true;
  }

  if (!filterFailed) rememberToolsListNames(identity, body);
  const headers = forceJson ? bufferedJsonHeaders(upstream) : passthroughBodyHeaders(upstream);
  const responseBytes = Buffer.byteLength(body);
  headers["content-length"] = responseBytes;
  res.writeHead(upstream.statusCode ?? 200, headers);
  res.end(body);
  return { filterFailed, errorDetail, responseBytes };
}

/** P1-37 U2：记下本次真实下发给该身份的工具名，供未知工具名拒绝时作为可见清单。 */
function rememberToolsListNames(identity: Identity, servedBody: string): void {
  try {
    const parsed = JSON.parse(servedBody) as { result?: { tools?: Array<{ name?: unknown }> } };
    const names = (parsed.result?.tools ?? []).map((tool) => tool.name).filter((name): name is string => typeof name === "string");
    rememberObservedToolNames(identity.userId, identity.tokenHashPrefix ?? "", getPolicyRuntimeStatus().policyVersion, names);
  } catch {
    // 记录是尽力而为，不影响 tools/list 响应。
  }
}

// Rewrites the upstream `initialize` response so `result.instructions` is the
// proxy's data-QA guidance text. On ANY failure (parse error, missing result,
// unsupported content-type, instructions text not loaded) we pass the original
// upstream body through unchanged. This is deliberately fail-open: a buggy
// rewriter must not block MCP session establishment for every client.
async function writeInitializeResponse(
  identity: Identity,
  upstream: IncomingMessage,
  upstreamBody: string,
  res: ServerResponse,
  requestId: string | number,
  sessionId?: string | null
): Promise<{ injectionFailed: boolean; errorDetail?: string; responseBytes: number }> {
  const originalBody = upstreamBody;
  const contentType = String(upstream.headers["content-type"] ?? "");
  const instructions = await buildRoleAwareInstructions(identity, sessionId);
  const isSse = contentType.includes("text/event-stream");

  let body = originalBody;
  let injectionFailed = false;
  let errorDetail: string | undefined;
  let forceJson = false;

  if (!instructions) {
    injectionFailed = true;
    errorDetail = "instructions_text_unavailable";
  } else {
    try {
      if (isSse) {
        const payload = decodeSseMessage(originalBody, requestId);
        if (!payload) throw new Error("missing SSE data frame");
        const record = payload as Record<string, unknown>;
        const result = record.result as Record<string, unknown> | undefined;
        if (!result || typeof result !== "object") throw new Error("missing result object");
        const rewritten = ensureJsonRpcEnvelope({ ...record, result: { ...result, instructions } }, requestId);
        body = JSON.stringify(rewritten);
        forceJson = true;
      } else if (contentType.includes("application/json")) {
        const parsed = JSON.parse(originalBody) as Record<string, unknown>;
        const result = parsed.result as Record<string, unknown> | undefined;
        if (!result || typeof result !== "object") throw new Error("missing result object");
        const rewritten = ensureJsonRpcEnvelope({ ...parsed, result: { ...result, instructions } }, requestId);
        body = JSON.stringify(rewritten);
        forceJson = true;
      } else {
        throw new Error(`unsupported content-type:${contentType || "<missing>"}`);
      }
    } catch (err) {
      injectionFailed = true;
      errorDetail = `instructions_injection_failed:${err instanceof Error ? err.message : String(err)}`;
      body = originalBody;
    }
  }

  const headers = forceJson ? bufferedJsonHeaders(upstream) : passthroughBodyHeaders(upstream);
  const responseBytes = Buffer.byteLength(body);
  headers["content-length"] = responseBytes;
  res.writeHead(upstream.statusCode ?? 200, headers);
  res.end(body);
  return { injectionFailed, errorDetail, responseBytes };
}

async function handlePost(req: IncomingMessage, res: ServerResponse, admitted: AdmittedRequest): Promise<void> {
  const trace = new TraceRecorder({ traceId: `trace_${randomUUID()}` });
  const traceContext = new TraceRequestContext(trace);
  const evidence = resolveClientIpEvidence(req);
  traceContext.ipSource = evidence.ipSource;
  traceContext.trustedSource = evidence.trustedSource;
  traceContext.instrumentResponse(res);
  await runWithTrace(traceContext, () => handlePostTraced(req, res, admitted, trace, traceContext));
}

async function handlePostTraced(
  req: IncomingMessage,
  res: ServerResponse,
  admitted: AdmittedRequest,
  trace: TraceRecorder,
  traceContext: TraceRequestContext
): Promise<void> {
  const sessionId = normalizeHeader(req.headers["mcp-session-id"]);
  const explicitTurnId = normalizeHeader(req.headers["x-lucy-turn-id"]);
  const { identity, body } = admitted;
  const networkMeta = extractRequestClientMeta(req);
  const requestMeta: Partial<Parameters<typeof writeLog>[0]> = {
    ...correlationMeta(req.headers),
    clientIp: networkMeta.clientIp,
    // Spec 162 §8 / SC-22 — forwarded chain is recorded for display only and
    // never participates in ACL.
    clientForwardedFor: networkMeta.clientForwardedFor,
    userAgent: networkMeta.userAgent,
    // Runtime device name only — never fall back to YAML remark.
    ...(networkMeta.deviceName ? { deviceName: networkMeta.deviceName } : {})
  };
  const start = Date.now();
  const traceId = trace.traceId;

  let rpcMethod: string | undefined;
  let toolName: string | undefined;
  let toolArgs: unknown;
  let scopeIntersectionEmpty = false;
  // Spec 20261107 D6 —— 行策略谓词会在下面被前插进 filters。先快照**原始用户
  // filter**，next_step 只回显它（且去值），策略谓词与强制表达式一律不出现。
  let originalUserFilters: unknown;
  // P0-4 —— 改写前完整口径快照＋门禁当拍 pin 证据（随请求携带，禁止响应期重读）。
  let argsBeforeRewrite: Record<string, unknown> | undefined;
  let requestPinnedCaliber: RequestPinnedCaliberEvidence | undefined;
  // P1-35 v0.4 D13：门闩档②放行披露，随请求携带到 lucy_query 成功投影。
  let sourceSelectionForAv: SourceSelectionDisclosure | undefined;
  let forcedFiltersForAv: unknown;
  let requestId: string | number = "";
  let argsSummary: Record<string, unknown> | undefined;
  let queryMeta: Partial<Parameters<typeof writeLog>[0]> = {};
  let queryTables: string[] = [];
  let parsedRpc: Record<string, unknown> | undefined;
  let initializeClientInfo: { name: string; version?: string } | undefined;
  let queryNormalizationReason: string | undefined;
  // Spec 162 §6.2 / SC-13：在途上游请求句柄。客户端断开时据此取消上游。
  // 结算发生在取消确认（上游 close）或绝对执行时限，不发生在 res.close。
  let upstreamRequestHandle: ClientRequest | null = null;
  let cancelUpstreamOnCapture = false;
  const captureUpstreamRequest = (request: ClientRequest): void => {
    upstreamRequestHandle = request;
    if (!cancelUpstreamOnCapture || request.destroyed) return;
    try {
      request.destroy(new Error("client_disconnected"));
    } catch {
      // 句柄已经结束。
    }
  };
  // Spec 162 §6.2 / SC-13 / SC-14：结算事实（绝对执行时限到点、取消未确认、
  // 客户端断开）写进本次调用的审计行，不另开一行，避免污染四桶恒等式。
  const noteBudgetSettlement = (facts: Record<string, unknown>): void => {
    const previous = (argsSummary?.budgetSettlement ?? {}) as Record<string, unknown>;
    argsSummary = { ...(argsSummary ?? {}), budgetSettlement: { ...previous, ...facts } };
  };

  try {
    const parsed = JSON.parse(body.toString()) as Record<string, unknown>;
    parsedRpc = parsed;
    rpcMethod = parsed.method as string | undefined;
    traceContext.rpcMethod = rpcMethod;
    requestId = (parsed.id as string | number | undefined) ?? "";

    if (rpcMethod === "initialize") {
      const clientInfo = (parsed.params as Record<string, unknown> | undefined)?.clientInfo as Record<string, unknown> | undefined;
      if (clientInfo?.name) {
        const version = clientInfo.version != null ? String(clientInfo.version) : undefined;
        initializeClientInfo = { name: String(clientInfo.name), version };
        identity.client = initializeClientInfo.name;
        identity.clientVersion = version;
        if (sessionId) {
          setSessionClient(sessionId, identity.userId, identity.tokenLabel, initializeClientInfo.name, version);
        }
      }
    }

    if (rpcMethod === "tools/call") {
      const params = parsed.params as Record<string, unknown> | undefined;
      toolName = params?.name as string | undefined;
      if (toolName === "lucy_query" || toolName === "lucy_explain_query") {
        const normalized = canonicalizeLucyQueryArgs(params?.arguments, toolName);
        if (normalized.ok) {
          toolArgs = normalized.args;
        } else {
          toolArgs = params?.arguments;
          queryNormalizationReason = normalized.reason;
        }
      } else {
        toolArgs = params?.arguments;
      }
      if (toolArgs !== params?.arguments && params) {
        params.arguments = toolArgs;
      }
      const args = params?.arguments as Record<string, unknown> | undefined;
      if (args) {
        // Keep only a safe subset of args for logging (Spec 137 — no raw question)
        argsSummary = summarizeArgsForAudit(toolName, args);
      }
      traceContext.rejection = {
        identityId: identity.userId,
        tool: toolName ?? "",
        args: toolArgs ?? null,
        sessionScope: sessionId || "default"
      };
      const rawQueryAudit = queryAuditMeta(toolArgs, toolName);
      const { queryTables: extractedQueryTables, ...safeQueryMeta } = rawQueryAudit;
      queryMeta = safeQueryMeta;
      queryTables = extractedQueryTables ?? [];
    }
  } catch {
    // non-JSON body; proxy as-is
  }

  const recordRequestAudit = (
    entry: Parameters<typeof writeLog>[0],
    sources?: SourceRef[]
  ) => {
    // Spec 173 v0.3 / 2026-10-19 audit-trust: attribution is frozen at admission (line 3004-3014 below).
    // No re-resolution at write time. effective_* and original_* must already be set on entry.
    // The previous bindOpenSessionTurn(...) call here is撤销; do not re-introduce without T00-r2 contract change.
    const withTrace = rpcMethod === "tools/call" ? { ...entry, traceId } : entry;
    recordAudit(withTrace, sources);
  };

  const respondLocalWikiSearch = async (
    query: string | undefined,
    limit: number,
    results: Awaited<ReturnType<typeof searchAccessibleWikiPages>>,
    upstreamError?: string
  ): Promise<void> => {
    // P1-36 §6.2：上游失败后本地回退须同时留下 upstream_call(error) 与 local_handler(wiki_fallback)。
    trace.mark("local_handler", {
      status: query ? "ok" : "error",
      attrs: { handler: upstreamError ? "wiki_fallback" : "wiki_search" }
    });
    // SC-12 — only articles this role can read are injected, and each one
    // is audited with its key and wiki version.
    const wikiInjectedKeys = results.map((hit) => hit.key);
    const wikiVersions = results.map((hit) => hit.version ?? "unknown");
    const responseBody = jsonRpcToolResult(requestId, JSON.stringify({
      query: query ?? "",
      results,
      filteredBy: "wiki_acl"
    }, null, 2), { isError: !query });
    res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
    res.end(responseBody);
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: "wiki_search",
      argsSummary: query ? { query, limit } : argsSummary,
      ...queryMeta,
      wikiInjectedKeys,
      wikiVersions,
      outcome: query ? "ok" : "error",
      errorDetail: query ? upstreamError : "wiki_query_missing",
      durationMs: Date.now() - start,
      responseBytes: Buffer.byteLength(responseBody),
      requestId,
      ...requestMeta,
      ...(await auditMeta(identity, query ? "local_wiki_search" : "wiki_query_missing")),
    });
    recordMcpTraceForTool({
      traceId,
      identity,
      toolName: "wiki_search",
      status: query ? "ok" : "error",
      startedAt: new Date(start).toISOString(),
      turnId: requestMeta.lucyTurnId ?? null,
      sessionId: requestMeta.lucySessionId ?? null,
      requestId,
      argsSummary: query ? { query, limit } : argsSummary,
      allowed: Boolean(query),
      reason: query ? "local_wiki_search" : "wiki_query_missing",
      policySource: "wiki_acl"
    });
  };

  // Spec 138: Session-bound matching is authoritative. Identity-only matching
  // remains a low-confidence compatibility fallback only when one candidate exists.
  if (rpcMethod === "tools/call" && toolName && questionBudgetScopeMode() === "stable" && questionBudgetEnabled()) {
    const preloaded = await questionBudget.preload(
      budgetIdentityKey(identity.userId, identity.tokenHashPrefix ?? ""),
      requestMeta.lucySessionId
    );
    if (preloaded?.turnId) {
      // Spec 162 §6.4 / SC-03：归属在**冻结前**从稳定作用域恢复。
      // 注册表条目的 TTL 锚点是**恢复时刻**，不是问询原始起点 ——
      // 否则一个已超过 10 分钟的问询刚恢复就被 purge 掉，归属当次丢失。
      // 问询年龄（慢问询标记）仍读稳定作用域的 `originStartedAt`。
      reportedTurns.record({
        identity,
        sessionId: requestMeta.lucySessionId,
        turnId: preloaded.turnId
      });
    }
  }
  if (rpcMethod === "tools/call" && toolName && toolName !== "lucy_begin_question") {
    // 空桑基修复 Spec §2：无 header 时延续同会话已 record 的 begin turn → confirmed。
    const attribution = reportedTurns.resolveToolCall({
      identity,
      sessionId: requestMeta.lucySessionId,
      explicitTurnId
    });
    requestMeta.lucyTurnId = attribution.turnId;
    requestMeta.turnAttributionMode = attribution.mode;
    requestMeta.turnAttributionConfidence = attribution.confidence;
    requestMeta.turnAttributionReason = attribution.reason;
    Object.assign(requestMeta, {
      associationStatus: attribution.associationStatus,
      originalTurnId: attribution.turnId, effectiveTurnId: attribution.turnId,
      originalAttributionMode: attribution.mode, effectiveAttributionMode: attribution.mode,
      originalAssociationStatus: attribution.associationStatus, effectiveAssociationStatus: attribution.associationStatus,
      originalAttributionConfidence: attribution.confidence, effectiveAttributionConfidence: attribution.confidence,
      originalReason: attribution.reason, effectiveReason: attribution.reason
    });
  }
  if (requestMeta.lucyTurnId) questionBudget.ensureTurn(requestMeta.lucyTurnId, Date.now());

  // Spec 162 §8 / SC-20 — a cancellation is attached to its question when the
  // session resolves to an open turn. Without a session there is nothing to
  // attach, so the notification is recorded without a turn id.
  if (rpcMethod === "notifications/cancelled") {
    const attribution = reportedTurns.resolve({
      identity,
      sessionId: requestMeta.lucySessionId
    });
    if (attribution.turnId) {
      requestMeta.lucyTurnId = attribution.turnId;
      requestMeta.turnAttributionMode = attribution.mode;
      requestMeta.turnAttributionConfidence = attribution.confidence;
      questionBudget.ensureTurn(attribution.turnId, Date.now());
    }
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: "notifications/cancelled",
      argsSummary,
      outcome: "ok",
      durationMs: Date.now() - start,
      requestId,
      ...requestMeta,
      ...(await auditMeta(identity, "cancelled")),
    });
    res.writeHead(202, { "content-length": "0" });
    res.end();
    return;
  }

  const invalidArgumentsReason = queryNormalizationReason ?? (
    rpcMethod === "tools/call" && toolName
      ? validateLucyToolArgs(toolName, toolArgs)
      : undefined
  );
  const respondInvalidArguments = async (invalidArgumentsReason: string, baseHint?: string): Promise<void> => {
    const tracked = await trackRejection(traceContext, invalidArgumentsReason);
    const hint = [baseHint, tracked.repeated ? REPEAT_REJECTION_HINT : undefined].filter(Boolean).join(" ") || undefined;
    const responseBody = jsonRpcToolResult(requestId, `Invalid arguments: ${invalidArgumentsReason}${hint ? `. ${hint}` : ""}`, { isError: true });
    res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
    res.end(responseBody);
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: toolName ?? "tools/call",
      tables: queryTables.length > 0 ? queryTables : undefined,
      argsSummary,
      ...queryMeta,
      outcome: "error",
      errorDetail: invalidArgumentsReason,
      // 入参 / 语义校验失败发生在上游调用之前 → 本次尝试**未执行**，
      // 不是执行失败（notExecuted 先于 verifiedFailure 判定）。
      executionEvidence: executionEvidenceFromObservation({
        notExecuted: true,
        authorizationAllowed: true
      }),
      durationMs: Date.now() - start,
      responseBytes: Buffer.byteLength(responseBody),
      requestId,
      ...requestMeta,
      ...(await auditMeta(identity, invalidArgumentsReason)),
    });
    recordMcpTraceForTool({
      traceId,
      identity,
      toolName: toolName ?? "tools/call",
      status: "error",
      startedAt: new Date(start).toISOString(),
      turnId: requestMeta.lucyTurnId ?? null,
      sessionId: requestMeta.lucySessionId ?? null,
      requestId,
      argsSummary,
      allowed: false,
      reason: invalidArgumentsReason,
      policySource: "other"
    });
  };
  if (invalidArgumentsReason) {
    // SC-05：整个查询形状缺失同样是 KTX 必然拒绝的形状，文案同样带示例（只加提示，不新增拒绝条件）。
    const shapeHint = invalidArgumentsReason === "invalid_arguments:lucy_query:query_shape_required"
      ? LUCY_QUERY_MEASURES_HINT
      : undefined;
    await respondInvalidArguments(invalidArgumentsReason, shapeHint);
    return;
  }

  // Spec 20261101 §4.1 / D27 — lucy-ops：剥离 gov.*；治理源绑定 snapshot；旧源拒 gov。
  let governanceBindId: string | undefined;
  if (rpcMethod === "tools/call" && toolName === "lucy_query" && toolArgs && typeof toolArgs === "object" && !Array.isArray(toolArgs)) {
    const record = toolArgs as Record<string, unknown>;
    const connectionId =
      typeof record.connectionId === "string"
        ? record.connectionId
        : typeof record.connection_id === "string"
          ? record.connection_id
          : typeof record.connection === "string"
            ? record.connection
            : undefined;
    const sourceName =
      typeof record.sourceName === "string"
        ? record.sourceName
        : typeof record.source_name === "string"
          ? record.source_name
          : typeof record.source === "string"
            ? record.source
            : typeof record.table === "string"
              ? record.table
              : undefined;

    if (connectionId === OPS_EVIDENCE_CONNECTION_ID || (typeof record.filters !== "undefined" && connectionId)) {
      const parsed = parseAndStripGovFilters(record.filters, { connectionId, sourceName });
      if (isGovFilterError(parsed)) {
        const reason = parsed.reason;
        const responseBody = jsonRpcToolResult(requestId, `Invalid arguments: ${reason}`, { isError: true });
        res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
        res.end(responseBody);
        recordRequestAudit({
          ts: new Date().toISOString(),
          userId: identity.userId,
          client: identity.client,
          tool: toolName,
          tables: queryTables.length > 0 ? queryTables : undefined,
          argsSummary,
          ...queryMeta,
          outcome: "error",
          errorDetail: reason,
          executionEvidence: executionEvidenceFromObservation({
            notExecuted: true,
            authorizationAllowed: true
          }),
          durationMs: Date.now() - start,
          responseBytes: Buffer.byteLength(responseBody),
          requestId,
          ...requestMeta,
          ...(await auditMeta(identity, reason))
        });
        return;
      }

      if (connectionId === OPS_EVIDENCE_CONNECTION_ID) {
        let stripped = applyStrippedGovFilters(record, parsed);
        if (isOpsEvidenceGovernanceSource(sourceName)) {
          try {
            const projectRoot = await resolveProjectRoot();
            const accessVer = await readAccessYamlVersion(projectRoot).catch(() => ({ version: "unknown", raw: "" }));
            const ktxDigest = await readKtxYamlDigest(projectRoot).catch(() => "unknown");
            const filtersDigest = digestGovFiltersForKey({
              trust: parsed.trust,
              focus: parsed.focus,
              rowFilters: parsed.rowFilters
            });
            const database = await getAdminAuditDb();
            const bound = await rebuildGovernanceSnapshotAtomic(database, {
              window: parsed.window,
              trust: parsed.trust,
              focus: parsed.focus,
              filtersDigest,
              versions: {
                accessConfigVersion: accessVer.version,
                policyVersion: ktxDigest,
                sourceMapVersion: ktxDigest,
                capabilityDigest: ktxDigest
              },
              projectRoot
            });
            governanceBindId = `${requestId}:${bound.materializationId}`;
            bindGovernanceMaterialization(governanceBindId, bound.materializationId);
            stripped = injectSnapshotIdFilter(stripped, bound.materializationId, sourceName!);
          } catch (error) {
            const reason =
              error instanceof GovernanceSnapshotUnreadyError
                ? `${OPS_EVIDENCE_GOVERNANCE_UNREADY}:${error.message}`
                : `${OPS_EVIDENCE_GOVERNANCE_UNREADY}:rebuild_failed`;
            const responseBody = jsonRpcToolResult(requestId, reason, { isError: true });
            res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
            res.end(responseBody);
            recordRequestAudit({
              ts: new Date().toISOString(),
              userId: identity.userId,
              client: identity.client,
              tool: toolName,
              tables: queryTables.length > 0 ? queryTables : undefined,
              argsSummary,
              ...queryMeta,
              outcome: "error",
              errorDetail: reason,
              executionEvidence: executionEvidenceFromObservation({
                notExecuted: true,
                authorizationAllowed: true
              }),
              durationMs: Date.now() - start,
              responseBytes: Buffer.byteLength(responseBody),
              requestId,
              ...requestMeta,
              ...(await auditMeta(identity, reason))
            });
            return;
          }
        }
        toolArgs = stripped;
        const params =
          parsedRpc?.params && typeof parsedRpc.params === "object" && !Array.isArray(parsedRpc.params)
            ? (parsedRpc.params as Record<string, unknown>)
            : undefined;
        if (params) params.arguments = stripped;
      }
    }
  }
  if (governanceBindId) {
    res.on("close", () => {
      if (governanceBindId) releaseGovernanceMaterializationBind(governanceBindId);
    });
  }

  /**
 * Spec 162 §7.8 / SC-13 / SC-19 — 认证路径 and the single template pilot.
 *
 * Execution is still a role-scoped `lucy_query`: the route/template never
 * grants access. A role that cannot read the source gets a permission denial
 * whose repair list is drawn only from that role's ACL. The success payload
 * always carries the source and, when declared, the applied version.
 */
async function writeCertifiedRouteResponse(
  identity: Identity,
  toolName: string,
  toolArgs: unknown,
  context: {
    res: ServerResponse;
    requestId: string | number;
    start: number;
    requestMeta: Partial<Parameters<typeof writeLog>[0]>;
    argsSummary: Record<string, unknown> | undefined;
    queryMeta: Partial<Parameters<typeof writeLog>[0]>;
    traceId: string;
  }
): Promise<void> {
  const { res, requestId, start, requestMeta, argsSummary, queryMeta, traceId } = context;
  const args = (toolArgs && typeof toolArgs === "object" && !Array.isArray(toolArgs)
    ? toolArgs as Record<string, unknown>
    : {}) as Record<string, unknown>;
  const firstString = firstStringField(args, ["routeId", "route_id"]) ?? "";
  const templateId = firstStringField(args, ["templateId", "template_id"]) ?? "";
  const identifier = toolName === "lucy_report_template" ? templateId : firstString;

  const resolved = await effectivePermissions(identity).catch(() => null);
  const permissions = resolved?.ok ? resolved.permissions : undefined;
  const readsSource = (source: string): boolean => {
    if (!permissions) return false;
    if (permissions.tables.includes("*")) return true;
    return permissions.sources.some((entry) => entry.sourceName === source || entry.table === source);
  };

  type Gate =
    | { ok: true; routeId: string; source: string; version?: string; query: Record<string, unknown> }
    | {
      ok: false;
      decision: "permission_denied" | "not_found";
      reason: string;
      repair: { connections: string[]; sources: string[] } | null;
    };

  const denyWith = (decision: "permission_denied" | "not_found", reason: string): Gate => ({
    ok: false,
    decision,
    reason,
    repair: permissions
      ? denialAllowList({ connections: permissions.connections, sources: permissions.sources })
      : null
  });

  let gate: Gate;
  if (toolName === "lucy_report_template") {
    const template = identifier ? lookupReportTemplate(identifier) : undefined;
    if (!template) {
      gate = denyWith("not_found", "report_template_not_found");
    } else if (!readsSource(template.source)) {
      gate = denyWith("permission_denied", `explicit_table_required:${template.source}`);
    } else {
      gate = {
        ok: true,
        routeId: template.templateId,
        source: template.source,
        version: template.version,
        query: { connectionId: template.source.split(".")[0], sourceName: template.source }
      };
    }
  } else {
    const resolvedRoute = resolveCertifiedRoute(identifier, {
      readsSource,
      permissions: permissions
        ? { connections: permissions.connections, sources: permissions.sources }
        : undefined
    });
    if (!resolvedRoute.ok) {
      gate = resolvedRoute.decision === "permission_denied"
        ? { ok: false, decision: "permission_denied", reason: resolvedRoute.reason, repair: resolvedRoute.repair }
        : { ok: false, decision: "not_found", reason: resolvedRoute.reason, repair: null };
    } else {
      const route = resolvedRoute.route;
      gate = {
        ok: true,
        routeId: route.routeId,
        source: route.source,
        version: route.version,
        query: route.query
      };
    }
  }

  const respond = async (payload: unknown, isError: boolean, decisionReason: string, errorDetail?: string): Promise<void> => {
    const responseBody = jsonRpcToolResult(requestId, JSON.stringify(payload, null, 2), isError ? { isError: true } : {});
    res.writeHead(200, { "content-type": "application/json" });
    res.end(responseBody);
    const denied = decisionReason.includes("required") || decisionReason.includes("forbidden");
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: toolName,
      argsSummary,
      ...queryMeta,
      outcome: isError ? (denied ? "denied" : "error") : "ok",
      errorDetail,
      durationMs: Date.now() - start,
      responseBytes: Buffer.byteLength(responseBody),
      requestId,
      ...requestMeta,
      ...(await auditMeta(identity, decisionReason)),
    });
    recordMcpTraceForTool({
      traceId,
      identity,
      toolName,
      status: isError ? (denied ? "denied" : "error") : "ok",
      startedAt: new Date(start).toISOString(),
      turnId: requestMeta.lucyTurnId ?? null,
      sessionId: requestMeta.lucySessionId ?? null,
      requestId,
      argsSummary,
      allowed: !isError,
      reason: decisionReason
    });
  };

  if (!gate.ok) {
    const failureDimension = gate.decision === "permission_denied" ? "权限拒绝" : "用法与语义";
    await respond(
      {
        error: gate.reason,
        failureDimension,
        ...(gate.decision === "permission_denied" && gate.repair
          ? { allowedConnections: gate.repair.connections, allowedSources: gate.repair.sources }
          : {})
      },
      true,
      gate.reason,
      gate.reason
    );
    return;
  }

  if (questionBudgetBypassEnabled() && questionBudgetEnabled()) {
    const compiledBudget = await effectivePermissions(identity).catch(() => null);
    const allowedTools = compiledBudget && compiledBudget.ok ? (compiledBudget.permissions.tools ?? []) : [];
    const budgetDecision = await questionBudget.consumePersisted(
      requestMeta.lucyTurnId,
      Date.now(),
      undefined,
      undefined,
      {
        identityKey: budgetIdentityKey(identity.userId, identity.tokenHashPrefix ?? ""),
        sessionId: requestMeta.lucySessionId,
        canContinue: allowedTools.includes("lucy_continue_question") || allowedTools.includes("*")
      }
    );
    if (budgetDecision.action !== "allow") {
      await respond(
        {
          reason: budgetDecision.reason,
          ...(budgetDecision.action === "stop"
            ? { partial: budgetDecision.partial, continueToken: budgetDecision.continueToken, continuable: budgetDecision.continuable }
            : { partial: true })
        },
        true,
        budgetDecision.reason,
        budgetDecision.reason
      );
      return;
    }
    const ticket = budgetDecision.ticket;
    // Spec 162 §6.2：旁路入口同样受绝对执行时限约束。到点停止等待、取消上游，
    // 记账封顶；取消未确认的事实写进审计。
    let upstreamHandle: ClientRequest | null = null;
    const deadlineTimer = ticket
      ? setTimeout(() => {
          try {
            upstreamHandle?.destroy(new Error("absolute_execution_deadline"));
          } catch {
            // 上游句柄可能已关闭；忽略。
          }
          void questionBudget.settle(ticket, ticket.startMonoMs + QUESTION_BUDGET_ABS_EXEC_MS, {
            timeoutUnconfirmed: true
          });
        }, QUESTION_BUDGET_ABS_EXEC_MS)
      : null;
    deadlineTimer?.unref();
    try {
      const execution = await forwardAuthorizedLucyQuery(identity, gate.query, (request) => {
        upstreamHandle = request;
      });
      if (!execution.ok) {
        await respond(
          { error: execution.reason, routeId: gate.routeId, source: gate.source },
          true,
          execution.reason,
          execution.reason
        );
        return;
      }
      await respond(
        {
          routeId: gate.routeId,
          source: gate.source,
          ...(gate.version ? { appliedVersion: gate.version } : {}),
          result: execution.payload
        },
        false,
        "allowed"
      );
    } finally {
      if (deadlineTimer) clearTimeout(deadlineTimer);
      // 成功、异常和提前退出都结算**同一张票据**（Spec §6.6）。
      if (ticket) await questionBudget.settle(ticket, questionBudget.monoNow());
    }
    return;
  }

  // Execution is a normal role-scoped lucy_query — the ACL still decides.
  const execution = await forwardAuthorizedLucyQuery(identity, gate.query);
  if (!execution.ok) {
    await respond(
      { error: execution.reason, routeId: gate.routeId, source: gate.source },
      true,
      execution.reason,
      execution.reason
    );
    return;
  }

  await respond(
    {
      routeId: gate.routeId,
      source: gate.source,
      ...(gate.version ? { appliedVersion: gate.version } : {}),
      result: execution.payload
    },
    false,
    "allowed"
  );
}

/**
 * Spec 162 §7.3 / SC-14 — the tools whose permission-denial payload carries
 * the shared allow list. One function, one list, no per-tool divergence.
 */
const DENIAL_REPAIR_TOOLS = new Set([
  "discover_data",
  "entity_details",
  "dictionary_search",
  "lucy_query",
  "lucy_read_source"
]);

/**
 * P1-37 U2：未知工具名的拒绝指引。清单＝该身份在当前策略版本下真实 `tools/list` 返回过的名称；
 * 没有记录时退回 `allowedToolNames`（其上界，已排除 absolute-deny 与未授权控制面）。
 * 不复用 `DENIAL_REPAIR_TOOLS` 的数据来源载荷。
 */
async function unknownToolGuidance(
  identity: Identity,
  toolName: string
): Promise<{ text: string; payload: Record<string, unknown> }> {
  const policyVersion = getPolicyRuntimeStatus().policyVersion;
  const observed = recallObservedToolNames(identity.userId, identity.tokenHashPrefix ?? "", policyVersion);
  const names = observed ?? await allowedToolNames(identity).catch(() => [] as string[]);
  const text = ` "${toolName}" is not a tool this server provides. Do not guess tool names; `
    + (names.length > 0 ? `use one of: ${names.join(", ")}.` : "call tools/list to see the tools available to you.");
  return {
    text,
    payload: { reason: "tool_unclassified", unknownTool: toolName, availableTools: names }
  };
}

/**
 * Builds the ACL-scoped repair payload shared by every permission denial.
 * Only connections and sources inside the caller's effective permissions are
 * returned; a resolution failure degrades to no list rather than guessing.
 */
async function buildDenialRepairPayload(
  identity: Identity,
  reason: string
): Promise<{ text: string; payload: Record<string, unknown> } | null> {
  const resolved = await effectivePermissions(identity).catch(() => null);
  if (!resolved?.ok) return null;
  const allow = denialAllowList({
    connections: resolved.permissions.connections,
    sources: resolved.permissions.sources
  });
  // B15：提示内容必须先通过可用性闭环（真实 Schema / 可见性 / 编译能力 /
  // 参数形态 / 可调用性）。无合法目标时给**事实性错误**与可用候选。
  const { evidence, schemaEvidenceAvailable } = await collectRepairEvidence({
    toolArgs: undefined,
    candidateSources: allow.sources,
    visibleSources: new Set(allow.sources),
    callable: true
  });
  const closure = buildRepairClosure({
    failureDimension: "权限拒绝",
    candidates: evidence,
    availableCandidates: allow.sources
  });
  const hint =
    closure.usableTargets.length > 0
      ? repairHint(
          { failureDimension: "权限拒绝", suggestedSources: closure.usableTargets },
          new Set(allow.sources)
        )
      : schemaEvidenceAvailable
        ? closure.text
        : repairHint(
            { failureDimension: "权限拒绝", suggestedSources: allow.sources },
            new Set(allow.sources)
          );
  const parts: string[] = [];
  if (allow.connections.length > 0) parts.push(`可用连接：${allow.connections.join("、")}。`);
  if (allow.sources.length > 0) parts.push(`可用来源：${allow.sources.join("、")}。`);
  if (hint) parts.push(hint);
  return {
    text: parts.length > 0 ? ` ${parts.join(" ")}` : "",
    payload: {
      reason,
      failureDimension: "权限拒绝",
      connections: allow.connections,
      sources: allow.sources
    }
  };
}

  // Spec 162 §7.8 — count(*) / count(1) with no source is repaired before the
  // empty-source ACL deny. A named table still reaches aclCheck.
  if (rpcMethod === "tools/call" && toolName && queryGuardrailsEnabled()) {
    const countStop = countWithoutSourceBeforeAcl(toolName, toolArgs);
    if (countStop) {
      const responseBody = jsonRpcToolResult(requestId, JSON.stringify({
        reason: countStop.reason,
        repair: countStop.repair,
        failureDimension: countStop.failureDimension
      }), { isError: true });
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName,
        tables: queryTables.length > 0 ? queryTables : undefined,
        argsSummary,
        ...queryMeta,
        outcome: "error",
        decisionReason: countStop.reason,
        errorDetail: countStop.repair,
        failureDimension: countStop.failureDimension,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, countStop.reason)),
      });
      recordMcpTraceForTool({
        traceId,
        identity,
        toolName,
        status: "error",
        startedAt: new Date(start).toISOString(),
        turnId: requestMeta.lucyTurnId ?? null,
        sessionId: requestMeta.lucySessionId ?? null,
        requestId,
        argsSummary,
        allowed: false,
        reason: countStop.reason,
        policySource: "other"
      });
      return;
    }
  }

  // ACL check for tool calls
  if (rpcMethod === "tools/call" && toolName) {
    const aclSpan = trace.start("acl");
    const decision = await aclCheck(identity, toolName, toolArgs);
    if (decision.allowed) {
      aclSpan.end({ status: "ok", reasonCode: "allowed", attrs: { decision: "allow" } });
    } else {
      const aclMapped = mapReasonCode({ decisionReason: decision.reason ?? "denied", outcome: "denied" });
      aclSpan.end({ status: "denied", reasonCode: aclMapped.code, reasonParam: aclMapped.param, errorCategory: aclMapped.errorCategory, attrs: { decision: "deny" } });
    }
    if (!decision.allowed) {
      const errorMsg = decision.reason ?? "denied";
      const compiled = await effectivePermissions(identity).catch(() => null);
      const compilerReason = compiled && !compiled.ok
        ? formatIdentityCompilerReason(compiled.diagnostic)
        : undefined;
      const meta = await auditMeta(identity, errorMsg, compilerReason ? { compilerReason } : undefined);
      // Spec 162 §7.3 / SC-14 — discover_data, entity_details,
      // dictionary_search, lucy_query and lucy_read_source share this one
      // allow-list function. Names outside the caller's ACL never appear.
      const denial = DENIAL_REPAIR_TOOLS.has(toolName)
        ? await buildDenialRepairPayload(identity, errorMsg)
        : null;
      const tracked = await trackRejection(traceContext, errorMsg);
      const unknownTool = errorMsg.startsWith("tool_unclassified:")
        ? await unknownToolGuidance(identity, toolName)
        : null;
      const repeatText = tracked.repeated ? ` ${REPEAT_REJECTION_HINT}` : "";
      const responseBody = JSON.stringify({
        jsonrpc: "2.0",
        id: requestId,
        result: {
          isError: true,
          content: [{ type: "text", text: `Access denied: ${errorMsg}${denial?.text ?? ""}${unknownTool?.text ?? ""}${repeatText}` }],
          ...(denial ? { data: denial.payload } : unknownTool ? { data: unknownTool.payload } : {})
        }
      });
      res.writeHead(200, { "content-type": "application/json" });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName,
        tables: queryTables.length > 0 ? queryTables : undefined,
        argsSummary,
        ...queryMeta,
        outcome: "denied",
        errorDetail: errorMsg,
        // ACL 裁决已真实发生（decision.allowed === false）→ 授权拒绝是观测到的事实；
        // 本次尝试未执行，故记 notExecuted 而非 failed。
        executionEvidence: executionEvidenceFromObservation({
          authorizationDenied: true,
          notExecuted: true
        }),
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...meta,
      });
      recordMcpTraceForTool({
        traceId,
        identity,
        toolName,
        status: "denied",
        startedAt: new Date(start).toISOString(),
        turnId: requestMeta.lucyTurnId ?? null,
        sessionId: requestMeta.lucySessionId ?? null,
        requestId,
        argsSummary,
        allowed: false,
        reason: errorMsg,
        matchedRule: decision.reason
      });
      return;
    }
    // ─── P0-1 问题类型口径绑定：注入前门禁 ───
    // 闸序（Spec D6）：**ACL →（若有可解析 Active Binding）口径集合 → 行权限注入／
    // 既有 guardrails**。偏离 → `caliber_binding_violation`，**不转发上游**。
    // 口径校验基于**注入前**的原始 Agent 入参（行权限谓词不参与）。
    if (toolName === "lucy_query" || toolName === "lucy_explain_query") {
      const caliberGate = await checkCaliberBindingGate({
        identity,
        identityKey: budgetIdentityKey(identity.userId, identity.tokenHashPrefix ?? ""),
        sessionId: requestMeta.lucySessionId,
        toolName,
        args: (toolArgs && typeof toolArgs === "object" && !Array.isArray(toolArgs))
          ? toolArgs as Record<string, unknown>
          : {}
      });
      if (caliberGate.kind === "deny") {
        const denial: CaliberBindingDenial = caliberGate.denial;
        const caliberRepeatText = await repeatRejectionSuffix(traceContext, denial.code);
        const responseBody = JSON.stringify({
          jsonrpc: "2.0",
          id: requestId,
          result: {
            isError: true,
            content: [{ type: "text", text: `${denial.text}${caliberRepeatText}` }],
            data: denial.payload
          }
        });
        res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
        res.end(responseBody);
        recordRequestAudit({
          ts: new Date().toISOString(),
          userId: identity.userId,
          client: identity.client,
          tool: toolName,
          tables: queryTables.length > 0 ? queryTables : undefined,
          argsSummary,
          ...queryMeta,
          outcome: "denied",
          decisionReason: denial.code,
          errorDetail: denial.code,
          failureDimension: denial.payload.failureDimension,
          durationMs: Date.now() - start,
          responseBytes: Buffer.byteLength(responseBody),
          requestId,
          ...requestMeta,
          // 口径偏离是「效果发生前」的拒绝：本次尝试**未执行**（零上游执行）。
          executionEvidence: executionEvidenceFromObservation({
            authorizationAllowed: true,
            notExecuted: true
          }),
          ...(await auditMeta(identity, denial.code))
        });
        recordMcpTraceForTool({
          traceId,
          identity,
          toolName,
          status: "denied",
          startedAt: new Date(start).toISOString(),
          turnId: requestMeta.lucyTurnId ?? null,
          sessionId: requestMeta.lucySessionId ?? null,
          requestId,
          argsSummary,
          allowed: false,
          reason: denial.code,
          matchedRule: denial.payload.dimension
        });
        return;
      }
      // P0-4 §5.2.1 — 门禁 allow 当拍 pin；随请求携带至响应装配。
      if (toolName === "lucy_query") {
        const argsRecord =
          toolArgs && typeof toolArgs === "object" && !Array.isArray(toolArgs)
            ? toolArgs as Record<string, unknown>
            : {};
        argsBeforeRewrite = deepCopyJson(argsRecord);
        requestPinnedCaliber = await captureRequestPinnedCaliberEvidence({
          identityKey: budgetIdentityKey(identity.userId, identity.tokenHashPrefix ?? ""),
          sessionId: requestMeta.lucySessionId
        });
      }
    }
    // ─── P0-3 表级歧义门闩：ACL＋口径之后、上游／explain 成功体之前 ───
    // explain 必须在本段拦截（约本地成功体之前）；不得只挂共享 query guard。
    if (toolName && sourceAmbiguityGateAppliesToTool(toolName)) {
      const sagResolved = await effectivePermissions(identity).catch(() => null);
      // 权限／目录不可读 → fail-closed（D10／SC-24），禁止静默跳过门闩。
      if (!sagResolved?.ok) {
        const denialText = `Access denied: source_ambiguity_gate（表级歧义：目录或权限不可读，请先确认来源表）${await repeatRejectionSuffix(traceContext, "source_ambiguity_gate")}`;
        const denialPayload = {
          reason: "source_ambiguity_gate",
          failureDimension: "source_selection",
          message: "表级歧义：请先确认来源表",
          detail: "catalog_unreliable",
          candidates: [] as unknown[],
          repair: { usableTargets: [], rejected: [], factualError: "当前没有可用的合法目标：目录或权限不可读。", text: "当前没有可用的合法目标：目录或权限不可读。" }
        };
        const responseBody = JSON.stringify({
          jsonrpc: "2.0",
          id: requestId,
          result: {
            isError: true,
            content: [{ type: "text", text: denialText }],
            data: denialPayload
          }
        });
        res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
        res.end(responseBody);
        recordRequestAudit({
          ts: new Date().toISOString(),
          userId: identity.userId,
          client: identity.client,
          tool: toolName,
          tables: queryTables.length > 0 ? queryTables : undefined,
          argsSummary,
          ...queryMeta,
          outcome: "denied",
          decisionReason: "source_ambiguity_gate",
          errorDetail: "catalog_unreliable",
          failureDimension: "source_selection",
          durationMs: Date.now() - start,
          responseBytes: Buffer.byteLength(responseBody),
          requestId,
          ...requestMeta,
          executionEvidence: executionEvidenceFromObservation({
            authorizationAllowed: true,
            notExecuted: true
          }),
          ...(await auditMeta(identity, "source_ambiguity_gate"))
        });
        recordMcpTraceForTool({
          traceId,
          identity,
          toolName,
          status: "denied",
          startedAt: new Date(start).toISOString(),
          turnId: requestMeta.lucyTurnId ?? null,
          sessionId: requestMeta.lucySessionId ?? null,
          requestId,
          argsSummary,
          allowed: false,
          reason: "source_ambiguity_gate"
        });
        return;
      }
      {
        // Critical：必须装配描述／度量／健康态；缺省仅 sourceName＋table 会让中文 description 场景 zero_hits 假放行。
        const enriched = await buildMatchableSourcesForGate(sagResolved.permissions.sources);
        const toolArgsRecord =
          (toolArgs && typeof toolArgs === "object" && !Array.isArray(toolArgs))
            ? toolArgs as Record<string, unknown>
            : {};
        // P1-35 D5：按完整身份装配真实 schema／completion 探测（仅 done＝compiled）。
        // SourceSummary：conn／schema／table(=sourceName)／qualifiedName(=physical)。
        const schemaProbeByIdentity = new Map<string, GateSchemaProbe>();
        let sourceMapReliable = true;
        try {
          const projectRoot = await resolveProjectRoot();
          const listed = await listSources(projectRoot, { skipAuthorizedCounts: true });
          // 度量名取自上面已装配的 overlay（与 measureCount 同源）；读不到名字＝空＝不合法（fail-closed）。
          const measureNamesByKey = new Map(
            enriched.matchableSources.map((m) => [repairEvidenceIdentityKey(m.identity), m.measureNames ?? []])
          );
          for (const src of listed) {
            const key = repairEvidenceIdentityKey({
              connectionId: src.conn,
              schema: src.schema,
              sourceName: src.table,
              physicalTable: src.qualifiedName || `${src.schema}.${src.table}`
            });
            schemaProbeByIdentity.set(key, {
              schemaExists: true,
              completion: src.completion,
              measureNames: measureNamesByKey.get(key) ?? []
            });
          }
          // 权限可见但 listSources 未收录 → schemaExists=false（已知不存在于语义清单）
          for (const s of sagResolved.permissions.sources) {
            const key = repairEvidenceIdentityKey({
              connectionId: s.connectionId,
              schema: s.schema,
              sourceName: s.sourceName,
              physicalTable: s.table
            });
            if (!schemaProbeByIdentity.has(key)) {
              schemaProbeByIdentity.set(key, {
                schemaExists: false,
                completion: null,
                measureNames: []
              });
            }
          }
        } catch {
          sourceMapReliable = false;
        }
        const sagOutcome = await checkSourceAmbiguityGate({
          identityKey: budgetIdentityKey(identity.userId, identity.tokenHashPrefix ?? ""),
          sessionId: requestMeta.lucySessionId,
          toolName,
          args: toolArgsRecord,
          permissions: sagResolved.permissions,
          matchableSources: enriched.matchableSources,
          sourceMapReliable,
          schemaProbeByIdentity
        });
        if (sagOutcome.kind === "allow" && sagOutcome.selection) {
          sourceSelectionForAv = toSelectionDisclosure(sagOutcome.selection);
        }
        if (sagOutcome.kind === "deny_caliber_unresolved") {
          const unresolvedRepeatText = await repeatRejectionSuffix(traceContext, "caliber_binding_unresolved");
          const responseBody = JSON.stringify({
            jsonrpc: "2.0",
            id: requestId,
            result: {
              isError: true,
              content: [{ type: "text", text: `${sagOutcome.text}${unresolvedRepeatText}` }],
              data: { reason: "caliber_binding_unresolved", failureDimension: "口径绑定" }
            }
          });
          res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
          res.end(responseBody);
          recordRequestAudit({
            ts: new Date().toISOString(),
            userId: identity.userId,
            client: identity.client,
            tool: toolName,
            tables: queryTables.length > 0 ? queryTables : undefined,
            argsSummary,
            ...queryMeta,
            outcome: "denied",
            decisionReason: "caliber_binding_unresolved",
            errorDetail: "caliber_binding_unresolved",
            durationMs: Date.now() - start,
            responseBytes: Buffer.byteLength(responseBody),
            requestId,
            ...requestMeta,
            executionEvidence: executionEvidenceFromObservation({
              authorizationAllowed: true,
              notExecuted: true
            }),
            ...(await auditMeta(identity, "caliber_binding_unresolved"))
          });
          recordMcpTraceForTool({
            traceId,
            identity,
            toolName,
            status: "denied",
            startedAt: new Date(start).toISOString(),
            turnId: requestMeta.lucyTurnId ?? null,
            sessionId: requestMeta.lucySessionId ?? null,
            requestId,
            argsSummary,
            allowed: false,
            reason: "caliber_binding_unresolved"
          });
          return;
        }
        if (sagOutcome.kind === "deny") {
          const denial: SourceAmbiguityDenial = sagOutcome.denial;
          const denialText = `Access denied: ${denial.reason}（${denial.message}）${await repeatRejectionSuffix(traceContext, denial.reason)}`;
          const responseBody = JSON.stringify({
            jsonrpc: "2.0",
            id: requestId,
            result: {
              isError: true,
              content: [{ type: "text", text: denialText }],
              data: denial
            }
          });
          res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
          res.end(responseBody);
          recordRequestAudit({
            ts: new Date().toISOString(),
            userId: identity.userId,
            client: identity.client,
            tool: toolName,
            tables: queryTables.length > 0 ? queryTables : undefined,
            argsSummary,
            ...queryMeta,
            outcome: "denied",
            decisionReason: denial.reason,
            errorDetail: denial.reason,
            failureDimension: denial.failureDimension,
            durationMs: Date.now() - start,
            responseBytes: Buffer.byteLength(responseBody),
            requestId,
            ...requestMeta,
            executionEvidence: executionEvidenceFromObservation({
              authorizationAllowed: true,
              notExecuted: true
            }),
            ...(await auditMeta(identity, denial.reason))
          });
          recordMcpTraceForTool({
            traceId,
            identity,
            toolName,
            status: "denied",
            startedAt: new Date(start).toISOString(),
            turnId: requestMeta.lucyTurnId ?? null,
            sessionId: requestMeta.lucySessionId ?? null,
            requestId,
            argsSummary,
            allowed: false,
            reason: denial.reason,
            matchedRule: denial.failureDimension
          });
          return;
        }
        // allow / skip_bound → 继续既有 guardrails／上游／explain
      }
    }
    // Spec 99 §6 — Proxy-only forced_filters injection for lucy_query; strip any user-supplied alias.
    if (toolName === "lucy_query") {
      const argsRecord =
        toolArgs && typeof toolArgs === "object" && !Array.isArray(toolArgs)
          ? toolArgs as Record<string, unknown>
          : {};
      // 若口径门禁未跑到（理论上不应），仍在改写前补齐快照／pin。
      if (!argsBeforeRewrite) argsBeforeRewrite = deepCopyJson(argsRecord);
      if (!requestPinnedCaliber) {
        requestPinnedCaliber = await captureRequestPinnedCaliberEvidence({
          identityKey: budgetIdentityKey(identity.userId, identity.tokenHashPrefix ?? ""),
          sessionId: requestMeta.lucySessionId
        });
      }
      originalUserFilters = argsBeforeRewrite.filters ?? argsRecord.filters;
      forcedFiltersForAv = decision.forcedFilters;
      scopeIntersectionEmpty = isScopeIntersectionEmpty(toolArgs, decision.forcedFilters);
      const record = applyLucyQueryForcedFilters(toolArgs, decision.forcedFilters);
      toolArgs = record;
      const params = parsedRpc?.params && typeof parsedRpc.params === "object" && !Array.isArray(parsedRpc.params)
        ? parsedRpc.params as Record<string, unknown>
        : undefined;
      if (params) params.arguments = record;
    }
    // L25-16 — 控制面工具分流：`lucy_ops_*` 由**代理本地**执行，
    // 绝不转发给 KTX（KTX 不认识这些工具）。
    //
    // fail-closed 的两道闸：
    // ① 上面的 ACL 判定已按 `role.allow.ops` 放行或拒绝；未在登记表里的
    //    `lucy_ops_*`（例如 W-B 的 `lucy_ops_semantic_publish`）在 ACL 阶段
    //    就被判为 `tool_unclassified:` 并拒绝，不会走到这里。
    // ② 控制面自己的授权判定在 `invokeOpsTool` 内再做一次（工具级 + 逐对象）。
    if (rpcMethod === "tools/call" && toolName && isControlPlaneTool(toolName)) {
      const projectRoot = await resolveProjectRoot();
      const opsArgs = toolArgs && typeof toolArgs === "object" && !Array.isArray(toolArgs)
        ? (toolArgs as Record<string, unknown>)
        : {};
      const envelope = await invokeOpsTool({
        toolName,
        args: opsArgs,
        userId: identity.userId,
        projectRoot
      });
      const isError = envelope.ok === false;
      const payload = envelope.ok ? envelope.data : envelope.error;
      const responseBody = JSON.stringify({
        jsonrpc: "2.0",
        id: requestId,
        result: {
          ...(isError ? { isError: true } : {}),
          content: [{ type: "text", text: JSON.stringify(payload, null, 2) }],
          data: payload
        }
      });
      res.writeHead(200, {
        "content-type": "application/json",
        "content-length": Buffer.byteLength(responseBody)
      });
      res.end(responseBody);
      const errorDetail = envelope.ok ? undefined : envelope.error.code;
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName,
        argsSummary,
        ...queryMeta,
        outcome: isError ? "error" : "ok",
        errorDetail,
        // 控制面信封是**观测到的事实**：ok 表示这次调用走到了执行与结算；
        // 拒绝码若属于「效果发生前」的集合，则本次尝试**未执行**。
        executionEvidence: executionEvidenceFromObservation({
          authorizationAllowed: true,
          ...(isError
            ? (OPS_NO_EFFECT_DENIAL_CODES.has(envelope.error.code)
              ? { notExecuted: true }
              : { failed: true })
            : { executed: true })
        }),
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, errorDetail ?? "ops_control_plane_call"))
      });
      recordMcpTraceForTool({
        traceId,
        identity,
        toolName,
        status: isError ? "error" : "ok",
        startedAt: new Date(start).toISOString(),
        turnId: requestMeta.lucyTurnId ?? null,
        sessionId: requestMeta.lucySessionId ?? null,
        requestId,
        argsSummary,
        allowed: true,
        reason: errorDetail ?? "ops_control_plane_call",
        policySource: "access_policy"
      });
      return;
    }
    // Count before local handlers return as well as before upstream dispatch.
    if (rpcMethod === "tools/call" && toolName && isQuestionDataTool(toolName) && questionBudgetEnabled()) {
      // B16 / B24：持久化预算 + 无 turnId 时按凭证 / 会话级上限兜底。
      // 兜底作用域键取凭证指纹 + 会话，**不因重连或省略 begin_question 而重置**。
      const budgetScope = `${identity.tokenHashPrefix ?? "no-token"}:${requestMeta.lucySessionId ?? "no-session"}`;
      const compiledBudget = await effectivePermissions(identity).catch(() => null);
      const allowedTools = compiledBudget && compiledBudget.ok ? (compiledBudget.permissions.tools ?? []) : [];
      const canContinue = allowedTools.includes("lucy_continue_question") || allowedTools.includes("*");
      const budgetDecision = await questionBudget.consumePersisted(
        requestMeta.lucyTurnId,
        Date.now(),
        normalizeHeader(req.headers["x-lucy-question-continue"]),
        budgetScope,
        {
          identityKey: budgetIdentityKey(identity.userId, identity.tokenHashPrefix ?? ""),
          sessionId: requestMeta.lucySessionId,
          canContinue
        }
      );
      if (budgetDecision.action === "reject") {
        const responseBody = jsonRpcToolResult(requestId, JSON.stringify({
          reason: budgetDecision.reason,
          partial: true
        }), { isError: true });
        res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
        res.end(responseBody);
        recordRequestAudit({
          ts: new Date().toISOString(),
          userId: identity.userId,
          client: identity.client,
          tool: toolName,
          argsSummary,
          ...queryMeta,
          outcome: "error",
          decisionReason: budgetDecision.reason,
          errorDetail: budgetDecision.reason,
          executionEvidence: { authorizationAllowed: true, notExecuted: true },
          durationMs: Date.now() - start,
          responseBytes: Buffer.byteLength(responseBody),
          requestId,
          ...requestMeta,
          ...(await auditMeta(identity, budgetDecision.reason)),
        });
        return;
      }
      if (budgetDecision.action === "stop") {
        // A durable-store fault is NOT a spent budget. It is refused with 503
        // and recorded as an error, so a storage fault can never be read back
        // as a legitimate `budget_stopped` credential.
        if (isBudgetUnavailable(budgetDecision)) {
          const failureBody = JSON.stringify({
            jsonrpc: "2.0",
            id: requestId,
            error: { code: -32000, message: "audit_unavailable", data: { reason: budgetDecision.reason } }
          });
          res.writeHead(503, {
            "content-type": "application/json",
            "content-length": Buffer.byteLength(failureBody)
          });
          res.end(failureBody);
          recordRequestAudit({
            ts: new Date().toISOString(),
            userId: identity.userId,
            client: identity.client,
            tool: toolName,
            tables: queryTables.length > 0 ? queryTables : undefined,
            argsSummary,
            ...queryMeta,
            outcome: "error",
            decisionReason: "question_budget_unavailable",
            errorDetail: "question_budget_unavailable",
            durationMs: Date.now() - start,
            responseBytes: Buffer.byteLength(failureBody),
            requestId,
            ...requestMeta,
            ...(await auditMeta(identity, "question_budget_unavailable")),
          });
          return;
        }
        const responseBody = JSON.stringify({
          jsonrpc: "2.0",
          id: requestId,
          result: {
            content: [{
              type: "text",
              text: JSON.stringify({
                reason: budgetDecision.reason,
                partial: budgetDecision.partial,
                continueToken: budgetDecision.continueToken,
                continuable: budgetDecision.continuable
              })
            }]
          }
        });
        res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
        res.end(responseBody);
        recordRequestAudit({
          ts: new Date().toISOString(),
          userId: identity.userId,
          client: identity.client,
          tool: toolName,
          tables: queryTables.length > 0 ? queryTables : undefined,
          ...queryMeta,
          outcome: "budget_stop",
          decisionReason: "question_budget_exhausted",
          errorDetail: "question_budget_exhausted",
          argsSummary: {
            ...(argsSummary ?? {}),
            budgetContinuation: {
              continuationPresented: budgetDecision.continuationPresented ?? false,
              continuationMatched: budgetDecision.continuationMatched ?? false,
              continuationCreditLeft: budgetDecision.continuationCreditLeft ?? false,
              canContinueByCapability: budgetDecision.canContinueByCapability ?? false
            },
            // REQ-030-035／P1-14：预算终止行写入可复盘快照（不加进 MCP 响应体）。
            ...("budgetSnapshot" in budgetDecision && budgetDecision.budgetSnapshot
              ? { budgetSnapshot: budgetDecision.budgetSnapshot as BudgetSnapshot }
              : {})
          },
          // 闸序事实：ACL 裁决（上方 aclCheck）先于预算闸。预算终止时授权**已经
          // 裁决通过**，因此显式记录该凭据 —— 预算桶不得覆盖已发生的授权裁决，
          // 也不得反推 `not_evaluated`（Spec §4.3(b) / §18.10 F-03）。
          executionEvidence: {
            authorizationAllowed: true,
            notExecuted: true
          },
          durationMs: Date.now() - start,
          responseBytes: Buffer.byteLength(responseBody),
          requestId,
          ...requestMeta,
          ...(await auditMeta(identity, "question_budget_exhausted")),
        });
        recordMcpTraceForTool({
          traceId,
          identity,
          toolName,
          status: "ok",
          startedAt: new Date(start).toISOString(),
          turnId: requestMeta.lucyTurnId ?? null,
          sessionId: requestMeta.lucySessionId ?? null,
          requestId,
          argsSummary,
          allowed: true,
          reason: "question_budget_exhausted",
          policySource: "other"
        });
        return;
      }
      if (budgetDecision.continued) {
        // Spec 162 §6.7 / SC-30：续查生效是**独立于声明**的可区分事实，
        // 并挂到本次数据调用上（同一 requestId）。声明事实写在
        // `lucy_continue_question` 那一行的 `budgetContinuation.declared`。
        const appliedFact = {
          applied: true,
          windowId: budgetDecision.ticket?.windowId ?? null,
          round: budgetDecision.ticket?.round ?? null,
          requestId: budgetDecision.ticket?.requestId ?? null
        };
        const previousFact = (argsSummary?.budgetContinuation ?? {}) as Record<string, unknown>;
        // REQ-030-035 R3：续查换窗生效行带换窗前快照（eventKind=continuation_rollover）。
        const rolloverSnap =
          "budgetSnapshot" in budgetDecision ? budgetDecision.budgetSnapshot : undefined;
        argsSummary = {
          ...(argsSummary ?? {}),
          budgetContinuation: { ...previousFact, ...appliedFact },
          ...(rolloverSnap ? { budgetSnapshot: rolloverSnap } : {})
        };
      }
      if (budgetDecision.ticket) {
        const ticket = budgetDecision.ticket;
        // Spec 162 §6.2 / SC-13：res.close 只取消上游。结算等上游 close（取消确认），
        // 或绝对执行时限。断开本身不清定时器，也不按断开时刻少计。
        bindQuestionBudgetSettlement({
          res,
          getUpstream: () => upstreamRequestHandle,
          now: () => questionBudget.monoNow(),
          startMonoMs: ticket.startMonoMs,
          absMs: QUESTION_BUDGET_ABS_EXEC_MS,
          settle: (endMonoMs, flags) => {
            void questionBudget.settle(ticket, endMonoMs, flags);
          },
          onDisconnected: () => {
            cancelUpstreamOnCapture = true;
            noteBudgetSettlement({ clientDisconnected: true });
          },
          onDeadline: (upstream) => {
            try {
              upstream?.destroy(new Error("absolute_execution_deadline"));
            } catch {
              // 上游句柄可能已经关闭；忽略，记账照常进行。
            }
            noteBudgetSettlement({
              absoluteExecutionDeadlineMs: QUESTION_BUDGET_ABS_EXEC_MS,
              timeoutUnconfirmed: true
            });
          }
        });
      }
    }

    if (toolName === "connection_list" || toolName === "lucy_catalog" || toolName === "kx_catalog") {
      const data = toolName === "connection_list"
        ? await connectionList(identity)
        : toolName === "lucy_catalog"
          ? await lucyCatalog(identity)
          : await kxCatalog(identity);
      const responseBody = JSON.stringify({
        jsonrpc: "2.0",
        id: requestId,
        result: {
          content: [{ type: "text", text: JSON.stringify(data, null, 2) }]
        }
      });
      res.writeHead(200, { "content-type": "application/json" });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName,
        argsSummary,
        ...queryMeta,
        outcome: "ok",
        // 目录已在本地真实构建并返回（connectionList / lucyCatalog / kxCatalog
        // 的 await 已完成），执行成功是观测到的事实。
        executionEvidence: executionEvidenceFromObservation({
          executed: true,
          authorizationAllowed: true
        }),
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, "allowed")),
      });
      recordMcpTraceForTool({
        traceId,
        identity,
        toolName,
        status: "ok",
        startedAt: new Date(start).toISOString(),
        turnId: requestMeta.lucyTurnId ?? null,
        sessionId: requestMeta.lucySessionId ?? null,
        requestId,
        argsSummary,
        allowed: true,
        reason: "allowed",
        matchedRule: decision.reason
      });
      return;
    }
    if (toolName === "lucy_certified_route" || toolName === "lucy_report_template") {
      await writeCertifiedRouteResponse(identity, toolName, toolArgs, {
        res,
        requestId,
        start,
        requestMeta,
        argsSummary,
        queryMeta,
        traceId
      });
      return;
    }
    if (toolName === "lucy_explain_query" || toolName === "lucy_freshness") {
      // lucy_explain_query is served locally and returns before the shared
      // query gate below. The recovery admission has to run here.
      if (toolName === "lucy_explain_query") {
        const hiveHandled = await maybeWriteHiveDivertedResponse({
          identity,
          toolName: "lucy_explain_query",
          toolArgs,
          requestId,
          res,
          start,
          requestMeta,
          argsSummary,
          queryMeta,
          queryTables,
          traceId,
          recordAuditEntry: recordRequestAudit
        });
        if (hiveHandled) return;
        const block = await readSemanticRecoveryDenial(toolArgs);
        if (block) {
          const responseBody = jsonRpcToolResult(requestId, JSON.stringify({
            code: block.code,
            message: block.message
          }), { isError: true });
          res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
          res.end(responseBody);
          recordRequestAudit({
            ts: new Date().toISOString(),
            userId: identity.userId,
            client: identity.client,
            tool: toolName,
            argsSummary,
            ...queryMeta,
            outcome: "error",
            decisionReason: block.code,
            errorDetail: block.message,
            durationMs: Date.now() - start,
            responseBytes: Buffer.byteLength(responseBody),
            requestId,
            ...requestMeta,
            ...(await auditMeta(identity, block.code)),
          });
          recordMcpTraceForTool({
            traceId,
            identity,
            toolName,
            status: "error",
            startedAt: new Date(start).toISOString(),
            turnId: requestMeta.lucyTurnId ?? null,
            sessionId: requestMeta.lucySessionId ?? null,
            requestId,
            argsSummary,
            allowed: false,
            reason: block.code,
            policySource: "other"
          });
          return;
        }
      }
      const data = toolName === "lucy_explain_query"
        ? await lucyExplainQuery(identity, toolArgs)
        : await lucyFreshness(identity, toolArgs);
      const responseBody = jsonRpcToolResult(requestId, JSON.stringify(data, null, 2));
      const sourceRefs = await extractSourceRefs(toolName, toolArgs).catch(() => []);
      res.writeHead(200, { "content-type": "application/json" });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName,
        tables: sourceRefs.length > 0 ? sourceRefs.map((ref) => ref.physicalTable) : undefined,
        argsSummary,
        ...queryMeta,
        outcome: "ok",
        // explain / freshness 的计算已在本地真实完成并返回结果。
        executionEvidence: executionEvidenceFromObservation({
          executed: true,
          authorizationAllowed: true
        }),
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        responseRowCount: 0,
        responseColumnCount: 0,
        responseTruncated: false,
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, "allowed")),
      }, sourceRefs);
      recordMcpTraceForTool({
        traceId,
        identity,
        toolName,
        status: "ok",
        startedAt: new Date(start).toISOString(),
        turnId: requestMeta.lucyTurnId ?? null,
        sessionId: requestMeta.lucySessionId ?? null,
        requestId,
        argsSummary,
        allowed: true,
        reason: "allowed",
        resultSnapshot: {
          rowCount: 0,
          columnCount: 0,
          responseBytes: Buffer.byteLength(responseBody),
          truncated: false
        },
        sourceRefs: sourceRefs.length > 0 ? sourceRefs : null
      });
      return;
    }
    if (toolName === "wiki_read") {
      const rawKey = wikiKeyFromArgs(toolArgs);
      const { page, decision } = rawKey
        ? await canAccessWikiKey(identity, rawKey)
        : { decision: { allowed: false, reason: "wiki_key_missing" } };
      const allowed = Boolean(decision.allowed && page);
      const responseBody = allowed && page
        ? jsonRpcToolResult(requestId, JSON.stringify({ key: page.key, title: page.title, content: page.body }, null, 2))
        : jsonRpcToolResult(requestId, contextExternalReason(decision.reason), { isError: true });
      res.writeHead(200, { "content-type": "application/json" });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName,
        argsSummary: rawKey ? { key: canonicalWikiKey(rawKey) ?? "<invalid>" } : argsSummary,
        ...queryMeta,
        outcome: allowed ? "ok" : "denied",
        errorDetail: allowed ? undefined : (decision.reason ?? "wiki_forbidden"),
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, allowed ? "allowed" : (decision.reason ?? "wiki_forbidden"))),
      });
      recordMcpTraceForTool({
        traceId,
        identity,
        toolName,
        status: allowed ? "ok" : "denied",
        startedAt: new Date(start).toISOString(),
        turnId: requestMeta.lucyTurnId ?? null,
        sessionId: requestMeta.lucySessionId ?? null,
        requestId,
        argsSummary: rawKey ? { key: canonicalWikiKey(rawKey) ?? "<invalid>" } : argsSummary,
        allowed,
        reason: allowed ? "allowed" : (decision.reason ?? "wiki_forbidden"),
        policySource: "wiki_acl"
      });
      return;
    }
    if (toolName === "lucy_continue_question") {
      const args = (toolArgs as Record<string, unknown> | undefined) ?? {};
      const token = typeof args.token === "string" ? args.token : "";
      const scopeKey = budgetIdentityKey(identity.userId, identity.tokenHashPrefix ?? "");
      const declared = await questionBudget.declareContinuation(
        questionBudgetScopeMode() === "stable"
          ? budgetScopeKey(scopeKey, requestMeta.lucySessionId)
          : `turn:${requestMeta.lucyTurnId ?? "none"}`,
        token
      );
      const responseBody = jsonRpcToolResult(
        requestId,
        JSON.stringify(declared.ok
          ? { ok: true, idempotent: declared.idempotent === true, declared: declared.declared === true }
          : { ok: false, reason: declared.reason }),
        declared.ok ? {} : { isError: true }
      );
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName,
        argsSummary: {
          tokenPresent: token.length > 0,
          // Spec 162 §6.7 / SC-30：续查**声明**事实。与后续数据调用上的
          // `budgetContinuation.applied` 是两条可区分事实。
          budgetContinuation: {
            declared: declared.ok === true && declared.declared === true,
            idempotent: declared.ok === true && declared.idempotent === true,
            windowId: declared.ok ? declared.windowId ?? null : null,
            round: declared.ok ? declared.round ?? null : null
          }
        },
        outcome: declared.ok ? "ok" : "error",
        decisionReason: declared.ok ? "budget_continuation_declared" : declared.reason,
        errorDetail: declared.ok ? undefined : declared.reason,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, declared.ok ? "budget_continuation_declared" : declared.reason)),
      });
      return;
    }
    if (toolName === "lucy_begin_question") {
      // P1-60 §D2: inactive → begin_not_available，在生成 ID／写 turn／预算／BindingSession 前返回。
      {
        const beginScopeKey = bindingScopeKey(
          budgetIdentityKey(identity.userId, identity.tokenHashPrefix ?? ""),
          requestMeta.lucySessionId
        );
        let caliberParticipation: "inactive" | "active" | "unknown";
        try { caliberParticipation = await classifyCaliberParticipation({ scopeKey: beginScopeKey }); }
        catch { caliberParticipation = "unknown"; }
        if (caliberParticipation !== "active") {
          const reason = caliberParticipation === "inactive" ? "begin_not_available" : "caliber_binding_unresolved";
          const message = caliberParticipation === "inactive"
            ? "当前未启用问询上报，可直接按现有权限查询。"
            : "本次问询的口径绑定状态不可信，本次开题未提交。";
          const responseBody = JSON.stringify({
            jsonrpc: "2.0",
            id: requestId,
            result: {
              isError: true,
              content: [{ type: "text", text: message }],
              data: { reason, trace: traceId }
            }
          });
          res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
          res.end(responseBody);
          recordRequestAudit({
            ts: new Date().toISOString(),
            userId: identity.userId,
            client: identity.client,
            tool: toolName,
            argsSummary,
            outcome: "denied",
            decisionReason: reason,
            errorDetail: reason,
            durationMs: Date.now() - start,
            responseBytes: Buffer.byteLength(responseBody),
            requestId,
            ...requestMeta,
            ...(await auditMeta(identity, "allowed")),
          });
          return;
        }
        // unknown → 既有治理 unresolved 链，不套用 D2（Spec §3.1）。
        // active → 既有 begin 路径不变。
      }

      const args = (toolArgs as Record<string, unknown> | undefined) ?? {};
      const intentSummary = typeof args.intentSummary === "string" ? args.intentSummary.trim() : "";
      if (!intentSummary) {
        const responseBody = JSON.stringify({
          jsonrpc: "2.0",
          id: requestId,
          result: { isError: true, content: [{ type: "text", text: "lucy_begin_question requires intentSummary" }] }
        });
        res.writeHead(200, { "content-type": "application/json" });
        res.end(responseBody);
        recordRequestAudit({
          ts: new Date().toISOString(),
          userId: identity.userId,
          client: identity.client,
          tool: toolName,
          argsSummary,
          outcome: "error",
          errorDetail: "missing_intent_summary",
          durationMs: Date.now() - start,
          responseBytes: Buffer.byteLength(responseBody),
          requestId,
          ...requestMeta,
          ...(await auditMeta(identity, "allowed")),
        });
        recordMcpTraceForTool({
          traceId,
          identity,
          toolName,
          status: "error",
          startedAt: new Date(start).toISOString(),
          turnId: requestMeta.lucyTurnId ?? null,
          sessionId: requestMeta.lucySessionId ?? null,
          requestId,
          argsSummary,
          allowed: false,
          reason: "missing_intent_summary",
          policySource: "other"
        });
        return;
      }


      const turnId = `lucy_${randomUUID()}`;
      const storePreview = storeQuestionPreviewEnabled();
      const rawQuestion = typeof args.question === "string" ? args.question : undefined;
      const maxChars = questionPreviewMaxChars();
      const questionPreview = storePreview && rawQuestion ? redactQuestionText(rawQuestion).slice(0, maxChars) : undefined;
      const questionHash = storePreview && rawQuestion ? createHash("sha256").update(rawQuestion).digest("hex") : undefined;

      // ─── P0-1 问题类型口径绑定：激活判定（准备阶段） ───
      // 显式 `caliberBindingId` 优先；否则按 O2 触发匹配，**恰好一条**才激活。
      // 激活错（ambiguous／显式 id 不可见或不存在）→ 拒绝，**不改旧 BindingSession**。
      const explicitBindingId = typeof args.caliberBindingId === "string" ? args.caliberBindingId.trim() : "";
      const activation = await prepareCaliberBindingActivation({
        identity,
        intentSummary,
        question: rawQuestion,
        explicitBindingId: explicitBindingId || undefined
      });
      if (!activation.ok) {
        const denial = activation.denial;
        const responseBody = JSON.stringify({
          jsonrpc: "2.0",
          id: requestId,
          result: {
            isError: true,
            content: [{ type: "text", text: denial.text }],
            data: denial.payload
          }
        });
        res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
        res.end(responseBody);
        recordRequestAudit({
          ts: new Date().toISOString(),
          userId: identity.userId,
          client: identity.client,
          tool: toolName,
          argsSummary,
          outcome: "denied",
          decisionReason: denial.code,
          errorDetail: denial.code,
          failureDimension: denial.payload.failureDimension,
          durationMs: Date.now() - start,
          responseBytes: Buffer.byteLength(responseBody),
          requestId,
          ...requestMeta,
          executionEvidence: executionEvidenceFromObservation({
            authorizationAllowed: true,
            notExecuted: true
          }),
          ...(await auditMeta(identity, denial.code))
        });
        recordMcpTraceForTool({
          traceId,
          identity,
          toolName,
          status: "denied",
          startedAt: new Date(start).toISOString(),
          turnId: null,
          sessionId: requestMeta.lucySessionId ?? null,
          requestId,
          argsSummary,
          allowed: false,
          reason: denial.code,
          policySource: "other"
        });
        return;
      }
      const chosenBinding = activation.activation.binding;
      const registryGeneration = activation.activation.registryGeneration;
      const caliberScopeKey = bindingScopeKey(
        budgetIdentityKey(identity.userId, identity.tokenHashPrefix ?? ""),
        requestMeta.lucySessionId
      );

      // ─── D11 共同提交与恢复 ───
      // 锁序：注册表激活互斥区间（与注册表提交互斥，**不仅** identityKey＋sessionId
      // 锁）→ 作用域锁。进入任何写入前复核：准备阶段 generation、当前绑定文件集合
      // ＋内容摘要＋sourceMap 解析依赖。任一不满足 → `caliber_binding_unresolved`，
      // **禁止提交旧选择**；旧 BindingSession 不变。
      const beginOutcome = await withCaliberBindingRegistryExclusion(() =>
        withCaliberBindingScopeLock(caliberScopeKey, async () => {
          const proof = await verifyCurrentBindingContentAndDependencies(registryGeneration);
          const registry = currentCaliberBindingRegistry();
          if (
            !registry
            || registry.generation !== registryGeneration
            || registrySyncPending()
            || !proof.complete
            || !proof.matchesCommitted
          ) {
            return { ok: false as const, code: "caliber_binding_unresolved" as const };
          }
          // ④ 前半段：先写 `preparing`（未完成提交）。失败时旧 Session 原样恢复。
          await beginBindingSessionPreparation(caliberScopeKey, {
            turnId,
            registryGeneration,
            bindingId: chosenBinding?.bindingId ?? null,
            boundKey: chosenBinding?.boundKey ?? null,
            caliberSnapshot: chosenBinding?.caliber ?? null
          });
          // ① turn 持久化
          try {
            await writeConversationTurn({
              turnId,
              sessionId: requestMeta.lucySessionId,
              userId: identity.userId,
              tokenHashPrefix: identity.tokenHashPrefix,
              platform: requestMeta.lucyPlatform,
              client: identity.client,
              questionHash,
              questionPreview,
              questionSummary: intentSummary,
              questionSource: "reported_tool",
              redactionVersion: "v1"
            });
          } catch (err) {
            console.error("[lucy-proxy] failed to write conversation turn", err);
            await restorePriorBindingSession(caliberScopeKey);
            return { ok: false as const, code: "persist_failed" as const };
          }
          // ②（可选）预算开题。预算整体关闭时不受预算存储故障牵连。
          const begun = questionBudgetEnabled()
            ? await questionBudget.beginQuestion({
                identityKey: budgetIdentityKey(identity.userId, identity.tokenHashPrefix ?? ""),
                sessionId: requestMeta.lucySessionId,
                turnId
              })
            : { ok: true as const, previousTurnId: null, state: null as never };
          if (!begun.ok) {
            await restorePriorBindingSession(caliberScopeKey);
            return { ok: false as const, code: "budget_failed" as const, reason: begun.reason };
          }
          // ③ 取代旧轮次指针
          reportedTurns.supersede({
            identity,
            sessionId: requestMeta.lucySessionId,
            turnId
          }, begun.previousTurnId ?? undefined);
          await bindPriorSessionCalls({
            turnId,
            userId: identity.userId,
            tokenHashPrefix: identity.tokenHashPrefix,
            sessionId: requestMeta.lucySessionId,
            at: new Date().toISOString()
          });
          // ④ 后半段：提交点。仅 ④ 成功后才标 `committed`；失败／中断 → lost_or_conflict。
          await commitBindingSession(caliberScopeKey, {
            turnId,
            registryGeneration,
            bindingId: chosenBinding?.bindingId ?? null,
            boundKey: chosenBinding?.boundKey ?? null,
            caliberSnapshot: chosenBinding?.caliber ?? null
          });
          // P0-3：写入旅程词源；supersede 清旧确认／快照／用户证据（对齐 generation）。
          const committed = await readBindingSession(caliberScopeKey);
          const sagScope = ambiguityScopeKey(
            budgetIdentityKey(identity.userId, identity.tokenHashPrefix ?? ""),
            requestMeta.lucySessionId
          );
          await upsertJourneyOnBegin({
            scopeKey: sagScope,
            generation: committed.record?.generation ?? 1,
            intentSummary,
            question: rawQuestion ?? null
          });
          return { ok: true as const, previousTurnId: begun.previousTurnId };
        })
      );

      if (!beginOutcome.ok && beginOutcome.code === "caliber_binding_unresolved") {
        const denialText = "Access denied: caliber_binding_unresolved（口径绑定无法解析）：绑定注册表状态不可信，本次开题未提交";
        const responseBody = JSON.stringify({
          jsonrpc: "2.0",
          id: requestId,
          result: {
            isError: true,
            content: [{ type: "text", text: denialText }],
            data: { reason: "caliber_binding_unresolved", failureDimension: "口径绑定" }
          }
        });
        res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
        res.end(responseBody);
        recordRequestAudit({
          ts: new Date().toISOString(),
          userId: identity.userId,
          client: identity.client,
          tool: toolName,
          argsSummary,
          outcome: "denied",
          decisionReason: "caliber_binding_unresolved",
          errorDetail: "caliber_binding_unresolved",
          failureDimension: "口径绑定",
          durationMs: Date.now() - start,
          responseBytes: Buffer.byteLength(responseBody),
          requestId,
          ...requestMeta,
          executionEvidence: executionEvidenceFromObservation({
            authorizationAllowed: true,
            notExecuted: true
          }),
          ...(await auditMeta(identity, "caliber_binding_unresolved"))
        });
        recordMcpTraceForTool({
          traceId,
          identity,
          toolName,
          status: "denied",
          startedAt: new Date(start).toISOString(),
          turnId: null,
          sessionId: requestMeta.lucySessionId ?? null,
          requestId,
          argsSummary,
          allowed: false,
          reason: "caliber_binding_unresolved",
          policySource: "other"
        });
        return;
      }

      if (!beginOutcome.ok && beginOutcome.code === "persist_failed") {
        const responseBody = JSON.stringify({
          jsonrpc: "2.0",
          id: requestId,
          result: { isError: true, content: [{ type: "text", text: "lucy_begin_question failed to persist; the turn was not recorded" }] }
        });
        res.writeHead(200, { "content-type": "application/json" });
        res.end(responseBody);
        recordRequestAudit({
          ts: new Date().toISOString(),
          userId: identity.userId,
          client: identity.client,
          tool: toolName,
          argsSummary,
          outcome: "error",
          errorDetail: "conversation_turn_write_failed",
          durationMs: Date.now() - start,
          responseBytes: Buffer.byteLength(responseBody),
          requestId,
          ...requestMeta,
          ...(await auditMeta(identity, "allowed")),
        });
        recordMcpTraceForTool({
          traceId,
          identity,
          toolName,
          status: "error",
          startedAt: new Date(start).toISOString(),
          turnId: requestMeta.lucyTurnId ?? null,
          sessionId: requestMeta.lucySessionId ?? null,
          requestId,
          argsSummary,
          allowed: false,
          reason: "conversation_turn_write_failed",
          policySource: "other"
        });
        return;
      }
      // Spec 162 §7.6 / SC-39：预算整体关闭时，问询开题不受预算存储故障牵连。
      // （预算开题与轮次取代已在上面的 D11 临界区内完成。）
      if (!beginOutcome.ok && beginOutcome.code === "budget_failed") {
        const responseBody = jsonRpcToolResult(requestId, JSON.stringify({
          reason: beginOutcome.reason
        }), { isError: true });
        res.writeHead(503, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
        res.end(responseBody);
        recordRequestAudit({
          ts: new Date().toISOString(),
          userId: identity.userId,
          client: identity.client,
          tool: toolName,
          argsSummary,
          outcome: "error",
          decisionReason: beginOutcome.reason,
          errorDetail: beginOutcome.reason,
          durationMs: Date.now() - start,
          responseBytes: Buffer.byteLength(responseBody),
          requestId,
          ...requestMeta,
          ...(await auditMeta(identity, beginOutcome.reason)),
        });
        return;
      }
      if (beginOutcome.ok && beginOutcome.previousTurnId) {
        // Spec 162 §6.5：同身份同会话的新问询**显式取代**旧轮次。
        // 取代事实写进本次开题的审计行（不另开一行，避免污染四桶恒等式）。
        // 审计不得回传 scopeKey / identityKey —— 只记两个 turnId。
        argsSummary = {
          ...(argsSummary ?? {}),
          budgetSupersession: { from: beginOutcome.previousTurnId, to: turnId }
        };
      }
      // spec §8.4: lazy, sampled purge trigger on the (low-frequency) report path — no background worker.
      if (Math.random() < Number(process.env.LUCY_QUESTION_PREVIEW_PURGE_SAMPLE_RATE ?? 0.01)) {
        purgeExpiredConversationTurns().catch((err) => {
          console.error("[lucy-proxy] lazy conversation-turn purge failed", err);
        });
      }

      const responseBody = JSON.stringify({
        jsonrpc: "2.0",
        id: requestId,
        result: {
          content: [{
            type: "text",
            text: JSON.stringify({
              turnId,
              // P0-1：本次问询旅程的生效绑定（未命中时为 null）。
              activeBindingId: chosenBinding?.bindingId ?? null,
              note: "Subsequent tool calls within the attach window will be associated with this turn automatically; no need to pass extra params."
            })
          }]
        }
      });
      res.writeHead(200, { "content-type": "application/json" });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName,
        argsSummary,
        outcome: "ok",
        // 问询登记已真实持久化（writeConversationTurn 成功返回后才走到这里）。
        // 执行成功是观测到的事实，不是由 outcome 反推的结论。
        executionEvidence: executionEvidenceFromObservation({
          executed: true,
          authorizationAllowed: true
        }),
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        lucyTurnId: turnId,
        turnAttributionMode: "explicit",
        turnAttributionConfidence: "high",
        associationStatus: "confirmed",
        originalTurnId: turnId, effectiveTurnId: turnId,
        originalAttributionMode: "explicit", effectiveAttributionMode: "explicit",
        originalAssociationStatus: "confirmed", effectiveAssociationStatus: "confirmed",
        originalAttributionConfidence: "high", effectiveAttributionConfidence: "high",
        ...(await auditMeta(identity, "allowed")),
      });
      recordMcpTraceForTool({
        traceId,
        identity,
        toolName,
        status: "ok",
        startedAt: new Date(start).toISOString(),
        turnId,
        sessionId: requestMeta.lucySessionId ?? null,
        requestId,
        argsSummary,
        allowed: true,
        reason: "allowed"
      });
      return;
    }
  }

  const skillReadRequest = rpcMethod === "resources/read"
    || rpcMethod === "prompts/get"
    || (rpcMethod === "tools/call" && toolName === "lucy_skill_read");
  if (skillReadRequest) {
    try {
      await ensureSkillAuditReady();
    } catch (error) {
      console.error("[lucy-proxy] Skill audit schema unavailable; denying content read", error);
      const responseBody = JSON.stringify({
        jsonrpc: "2.0",
        id: requestId,
        error: { code: -32003, message: "Access denied: skill_audit_unavailable" }
      });
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      return;
    }
  }

  // ─── Spec 131: Governed Skills MCP Protocol Interceptions ───
  if (rpcMethod === "resources/list") {
    let resources: Array<{ uri: string; name: string; description: string; mimeType: string }> = [];
    try {
      const allSkills = await loadAllSkillsFresh();
      const accessible = await filterAccessibleSkills(identity, allSkills, "discover");
      resources = accessible.map((s) => ({
        uri: s.uri,
        name: s.name,
        description: s.description,
        mimeType: "text/markdown"
      }));
    } catch (err) {
      console.error("[lucy-proxy] failed to load resources/list", err);
    }

    const responsePayload = {
      jsonrpc: "2.0",
      id: requestId,
      result: { resources }
    };
    const responseBody = JSON.stringify(responsePayload);
    res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
    res.end(responseBody);
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: rpcMethod,
      outcome: "ok",
      // resources/list：技能清单已真实加载并按可见性过滤后返回。
      // 执行成功是观测到的事实，不是由 outcome 反推的结论。
      executionEvidence: executionEvidenceFromObservation({
        executed: true,
        authorizationAllowed: true
      }),
      durationMs: Date.now() - start,
      responseBytes: Buffer.byteLength(responseBody),
      requestId,
      ...requestMeta,
      ...(await auditMeta(identity, "allowed")),
      skillAction: "discover"
    });
    return;
  }

  if (rpcMethod === "resources/read") {
    const params = parsedRpc?.params as Record<string, unknown> | undefined;
    const uri = typeof params?.uri === "string" ? params.uri.trim() : "";
    const skill = uri ? await getSkillByUri(uri, undefined, undefined, { fresh: true }) : null;
    if (!skill) {
      const errPayload = contextUnavailableRpc(requestId, "skill_not_found");
      const responseBody = JSON.stringify(errPayload);
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: rpcMethod,
        outcome: "error",
        errorDetail: `resource_not_found:${uri}`,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, "resource_not_found")),
      });
      return;
    }

    const decision = await canAccessSkill(identity, skill, "read");
    if (!decision.allowed) {
      const errPayload = contextUnavailableRpc(requestId, decision.reason);
      const responseBody = JSON.stringify(errPayload);
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: rpcMethod,
        outcome: "denied",
        errorDetail: decision.reason,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, decision.reason ?? "denied_skill_acl")),
        ...skillAuditFields(skill, "read", decision),
      });
      return;
    }

    const responsePayload = {
      jsonrpc: "2.0",
      id: requestId,
      result: {
        contents: [
          {
            uri: skill.uri,
            mimeType: "text/markdown",
            text: skill.raw || skill.content
          }
        ]
      }
    };
    const responseBody = JSON.stringify(responsePayload);
    res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
    res.end(responseBody);
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: rpcMethod,
      outcome: "ok",
      // prompts/list：提示清单已真实加载并按可见性过滤后返回。
      // 执行成功是观测到的事实，不是由 outcome 反推的结论。
      executionEvidence: executionEvidenceFromObservation({
        executed: true,
        authorizationAllowed: true
      }),
      durationMs: Date.now() - start,
      responseBytes: Buffer.byteLength(responseBody),
      requestId,
      ...requestMeta,
      ...(await auditMeta(identity, "allowed")),
      ...skillAuditFields(skill, "read", decision),
    });
    return;
  }

  if (rpcMethod === "prompts/list") {
    let prompts: Array<{ name: string; description: string; arguments?: Array<{ name: string; description: string; required: boolean }> }> = [];
    try {
      const allSkills = await loadAllSkillsFresh();
      const accessible = await filterAccessibleSkills(identity, allSkills, "discover");
      prompts = accessible.map((s) => ({
        name: s.name,
        description: s.description,
        arguments: [
          {
            name: "context",
            description: "Optional business context or focus dimension",
            required: false
          }
        ]
      }));
    } catch (err) {
      console.error("[lucy-proxy] failed to load prompts/list", err);
    }

    const responsePayload = {
      jsonrpc: "2.0",
      id: requestId,
      result: { prompts }
    };
    const responseBody = JSON.stringify(responsePayload);
    res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
    res.end(responseBody);
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: rpcMethod,
      outcome: "ok",
      // resources/read：技能内容已真实读取并通过读取 ACL 后返回。
      // 执行成功是观测到的事实，不是由 outcome 反推的结论。
      executionEvidence: executionEvidenceFromObservation({
        executed: true,
        authorizationAllowed: true
      }),
      durationMs: Date.now() - start,
      responseBytes: Buffer.byteLength(responseBody),
      requestId,
      ...requestMeta,
      ...(await auditMeta(identity, "allowed")),
      skillAction: "discover"
    });
    return;
  }

  if (rpcMethod === "prompts/get") {
    const params = parsedRpc?.params as Record<string, unknown> | undefined;
    const promptName = typeof params?.name === "string" ? params.name.trim() : "";
    const skill = promptName ? await getSkillByName(promptName, undefined, undefined, { fresh: true }) : null;
    if (!skill) {
      const errPayload = contextUnavailableRpc(requestId, "skill_not_found");
      const responseBody = JSON.stringify(errPayload);
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: rpcMethod,
        outcome: "error",
        errorDetail: `prompt_not_found:${promptName}`,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, "prompt_not_found")),
      });
      return;
    }

    const decision = await canAccessSkill(identity, skill, "read");
    if (!decision.allowed) {
      const errPayload = contextUnavailableRpc(requestId, decision.reason);
      const responseBody = JSON.stringify(errPayload);
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: rpcMethod,
        outcome: "denied",
        errorDetail: decision.reason,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, decision.reason ?? "denied_skill_acl")),
        ...skillAuditFields(skill, "read", decision),
      });
      return;
    }

    const responsePayload = {
      jsonrpc: "2.0",
      id: requestId,
      result: {
        description: skill.description,
        messages: [
          {
            role: "user",
            content: {
              type: "text",
              text: `## Active Governed Skill: ${skill.title}\n\n${skill.content}`
            }
          }
        ]
      }
    };
    const responseBody = JSON.stringify(responsePayload);
    res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
    res.end(responseBody);
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: rpcMethod,
      outcome: "ok",
      // prompts/get：提示内容已真实读取并通过读取 ACL 后返回。
      // 执行成功是观测到的事实，不是由 outcome 反推的结论。
      executionEvidence: executionEvidenceFromObservation({
        executed: true,
        authorizationAllowed: true
      }),
      durationMs: Date.now() - start,
      responseBytes: Buffer.byteLength(responseBody),
      requestId,
      ...requestMeta,
      ...(await auditMeta(identity, "allowed")),
      ...skillAuditFields(skill, "read", decision),
    });
    return;
  }

  if (rpcMethod === "tools/call" && toolName === "lucy_skill_search") {
    const rawArgs = toolArgs as Record<string, unknown> | undefined;
    const query = typeof rawArgs?.query === "string" ? rawArgs.query.trim().toLowerCase() : (typeof rawArgs?.q === "string" ? rawArgs.q.trim().toLowerCase() : "");
    const domainFilter = typeof rawArgs?.domain === "string" ? rawArgs.domain.trim().toLowerCase() : "";

    const allSkills = await loadAllSkillsFresh();
    const accessible = await filterAccessibleSkills(identity, allSkills, "discover");

    const matches = accessible.filter((s) => {
      if (domainFilter && s.domain.toLowerCase() !== domainFilter) return false;
      if (!query) return true;
      const matchName = s.name.toLowerCase().includes(query);
      const matchTitle = s.title.toLowerCase().includes(query);
      const matchTriggers = s.triggers.some((t) => t.toLowerCase().includes(query));
      const matchDesc = s.description.toLowerCase().includes(query);
      return matchName || matchTitle || matchTriggers || matchDesc;
    });

    const result = {
      query: (rawArgs?.query ?? rawArgs?.q ?? "") as string,
      count: matches.length,
      skills: matches.map((s) => ({
        name: s.name,
        title: s.title,
        domain: s.domain,
        uri: s.uri,
        version: s.version,
        triggers: s.triggers,
        description: s.description
      }))
    };

    const responseBody = jsonRpcToolResult(requestId, JSON.stringify(result, null, 2));
    res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
    res.end(responseBody);
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: toolName,
      argsSummary,
      outcome: "ok",
      // lucy_skill_search：技能集合已真实加载并完成匹配后返回。
      // 执行成功是观测到的事实，不是由 outcome 反推的结论。
      executionEvidence: executionEvidenceFromObservation({
        executed: true,
        authorizationAllowed: true
      }),
      durationMs: Date.now() - start,
      responseBytes: Buffer.byteLength(responseBody),
      requestId,
      ...requestMeta,
      ...(await auditMeta(identity, "allowed")),
      skillAction: "discover"
    });
    recordMcpTraceForTool({
      traceId,
      identity,
      toolName,
      status: "ok",
      startedAt: new Date(start).toISOString(),
      turnId: requestMeta.lucyTurnId ?? null,
      sessionId: requestMeta.lucySessionId ?? null,
      requestId,
      argsSummary,
      allowed: true,
      reason: "allowed",
      policySource: "access_policy"
    });
    return;
  }

  if (rpcMethod === "tools/call" && toolName === "lucy_skill_read") {
    const rawArgs = toolArgs as Record<string, unknown> | undefined;
    const target = typeof rawArgs?.skill_name === "string" ? rawArgs.skill_name.trim() : (typeof rawArgs?.name === "string" ? rawArgs.name.trim() : "");
    const skill = target.startsWith("lucy-skill://")
      ? await getSkillByUri(target, undefined, undefined, { fresh: true })
      : await getSkillByName(target, undefined, undefined, { fresh: true });

    if (!skill) {
      const responseBody = jsonRpcToolResult(requestId, contextExternalReason("skill_not_found"), { isError: true });
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName,
        argsSummary,
        outcome: "error",
        errorDetail: `skill_not_found:${target}`,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, "skill_not_found")),
      });
      return;
    }

    const decision = await canAccessSkill(identity, skill, "read");
    if (!decision.allowed) {
      const responseBody = jsonRpcToolResult(requestId, contextExternalReason(decision.reason), { isError: true });
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName,
        argsSummary,
        outcome: "denied",
        errorDetail: decision.reason,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, decision.reason ?? "denied_skill_acl")),
        ...skillAuditFields(skill, "read", decision),
      });
      return;
    }

    const responseBody = jsonRpcToolResult(requestId, skill.raw || skill.content);
    res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
    res.end(responseBody);
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: toolName,
      argsSummary,
      outcome: "ok",
      // lucy_skill_read：技能内容已真实读取并通过读取 ACL 后返回。
      // 执行成功是观测到的事实，不是由 outcome 反推的结论。
      executionEvidence: executionEvidenceFromObservation({
        executed: true,
        authorizationAllowed: true
      }),
      durationMs: Date.now() - start,
      responseBytes: Buffer.byteLength(responseBody),
      requestId,
      ...requestMeta,
      ...(await auditMeta(identity, "allowed")),
      ...skillAuditFields(skill, "read", decision),
    });
    recordMcpTraceForTool({
      traceId,
      identity,
      toolName,
      status: "ok",
      startedAt: new Date(start).toISOString(),
      turnId: requestMeta.lucyTurnId ?? null,
      sessionId: requestMeta.lucySessionId ?? null,
      requestId,
      argsSummary,
      allowed: true,
      reason: "allowed",
      policySource: "access_policy"
    });
    return;
  }

  if (
    queryGuardrailsEnabled()
    && rpcMethod === "tools/call"
    && (toolName === "lucy_query" || toolName === "lucy_read_source")
    && toolArgs
    && typeof toolArgs === "object"
  ) {
    const resolvedPermissions = await effectivePermissions(identity).catch(() => null);
    const readable = new Set<string>();
    if (resolvedPermissions?.ok) {
      if (resolvedPermissions.permissions.tables.includes("*")) readable.add("*");
      for (const source of resolvedPermissions.permissions.sources) {
        if (source.sourceName) readable.add(source.sourceName);
        if (source.table) readable.add(source.table);
        if (source.connectionId && source.sourceName) readable.add(`${source.connectionId}.${source.sourceName}`);
      }
    }
    const catalog = await loadPublishedAmbiguityCatalog();
    const guard = applyLucyCallGuard({
      toolName,
      args: toolArgs,
      readableSourceNames: resolvedPermissions?.ok ? readable : null,
      catalog
    });
    if (guard.action === "stop") {
      const responseBody = jsonRpcToolResult(requestId, JSON.stringify({
        reason: guard.reason,
        repair: guard.repair,
        failureDimension: guard.failureDimension
      }), { isError: true });
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName,
        tables: queryTables.length > 0 ? queryTables : undefined,
        argsSummary,
        ...queryMeta,
        outcome: "error",
        decisionReason: guard.reason,
        errorDetail: guard.repair,
        failureDimension: guard.failureDimension,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, guard.reason)),
      });
      recordMcpTraceForTool({
        traceId,
        identity,
        toolName,
        status: "error",
        startedAt: new Date(start).toISOString(),
        turnId: requestMeta.lucyTurnId ?? null,
        sessionId: requestMeta.lucySessionId ?? null,
        requestId,
        argsSummary,
        allowed: false,
        reason: guard.reason,
        policySource: "other"
      });
      return;
    }
    toolArgs = guard.args;
    argsSummary = summarizeArgsForAudit(toolName, guard.args);
  }

  // L25-11 §7.2 / D3 — an unresolved semantic write closes the affected Lucy
  // read. This runs before the query slot is taken and before the call is
  // forwarded, so a blocked asset never reaches KTX.
  if (
    rpcMethod === "tools/call"
    && (toolName === "lucy_query" || toolName === "lucy_read_source" || toolName === "lucy_explain_query")
  ) {
    const block = await readSemanticRecoveryDenial(toolArgs);
    if (block) {
      const responseBody = jsonRpcToolResult(requestId, JSON.stringify({
        code: block.code,
        message: block.message
      }), { isError: true });
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName,
        tables: queryTables.length > 0 ? queryTables : undefined,
        argsSummary,
        ...queryMeta,
        outcome: "error",
        decisionReason: block.code,
        errorDetail: block.message,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, block.code)),
      });
      recordMcpTraceForTool({
        traceId,
        identity,
        toolName,
        status: "error",
        startedAt: new Date(start).toISOString(),
        turnId: requestMeta.lucyTurnId ?? null,
        sessionId: requestMeta.lucySessionId ?? null,
        requestId,
        argsSummary,
        allowed: false,
        reason: block.code,
        policySource: "other"
      });
      return;
    }
  }

  if (rpcMethod === "tools/call" && toolName === "lucy_query") {
    const slot = acquireLucyQuerySlot(identity);
    if (!slot.allowed) {
      const reason = "query_concurrency_exceeded";
      const responseBody = JSON.stringify({
        jsonrpc: "2.0",
        id: requestId,
        result: {
          isError: true,
          content: [{
            type: "text",
            text: `Access denied: ${reason}; active=${slot.active}; max=${slot.max}`
          }]
        }
      });
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      let sourceRefs: SourceRef[] = [];
      try {
        sourceRefs = await extractSourceRefs(toolName, toolArgs);
      } catch {
        // source attribution is best-effort for guardrail denials.
      }
      const structuredTables = sourceRefs.map((ref) => ref.physicalTable);
      const tables = [...new Set([...structuredTables, ...queryTables])];
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName,
        tables: tables.length > 0 ? tables : undefined,
        argsSummary,
        ...queryMeta,
        outcome: "denied",
        errorDetail: `${reason}:active=${slot.active};max=${slot.max}`,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, reason)),
      }, sourceRefs);
      recordMcpTraceForTool({
        traceId,
        identity,
        toolName,
        status: "denied",
        startedAt: new Date(start).toISOString(),
        turnId: requestMeta.lucyTurnId ?? null,
        sessionId: requestMeta.lucySessionId ?? null,
        requestId,
        argsSummary,
        allowed: false,
        reason,
        policySource: "rate_limit"
      });
      return;
    }
    releaseOnResponseEnd(res, slot.release);
  }

  if (
    rpcMethod === "tools/call"
    && (toolName === "lucy_query" || toolName === "lucy_read_source")
  ) {
    const hiveHandled = await maybeWriteHiveDivertedResponse({
      identity,
      toolName,
      toolArgs,
      requestId,
      res,
      start,
      requestMeta,
      argsSummary,
      queryMeta,
      queryTables,
      traceId,
      argsBeforeRewrite,
      requestPinnedCaliber,
      sourceSelection: sourceSelectionForAv,
      forcedFilters: forcedFiltersForAv,
      recordAuditEntry: recordRequestAudit
    });
    if (hiveHandled) return;
  }

  // P1-37 U2（O6 取证，KTX 0.16.0）：`sl_query` 要求 `measures` 为非空数组，与其他入参无关；
  // 缺失或为空时上游必然拒绝，且其错误文案会泄露内部工具名 `sl_query`。这里只复制该必然拒绝的条件，
  // 在转发前以 Lucy 工具名＋示例返回；放在 Hive 分流之后，只影响真正要转发给 KTX 的请求。
  if (rpcMethod === "tools/call" && toolName === "lucy_query") {
    const measuresReason = lucyQueryMeasuresRequiredReason(toolArgs);
    if (measuresReason) {
      await respondInvalidArguments(measuresReason, LUCY_QUERY_MEASURES_HINT);
      return;
    }
  }

  let outboundBody = body;
  if (rpcMethod === "tools/call" && parsedRpc && toolName === "lucy_read_source") {
    outboundBody = rewriteToolCall(parsedRpc, "sl_read_source", lucyReadSourceUpstreamArgs(toolArgs));
  }
  if (rpcMethod === "tools/call" && parsedRpc && toolName === "lucy_query") {
    outboundBody = rewriteToolCall(parsedRpc, "sl_query", lucyQueryUpstreamArgs(toolArgs));
  }
  if (rpcMethod === "tools/call" && parsedRpc && toolName === "wiki_search") {
    outboundBody = rewriteToolCall(parsedRpc, "wiki_search", wikiSearchUpstreamArgs(toolArgs));
  }

  // `initialize`, `tools/list` and `tools/call` responses are all buffered before
  // being rewritten, so they are read here once and passed down. Only these paths
  // can recover a refused upstream session (a piped response cannot be retried).
  // P1-37 U3a：`ping` 也走带恢复的缓冲路径（失效会话上 ping 同样得到 404）。
  const bufferedUpstream = rpcMethod === "initialize" || rpcMethod === "tools/list" || rpcMethod === "tools/call" || rpcMethod === "ping";
  // Strat-B DRAIN：KTX 上游语义 tools/call 计入在途，供 beginAdmissionDrain 有界排空。
  const trackKtxUpstream =
    rpcMethod === "tools/call" &&
    typeof toolName === "string" &&
    requestWouldHitUpstreamSemanticExecution(toolName);
  let upstream: IncomingMessage;
  let upstreamBody = "";
  let upstreamSession: UpstreamSessionState | undefined;
  if (trackKtxUpstream) trackUpstreamSemanticEnter();
  try {
    if (rpcMethod === "initialize") {
      // `initialize` is what establishes the session; never inject one into it.
      upstream = await withUpstreamSpan("upstream_handshake", () => forwardToKtx(req.method ?? "POST", MCP_UPSTREAM_PATH, headersWithOwnedSession(identity, req.headers), outboundBody, undefined, captureUpstreamRequest));
      upstreamBody = await readUpstreamBody(upstream);
    } else if (bufferedUpstream) {
      const forwarded = await forwardToKtxWithSession(
        identity,
        req.method ?? "POST",
        MCP_UPSTREAM_PATH,
        req.headers,
        outboundBody,
        captureUpstreamRequest
      );
      upstream = forwarded.upstream;
      upstreamBody = forwarded.body;
      upstreamSession = forwarded.session;
    } else {
      upstream = await withUpstreamSpan("upstream_call", () => forwardToKtx(
        req.method ?? "POST",
        MCP_UPSTREAM_PATH,
        headersWithOwnedSession(identity, req.headers),
        outboundBody,
        resolveOutboundSession(identity, req.headers),
        captureUpstreamRequest
      ));
    }
  } catch (err) {
    if (rpcMethod === "initialize") {
      // The client gets a 200 but KTX holds no session, so anything cached for
      // this Token is stale; drop it and let the next data call re-handshake.
      clearUpstreamSession(upstreamSessionOwner(identity));
      const instructions = instructionsInjectionEnabled() ? await buildRoleAwareInstructions(identity, requestMeta.lucySessionId) : undefined;
      currentTrace()?.mark("local_handler", { status: "ok", attrs: { handler: "initialize_fallback" } });
      const payload = localInitializePayload(requestId, instructions);
      const responseBody = JSON.stringify(payload);
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: rpcMethod,
        outcome: "ok",
        errorDetail: `upstream_unavailable:${err instanceof Error ? err.message : String(err)}`,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, "local_initialize_fallback")),
        skillAction: "discover"
      });
      return;
    }
    if (rpcMethod === "tools/list") {
      // Spec 178 / T1 — compile failure takes priority over the local fallback;
      // never serve `tools: []` for a failed identity.
      const compiled = await effectivePermissions(identity).catch(() => null);
      if (compiled && !compiled.ok && isToolsListCompileDenialReason(compiled.reason)) {
        const envelope = compileDeniedToolsListEnvelope(requestId, compiled.reason);
        const responseBytes = Buffer.byteLength(envelope.body);
        res.writeHead(envelope.statusCode, { "content-type": "application/json", "content-length": responseBytes });
        res.end(envelope.body);
        const compilerReason = formatIdentityCompilerReason(compiled.diagnostic);
        recordRequestAudit({
          ts: new Date().toISOString(),
          userId: identity.userId,
          client: identity.client,
          tool: rpcMethod,
          outcome: "denied",
          errorDetail: compiled.reason,
          durationMs: Date.now() - start,
          responseBytes,
          requestId,
          ...requestMeta,
          ...(await auditMeta(identity, compiled.reason, compilerReason ? { compilerReason } : undefined)),
        });
        return;
      }
      const payload = await localToolsListPayload(identity, requestId, requestMeta.lucySessionId);
      const responseBody = JSON.stringify(payload);
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: rpcMethod,
        outcome: "ok",
        errorDetail: `upstream_unavailable:${err instanceof Error ? err.message : String(err)}`,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, "local_tools_list_fallback")),
      });
      return;
    }

    if (rpcMethod === "tools/call" && toolName === "wiki_search") {
      const { query, limit } = wikiQueryFromArgs(toolArgs);
      const results = query ? await searchAccessibleWikiPages(identity, query, limit) : [];
      await respondLocalWikiSearch(query, limit, results, `upstream_unavailable:${err instanceof Error ? err.message : String(err)}`);
      return;
    }
    if (rpcMethod === "tools/call") {
      const reason = upstreamFailureReason(err);
      const responseBody = JSON.stringify(rpcErrorResponse(requestId, "KTX upstream unavailable", reason));
      res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(responseBody) });
      res.end(responseBody);

      let sourceRefs: SourceRef[] = [];
      try {
        sourceRefs = toolName ? await extractSourceRefs(toolName, toolArgs) : [];
      } catch {
        // Source attribution is best-effort on upstream failure.
      }
      const structuredTables = sourceRefs.map((ref) => ref.physicalTable);
      const tables = [...new Set([...structuredTables, ...queryTables])];
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: toolName ?? "tools/call",
        tables: tables.length > 0 ? tables : undefined,
        argsSummary,
        ...queryMeta,
        outcome: "error",
        errorDetail: `${reason}:${err instanceof Error ? err.message : String(err)}`,
        durationMs: Date.now() - start,
        responseBytes: Buffer.byteLength(responseBody),
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, reason)),
      }, sourceRefs);
      recordMcpTraceForTool({
        traceId,
        identity,
        toolName: toolName ?? "tools/call",
        status: "error",
        startedAt: new Date(start).toISOString(),
        turnId: requestMeta.lucyTurnId ?? null,
        sessionId: requestMeta.lucySessionId ?? null,
        requestId,
        argsSummary,
        allowed: true,
        reason,
        policySource: "other"
      });
      return;
    }
    throw err;
  } finally {
    if (trackKtxUpstream) trackUpstreamSemanticLeave();
  }

  if (upstreamSession?.recovered) {
    console.warn(`[lucy-proxy] re-established KTX upstream session user=${identity.userId} tool=${toolName ?? rpcMethod}`);
  }
  if (upstreamSession?.recoveryFailed) {
    console.error(`[lucy-proxy] KTX upstream session recovery failed user=${identity.userId} tool=${toolName ?? rpcMethod}`);
  }

  if (rpcMethod === "initialize") {
    const responseSessionId = normalizeHeader(upstream.headers["mcp-session-id"]);
    // Hold the session KTX just created, so a client that does not retain
    // `Mcp-Session-Id` still reaches KTX-bound tools on its next call.
    if (responseSessionId && (upstream.statusCode ?? 200) < 400) {
      setUpstreamSession(upstreamSessionOwner(identity), responseSessionId);
    }
    if (responseSessionId) requestMeta.lucySessionId = responseSessionId;
    if (responseSessionId && initializeClientInfo) {
      setSessionClient(
        responseSessionId,
        identity.userId,
        identity.tokenLabel,
        initializeClientInfo.name,
        initializeClientInfo.version
      );
    }
  }

  if (rpcMethod === "initialize" && instructionsInjectionEnabled()) {
    const initResult = await writeInitializeResponse(identity, upstream, upstreamBody, res, requestId, requestMeta.lucySessionId);
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: rpcMethod,
      outcome: "ok",
      // initialize：上游握手响应已真实读取并写出。
      // 执行成功是观测到的事实，不是由 outcome 反推的结论。
      executionEvidence: executionEvidenceFromObservation({
        executed: true,
        authorizationAllowed: true
      }),
      errorDetail: initResult.injectionFailed ? initResult.errorDetail : undefined,
      durationMs: Date.now() - start,
      responseBytes: initResult.responseBytes,
      requestId,
      ...requestMeta,
      ...(await auditMeta(identity, initResult.injectionFailed ? "instructions_injection_failed" : "allowed")),
      skillAction: "discover"
    });
    return;
  }

  if (rpcMethod === "tools/list") {
    const toolsList = await writeToolsListResponse(identity, upstream, upstreamBody, res, requestId, upstreamSession, requestMeta.lucySessionId);
    // Spec 178 / T1 — compile failure short-circuits inside writeToolsListResponse
    // (HTTP 403 + JSON-RPC -32003 already on the wire). Audit must record the
    // denial with the full machine reason and the structured diagnostic;
    // `role_ids` stays empty because permissionSnapshot is undefined on failure.
    if (toolsList.compileDenied) {
      const compiled = await effectivePermissions(identity).catch(() => null);
      const compilerReason = compiled && !compiled.ok
        ? formatIdentityCompilerReason(compiled.diagnostic)
        : undefined;
      const denialReason = compiled && !compiled.ok ? compiled.reason : (toolsList.errorDetail ?? "denied");
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: rpcMethod,
        outcome: "denied",
        errorDetail: denialReason,
        durationMs: Date.now() - start,
        responseBytes: toolsList.responseBytes,
        requestId,
        ...requestMeta,
        ...(await auditMeta(
          identity,
          denialReason,
          compilerReason ? { compilerReason } : undefined
        )),
      });
      return;
    }
    // Spec 177 — successful compile: the structured diagnostic still rides on
    // `compiler_reason` for admin review, never into the client body.
    const compiled = await effectivePermissions(identity).catch(() => null);
    const compilerReason = compiled && !compiled.ok
      ? formatIdentityCompilerReason(compiled.diagnostic)
      : undefined;
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: rpcMethod,
      outcome: toolsList.upstreamFailure ? "error" : "ok",
      errorDetail: toolsList.errorDetail,
      durationMs: Date.now() - start,
      responseBytes: toolsList.responseBytes,
      requestId,
      ...requestMeta,
      ...(await auditMeta(
        identity,
        withUpstreamSessionNote(
          toolsList.upstreamFailure ?? (toolsList.filterFailed ? "tools_list_filter_failed" : "allowed"),
          upstreamSession
        ),
        compilerReason ? { compilerReason } : undefined
      )),
    });
    return;
  }

  if (rpcMethod === "tools/call" && toolName === "wiki_search") {
    const originalBody = upstreamBody;
    const contentType = String(upstream.headers["content-type"] ?? "");
    const wikiUpstreamFailure = classifyUpstreamFailure(upstream.statusCode, contentType, originalBody, requestId, upstreamSession);
    if (wikiUpstreamFailure) {
      await writeUpstreamFailureResponse(wikiUpstreamFailure, {
        identity,
        upstream,
        res,
        requestId,
        toolName,
        start,
        requestMeta,
        argsSummary,
        queryMeta,
        tables: queryTables,
        sourceRefs: [],
        traceId
      });
      return;
    }
    let body = originalBody;
    let filterFailed: string | undefined;
    let filteredCount = 0;
    let forceJson = false;

    try {
      if (contentType.includes("text/event-stream")) {
        const payload = decodeSseMessage(originalBody, requestId);
        if (!payload) throw new Error("missing SSE data frame");
        const filtered = await filterWikiSearchPayload(identity, payload);
        if (filtered.failed) {
          filterFailed = filtered.failed;
          body = JSON.stringify(rpcErrorResponse(requestId, "wiki_search filtering failed", filtered.failed));
        } else {
          filteredCount = filtered.filtered;
          body = JSON.stringify(ensureJsonRpcEnvelope(filtered.payload, requestId));
        }
        forceJson = true;
      } else if (contentType.includes("application/json")) {
        const filtered = await filterWikiSearchPayload(identity, JSON.parse(originalBody));
        if (filtered.failed) {
          filterFailed = filtered.failed;
          body = JSON.stringify(rpcErrorResponse(requestId, "wiki_search filtering failed", filtered.failed));
          forceJson = true;
        } else {
          filteredCount = filtered.filtered;
          body = JSON.stringify(ensureJsonRpcEnvelope(filtered.payload, requestId));
          forceJson = true;
        }
      } else {
        filterFailed = `wiki_search_filter_failed:unsupported_content_type:${contentType || "<missing>"}`;
        body = JSON.stringify(rpcErrorResponse(requestId, "wiki_search filtering failed", filterFailed));
        forceJson = true;
      }
    } catch (err) {
      filterFailed = `wiki_search_filter_failed:${err instanceof Error ? err.message : String(err)}`;
      body = JSON.stringify(rpcErrorResponse(requestId, "wiki_search filtering failed", filterFailed));
      forceJson = true;
    }

    // Preserve upstream search and ACL filtering. A canonical keyword fallback
    // fills a successful empty index result; it never masks upstream/filter errors.
    if (!filterFailed && wikiSearchPayloadIsEmpty(JSON.parse(body))) {
      const { query, limit } = wikiQueryFromArgs(toolArgs);
      const results = query ? await searchAccessibleWikiPages(identity, query, limit) : [];
      if (results.length > 0) {
        await respondLocalWikiSearch(query, limit, results);
        return;
      }
    }

    const headers = forceJson ? bufferedJsonHeaders(upstream) : passthroughBodyHeaders(upstream);
    const responseBytes = Buffer.byteLength(body);
    headers["content-length"] = responseBytes;
    res.writeHead(upstream.statusCode ?? 200, headers);
    res.end(body);
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: toolName,
      argsSummary,
      ...queryMeta,
      outcome: filterFailed ? "error" : "ok",
      errorDetail: filterFailed,
      durationMs: Date.now() - start,
      responseBytes,
      requestId,
      ...requestMeta,
      ...(await auditMeta(identity, withUpstreamSessionNote(
        filterFailed ? "wiki_search_filter_failed" : filteredCount > 0 ? `wiki_filtered:${filteredCount}` : "allowed",
        upstreamSession
      ))),
    });
    recordMcpTraceForTool({
      traceId,
      identity,
      toolName,
      status: filterFailed ? "error" : "ok",
      startedAt: new Date(start).toISOString(),
      turnId: requestMeta.lucyTurnId ?? null,
      sessionId: requestMeta.lucySessionId ?? null,
      requestId,
      argsSummary,
      allowed: !filterFailed,
      reason: withUpstreamSessionNote(
        filterFailed ?? (filteredCount > 0 ? `wiki_filtered:${filteredCount}` : "allowed"),
        upstreamSession
      ),
      policySource: "wiki_acl"
    });
    return;
  }

  if (rpcMethod === "tools/call" && (toolName === "lucy_query" || toolName === "lucy_read_source")) {
    await writeLucySemanticResponse(
      identity,
      upstream,
      upstreamBody,
      res,
      requestId,
      toolName,
      toolArgs,
      start,
      requestMeta,
      argsSummary,
      queryMeta,
      queryTables,
      traceId,
      upstreamSession,
      {
        scopeIntersectionEmpty,
        originalUserFilters,
        argsBeforeRewrite,
        requestPinnedCaliber,
        sourceSelection: sourceSelectionForAv,
        forcedFilters: forcedFiltersForAv
      }
    );
    return;
  }

  // For tool calls: normalize finite SSE to JSON (Streamable HTTP clients such as
  // Cursor / Claude Code hang on Content-Length + keep-alive SSE).
  // Non-SSE JSON still passes through with original headers.
  if (rpcMethod === "tools/call") {
    const responseBody = Buffer.from(upstreamBody);
    const contentType = String(upstream.headers["content-type"] ?? "");
    let sourceRefs: SourceRef[] = [];
    let tables: string[] | undefined;
    if (toolName) {
      try {
        const extracted = await extractTables(toolName, toolArgs);
        const merged = new Set([...extracted, ...queryTables]);
        if (merged.size > 0) tables = [...merged];
      } catch {
        // don't fail the request
      }
      if (!tables && queryTables.length > 0) tables = queryTables;
      try {
        const structuredRefs = await extractSourceRefs(toolName, toolArgs);
        const coveredTables = new Set(structuredRefs.map((ref) => ref.physicalTable));
        const fallbackTables = queryTables.filter((table) => !coveredTables.has(table));
        const fallbackRefs = fallbackTables.length > 0 ? await resolveSourceRefsForTables(fallbackTables) : [];
        sourceRefs = [...structuredRefs, ...fallbackRefs];
      } catch {
        // source normalization is best-effort; never block the response
      }
    }
    const callUpstreamFailure = classifyUpstreamFailure(upstream.statusCode, contentType, upstreamBody, requestId, upstreamSession);
    if (callUpstreamFailure) {
      await writeUpstreamFailureResponse(callUpstreamFailure, {
        identity,
        upstream,
        res,
        requestId,
        toolName: toolName ?? "tools/call",
        start,
        requestMeta,
        argsSummary,
        queryMeta,
        tables: tables ?? queryTables,
        sourceRefs,
        traceId
      });
      return;
    }

    let outBody = responseBody;
    let headers: Record<string, string | string[] | number>;
    let forceJson = false;

    if (contentType.includes("text/event-stream")) {
      try {
        const payload = decodeSseMessage(responseBody.toString(), requestId);
        if (!payload) throw new Error("missing SSE data frame");
        outBody = Buffer.from(JSON.stringify(ensureJsonRpcEnvelope(payload, requestId)));
        forceJson = true;
      } catch {
        // Keep original body if we cannot decode; still prefer JSON headers when
        // we successfully rewrite below. On decode failure, pass through as-is.
        forceJson = false;
      }
    }

    if (forceJson) {
      headers = bufferedJsonHeaders(upstream);
    } else {
      headers = {};
      for (const [k, v] of Object.entries(upstream.headers)) {
        if (v !== undefined) headers[k] = v;
      }
    }
    // Full body is buffered; never emit Content-Length together with chunked TE.
    delete headers["transfer-encoding"];
    if (forceJson) delete headers["connection"];
    headers["content-length"] = outBody.byteLength;
    res.writeHead(upstream.statusCode ?? 200, headers);
    res.end(outBody);

    const callUpstreamStatus = upstream.statusCode ?? 200;
    let outcome: "ok" | "error" = callUpstreamStatus >= 400 ? "error" : "ok";
    let errorDetail: string | undefined = callUpstreamStatus >= 400
      ? `upstream_status=${callUpstreamStatus}`
      : undefined;
    try {
      const sniffType = forceJson ? "application/json" : contentType;
      if (sniffType.includes("application/json")) {
        const parsed = JSON.parse(outBody.toString()) as Record<string, unknown>;
        if (parsed.error || (parsed.result as Record<string, unknown> | undefined)?.isError) {
          outcome = "error";
          const parsedDetail = JSON.stringify(parsed.error ?? (parsed.result as Record<string, unknown>)?.content);
          errorDetail = errorDetail ? `${errorDetail};${parsedDetail}` : parsedDetail;
        }
      }
    } catch {
      // best-effort sniff; don't fail the request
    }

    const responseMeta = responseAuditMeta(responseBody, upstream.headers["content-type"]);
    recordRequestAudit({
      ts: new Date().toISOString(),
      userId: identity.userId,
      client: identity.client,
      tool: toolName ?? "tools/call",
      tables,
      argsSummary,
      ...queryMeta,
      outcome,
      errorDetail,
      // 上游响应已真实读取并 sniff 解析（上面的 JSON.parse 已判定 outcome），
      // 因此登记的是观测到的事实，不是由 outcome 反推的结论。
      executionEvidence: executionEvidenceFromObservation(
        outcome === "ok"
          ? { executed: true, authorizationAllowed: true }
          : { failed: true, authorizationAllowed: true }
      ),
      durationMs: Date.now() - start,
      ...responseMeta,
      requestId,
      ...requestMeta,
      ...(await auditMeta(identity, withUpstreamSessionNote(outcome === "ok" ? "allowed" : "upstream_error", upstreamSession))),
    }, sourceRefs);
    recordMcpTraceForTool({
      traceId,
      identity,
      toolName: toolName ?? "tools/call",
      status: outcome,
      startedAt: new Date(start).toISOString(),
      turnId: requestMeta.lucyTurnId ?? null,
      sessionId: requestMeta.lucySessionId ?? null,
      requestId,
      argsSummary,
      allowed: true,
      reason: withUpstreamSessionNote(outcome === "ok" ? "allowed" : "upstream_error", upstreamSession),
      resultSnapshot: resultSnapshotFromAuditMeta(responseMeta),
      sourceRefs: sourceRefs.length > 0 ? sourceRefs : null
    });
  } else {
    if (bufferedUpstream) {
      // Body was already consumed for session handling (e.g. `initialize` with
      // instructions injection disabled); replay it instead of piping an empty
      // stream.
      const headers = passthroughBodyHeaders(upstream);
      headers["content-length"] = Buffer.byteLength(upstreamBody);
      res.writeHead(upstream.statusCode ?? 200, headers);
      res.end(upstreamBody);
    } else {
      pipeResponse(upstream, res);
    }
    if (rpcMethod) {
      recordRequestAudit({
        ts: new Date().toISOString(),
        userId: identity.userId,
        client: identity.client,
        tool: rpcMethod,
        outcome: (upstream.statusCode ?? 200) >= 400 ? "error" : "ok",
        errorDetail: (upstream.statusCode ?? 200) >= 400 ? `upstream_status=${upstream.statusCode}` : undefined,
        durationMs: Date.now() - start,
        requestId,
        ...requestMeta,
        ...(await auditMeta(identity, (upstream.statusCode ?? 200) >= 400 ? "upstream_error" : "allowed")),
      });
    }
  }
}

async function handlePassthrough(req: IncomingMessage, res: ServerResponse, admitted: AdmittedRequest): Promise<void> {
  const { identity } = admitted;
  const heldSession = resolveOutboundSession(identity, req.headers);
  // `DELETE /mcp` terminates the MCP session; a cached id would otherwise be
  // replayed on the next data call against a session KTX has already dropped.
  // Only a session this Token holds can be terminated here.
  if (heldSession && req.method === "DELETE") clearUpstreamSession(upstreamSessionOwner(identity), heldSession);
  const upstream = await forwardToKtx(
    req.method ?? "GET",
    MCP_UPSTREAM_PATH,
    headersWithOwnedSession(identity, req.headers),
    undefined,
    heldSession
  );
  pipeResponse(upstream, res);
}

/**
 * V5 — lucy-skills passthrough.
 * Routes requests hitting `/mcp/skills*` to the lucy-skills upstream
 * (default 127.0.0.1:7881). Strips the `/mcp/skills` prefix so the upstream
 * sees a normal `/mcp` path. No KTX-specific post-processing (no
 * instructions injection, no ACL, no audit/trace write — those are
 * KTX-shaped and would produce noise for a read-only resources server).
 *
 * To be revisited: if skills need trace evidence or ACL, fold them in here.
 */
async function handleSkillsPassthrough(req: IncomingMessage, res: ServerResponse, admitted: AdmittedRequest): Promise<void> {
  const { body } = admitted;
  const upstream = await forwardToUpstream(
    { host: LUCY_SKILLS_HOST, port: LUCY_SKILLS_PORT },
    req.method ?? "GET",
    MCP_UPSTREAM_PATH,
    req.headers,
    body.byteLength > 0 ? body : undefined,
    "lucy-skills"
  );
  pipeResponse(upstream, res);
}

function normalizeHeader(v: string | string[] | undefined): string | undefined {
  if (!v) return undefined;
  return Array.isArray(v) ? v[0] : v;
}

/** Same gate as a live lucy_query: authorize, then forward the call to KTX (or Hive). */
export async function forwardAuthorizedLucyQuery(
  identity: Identity,
  args: Record<string, unknown>,
  onRequest?: (request: ClientRequest) => void
): Promise<{ ok: true; payload: unknown } | { ok: false; reason: string }> {
  const decision = await authorizeAndRewrite(identity, "lucy_query", args);
  if (!decision.allowed) return { ok: false, reason: decision.reason ?? "acl_denied" };
  const outbound = decision.forcedFilters ? { ...args, forced_filters: decision.forcedFilters } : args;
  const projectRoot = await resolveProjectRoot();
  const hiveDecision = await resolveAndMaybeServeHiveTool({
    projectRoot,
    tool: "lucy_query",
    connectionId: firstConnectionIdFromArgs(outbound),
    args: outbound
  });
  if (hiveDecision.action === "error") {
    return { ok: false, reason: hiveDecision.reason };
  }
  if (hiveDecision.action === "serve_hive") {
    const payload = hiveBridgePayload(hiveDecision.response);
    if (payload.ok === false) {
      return { ok: false, reason: typeof payload.reason === "string" ? payload.reason : "hive_query_failed" };
    }
    return { ok: true, payload };
  }
  try {
    const held = getUpstreamSession(upstreamSessionOwner(identity));
    const sessionId = held ?? (await (async () => {
      const recovery = await handshakeUpstreamSession(identity);
      return recovery.ok ? recovery.sessionId : undefined;
    })());
    if (!sessionId) return { ok: false, reason: "execution_interrupted" };
    const body = Buffer.from(JSON.stringify({
      jsonrpc: "2.0",
      id: `lucy-offline-batch-${randomUUID()}`,
      method: "tools/call",
      params: { name: "lucy_query", arguments: outbound }
    }));
    const upstream = await forwardToKtx("POST", "/mcp", { "content-type": "application/json" }, body, sessionId, onRequest);
    const text = await readUpstreamBody(upstream);
    if ((upstream.statusCode ?? 200) >= 400) return { ok: false, reason: "execution_interrupted" };
    return {
      ok: true,
      payload: decodeUpstreamPayload(text, String(upstream.headers["content-type"] ?? ""), "offline-batch")
    };
  } catch {
    return { ok: false, reason: "execution_interrupted" };
  }
}

const ADMISSION_AUDIT: AdmissionAudit = {
  record: (entry) => recordAudit(entry),
  meta: auditMeta,
  correlation: correlationMeta
};

/** Method / tool name / id for the ledger; never arguments or content. */
function ledgerRequestShape(req: IncomingMessage, body: Buffer): {
  method: string;
  tool?: string;
  requestId: string | number | null;
} {
  const verb = req.method ?? "GET";
  if (body.byteLength === 0) return { method: verb, requestId: null };
  try {
    const parsed = JSON.parse(body.toString()) as {
      method?: unknown;
      id?: unknown;
      params?: { name?: unknown };
    };
    const method = typeof parsed.method === "string" ? parsed.method : verb;
    const tool = method === "tools/call" && typeof parsed.params?.name === "string" ? parsed.params.name : undefined;
    const id = typeof parsed.id === "string" || typeof parsed.id === "number" ? parsed.id : null;
    return { method, tool, requestId: id };
  } catch {
    return { method: verb, requestId: null };
  }
}

export type BuildProxyOptions = {
  /** Tests only: override buffer / wall-clock limits. Production reads tighten-only env. */
  responseCommit?: ResponseCommitConfig;
  /** Tests only: ledger with an injected store provider. */
  ledger?: ReleaseLedger;
  /** Called after an operation reaches a terminal ledger state (projection trigger). */
  onOperationSettled?: () => void;
};

/**
 * B16：构造预算持久化适配器。
 *
 * 审计模块在部分测试里被整体 mock，此时持久化导出不存在 —— 此时返回
 * `null` 表示**未装配**（降级为进程内计数），而不是在请求路径上抛错。
 */
function createBudgetPersistence(): BudgetPersistence | null {
  try {
    const load = loadBudgetState;
    const save = saveBudgetState;
    const list = listBudgetScopes;
    if (typeof load !== "function" || typeof save !== "function" || typeof list !== "function") {
      return null;
    }
    return {
      load: (scopeKey) => load(scopeKey),
      save: (scopeKey, state, idempotencyKey) => save(scopeKey, state, idempotencyKey),
      listScopes: () => list()
    };
  } catch {
    return null;
  }
}

/**
 * 宿主确认提交 HTTP（非 MCP tools/call）。
 * POST /mcp/host/source-ambiguity/confirm
 * Body: { sessionId, generation, selectedIdentity }
 * Auth: Bearer + `actorKind=person` + `x-lucy-host-attestation`；
 * 禁止 automation／未标注 actor／缺宿主头用同一 MCP Bearer 自证。
 */
async function handleSourceAmbiguityHostConfirm(
  req: IncomingMessage,
  res: ServerResponse
): Promise<boolean> {
  const pathname = (req.url ?? "").split("?")[0];
  if (pathname !== SOURCE_AMBIGUITY_CONFIRM_PATH && pathname !== `${SOURCE_AMBIGUITY_CONFIRM_PATH}/`) {
    return false;
  }
  if ((req.method ?? "").toUpperCase() !== "POST") {
    const body = JSON.stringify({ error: "Method not allowed" });
    res.writeHead(405, {
      "content-type": "application/json",
      "content-length": Buffer.byteLength(body),
      allow: "POST"
    });
    res.end(body);
    return true;
  }
  const sessionHeader =
    normalizeHeader(req.headers["mcp-session-id"])
    || normalizeHeader(req.headers["x-lucy-session-id"]);
  const identify = await identifyRequestDetailed(req.headers.authorization, sessionHeader);
  if (!identify.ok) {
    const body = JSON.stringify({ error: "Unauthorized" });
    res.writeHead(401, { "content-type": "application/json", "content-length": Buffer.byteLength(body) });
    res.end(body);
    return true;
  }
  const hostAttestation = normalizeHeader(req.headers[LUCY_HOST_ATTESTATION_HEADER]);
  const hostAdmit = admitHostConfirmRequest({
    identity: identify.identity,
    hostAttestationHeader: hostAttestation
  });
  if (!hostAdmit.ok) {
    const body = JSON.stringify({
      error: "Forbidden",
      reason: hostAdmit.reason,
      detail: "Source confirmation requires actorKind=person and x-lucy-host-attestation"
    });
    res.writeHead(403, { "content-type": "application/json", "content-length": Buffer.byteLength(body) });
    res.end(body);
    return true;
  }
  let payload: {
    sessionId?: unknown;
    generation?: unknown;
    selectedIdentity?: unknown;
  };
  try {
    const raw = await readBody(req);
    payload = JSON.parse(raw.toString("utf8")) as typeof payload;
  } catch {
    const body = JSON.stringify({ error: "Invalid JSON body" });
    res.writeHead(400, { "content-type": "application/json", "content-length": Buffer.byteLength(body) });
    res.end(body);
    return true;
  }
  const sessionId =
    typeof payload.sessionId === "string" && payload.sessionId.trim()
      ? payload.sessionId.trim()
      : sessionHeader;
  const generation = typeof payload.generation === "number" ? payload.generation : Number.NaN;
  const selected = payload.selectedIdentity;
  const identityOk =
    selected
    && typeof selected === "object"
    && !Array.isArray(selected)
    && typeof (selected as SourceIdentity).connectionId === "string"
    && typeof (selected as SourceIdentity).schema === "string"
    && typeof (selected as SourceIdentity).sourceName === "string"
    && typeof (selected as SourceIdentity).physicalTable === "string";
  if (!sessionId || !Number.isInteger(generation) || !identityOk) {
    const body = JSON.stringify({
      error: "Invalid confirm payload",
      detail: "sessionId, generation, selectedIdentity required"
    });
    res.writeHead(400, { "content-type": "application/json", "content-length": Buffer.byteLength(body) });
    res.end(body);
    return true;
  }
  const identityKey = budgetIdentityKey(
    identify.identity.userId,
    identify.identity.tokenHashPrefix ?? ""
  );
  const scopeKey = ambiguityScopeKey(identityKey, sessionId);
  const attested = await attestSourceConfirmation({
    scopeKey,
    generation,
    selectedIdentity: selected as SourceIdentity
  });
  if (!attested.ok) {
    const body = JSON.stringify({ ok: false, reason: attested.reason });
    res.writeHead(409, { "content-type": "application/json", "content-length": Buffer.byteLength(body) });
    res.end(body);
    return true;
  }
  const body = JSON.stringify({
    ok: true,
    confirmedSourceKey: attested.journey.confirmedSourceKey,
    generation: attested.journey.generation
  });
  res.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(body) });
  res.end(body);
  return true;
}

export function buildProxy(options: BuildProxyOptions = {}) {
  assertSkillsPassthroughPolicy();
  const ledger = options.ledger ?? new ReleaseLedger();
  const skillsPassthroughEnabled = skillsPassthroughRequested();
  const port = Number(process.env.LUCY_PROXY_PORT ?? 7879);
  const host = process.env.LUCY_PROXY_HOST ?? "127.0.0.1";

  // B16：装配**持久化**预算（重启不丢，Spec §10.5「以账本为准幂等重建计数」）。
  //
  // 持久层**未装配**（审计模块在测试中被整体 mock）→ 降级为进程内计数：
  // 预算仍然生效，只是不跨进程。持久层已装配但读写失败仍然失败关闭。
  installBudgetPersistence(createBudgetPersistence());

  // B25：装配账本序号解析器 —— `access_log.ledger_seq` 记录行写入时
  // canonical ledger 的已提交上界，供 as-of S 视图纳入。
  setLedgerSeqResolver(async () => {
    const store = await getSecurityStore();
    if (!store.ok) return null;
    const max = store.value.maxEventSeq();
    return max.ok ? max.value : null;
  });

  // B7：启动时**从账本**派生未闭合操作并幂等追加恢复标记；不重放业务。
  void runStartupRecoveryScan();

  const server = createServer(async (req: IncomingMessage, res: ServerResponse) => {
    // Atomic SERVING check + ticket precedes every async admission/dispatch step.
    // GET is an idle transport subscription, not an accepted business RPC.
    const work = req.method === "GET" ? null : admitMcpProcessWork(res);
    const phase = getProcessLifecyclePhase();
    if ((work && !work.ok) || phase === "DRAINING" || phase === "STOPPING" || phase === "STOPPED") {
      res.writeHead(503, { "content-type": "application/json", "cache-control": "no-store" });
      const denied = work && !work.ok ? work.error : null;
      res.end(JSON.stringify({ ok: false, error: {
        code: denied?.code ?? SERVICE_DRAINING, message: denied?.message ?? SERVICE_DRAINING_MESSAGE,
        ...(denied && "requestId" in denied ? { requestId: denied.requestId, deadlineAt: denied.deadlineAt, rejectedAt: denied.rejectedAt } : {})
      } }));
      return;
    }
    const idleReloadError = req.method === "GET" ? mcpReloadAdmissionError() : null;
    if (idleReloadError) {
      res.writeHead(503, { "content-type": "application/json", "cache-control": "no-store" });
      res.end(JSON.stringify({ ok: false, error: { code: idleReloadError.code, message: idleReloadError.message,
        requestId: idleReloadError.requestId, deadlineAt: idleReloadError.deadlineAt, rejectedAt: idleReloadError.rejectedAt } }));
      return;
    }
    const handle = async () => {
    try {
      // 宿主 attested 确认：非 tools/call，先于 MCP 准入信封校验。
      if (await handleSourceAmbiguityHostConfirm(req, res)) return;

      // T04-3: stamp before admission so a narrowing committed while identity
      // is being resolved still covers this request.
      const authorizationStamp = currentAuthorizationSequence();
      // ─── Lucy v0.25 / L25-09 S02 / B6 / D3 ────────────────────────────────
      // 入口身份在**准入之前**分配：operation_id / attempt_id / ingress_event_id
      // 同时分配（D3）。被拒绝的请求也有 attempt_id，只是 execution=not_executed。
      const ingress = allocateIngressIdentity({ endpointId: "mcp-http", operationPrefix: "mcp" });
      const admitted = await admitMcpRequest(req, res, ADMISSION_AUDIT, {
        skillsPassthroughEnabled,
        readBody,
        // 入口持久化屏障：`received` 写入成功才允许后续的授权 / 分派。
        onReceived: async ({ identity, sessionId }) => {
          const store = await getSecurityStore();
          if (!store.ok) return { ok: false, reason: "security_store_unavailable" };
          const appended = appendIngressReceived({
            operationId: ingress.operationId,
            attemptId: ingress.attemptId,
            endpointId: ingress.endpointId,
            actor: identity.userId,
            actorType: "agent",
            networkInfo: req.socket?.remoteAddress,
            sessionFingerprint: identity.tokenHashPrefix,
            method: req.method ?? "",
            sessionId,
            appender: (event) => {
              const committed = store.value.appendEvent({
                eventId: event.eventId,
                operationId: event.operationId,
                phase: event.phase,
                actor: event.actor,
                actorType: event.actorType,
                networkInfo: event.networkInfo,
                sessionFingerprint: event.sessionFingerprint,
                endpointId: event.endpointId,
                verdict: event.verdict,
                resultSummary: event.resultSummary
              });
              if (!committed.ok) return { ok: false, reason: committed.reason };
              return { ok: true, seq: committed.value.seq };
            }
          });
          if (!appended.ok) return { ok: false, reason: appended.reason };
          // U12：仅在 received 已提交后回传三项审计关联头。
          const headers = buildCorrelationHeaders(ingress);
          for (const [name, value] of Object.entries(headers)) res.setHeader(name, value);
          return { ok: true };
        }
      });
      if (!admitted.ok) return;
      const barrier = beginGuardedRequest(admitted.identity, res, authorizationStamp);
      // T07 / Spec §5.1: durable `request_admitted` before any upstream work;
      // content is released only after a durable `response_prepared`.
      const shape = ledgerRequestShape(req, admitted.body);
      const context: ReleaseOperationContext = {
        // 复用入口分配的 operation_id —— `received` 与 `request_admitted` 属同一操作。
        operationId: ingress.operationId,
        actor: admitted.identity.userId,
        actorType: "agent",
        networkInfo: req.socket?.remoteAddress,
        sessionFingerprint: admitted.identity.tokenHashPrefix,
        method: shape.method,
        tool: shape.tool
      };
      const gated = await beginGatedResponse(res, {
        ledger,
        context,
        requestId: shape.requestId,
        isCurrent: () => barrier.isCurrent(),
        config: options.responseCommit,
        onWorkRegistered: trackMcpResponseCommit,
        onSettled: options.onOperationSettled
      });
      if (!gated) return;
      await runWithBarrier(barrier, async () => {
        if (admitted.route === "skills") {
          await handleSkillsPassthrough(req, res, admitted);
        } else if (req.method === "POST") {
          await handlePost(req, res, admitted);
        } else {
          await handlePassthrough(req, res, admitted);
        }
      });
    } catch (err) {
      if (!res.headersSent) {
        const statusCode = err instanceof BodyTooLargeError ? err.statusCode : 502;
        const detail = err instanceof BodyTooLargeError ? err.message : "Upstream unavailable";
        res.writeHead(statusCode, { "content-type": "application/json" });
        res.end(JSON.stringify({ error: "Proxy error", detail }));
      }
    }
    };
    if (work?.ok) await work.run(handle);
    else await handle();
  });

  return { server, host, port };
}
