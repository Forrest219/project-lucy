# P170 TERM helper revision11 独立只读复核

**APPROVED（限定缺失注入目标的辅助恢复资格）**，本次窄差异无剩余 P1/P2；fresh actual TERM 仍由 M 授权，不签旧10TERM PASS 或完整 F70/UAT。

已独立读取10TERM实际原始helper invocation/stderr/规范503与退出状态，以及10→11全差异、hash/freeze/157离线日志。旧10的实际stop143/nonOOM/1.480秒、原503/term-end/writerfailed受到其已有证据支持；helper在exactbackup通过后于target.lstat触发ENOENT，尚未执行unlink或replace，stdout为空/exit1，故后续恢复/审计不能追补。不能从ENOENT推定某个删除主体或产品恢复完成。

新helper只有在原app已stop且host验证本task原卷、exact私有backup的dev/inode/hash/size/mode/uid/gid/nlink/noSymlink及原注入backup均匹配后，才检查target。仅lstat明确FileNotFoundError归missing，其余错误传播；符号链接（含dangling）lstat成功，随后kind检查拒绝。existing target只接受exact注入FIFO，任何新合法regular或错FIFO拒绝。缺父目录虽lstatENOENT，但不mkdir，最终replace明确失败，不能造路径/任意字节。

不预unlink，直接os.replace exactbackup→target，在已停私有卷/无其他产品writer的受限场景下原子恢复既有preimage。输出targetBefore/action分列missing与exactFIFO，不猜actor。恢复后exact原inode/bytes/metadata、backupAbsent、WAL/lock前后hash不变仍must。备份已不存在时原来仅验证exact已恢复original的幂等分支保留。

driver/oracles相对10逐字一致，因此原stop143/nonOOM/<=40、规范原503/transportGAP、readonly-root/networknone/capdropALL/uid10001同AE0仅挂原卷、执行+absence共10秒、latest helper未知不复用旧true且main4/helper严格清理聚合、原FAIL不洗、重启原app同Token/原问题/SQL/预算/有效审计后段全部保留。没有产品/WAL/latch直接修补，没有扩大恢复合同。

157/157与四compile是作者实际记录，reviewer未重跑；actual11仍NOTRUN待授权。旧10TERM FAIL与10failure实际PASS各自保留，不能按新工具重写历史。

实际SHA256：

- `verify-semantic-read-docker.py` `530de7c0f763cedffaacd9f441a60293992944e70392494a665a832645998030`
- `semantic-oracles.py` `13e241280344def1c88dadcc76a48d6a28b837de854ed8265dc048177f0b9c05`
- `semantic-control.py` `30991a77080b9aa96b6ecbe2926399b54d3df254d498f6aebf952c97ac7e3851`
- `verify-semantic-read-docker.test.py` `7febe88c59c3cb3332eaf24913d5a3a32d1914d9eb30f91290c180f9daba1db9`
- `driver-freeze.json` `4d7b0cf35e24d241d4c676b9cc80b291d92cbf8ad8d2fdf712ace0c44d8a5347`

未运行新 tests/Docker/SQL，不修改任何 source/旧证据/共享状态。
