# P1-70 r2 冻结／三项独立复核竞态关闭

当前代码冻结；精确四runtime／三tests hash与实际argv见 `implementation-manifest-r2.json`。相对旧r4基线完整差异是 `implementation-runtime-r2.diff`；相对r1阶段差异是 `implementation-cr-r1-r2.diff`。r1 manifest、77/77结果、报告及 `implementation-r1-source-snapshot/` 原样保留，不能代签最终r2。

## 本轮窄修

仅修改既有白名单内mcp-proxy.ts及C拥有的两tests。其他三个runtime和A的api.catalog-assets.test.ts精确hash不变；预算模块、计费常量、原timeout、process-drain、entrypoint、WebUI与上游不改。

| 独立CR具体缺陷 | 真正先红 | r2修复与当前断言 |
|---|---|---|
| 旧WAL阻断快照→owner已完成删登记→nostage权威重查漏固定截止 | cr-snapshot-deadline-red.log：原入口20秒已过仍允许 | 该阻断快照路径的复核前后都查原资格deadline/cancel/TERM/ACL；**始终无block的普通请求仍不受20秒整体截断** |
| revalidation多个await/earlyreturn/throw后TERM被降为semantic HTTP200 | cr-late-priority-cancel-red.log：实际HTTP200而非503 | wrapper统一在恢复guard结果、revalidation结果与catch出口重新检查原barrier／TERM优先；实际lateTERM HTTP503 SERVICE_DRAINING、业务0 |
| wait/revalidation完成后，budget-off非Hive resolver await期间客户端已断，capture仍写RPC body | cr-known-server-close-red.log：明确等实际server res.close后才释放真实resolver，业务仍1 | capture在forwardToUpstream.end(body)之前同步检查真正signal/TERM/原budget绝对剩余，destroy不发业务；实际业务0，原MCP票据终结；不把等待资格20秒作为执行总截止 |
| 同一capture TERM分支被原generic upstream catch再降为HTTP200 | cr-capture-term-response-red.log | 仅曾进入本条等待的新路径保留TERM canonical503；原业务审计真值不谎称未执行，实际该反例业务0 |

没有用宽窗／stdout结果代替实际HTTP或业务调用计数。原复核红与首次注册/phase/TERM红均保留。新的取消见证用真实response.close事件，不固定sleep猜客户端断连是否已被服务端观察到。

## 最终验证

cwd：隔离worktree/webui；单worker，真实HTTP用已授权随机回环监听／临时合成项目，没有Docker或外部SQL。

```sh
npx vitest run --maxWorkers=1 server/__tests__/semantic-read-write-settle.test.ts server/__tests__/semantic-batch-recovery.test.ts server/__tests__/semantic-batch-journal-lifecycle.test.ts server/__tests__/mcp-proxy-execution-stale.test.ts server/__tests__/mcp-reload-inflight.test.ts server/__tests__/question-budget-settlement.test.ts server/__tests__/question-budget-window-mode.test.ts
npm run typecheck
```

`directed-frozen-r2.log`：7文件 **81/81 PASS**，6.70秒。`typecheck-frozen-r2.log`：exit0。另外A原SC04八case此前8/8绿，其生产依赖三文件和原tests hash均未变；M整合时合并原31路由与8case完整文件，不在本报告重复宣称已完整运行。当前没有测试/服务器/子进程在途，CPU窗口归M。

原77基础上新增4例：组件nostage晚截止1、HTTP revalidation-TERM1、HTTP budget-off已知断连-before-dispatch1、HTTP resolver-TERM-before-dispatch1；原所有断言保留。新组件文件14例，HTTP文件15例（原5＋本轮新增9参数场景＋初次WAL失败1）。

## SC覆盖与范围

r1报告的SC-01–08覆盖/GAP继续成立；本轮只补SC-02固定资格复核、SC-05/06实际高优先响应、SC-06真实已知断连不得迟到发业务和原budget真正截止。三个工具各自业务/metadata/plan oracle、budget calls/attempts1、有效audit唯一行保持通过。

真实KTX/MySQL F70 Docker、同身份故障恢复阶段矩阵、新镜像短校准和正式30分钟/12周期组合仍 **NOT RUN**，由M唯一资源锁调度B的driver。原r4 FAIL不豁免，不把组件替身签真实KTX UAT；无发布/前台/客户部署结论。

冻结proxy SHA256：`4fddc08f8a97b58b6e1676ad68267086293b321bf0a86b560f814ca7a18e8202`。等待A复核新hash关闭具体finding、M整合/代码CLI和新候选，不继续扩实现或无证据扩测。
