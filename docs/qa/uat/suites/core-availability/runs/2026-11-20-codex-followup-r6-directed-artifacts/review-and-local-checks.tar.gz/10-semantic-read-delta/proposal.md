# 正常语义写入期间纯 MCP 读取的有界等待差集草案

| 元数据 | 值 |
|---|---|
| 状态 | 可审阅草案，待 M 入账、正式 Spec／配对 Plan、终稿确权与增量开发授权；**未实施** |
| 触发 | calibration-r4-contract 普通 mcp-11 返回 semantic_recovery_required；原 FAIL 保留 |
| 授权边界 | 当前仅只读诊断与 inbox 文档；生产源码、镜像和工具判定不改 |
| 建议正式身份 | `lucy-20261120-semantic-read-write-settle`，Spec／Plan 同 slug；P1／REQ 编号由 M 分配，不预占 |
| 上位约束 | DEVELOPMENT 主路径可用性优先；user-personas 四画像；原 L25-11 §7.2、P1-69 和预算／审计／权限合同 |

## 1. 结论与确切触发

推荐在现有共享发布 owner 内证明正常写入的真实写盘／镜像阶段，并给涉及资产的 MCP 读取一个**在原请求截止内的有界等待机会**。等待不执行 SQL，不自动重放业务；结束后重读权威恢复日志与权限／配置状态。真实故障、孤儿、损坏、未知所有者及不确定结果仍失败关闭。**20 秒只是待确权的等待上限候选，不是本草案赋予实现者的预算或开发授权。**

不删恢复 guard、不删除 connectionId hints、不豁免 semantic_recovery_required、不把其重命名成重载 503。P1-69 对真实 reload owner 的立即拒绝合同继续成立；本草案只补该 owner 之前的正常语义写入阶段。

### 1.1 r4 原始时间线（UTC）

| 事件 | 时间 | 原始依据 |
|---|---|---|
| mcp-11 发起，agent11 / independent-question-11，查询固定 SOURCE | 09:52:03.429793 | `01-tools/calibration-r4-contract/events.jsonl:747` |
| cycle-1 正常变更开始 | 09:52:08.424644 | 同文件 :816 |
| upload 服务端受理整份 Manifest | 09:52:09.801 | `candidate/final-container-log.json:603` |
| mcp-11 返回 HTTP200 / result.isError / semantic_recovery_required | 09:52:10.784450 | events :854；`candidate/soak-query-11.json` |
| 上传记录创建（源码位于 mirror 返回之后） | 09:52:12.406 | `candidate/cycle-1-upload.json` record.createdAt |
| 静态 reloadCatalog 开始／结束 | 09:52:12.406 / 12.552 | 同回执 reload 时间 |
| upload 正常成功，uploaded=true | 09:52:15.994 | container log :653，events :920 |
| 本周期执行层 reload owner acquire／release | 09:52:22.580 / 35.322 | container log :713 / :813 |

夹具调用的是正常 `/api/catalog/assets/upload`，没有写入故障状态。它只改变 TARGET=uat_t1882 的短名，但原子替换的是包含 1884 表、也包含 SOURCE=uat_begin_zero_orders 的 `_schema/uat.yaml`，所以物理写入范围包含查询资产。mcp-11 的拒绝来自正常 open/write_in_progress WAL 命中。mcp-10、mcp-12 成功，upload 最终正常成功；没有证据表明这是长期残留故障恢复状态。

**证据精度：** 此次未收取逐阶段 journal ID、rename 与 mirror 完成时间。拒绝发生于静态 reload 之前，不能断言落在“文件已保存但 phase 尚未推进”的冗余阶段。应先以分段 deferred 反例补足，不以外部响应时间窗猜实际阶段。裁剪证据见 `01-tools/r4-semantic-recovery-diagnosis.json`；原始目录不改写。

## 2. 现行合同与新增差集

| 依据 | 原有义务 | 此次处理 |
|---|---|---|
| L25-11 `lucy-20261020-v2p5-semantic-batch-operations-spec.md` §7.1／7.2 | 写入口共享发布窗口，WAL 先于写，完整写入后进入 files_saved；索引／终结未确认不能 completed；未恢复或不确定资产读取关闭 | 完全保留；等待期间仍不放行读取，不使用时间经过替代内容／日志核验 |
| `semantic-recovery-journal.ts:109,497,840` | write_in_progress 阻断；files_saved 表示目标已写而索引／终结未知，journal 仍开放；recovery_required 一直阻断 | 正常活跃 owner 可以等待实际写入阶段结束，再执行原判定；不是将 write_in_progress 改成允许 |
| `semantic-batch-recovery.test.ts` D3 | connection-only、含点 connection、无法命名资产均保守关闭；不同明确资产才可证明不相交 | 保留全部原断言；此草案不收窄 hint 或 WAL 影响范围 |
| P1-69 §决策 1／2／7／9，SC-01／03／07／10 | reload 新 RPC 立即 503；已受理工作真实结束才 stop；TERM 和当前授权优先；合法身份可显式恢复 | 保留；不能让写 owner 等查询而查询又等该 owner 的 reload／终态 |
| 预算 Spec162／question-experience 与既有审计 gate | 作用域稳定、真实时间结算、durable fail-closed；不得靠新 session 或重试洗预算 | 保留原票据和原截止；等待不再创建第二票据，不重置计时、不回填成功 |
| DEVELOPMENT 第一性原理、Plan CA-05 | 约束与合法纯 MCP 成交均要验；超出现有合同／授权先回合同流程 | 新等待范围／上限／截止合成／补偿 SC 必须先确权，不能在冻结生产上直接修 |

新增承诺是：**有可证明正常活跃写 owner 时，原请求可在固定上限和剩余原预算内暂缓最终恢复拒绝；只有权威状态允许后才首次执行。** 既有合同没有规定这项等待，也没有保证“正常发布期间所有读取瞬时一致或全部零失败”；本草案不能借原合同默认实施。

## 3. 推荐范围与真正 owner 证据

首期仅覆盖**同进程、同项目、已被现有共享 publish-coordinator 持有且显式登记的正常语义写阶段**。必须为每个可等待 WAL 证明 journalId / releaseId / operationId 与该实际 owner 的绑定及其真实写／镜像工作 Promise；单凭锁文件存在、pid 活着、时间很新或 journal.status=open 都不够。遗留日志和不具备绑定的入口继续原拒绝，不推断它们是正常事务。

先以本次 Manifest upload 入口交付闭环；若统一登记机制可自然覆盖其他既有写入口，仍须逐入口测试真实绑定。未证明的 batch、restore、table-save 不自动获得等待资格，留 GAP，禁止偷偷扩大至权限写或所有发布锁。无需新控制器、新全局生命周期或公开状态 API。

owner 的“可供读者等待完成”事件是：**本次全部正式目标已按计划写入、必要镜像完成并核验、files_saved 状态真实持久化**，或者实际写阶段已经失败且恢复／待修复事实可读。它不是整个发布窗口释放，不是 reload／索引／审计最终完成，也不是调用者超时。owner 工作未终止时不能伪造 settled；读请求自己的等待截止不取消写 owner。

当前 coordinator.operationId 通常是随机 UUID，而 Manifest WAL.operationId=releaseId，两者没有天然相等关系。实现必须在同一 owner 上显式绑定，不能拿字符串时间窗口配对。绑定完成之前碰到 WAL 的读者保守拒绝。所有登记由真实写路径创建／终结，不由读取者临时推导所有权。

## 4. 等待、截止与恢复（均待确权）

1. 只在原恢复 guard 返回普通 write_in_progress、且所有命中阻断日志都具备真实活跃绑定时考虑等待。任何 recovery_required、不可读、无法命名、孤儿、未知绑定或实际写失败立即沿原错误失败关闭。
2. 固定本请求首次命中的 owner／journal 集合；不追逐后继发布、不随新 owner 重置截止。等待用异步事件／实际 Promise，不同步轮询 SQLite、不 busy-loop，不长期持发布写锁。
3. 候选上限 `20_000ms`：复用已确权短工作 20 秒量级作候选，实际 r4 查询只需跨越约 1.62 秒的 mirror 后记录时间差，但该差不能证明真实等待上界。**该数值待 M／终审确权，不以单次观测或实现便利视为获批。**
4. 等待截止取 `min(首次等待时刻+候选上限, 原请求绝对截止, 原预算真实剩余截止, 任何更紧原有取消时刻)`；后续执行只可用原剩余量。原生产 upstream socket inactivity timeout=30 秒不等于已存在端到端 30 秒绝对截止，不能误写。当前 question 绝对上限 120 秒亦不能因为等待重置；工具 MCP 180 秒是夹具网络截止，不能当产品新预算。
5. 推荐保留现行预算票据取得顺序和计费合同：现 consumePersisted 在恢复 gate 前，等待包含在本请求真实占用／原绝对计时内，不重复 consume、不返还伪造未执行时间。本项不承诺等待拒绝像 SC-03 一样零预算；若希望改变预算准入位置，应单独确权。未启用预算时也必须固定一次请求截止，不能无限等；其精确截止来源是开发前必须解决的合同接缝，不拿 20 秒外加现有 socket 30 秒静默扩容。
6. owner 写阶段结束后，重新读取**全部**权威 WAL；仍阻断则原错误。通过后重新执行当前 ACL／授权代次、对象解析／配置与 execution-stale 门禁；有变化按真实原因拒绝，不以 owner 成功当授权或运行配置有效证据。请求仍只首次执行一次 SQL。
7. TERM／客户端取消及时终止读者等待；不改变整实例不可逆状态，不取消或伪终结写 owner。已有准入工作保持原真实 RPC 票据，不能先退票再排队。
8. 不等整个 publish owner：写 owner 后续 reload 可能排空 MCP，而本请求属于真实 MCP 在途，等整个 owner 会自等。等待只到已写／镜像阶段，随后读者走权威核验和原执行或拒绝，最终由原 MCP settle 退票。若该阶段本身会等本请求，禁止登记为可等待，必须先拆清真实依赖。
9. 截止／残留故障沿现有 semantic_recovery_required / unreadable 返回失败，增加纯 MCP 可执行提示须在术语标准登记：正常维护可在维护结束后用**同一 Token、同一 session、原问题**显式重试；故障待治理／运维恢复后同身份同问题仍可达。不给假恢复时刻、固定 Retry-After 或自动 SQL 重放。已吊销身份不会因恢复重获权限。

```text
original MCP admission + original budget/deadline (unchanged)
block = authoritativeRecoveryReadBlock(original args)
if block exists:
  live = existingPublishOwner.proveAllMatchedWriteOwners(block.journals)
  if not live.normalAndBound or originalPhaseNotServing: originalDenial()
  fixedDeadline = min(proposed20s, original remaining deadlines)
  await live.actualWriteAndMirrorSettled OR reader cancel/deadline
  # reader timeout never terminates/retires writer; do not chase next owner
  if cancel/deadline: originalFailureWithoutSQL()
  block = authoritativeRecoveryReadBlock(original args)
  if block exists: originalDenial()
recheck current authorization + semantic/config/execution gates
execute original read once with remaining original budget
settle original real MCP work + durable response gate
```

## 5. 独立既有缺陷：files_saved 推进过晚

catalog-assets.ts 当前顺序为 rename → mirror → reloadCatalog → appendRecord → markFilesSaved → closeContentBatch。按 L25-11 §7.2 / journal 阶段定义，目标写／镜像完成后仍因目录重载／审计耗时伪留 write_in_progress，是独立的阶段准确性缺陷。建议按实际目标与必要镜像 digest 核验后推进 files_saved，保留 open／unconfirmed，终态证据齐备后再 completed。

该改动可在原合同下做窄修，但仍须 M 明确开发授权与失败处置范围；不能冒充本次已证根因修复。mcp-11 拒绝早于静态 reload 开始；只前移 mark 无法保证实际写／镜像期间的主路径。不能早于实际写和镜像核验推进，更不能提前终结 journal。阶段推进后静态 reload、appendRecord 或终态审计失败仍必须保留正确保存事实与未确认状态，不得 success，也不得错误回滚已完整保存的内容。

## 6. 受影响画像

| 画像 | 判定与依据 | ↓ 补偿及验收 |
|---|---|---|
| 问数方 | 问数面总体↑，正常维护可首次成交；单次等待延迟按最差判↓。报告面＝，不触及 Report Runner/固定URL执行 | SC-SW01／02／03：固定上限与原截止；同 Token/session/原问题显式恢复；不依赖 WebUI、人类 attestation 或宿主插件 |
| 治理方 | 语义口径面↑，上传不无故误报故障；权限授权面＝，原 ACL 和代次优先。保存交互模型不新增 | SC-SW04／05：写失败仍关闭、保存与生效分层真实；如需改变页面反馈则撤交互豁免并做前台浏览器计时 |
| 运维方 | 运行观察面↑，正常写、故障、孤儿可区分；交付运维面＝，无新部署支持／新手工恢复前置 | SC-SW03／04／07：残留仍可核验恢复，未知不猜成功，不要求用户重启整实例 |
| 管理层 | 口径质量面＝，不改业务指标；业务结果面↑，维护期间实际成交与失败分母清楚 | SC-SW08：原 FAIL 不洗白；候选重测与正式30分钟分别签署，功能闭口不等于上线 |

## 7. 先红后绿验收草案

| SC | 约束生效／反例 | 合法原任务与取证 |
|---|---|---|
| SC-SW01 | 真实文件临时目录、deferred 卡住 rename/mirror，WAL 仍 write_in_progress；无 SQL；原码立即拒绝先红 | 有效 owner 在固定等待内完成写／镜像，真实持久 files_saved，原请求首次 query 4/100、真实 SQL 1 次 |
| SC-SW02 | 持续真实写 >候选20秒或原剩余截止更短；不得重置、无限等、取消写 owner、放行未核验内容 | 截止保留失败和预算真值；实际 owner 后来结束，同 Token/session/原问题显式恢复4/100，不自动重放 |
| SC-SW03 | orphan/旧格式/未知绑定/pid仅存活/损坏/不可读/recovery_required/失败 mirror/失败mark 均不进入正常等待放行 | 合法恢复按现有治理流程结清后同身份显式成交；无重启Lucy要求；真实失败与恢复各保留 |
| SC-SW04 | 早期 phase 独立反例：deferred reloadCatalog、已完成实际写/mirror/digest，旧码仍write_in_progress先红 | 修后files_saved/open，读门可过但release非confirmed；reload/append/终态失败仍不假成功；重启不错误回滚已保存内容 |
| SC-SW05 | 等待期间权限收紧／吊销、配置代次或 execution-stale 变化 | 当前授权/配置重新核验；被吊销仍拒绝，仍合法原用户恢复成交；禁止旧授权缓存 |
| SC-SW06 | 写owner到files_saved后触发reload并排空；读者不得等publish最终态；TERM/断开不提前退真实工作票据 | 原20/40/45和reload20/60不变；无MCP自等、无stop提前、无TERM后重开；正常短工作可settle |
| SC-SW07 | 两个连续owner；旧结束后新WAL出现；错配release/journal、迟到settle不得串单或延长等待 | 只等待原集合，醒来重查全量权威；同身份后续显式恢复，owner真实结束证据完整 |
| SC-SW08 | 实际 Docker 1883表、原普通MCP5秒频率与变更同窗，保留原r4失败与所有新失败/自然分母 | 新候选先短校准，再由M调度原30分钟/12周期，不改性能/预算门槛；正确4/100、SQL次数、预算/审计唯一性闭包 |

组件反例必须使用真实目录/WAL与可控 deferred Promise，不用 sleep 或假 phase 替代实际阶段。真实 Docker UAT 用 MySQL 受理事实、真实 KTX/owner和服务器日志，不能把组件替身写成现场 PASS。SC-SW01/02 的 SQL=0或1、预算/执行事实需分别审计；本草案不声明 current budget消耗等于0。

## 8. 最小拟议文件白名单与实施顺序

待授权运行文件仅建议：`webui/server/publish-coordinator.ts`（现有 owner 私有写阶段登记/settle）、`webui/server/catalog-assets.ts`（Manifest绑定与阶段准确性）、`webui/server/semantic-recovery-journal.ts`（内部阻断详情/真实绑定核对，原guard不松）、`webui/server/proxy/mcp-proxy.ts`（原请求有界等待与重新核验）。如现有预算deadline不能只读复用，先交接缝方案，不默认扩白名单或改预算语义。

对应现有测试：`api.catalog-assets.test.ts`、`semantic-batch-recovery.test.ts`、`semantic-batch-journal-lifecycle.test.ts`、`mcp-reload-inflight.test.ts`、权限/预算既有定向回归；必要新增 `webui/server/__tests__/semantic-read-write-settle.test.ts`。实际HTTP监听测试遵守现有环境授权。inbox真实driver单独文件，不改A/B冻结工具；工具只扩必要证据采集，不扩失败豁免。index.ts、process-drain.ts、entrypoint、WebUI组件、KTX上游均不在拟议白名单。

顺序：M入账与正式同名Spec/Plan → 终稿确权/增量授权 → 未修改生产时保留phase和实际write等待两组红 → 最小实现/定向绿/原断言保持 → 非作者独立检查owner、预算与自等 → 新hash/新镜像 → M资源锁串行真实校准与原30分钟。当前仅完成草案，不替代任何门禁。

## 9. 风险、术语与交互合同

- 真实活跃 owner 与残留WAL混淆：必须绑定对象身份与实际Promise，不采时间宽窗；缺证明保持拒绝。
- 并发写后或等待后的TOCTOU：重查全量WAL、当前权限与配置；不宣称全文件系统与索引瞬时原子快照。
- 发布→reload→MCP自等：事件限写／镜像阶段，不等全publish或reload。真实阶段仍需反例证明无反向依赖。
- 等待延迟／预算增加：等待计入原票据时间，固定截止，不增加原总预算或改5秒频率；20秒上限待确权，不用抬MCP网络超时凑绿。
- 文件阶段修正后故障处置：files_saved不等于completed/confirmed；索引和审计失败必须真值保留，不偷改rollback/持久恢复义务。

复用原机器码及主要术语；若补可执行恢复消息，正式Spec须登记 `Terminology Compliance`，且不能声称“恢复故障”是每次正常维护的真实状态。无需新增产品公开API或日志产品。

## 交互合同豁免

原因：拟议实现为纯 MCP／后端私有阶段等待，**不改变用户可见 WebUI 表面**。若最终修改保存反馈、Toast或状态解释，应撤该豁免，并补真实前台浏览器与即时计时，不能以后端回执代签。

## 浏览器验证

不适用：本草案拟议范围为纯 MCP／后端等待，不改变用户可见 WebUI 表面；后续正式 Plan 必须仅保留一个该二级标题，并在范围触及页面反馈时更改为真实浏览器验证步骤。
