# SC04 independent API upload regressions

Owner A changes only `webui/server/__tests__/api.catalog-assets.test.ts`.

Baseline: `baseline-hashes.json`, copies of the unmodified runtime/test/journal, and `red-api.catalog-assets.test.ts`. Selector `P1-70 SC04`, single worker, actual temporary A2 directory/WAL/content-root and KTX sibling mirror. Direct existing `uploadCatalogAsset` export avoids sockets, listeners, Docker and SQL work. Only the downstream fault/deferred dependency is mocked; the file write, rename, mirror (except the explicit mirror fault wrapper), digest surfaces, journal and startup recovery remain actual code.

Baseline `red.log`: exit 1, 7 expected assertion failures and 1 existing safe mirror-error case pass; 31 unrelated tests skipped. No missing-export/import error counted as red. Runtime `catalog-assets.ts` remained SHA256 `5ece1bdfaffee77d4bdb17389963831e53f10892a84e77349361494a26869933` during all baseline tests.

Cases:

1. Defer actual static reload: both surfaces already contain expected bytes; journal must be `files_saved/open`, authoritative read guard open, release still unconfirmed.
2. Defer actual history sidecar write: same saved/open boundary must already be durable.
3. Mirror failure count >0: upload fails before reload, journal still blocks.
4. Mirror says failed=0 but actual sibling bytes differ: digest must catch it; no reload/success.
5. Journal files-saved persistence throws: no reload, no saved/completed phase, guard remains closed.
6–8. Static reload, history persistence, terminal-close failure: API rejects, saved/open fact and unconfirmed release persist. Real startup-recovery scan must choose activation_pending, never rollback; both surface contents remain new bytes.

Red and any future green are separate immutable logs. These offline regressions do not sign the new pure MCP actual-wait scenario or Docker UAT.

Green: original eight cases passed unchanged (8/8, exit0, 1.05s), selector log `green-attempt-1.log`; runtime source snapshots and hashes in `green-source/` and `green-freeze.json`. Test bytes are identical to the red snapshot. The parent will run the whole API test file in the central integration window; this scoped green does not claim the 31 skipped route tests ran.
