# P170 TERM-only driver revision9 独立只读复核

**REQUEST CHANGES：一项清理证据口径 P2，已报 M/B；其余本次窄生命周期修正未见 P1/P2。** 仅静态 review，不执行测试／Docker／SQL，不追认旧8TERM FAIL为PASS。

## P2：helper未证明absent时cleanupComplete仍可true

`finally`调用cleanup_term_helper失败仅记录status=FAIL与termHelperCleanupError；随后rig.close成功无条件赋cleanupComplete=True。若helper remove/inspect超时或未知，且原app/db/network/volume四资源清理成功，则summary可出现cleanupComplete=true而helper仍存在或未知。status仍FAIL所以不会直接假PASS，但后续allcleanuptrue的口径会误报，违背新增owned helper必须真实absence的取证要求。建议窄合并：cleanupComplete必须同时满足原四资源清理与helper未创建／最终已证明absent；记录失败即保留FAIL，最终重试成功也不能洗掉原失败。需无helper、helperabsent、helper未知／false三种判据负例。

## 已核实合理的修正

- 原writer真实failed、原reader term-end后，等待原stop future，inspect Running=false/exit143/nonOOM，<=40只计到实际docker stop返回，不把后置helper耗时冒充TERM耗时。原规范503仍must，transport仅GAP。
- 不再向已停止app执行restore/facts。helper只在stop验真后启动，挂载原app inspect中匹配的本task命名卷；同AE0、独立自有name、--rm、readonly根文件系统、network none、cap-dropALL/no-new-privileges/uid10001、Python入口不启动产品。
- helper在共享10秒绝对窗口内执行与rm/absence证明，原overall300不扩大；失败finally还有有限自有回收重试，不能把unknown inspect当absence。
- 注入前捕获原regular dev/inode/hash/size/mode/uid/gid/nlink/noSymlink，注入后backup必须精确等于原preimage。恢复仅当exact私有backup+exact FIFO均匹配才unlinkFIFO/renamebackup；已经恢复仅接受exact原regular。新合法regular、wronginode/hash/metadata/symlink/hardlink/path不覆盖。不是广义文件恢复或产品恢复API。
- semantic WAL/lock目录仅只读计算前后hash，恢复无WAL/lock写、latch清零或假终态审计。原app同volume重新start，同Token／原问题后续SQL、预算与有效审计仍原路径must；不因fixture恢复跳过它们。
- generic oracles与rev8逐字一致；revocation/normal/deadline/failure不因新TERM路径变化。原历史FAIL/GAP、未执行后段保留。

作者146/146轻离线与四source compile记录已读，不能替代actual stopped-volume运行；本review未重跑。源hash：

- `verify-semantic-read-docker.py` `2f1e889f704b4bc226e2ee1facd493a7f53fb2a27f570e3efd178be75609fede`
- `semantic-oracles.py` `13e241280344def1c88dadcc76a48d6a28b837de854ed8265dc048177f0b9c05`
- `semantic-control.py` `3c2956b228922533191798045e338f871d6db7623e3dd3e98d93da7570098b81`
- `verify-semantic-read-docker.test.py` `91a5be27b75fe345a68b924562bdbc901e59d9dd95db744c266acee89570d18a`
