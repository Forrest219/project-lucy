# P1-70 初版实现冻结与定向证据

状态：运行实现已落授权四文件并冻结，供非作者 CR／整合／代码终审；定向组件通过，**F70真实 Docker／新同候选30分钟组合仍 NOT RUN**。不主张功能收口、整套 UAT PASS 或上线。原 r4 FAIL 保留。M负责正式状态与三台账镜像。

## 改动与授权

依据用户“批准补充合同并修复”、G2.json、contract-cli-review-r2.txt APPROVED及M显式四运行文件放行。未改其他运行文件、KTX、WebUI、部署、预算模块或不可逆生命周期。未 commit/push，未运行Docker或外部SQL。

- publish-coordinator：真实 Manifest holder／项目／journal／release／目标摘要精确绑定，阶段 Promise 仅真实 writer 结算。注册发生于首次WAL持久化前；读者timer不释放writer。未知／错配／失去owner不获等待资格。
- semantic-recovery-journal：同步onBeforePersist接缝；原恢复guard默认失败关闭，详细阻断集合供私有匹配，原hint与D3断言保留。
- catalog-assets：真实rename、必要mirror、实际目标/镜像digest及files_saved持久读回后结写阶段，再继续catalog／历史／终态；mark null/失败关闭；后续异常保持saved/open/unconfirmed，不错误回滚已保存内容。
- mcp-proxy：RPC入口固定20秒等待资格，原ticket120秒和elapsed墙钟只收紧，settled不新增墙钟限额，不重复consume；两个gate复用等待，醒来重读全量WAL与当前纯ACL/guard裁决。保留原socket30 inactivity，不伪造端到端30秒。取消／TERM／吊销优先，原真实MCP／response gate退票不改。

有限stdout只记录真实ID／服务器阶段时间，schema符合终稿及M补充要求：ingressMonoMs、fixedInitialWaitDeadlineMonoMs和effective waitDeadlineMonoMs均可独立核验；无问句／Token／DSN。owner_settled不等于业务成功。不新增公开API或日志产品。

精确hash与ownership见 `implementation-manifest-r1.json`；相对M保存旧四文件的差异见 `implementation-runtime-r1.diff`。A独占api.catalog-assets.test.ts，C未修改该文件。

## 红到绿

| 反例 | 原始红 | 最终对应绿 |
|---|---|---|
| 正常真实WAL尚在deferred写阶段，旧guard立即semantic拒绝 | read-wait-baseline-red.log，1FAIL/2PASS；不是缺export/import | canonical新测试直接使用最终接口；旧版本适配只在baseline-only-read-wait-red.test.ts归档 |
| phase迟推进、镜像计数0但bytes不符、mark失败与post-save故障 | A的sc04-tests/red.log，7FAIL/1PASS | A原八case未减断言，green-attempt-1.log 8/8 |
| 等待中的TERM被初版误报HTTP200 semantic错误 | http-priority-red.log | http-priority-green.log，TERM实际503 SERVICE_DRAINING；吊销实际403授权原信封；零业务执行 |
| WAL快照读在前、owner完成清登记在后，旧快照被误判孤儿 | owner-completion-snapshot-red.log | 原输入只重新读取权威guard，unknown/故障仍关；最终对应case通过 |

中途旧sandbox EPERM（既有lifecycle用回环HTTP）、初次类型错误、测试误用无ticket的同步consume、浮点精度断言失败均保留原日志。没有增加timeout、绕guard或删原断言。最终canonical无旧／新版本fallback分支。

## 最终定向命令与结果

cwd为隔离worktree/webui。真实HTTP使用已授权require_escalated回环监听；仅临时合成项目／测试SQLite，无Docker、无外部SQL。

```sh
npx vitest run --maxWorkers=1 server/__tests__/semantic-read-write-settle.test.ts server/__tests__/semantic-batch-recovery.test.ts server/__tests__/semantic-batch-journal-lifecycle.test.ts server/__tests__/mcp-proxy-execution-stale.test.ts server/__tests__/mcp-reload-inflight.test.ts server/__tests__/question-budget-settlement.test.ts server/__tests__/question-budget-window-mode.test.ts
npm run typecheck
```

结果：`directed-final-r2.log`，7文件 **77/77 PASS**，5.68秒；`typecheck-final-r2.log`，exit0。A另外原SC04八case8/8 PASS，原test hash保持aa0f72bc22b10103ba34f9d675c05f3669e6171bb12bdf0ec987733928d24e74。完整api31旧路由及M整合集合由M串行运行，本报告不冒充已覆盖。

## 具名新测试与SC范围

| SC | 已完成定向证据 | 剩余GAP |
|---|---|---|
| SC-01 | 新文件真实WAL“waits on a real live WAL…”；HTTP参数化lucy_query/read_source/explain分别4/100+上游业务1、授权metadata+业务0、plan_only executed:false+业务0；各真实持久budget calls/attempts1、audit唯一有效行 | HTTP上游为组件fixture，真实KTX/MySQL由B新driver证明 |
| SC-02 | “uses the original ingress cutoff…”前置已耗尽20秒；“tightens the one original ticket…”ABS剩余/elapsed MAX_WALL/settled/原最后call/不重复consume；“exposes the original fixed ingress…”begin晚500ms且预算更紧不重算20秒；sockettimeout取消监听不改timer值 | 实际Docker慢写>20秒与原身份补偿待运行；非预算RPC原无overall30，未新增假合同 |
| SC-03 | 原semantic-batch-recovery故障/D3回归；orphan新case；真实初次WAL持久化写失败注册→failed、无正式内容写、guardunreadable | 实际Docker故障结清与同身份恢复待运行，继承原故障恢复边界 |
| SC-04 | A八个真实目录反例：deferred reload/append、mirror失败／实际bytes错、mark失败、post-save reload/append/terminal失败及startup不误回滚 | 同候选实际阶段见证尚待Docker |
| SC-05 | 实际HTTP等待中narrowAuthorization，实际403原授权错误且业务0；等待后当前ACL纯裁决/guard路径，原response/发送barrier保持 | 更完整实际admin吊销/行策略/配置变化矩阵由独立审查及真实阶段补证，不把单一narrow代签全部 |
| SC-06 | HTTP TERM503、真实fetch断连且MCP票据终结而writer仍write_in_progress、业务0；“wakes at actual files-saved while publish owner still pending”避免等待整个publish；原reload真实工作集合回归 | 实际写→reload→TERM连锁的Docker阶段矩阵仍待运行；原20/40/45与20/60不改 |
| SC-07 | 首次WAL发布前绑定、同步绑定失败无WAL、初次持久写失败、错release/root/target、后继WAL不追逐、旧快照完成race；预算window变化拒绝 | 真Docker原始阶段日志／唯一ID闭包待运行 |
| SC-08 | 原r4FAIL、全部中间失败与源码冻结保留，无semantic错误豁免 | 新候选短校准、正式30分钟12周期、性能/自然分母/完整审计闭包尚NOT RUN |

HTTP参数化测试正式名称：`P1-70 real HTTP retains tool semantics and higher-priority response while waiting (%s)`，六参数为三个工具、revoke、term、disconnect；初次WAL失败测试正式名称：`P1-70 keeps initial WAL persistence failure closed after the real owner was registered`。其他新case完整名称在canonical semantic-read-write-settle.test.ts；其13case均实际通过。

## 冻结与接续

当前无测试/服务器/子进程在途，CPU窗口归M。M可进行非作者proxy CR、统一整合集合、代码CLI终审及新镜像；C保持四runtime与相关tests不动，发现具体真实缺陷再按M派发窄修。B只用新镜像执行真实driver，缺日志或私有绑定事实留FAIL/GAP，不能依旧r4镜像签新功能。
