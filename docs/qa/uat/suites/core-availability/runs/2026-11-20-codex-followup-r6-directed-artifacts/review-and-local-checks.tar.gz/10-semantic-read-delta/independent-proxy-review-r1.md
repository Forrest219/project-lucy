# P1-70 non-author implementation review r1

**REQUEST CHANGES.** Three concrete post-snapshot/post-wait races remain in frozen proxy `e2ecc49df31f3603adda124a505f4f1a70d5c732d23cb6fd671b13c142ddae7f`. CR-70-A-01 and 02 were independently source-confirmed by implementation owner C after notification. CR-70-A-03 is a source-level counterexample supplied for a deterministic negative; this reviewer did not execute or invent a red result. All are P2 correctness/contract issues.

The three previously reviewed stable files are unchanged: coordinator `c81c2f4d…`, recovery journal `a5863c17…`, catalog upload `65d323fa…`. Exact full hashes are in `independent-proxy-review-r1-identity.json`. No source edits, tests, listeners, Docker or other load were started by this review. The supplied directed 77/77 and typecheck0 are author evidence, not a full UAT verdict.

## CR-70-A-01 — Late owner-completion snapshot can bypass fixed wait deadline (P2)

Location: `mcp-proxy.ts:2359–2367`, plus downstream revalidation at `4429–4468`.

If the initial filesystem snapshot reports write_in_progress but the actual owner completes before the continuation matches the private stage, `matchedActivePublishWriteStages` correctly returns null. The new fallback performs a fresh authoritative read, marks context.waited and returns null when files_saved is now visible. Unlike the matched-stage branch, it never checks the original effective monotonic deadline. Revalidation checks cancellation, lifecycle and budget-current state, but not this deadline.

Deterministic counterexample: capture a real registered writer's blocking WAL snapshot before the ingress deadline; finish that writer and delete its stage; advance the test monotonic clock beyond the already-fixed context deadline; resolve the held initial snapshot. Current code sees no stage, rereads open files_saved and can execute the RPC. This violates the fixed waiting qualification and delayed-callback rule, including budget-off requests. It must not impose 20 seconds on ordinary requests that never observed a blocker.

Requested correction: apply actual deadline/cancellation/TERM/authorization checks to this observed-block fallback too, including after its awaited reread. Extend the existing owner-completion-snapshot test with deadline+1; no real 20-second sleep is needed.

## CR-70-A-02 — TERM during async revalidation is downgraded to semantic HTTP 200 (P2)

Location: `mcp-proxy.ts:4429–4460`, `readSemanticRecoveryDenial:2417–2435`, and either HTTP gate.

The wrapper checks TERM before awaiting revalidation. Revalidation itself checks lifecycle at entry, then awaits aclCheck/effectivePermissions/catalog. If TERM begins during one of those awaits, its final combined condition returns semantic_recovery_required. Both gates translate that to HTTP200, despite SERVICE_DRAINING being the required canonical HTTP503. Early ACL/guard denial returns and the generic unreadable catch can similarly bypass the post-await canonical priority. This is distinct from the already-fixed test that enters TERM while the writer is still pending.

Deterministic counterexample: allow the actual writer to settle, defer the second aclCheck (the new revalidation), begin the real process drain, then release aclCheck. Require HTTP503/SERVICE_DRAINING and zero business SQL. An authorization narrowing must still produce the existing barrier's canonical 403.

Requested correction: perform common current barrier/lifecycle priority after awaited revalidation (and its failure) before returning the lower-priority result, rather than relying solely on entry checks. C confirmed the late-TERM branch from source.

## CR-70-A-03 — Post-wait client cancellation can still dispatch when budget is disabled (P2)

Location: `mcp-proxy.ts:4412–4420`, `5893–5907`, post-gate `maybeWriteHiveDivertedResponse` at `7264` and later dispatch.

The new ingress signal accurately observes a disconnect, but captureUpstreamRequest only checks cancelUpstreamOnCapture. That flag is assigned by the existing budget settlement onDisconnected callback, installed only when questionBudgetEnabled(). After a valid F70 wait and revalidation finish, the handler performs further awaited connection/Hive resolution before dispatch. A client can disconnect during that await. With budgets disabled, the new signal is aborted, the flag remains false, and there is no further signal check before creating/ending sl_query. The current HTTP disconnect test disconnects while the writer is still pending and does not exercise this boundary.

Deterministic counterexample: disable question budget, complete a real registered writer and semantic revalidation, defer actual non-Hive resolution/config read, disconnect the HTTP client, then allow resolution to return not-handled. Assert no business RPC/SQL is dispatched. No timer/budget change is required. In the existing forwarder, onRequest runs before upstream.end(body), so a synchronous current-cancel check at capture can prevent the late RPC from being written; retain actual upstream-close/MCP retirement semantics.

## Boundaries otherwise reviewed

- Both the local explain path and pre-slot query/read-source path call the same semantic waiting/revalidation helper; original identity, RPC ID and ingress context are retained.
- Fixed ingress monotonic deadline is captured before async admission; budget tightening uses original ticket ABS120s and elapsed-mode original startedAt. Settled mode does not invent a wall deadline. No second consume or new question/session is introduced.
- Successful matched-stage completion rereads all relevant WAL and checks interruption before allowing the original request. Later/unknown writers are not followed by another wait. The fallback's fresh reread is directionally correct but needs CR-01's deadline checks.
- Query revalidation rebuilds forced filters from the original pre-rewrite snapshot and current ACL, then rewrites existing parsed arguments. This avoids duplicate forced predicates. Current effective permissions and ambiguity catalog are read again; original budget and audit tickets remain in place.
- Manifest stage settles before static reload/history/terminal, so it does not wait for a reload that drains this same original RPC. No new MCP process work ticket is acquired after waiting. Existing real upstream handles and durable response-gate work are still tracked by the original ALS work set; response close alone cannot retire the owner.
- The newly added real first-WAL-persistence-failure HTTP test now covers the non-blocking coverage suggestion from the three-file review: registration occurs, actual WAL publication fails, failed stage and unreadable guard follow. The unchanged SC04 eight-case green preserves saved/open truth through reload/history/terminal failures and startup recovery.

Re-review the narrow fixes and their actual negative/positive evidence under a new hash. Final integration and same-candidate Docker F70 remain required; neither this review nor directed unit PASS signs them.
