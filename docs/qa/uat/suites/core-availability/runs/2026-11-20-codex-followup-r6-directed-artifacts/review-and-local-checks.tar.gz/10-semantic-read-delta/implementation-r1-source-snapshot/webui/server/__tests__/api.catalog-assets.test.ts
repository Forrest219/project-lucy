import { rmSync } from "node:fs";
import { lstat, mkdir, mkdtemp, readFile, rm, symlink, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import request from "supertest";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { parse as parseYaml } from "yaml";
import { resetAuditDbForTests } from "../admin/audit";
import { SEMANTIC_BATCH_LIMITS } from "../semantic-limits";

// M17 mirror of the M14 ingest-route defense: the WebUI catalog-asset routes
// must never shell out to the ktx CLI. Mock the whole ktx module so any
// accidental call to testConnection, runIngest, or validateSource throws and
// surfaces in the test output.
vi.mock("../ktx", async () => {
  const actual = await vi.importActual<typeof import("../ktx")>("../ktx");
  const failIfCalled = () => {
    throw new Error("M17: WebUI must not call ktx helpers from /api/catalog/assets/*");
  };
  return {
    ...actual,
    runIngest: vi.fn(failIfCalled),
    testConnection: vi.fn(failIfCalled),
    validateSource: vi.fn(failIfCalled)
  };
});

let projectRoot: string;
let auditDbPath: string;
let previousRoot: string | undefined;
let previousContentRoot: string | undefined;
let previousAuditDb: string | undefined;

async function makeProject(
  yaml: string,
  manifestFiles: Record<string, string> = {}
): Promise<string> {
  const root = await mkdtemp(path.join(os.tmpdir(), "lucy-api-catalog-assets-"));
  await writeFile(path.join(root, "ktx.yaml"), yaml, "utf8");
  await mkdir(path.join(root, ".ktx-ui"), { recursive: true });
  const connId = "demo-mysql";
  const dir = path.join(root, "semantic-layer", connId, "_schema");
  await mkdir(dir, { recursive: true });
  for (const [name, content] of Object.entries(manifestFiles)) {
    await writeFile(path.join(dir, `${name}.yaml`), content, "utf8");
  }
  return root;
}

// A2 default layout: content root is <projectRoot>/config/. Tests using this
// fixture must leave LUCY_CONTENT_ROOT unset.
async function makeProjectA2(
  yaml: string,
  manifestFiles: Record<string, string> = {}
): Promise<string> {
  const root = await mkdtemp(path.join(os.tmpdir(), "lucy-api-catalog-assets-a2-"));
  await writeFile(path.join(root, "ktx.yaml"), yaml, "utf8");
  await mkdir(path.join(root, ".ktx-ui"), { recursive: true });
  const connId = "demo-mysql";
  const dir = path.join(root, "config", "semantic-layer", connId, "_schema");
  await mkdir(dir, { recursive: true });
  for (const [name, content] of Object.entries(manifestFiles)) {
    await writeFile(path.join(dir, `${name}.yaml`), content, "utf8");
  }
  return root;
}

beforeEach(async () => {
  vi.resetModules();
  previousRoot = process.env.KTX_PROJECT_ROOT;
  previousContentRoot = process.env.LUCY_CONTENT_ROOT;
  previousAuditDb = process.env.LUCY_AUDIT_DB;
  vi.clearAllMocks();
});

afterEach(() => {
  // Close the audit singleton before deleting its on-disk path, then remove the
  // temp project BEFORE restoring env. Same ENOTEMPTY race class as
  // semantic-batch-journal-lifecycle / display-invalidation: a late content-path
  // resolve can recreate children under the temp root mid-rmdir.
  resetAuditDbForTests();
  if (projectRoot) {
    rmSync(projectRoot, { recursive: true, force: true, maxRetries: 5, retryDelay: 50 });
  }
  if (previousRoot === undefined) {
    delete process.env.KTX_PROJECT_ROOT;
  } else {
    process.env.KTX_PROJECT_ROOT = previousRoot;
  }
  if (previousContentRoot === undefined) {
    delete process.env.LUCY_CONTENT_ROOT;
  } else {
    process.env.LUCY_CONTENT_ROOT = previousContentRoot;
  }
  if (previousAuditDb === undefined) {
    delete process.env.LUCY_AUDIT_DB;
  } else {
    process.env.LUCY_AUDIT_DB = previousAuditDb;
  }
});

async function buildFreshServer() {
  const { buildServer } = await import("../index");
  return buildServer();
}

function baseYaml(): string {
  return `connections:
  demo-mysql:
    driver: mysql
    schemas:
      - dataforai
      - openclaw_db
    enabled_tables:
      - dataforai.superstore_orders
`;
}

const SAMPLE_MANIFEST = "tables:\n  customers:\n    table: openclaw_db.customers\n";

describe("POST /api/catalog/assets/validate", () => {
  it("accepts canonical assetKind schema_manifest", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetKind: "schema_manifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.data.valid).toBe(true);
    expect(res.body.data.assetKind).toBe("schema_manifest");
    expect(res.body.data.assetType).toBe("schemaManifest");
    await app.close();
  });

  it("returns valid payload without writing the file", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetKind: "schema_manifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.ok).toBe(true);
    const data = res.body.data;
    expect(data.valid).toBe(true);
    expect(data.assetKind).toBe("schema_manifest");
    expect(data.assetType).toBe("schemaManifest");
    expect(data.targetPath).toBe("semantic-layer/demo-mysql/_schema/openclaw_db.yaml");
    expect(data.tables).toBe(1);
    expect(data.tableNames).toEqual(["customers"]);
    expect(data.exists).toBe(false);
    expect(data.warnings).toEqual([]);
    expect(data.errors).toEqual([]);
    expect(data.sourceNameConflicts).toEqual([]);
    expect(data.sizeBytes).toBe(Buffer.byteLength(SAMPLE_MANIFEST, "utf8"));
    expect(typeof data.sha256).toBe("string");
    expect(data.sha256).toMatch(/^[0-9a-f]{64}$/);

    // File must not have been written.
    const manifestPath = path.join(
      projectRoot,
      "semantic-layer/demo-mysql/_schema/openclaw_db.yaml"
    );
    await expect(readFile(manifestPath, "utf8")).rejects.toMatchObject({ code: "ENOENT" });

    await app.close();
  });

  it("reports UNKNOWN_CONNECTION when the connectionId is not declared in ktx.yaml", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "ghost-conn",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.ok).toBe(true);
    expect(res.body.data.valid).toBe(false);
    const codes = (res.body.data.errors as Array<{ code: string }>).map((e) => e.code);
    expect(codes).toContain("UNKNOWN_CONNECTION");
    await app.close();
  });

  it("reports SCHEMA_NOT_CONFIGURED when the schema is not in the connection's list", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "ghost_schema",
        assetType: "schemaManifest",
        filename: "ghost_schema.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.ok).toBe(true);
    expect(res.body.data.valid).toBe(false);
    const codes = (res.body.data.errors as Array<{ code: string }>).map((e) => e.code);
    expect(codes).toContain("SCHEMA_NOT_CONFIGURED");
    await app.close();
  });

  it("rejects filename with the wrong extension", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.txt",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.data.valid).toBe(false);
    const codes = (res.body.data.errors as Array<{ code: string }>).map((e) => e.code);
    expect(codes).toContain("INVALID_FILENAME");
    await app.close();
  });

  it("reports ASSET_KIND_UNSUPPORTED instead of coercing unknown asset types", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "overlayYaml",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.data.valid).toBe(false);
    const codes = (res.body.data.errors as Array<{ code: string }>).map((e) => e.code);
    expect(codes).toContain("ASSET_KIND_UNSUPPORTED");
    await app.close();
  });

  it("reports ASSET_KIND_ROUTE_MISMATCH for semantic overlay on the catalog upload route", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetKind: "semantic_overlay",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.data.valid).toBe(false);
    const codes = (res.body.data.errors as Array<{ code: string }>).map((e) => e.code);
    expect(codes).toContain("ASSET_KIND_ROUTE_MISMATCH");
    await app.close();
  });

  it("reports ASSET_KIND_REQUIRED when no asset kind or legacy asset type is provided", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.data.valid).toBe(false);
    const codes = (res.body.data.errors as Array<{ code: string }>).map((e) => e.code);
    expect(codes).toContain("ASSET_KIND_REQUIRED");
    await app.close();
  });

  it("validates and uploads a complete Manifest larger than the default HTTP limit", async () => {
    projectRoot = await makeProject(baseYaml());
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    const app = await buildFreshServer();
    await app.ready();
    try {
      const content = "tables:\n" + Array.from({ length: 298 }, (_, table) =>
        `  source_${table}:\n    table: openclaw_db.table_${table}\n    columns:\n` +
        Array.from({ length: table < 191 ? 22 : 21 }, (_, column) =>
          `      - name: column_${column}\n        type: string\n        descriptions:\n          ai: ${"测试字段说明".repeat(8)}\n`
        ).join("")
      ).join("");
      expect(Buffer.byteLength(content)).toBeGreaterThan(1024 * 1024);
      const payload = {
        connectionId: "demo-mysql", schema: "openclaw_db", assetKind: "schema_manifest",
        filename: "openclaw_db.yaml", content
      };
      const checked = await app.inject({ method: "POST", url: "/api/catalog/assets/validate", payload });
      expect(checked.statusCode).toBe(200);
      expect(checked.json().data).toMatchObject({ valid: true, tables: 298 });
      const uploaded = await app.inject({ method: "POST", url: "/api/catalog/assets/upload", payload });
      expect(uploaded.statusCode).toBe(200);
      expect(uploaded.json().data.validation).toMatchObject({ valid: true, tables: 298 });
      const stored = await readFile(path.join(projectRoot, "semantic-layer/demo-mysql/_schema/openclaw_db.yaml"), "utf8");
      expect(stored).toBe(content);
      const tables = Object.values(parseYaml(stored).tables) as Array<{ columns: unknown[] }>;
      expect(tables).toHaveLength(298);
      expect(tables.reduce((count, table) => count + table.columns.length, 0)).toBe(6449);
    } finally {
      await app.close();
    }
  }, 30_000);

  it("accepts the UTF-8 file size boundary and rejects one extra byte before parsing", async () => {
    projectRoot = await makeProject(baseYaml());
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    const app = await buildFreshServer();
    await app.ready();
    try {
      const prefix = SAMPLE_MANIFEST + "# 中文字段说明";
      const content = prefix + "x".repeat(8 * 1024 * 1024 - Buffer.byteLength(prefix));
      for (const extra of ["", "x"]) {
        const response = await app.inject({ method: "POST", url: "/api/catalog/assets/validate", payload: {
          connectionId: "demo-mysql", schema: "openclaw_db", assetKind: "schema_manifest",
          filename: "openclaw_db.yaml", content: content + extra
        } });
        expect(response.statusCode).toBe(200);
        expect(response.json().data.valid).toBe(extra === "");
        expect(response.json().data.sizeBytes).toBe(8 * 1024 * 1024 + extra.length);
        if (extra) expect(response.json().data.errors).toContainEqual(expect.objectContaining({ code: "FILE_TOO_LARGE" }));
      }
      const rejectedUpload = await app.inject({ method: "POST", url: "/api/catalog/assets/upload", payload: {
        connectionId: "demo-mysql", schema: "openclaw_db", assetKind: "schema_manifest",
        filename: "openclaw_db.yaml", content: content + "x"
      } });
      expect(rejectedUpload.statusCode).toBe(400);
      expect(rejectedUpload.json().error.code).toBe("FILE_TOO_LARGE");
      await expect(readFile(path.join(projectRoot, "semantic-layer/demo-mysql/_schema/openclaw_db.yaml"))).rejects.toMatchObject({ code: "ENOENT" });
    } finally {
      await app.close();
    }
  }, 30_000);

  it("enforces the HTTP byte boundary only on routes carrying asset contents", async () => {
    projectRoot = await makeProject(baseYaml());
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    const app = await buildFreshServer();
    await app.ready();
    try {
      // No valid assets: accepted HTTP requests cannot parse YAML or write files.
      const base = JSON.stringify({ assetKind: "invalid", padding: "中文" });
      const payload = base.slice(0, -1) + " ".repeat(SEMANTIC_BATCH_LIMITS.maxHttpBodyBytes - Buffer.byteLength(base)) + "}";
      expect(Buffer.byteLength(payload)).toBe(32 * 1024 * 1024);
      for (const url of ["/api/catalog/assets/validate", "/api/catalog/assets/upload", "/api/semantic-assets/validate"]) {
        const accepted = await app.inject({ method: "POST", url, headers: { "content-type": "application/json" }, payload });
        expect(accepted.statusCode).toBe(url === "/api/catalog/assets/upload" ? 400 : 200);
        const rejected = await app.inject({ method: "POST", url, headers: { "content-type": "application/json" }, payload: payload + " " });
        expect(rejected.statusCode).toBe(413);
        expect(rejected.json().error).toMatchObject({ code: "FST_ERR_CTP_BODY_TOO_LARGE", message: expect.stringContaining("32 MiB") });
        expect(rejected.json().error.message).toContain("请减少");
      }
      const ordinary = await app.inject({ method: "POST", url: "/api/catalog/reload", headers: { "content-type": "application/json" }, payload: JSON.stringify({ padding: "x".repeat(1024 * 1024) }) });
      expect(ordinary.statusCode).toBe(413);
      expect(ordinary.json().error.message).toContain("1 MiB");
    } finally {
      await app.close();
    }
  }, 30_000);

  it("rejects oversize content (over 8 MiB)", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const big = "x".repeat(8 * 1024 * 1024 + 1);
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.yaml",
        content: big
      })
      .expect(200);

    expect(res.body.data.valid).toBe(false);
    const codes = (res.body.data.errors as Array<{ code: string }>).map((e) => e.code);
    expect(codes).toContain("FILE_TOO_LARGE");
    await app.close();
  });

  it("rejects YAML that fails to parse", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.yaml",
        content: ":\n: this is broken yaml [\n"
      })
      .expect(200);

    expect(res.body.data.valid).toBe(false);
    const codes = (res.body.data.errors as Array<{ code: string }>).map((e) => e.code);
    expect(codes).toContain("YAML_PARSE_FAILED");
    await app.close();
  });

  it("rejects semantic overlay YAML in the Schema Manifest upload route", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const overlayYaml = [
      "name: superstore_orders",
      "grain:",
      "  - order_id",
      "measures:",
      "  - name: total_sales",
      "    expr: sum(sales)",
      ""
    ].join("\n");

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetKind: "schema_manifest",
        filename: "superstore_orders.yaml",
        content: overlayYaml
      })
      .expect(200);

    expect(res.body.data.valid).toBe(false);
    const errors = res.body.data.errors as Array<{ code: string; message: string }>;
    expect(errors.map((e) => e.code)).toContain("OVERLAY_FIELD_IN_MANIFEST");
    expect(errors.map((e) => e.message).join("\n")).toContain("semantic overlay");
    await app.close();
  });

  it("rejects YAML without tables as not a Schema Manifest", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetKind: "schema_manifest",
        filename: "openclaw_db.yaml",
        content: "name: openclaw_db\n"
      })
      .expect(200);

    expect(res.body.data.valid).toBe(false);
    const codes = (res.body.data.errors as Array<{ code: string }>).map((e) => e.code);
    expect(codes).toContain("SCHEMA_MANIFEST_EXPECTED");
    await app.close();
  });

  it("reports TARGET_EXISTS warning when the file already exists", async () => {
    projectRoot = await makeProject(baseYaml(), {
      openclaw_db: SAMPLE_MANIFEST
    });
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.data.valid).toBe(true);
    expect(res.body.data.exists).toBe(true);
    const warnCodes = (res.body.data.warnings as Array<{ code: string }>).map((w) => w.code);
    expect(warnCodes).toContain("TARGET_EXISTS");
    await app.close();
  });

  it("rejects with PATH_NOT_ALLOWED when the target file is a symlink", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    // Create a symlink in place of the target manifest.
    const targetLink = path.join(
      projectRoot,
      "semantic-layer/demo-mysql/_schema/openclaw_db.yaml"
    );
    await writeFile(path.join(projectRoot, "real-target.yaml"), SAMPLE_MANIFEST, "utf8");
    await symlink(path.join(projectRoot, "real-target.yaml"), targetLink);

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.data.valid).toBe(false);
    const codes = (res.body.data.errors as Array<{ code: string }>).map((e) => e.code);
    expect(codes).toContain("PATH_NOT_ALLOWED");
    await app.close();
  });

  it("does not create missing target directories during validate", async () => {
    projectRoot = await makeProject(baseYaml());
    await rm(path.join(projectRoot, "semantic-layer/demo-mysql"), {
      recursive: true,
      force: true
    });
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.data.valid).toBe(true);
    await expect(
      lstat(path.join(projectRoot, "semantic-layer/demo-mysql"))
    ).rejects.toMatchObject({ code: "ENOENT" });
    await app.close();
  });

  it("rejects with PATH_NOT_ALLOWED when a target parent component is a symlink", async () => {
    projectRoot = await makeProject(baseYaml());
    await rm(path.join(projectRoot, "semantic-layer/demo-mysql"), {
      recursive: true,
      force: true
    });
    const outside = path.join(projectRoot, "outside-demo-mysql");
    await mkdir(path.join(outside, "_schema"), { recursive: true });
    await symlink(outside, path.join(projectRoot, "semantic-layer/demo-mysql"));
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.data.valid).toBe(false);
    const codes = (res.body.data.errors as Array<{ code: string }>).map((e) => e.code);
    expect(codes).toContain("PATH_NOT_ALLOWED");
    await app.close();
  });
});

describe("POST /api/catalog/assets/upload", () => {
  it("writes the manifest, records an audit row, and triggers catalog reload", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/upload")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.ok).toBe(true);
    expect(res.body.data.uploaded).toBe(true);
    const record = res.body.data.record;
    expect(record.connectionId).toBe("demo-mysql");
    expect(record.schema).toBe("openclaw_db");
    expect(record.assetKind).toBe("schema_manifest");
    expect(record.assetType).toBe("schemaManifest");
    expect(record.tables).toBe(1);
    expect(record.sha256).toMatch(/^[0-9a-f]{64}$/);
    expect(record.overwritten).toBe(false);
    expect(record.targetPath).toBe("semantic-layer/demo-mysql/_schema/openclaw_db.yaml");

    // File is on disk.
    const onDisk = await readFile(
      path.join(projectRoot, record.targetPath),
      "utf8"
    );
    expect(onDisk).toBe(SAMPLE_MANIFEST);

    // Audit sidecar was written.
    const sidecarPath = path.join(projectRoot, ".ktx-ui/catalog-asset-uploads.json");
    const sidecar = JSON.parse(await readFile(sidecarPath, "utf8")) as {
      records: Array<{ id: string; targetPath: string }>;
    };
    expect(sidecar.records).toHaveLength(1);
    expect(sidecar.records[0]?.targetPath).toBe(record.targetPath);

    // Reload is the new static catalog run.
    const reload = res.body.data.reload;
    expect(res.body.data.validation.assetKind).toBe("schema_manifest");
    expect(reload.source).toBe("static-yaml");
    expect(reload.requestedConnectionId).toBe("demo-mysql");
    expect(reload.requestedSchema).toBe("openclaw_db");
    expect(record.reloadRunId).toBe(reload.id);

    // No `ktx ingest` was ever invoked.
    const ktx = await import("../ktx");
    expect(vi.mocked(ktx.runIngest)).not.toHaveBeenCalled();

    await app.close();
  });

  it("returns 409 and does not modify the file when the target exists and confirmOverwrite is missing", async () => {
    projectRoot = await makeProject(baseYaml(), {
      openclaw_db: "tables: {}\n"
    });
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const beforeContent = await readFile(
      path.join(projectRoot, "semantic-layer/demo-mysql/_schema/openclaw_db.yaml"),
      "utf8"
    );

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/upload")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(409);

    expect(res.body.ok).toBe(false);
    const code = (res.body.error as { code?: string }).code;
    expect(["PATH_NOT_ALLOWED", "TARGET_EXISTS", "OVERWRITE_REQUIRED"]).toContain(code);

    // File unchanged.
    const afterContent = await readFile(
      path.join(projectRoot, "semantic-layer/demo-mysql/_schema/openclaw_db.yaml"),
      "utf8"
    );
    expect(afterContent).toBe(beforeContent);

    // No sidecar was written.
    const sidecarPath = path.join(projectRoot, ".ktx-ui/catalog-asset-uploads.json");
    await expect(readFile(sidecarPath, "utf8")).rejects.toMatchObject({ code: "ENOENT" });
    await app.close();
  });

  it("overwrites and records overwritten=true when confirmOverwrite is true", async () => {
    projectRoot = await makeProject(baseYaml(), {
      openclaw_db: "tables: {}\n"
    });
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/upload")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST,
        confirmOverwrite: true
      })
      .expect(200);

    expect(res.body.data.record.overwritten).toBe(true);
    const onDisk = await readFile(
      path.join(projectRoot, "semantic-layer/demo-mysql/_schema/openclaw_db.yaml"),
      "utf8"
    );
    expect(onDisk).toBe(SAMPLE_MANIFEST);
    await app.close();
  });

  it("refuses to overwrite when the existing target is a symlink, even with confirmOverwrite=true", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const linkPath = path.join(
      projectRoot,
      "semantic-layer/demo-mysql/_schema/openclaw_db.yaml"
    );
    await writeFile(path.join(projectRoot, "real-target.yaml"), "tables: {}\n", "utf8");
    await symlink(path.join(projectRoot, "real-target.yaml"), linkPath);

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/upload")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST,
        confirmOverwrite: true
      })
      .expect(403);

    expect(res.body.ok).toBe(false);
    const code = (res.body.error as { code?: string }).code;
    expect(code).toBe("PATH_NOT_ALLOWED");

    // The real target file behind the symlink must remain unchanged.
    const real = await readFile(path.join(projectRoot, "real-target.yaml"), "utf8");
    expect(real).toBe("tables: {}\n");
    await app.close();
  });
});

describe("GET /api/catalog/assets/uploads", () => {
  it("returns the latest record and lastBySchema for the connection.schema key", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    await request(app.server)
      .post("/api/catalog/assets/upload")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    const res = await request(app.server)
      .get("/api/catalog/assets/uploads")
      .expect(200);

    expect(res.body.ok).toBe(true);
    const records = res.body.data.records as Array<{ targetPath: string }>;
    expect(records.length).toBeGreaterThan(0);
    const lastBySchema = res.body.data.lastBySchema as Record<
      string,
      { targetPath: string }
    >;
    const key = "demo-mysql.openclaw_db";
    expect(lastBySchema[key]).toBeDefined();
    expect(lastBySchema[key]?.targetPath).toBe(
      "semantic-layer/demo-mysql/_schema/openclaw_db.yaml"
    );
    await app.close();
  });

  it("caps the records at 50", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    // Seed 55 records directly into the sidecar.
    const sidecar = {
      version: 1,
      records: Array.from({ length: 55 }, (_, i) => ({
        id: `rec_${i}`,
        createdAt: new Date(2026, 0, 1, 0, 0, i).toISOString(),
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest" as const,
        targetPath: "semantic-layer/demo-mysql/_schema/openclaw_db.yaml",
        originalFilename: "openclaw_db.yaml",
        sizeBytes: 10,
        sha256: "0".repeat(64),
        tables: 0,
        overwritten: false,
        warnings: []
      }))
    };
    await mkdir(path.join(projectRoot, ".ktx-ui"), { recursive: true });
    await writeFile(
      path.join(projectRoot, ".ktx-ui/catalog-asset-uploads.json"),
      JSON.stringify(sidecar),
      "utf8"
    );

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .get("/api/catalog/assets/uploads")
      .expect(200);

    expect(res.body.data.records.length).toBeLessThanOrEqual(50);
    await app.close();
  });
});

describe("GET /api/catalog/assets/schema-manifest", () => {
  it("reads the server-computed schema manifest path", async () => {
    projectRoot = await makeProject(baseYaml(), {
      dataforai: "tables:\n  superstore_orders:\n    table: dataforai.superstore_orders\n"
    });
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .get("/api/catalog/assets/schema-manifest")
      .query({ connectionId: "demo-mysql", schema: "dataforai" })
      .expect(200);

    expect(res.body.ok).toBe(true);
    expect(res.body.data.targetPath).toBe("semantic-layer/demo-mysql/_schema/dataforai.yaml");
    expect(res.body.data.filename).toBe("dataforai.yaml");
    expect(res.body.data.content).toContain("dataforai.superstore_orders");
    expect(res.body.data.sha256).toMatch(/^[0-9a-f]{64}$/);
    await app.close();
  });

  it("returns 404 when the configured schema has no manifest file", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .get("/api/catalog/assets/schema-manifest")
      .query({ connectionId: "demo-mysql", schema: "dataforai" })
      .expect(404);

    expect(res.body.ok).toBe(false);
    expect(res.body.error.code).toBe("ASSET_NOT_FOUND");
    await app.close();
  });

  it("rejects unsafe connection and schema path segments", async () => {
    projectRoot = await makeProject(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    process.env.LUCY_CONTENT_ROOT = ".";
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .get("/api/catalog/assets/schema-manifest")
      .query({ connectionId: "../demo-mysql", schema: "dataforai" })
      .expect(403);

    expect(res.body.ok).toBe(false);
    expect(res.body.error.code).toBe("PATH_NOT_ALLOWED");
    await app.close();
  });
});

// ─── A2 default content root (<projectRoot>/config/) ───────────────────────
// Regression: the M17 upload path anchored `semantic-layer/` at the project
// root (legacy sibling of ktx.yaml) while the catalog reload reads the A2
// content root. Uploaded manifests were therefore invisible to the catalog
// (badge stuck on 缺失 Manifest). These tests pin the content-root anchoring
// and the one-way mirror to the ktx-facing sibling view.

describe("A2 default content root (config/)", () => {
  it("validate targets the content root, not the legacy sibling", async () => {
    projectRoot = await makeProjectA2(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    delete process.env.LUCY_CONTENT_ROOT;
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/validate")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetKind: "schema_manifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.data.valid).toBe(true);
    expect(res.body.data.exists).toBe(false);

    // Nothing may be written by validate — at either root.
    await expect(
      readFile(path.join(projectRoot, "config/semantic-layer/demo-mysql/_schema/openclaw_db.yaml"), "utf8")
    ).rejects.toMatchObject({ code: "ENOENT" });
    await app.close();
  });

  it("upload writes to the content root, reload sees it, sibling view is mirrored", async () => {
    projectRoot = await makeProjectA2(baseYaml());
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    delete process.env.LUCY_CONTENT_ROOT;
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .post("/api/catalog/assets/upload")
      .send({
        connectionId: "demo-mysql",
        schema: "openclaw_db",
        assetType: "schemaManifest",
        filename: "openclaw_db.yaml",
        content: SAMPLE_MANIFEST
      })
      .expect(200);

    expect(res.body.ok).toBe(true);

    // Authoritative copy lives under the content root.
    const contentRootCopy = await readFile(
      path.join(projectRoot, "config/semantic-layer/demo-mysql/_schema/openclaw_db.yaml"),
      "utf8"
    );
    expect(contentRootCopy).toBe(SAMPLE_MANIFEST);

    // Catalog reload in the same request consumed the content root copy.
    const reload = res.body.data.reload;
    expect(reload.source).toBe("static-yaml");
    expect(reload.manifestSchemas).toBe(1);
    expect(reload.warnings).toEqual([]);

    // ktx-facing sibling view received the mirror copy.
    const siblingCopy = await readFile(
      path.join(projectRoot, "semantic-layer/demo-mysql/_schema/openclaw_db.yaml"),
      "utf8"
    );
    expect(siblingCopy).toBe(SAMPLE_MANIFEST);

    await app.close();
  });

  it("schema-manifest read resolves the content root", async () => {
    projectRoot = await makeProjectA2(baseYaml(), {
      openclaw_db: "tables:\n  customers:\n    table: openclaw_db.customers\n"
    });
    auditDbPath = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
    process.env.KTX_PROJECT_ROOT = projectRoot;
    delete process.env.LUCY_CONTENT_ROOT;
    process.env.LUCY_AUDIT_DB = auditDbPath;

    const app = await buildFreshServer();
    await app.ready();
    const res = await request(app.server)
      .get("/api/catalog/assets/schema-manifest")
      .query({ connectionId: "demo-mysql", schema: "openclaw_db" })
      .expect(200);

    expect(res.body.ok).toBe(true);
    expect(res.body.data.content).toContain("openclaw_db.customers");

    // A legacy-sibling-only copy must NOT satisfy the read.
    const legacyOnly = await makeProject(baseYaml(), {
      openclaw_db: "tables:\n  customers:\n    table: openclaw_db.customers\n"
    });
    // Empty content root (server boot would ensureContentDirs()).
    await mkdir(path.join(legacyOnly, "config", "semantic-layer"), { recursive: true });
    const prevRoot = projectRoot;
    projectRoot = legacyOnly;
    process.env.KTX_PROJECT_ROOT = legacyOnly;
    const app2 = await buildFreshServer();
    await app2.ready();
    await request(app2.server)
      .get("/api/catalog/assets/schema-manifest")
      .query({ connectionId: "demo-mysql", schema: "openclaw_db" })
      .expect(404);
    await app2.close();
    await rm(legacyOnly, { recursive: true, force: true });
    projectRoot = prevRoot;

    await app.close();
  });
});

// P1-70 SC-04: the durable write phase ends before static reload/history/terminal.
// These exercise the real upload, content mirror and recovery journal on disk.
describe("P1-70 SC04 catalog upload durable phase", () => {
  const payload = {
    connectionId: "demo-mysql",
    schema: "openclaw_db",
    assetType: "schemaManifest" as const,
    filename: "openclaw_db.yaml",
    content: SAMPLE_MANIFEST
  };

  function deferred() {
    let resolve!: () => void;
    const promise = new Promise<void>((done) => { resolve = done; });
    return { promise, resolve };
  }

  async function prepare() {
    projectRoot = await makeProjectA2(baseYaml());
    process.env.KTX_PROJECT_ROOT = projectRoot;
    delete process.env.LUCY_CONTENT_ROOT;
    process.env.LUCY_AUDIT_DB = path.join(projectRoot, ".ktx-ui", "audit.sqlite");
  }

  afterEach(() => {
    vi.doUnmock("../catalog-reload");
    vi.doUnmock("../content-mirror");
    vi.doUnmock("../semantic-recovery-journal");
    vi.doUnmock("../semantic-assets");
    vi.doUnmock("node:fs/promises");
  });

  it("persists files_saved/open before deferred static reload, without claiming completed", async () => {
    await prepare();
    const entered = deferred();
    const resume = deferred();
    vi.doMock("../catalog-reload", async () => {
      const actual = await vi.importActual<typeof import("../catalog-reload")>("../catalog-reload");
      return { ...actual, reloadCatalog: async (...args: Parameters<typeof actual.reloadCatalog>) => {
        entered.resolve();
        await resume.promise;
        return actual.reloadCatalog(...args);
      } };
    });
    const { uploadCatalogAsset } = await import("../catalog-assets");
    const journalApi = await import("../semantic-recovery-journal");
    const pending = uploadCatalogAsset(projectRoot, payload);
    try {
      await entered.promise;
      const journals = await journalApi.listOpenRecoveryJournals(projectRoot);
      expect(journals).toHaveLength(1);
      // Both actual surfaces must already contain the new bytes at this boundary.
      for (const prefix of ["config/", ""]) {
        expect(await readFile(path.join(projectRoot, prefix,
          "semantic-layer/demo-mysql/_schema/openclaw_db.yaml"), "utf8")).toBe(SAMPLE_MANIFEST);
      }
      expect(journals[0]?.phase).toBe("files_saved");
      expect(journals[0]?.status).toBe("open");
      expect(await journalApi.semanticRecoveryReadBlock(projectRoot, [])).toBeNull();
      const { readSemanticAssetRelease } = await import("../semantic-assets");
      const release = await readSemanticAssetRelease(projectRoot, journals[0]!.releaseId);
      expect(release?.activationStatus).toBe("unconfirmed");
    } finally {
      resume.resolve();
      await pending;
    }
  });

  it("keeps files_saved/open while the actual upload history write is deferred", async () => {
    await prepare();
    const entered = deferred();
    const resume = deferred();
    vi.doMock("node:fs/promises", async () => {
      const actual = await vi.importActual<typeof import("node:fs/promises")>("node:fs/promises");
      return { ...actual, writeFile: async (...args: Parameters<typeof actual.writeFile>) => {
        if (String(args[0]).endsWith("/catalog-asset-uploads.json")) {
          entered.resolve();
          await resume.promise;
        }
        return actual.writeFile(...args);
      } };
    });
    const { uploadCatalogAsset } = await import("../catalog-assets");
    const journalApi = await import("../semantic-recovery-journal");
    const pending = uploadCatalogAsset(projectRoot, payload);
    try {
      await entered.promise;
      const journals = await journalApi.listOpenRecoveryJournals(projectRoot);
      expect(journals).toHaveLength(1);
      expect(journals[0]?.phase).toBe("files_saved");
      expect(journals[0]?.status).toBe("open");
      expect(await journalApi.semanticRecoveryReadBlock(projectRoot, [])).toBeNull();
    } finally {
      resume.resolve();
      await pending;
    }
  });

  it.each(["mirror", "mirror-digest", "mark"] as const)(
    "fails closed when %s fails before the saved phase is durable", async (fault) => {
      await prepare();
      const reload = vi.fn(async (...args: Parameters<typeof import("../catalog-reload").reloadCatalog>) => {
        const actual = await vi.importActual<typeof import("../catalog-reload")>("../catalog-reload");
        return actual.reloadCatalog(...args);
      });
      vi.doMock("../catalog-reload", async () => ({
        ...await vi.importActual<typeof import("../catalog-reload")>("../catalog-reload"),
        reloadCatalog: reload
      }));
      if (fault === "mark") {
        vi.doMock("../semantic-recovery-journal", async () => ({
          ...await vi.importActual<typeof import("../semantic-recovery-journal")>("../semantic-recovery-journal"),
          markRecoveryJournalFilesSaved: async () => { throw new Error("SC04 mark persistence failure"); }
        }));
      } else {
        vi.doMock("../content-mirror", async () => {
          const actual = await vi.importActual<typeof import("../content-mirror")>("../content-mirror");
          return { ...actual, syncContentToProjectRoot: async (...args: Parameters<typeof actual.syncContentToProjectRoot>) => {
            const result = await actual.syncContentToProjectRoot(...args);
            if (fault === "mirror") return { ...result, failed: 1 };
            // A zero failure counter cannot substitute for checking actual mirror bytes.
            await writeFile(path.join(projectRoot,
              "semantic-layer/demo-mysql/_schema/openclaw_db.yaml"), "tables: {}\n", "utf8");
            return result;
          } };
        });
      }
      const { uploadCatalogAsset } = await import("../catalog-assets");
      await expect(uploadCatalogAsset(projectRoot, payload)).rejects.toThrow();
      expect(reload).not.toHaveBeenCalled();
      const journalApi = await import("../semantic-recovery-journal");
      const journals = await journalApi.listOpenRecoveryJournals(projectRoot);
      expect(journals).toHaveLength(1);
      expect(journals[0]?.phase).not.toBe("files_saved");
      expect(journals[0]?.phase).not.toBe("completed");
      expect(await journalApi.semanticRecoveryReadBlock(projectRoot, [])).not.toBeNull();
    }
  );

  it.each(["reload", "append", "terminal"] as const)(
    "preserves saved content and unconfirmed truth after %s failure and startup recovery", async (fault) => {
      await prepare();
      if (fault === "reload") {
        vi.doMock("../catalog-reload", async () => ({
          ...await vi.importActual<typeof import("../catalog-reload")>("../catalog-reload"),
          reloadCatalog: async () => { throw new Error("SC04 static reload failure"); }
        }));
      } else if (fault === "append") {
        vi.doMock("node:fs/promises", async () => {
          const actual = await vi.importActual<typeof import("node:fs/promises")>("node:fs/promises");
          return { ...actual, writeFile: async (...args: Parameters<typeof actual.writeFile>) => {
            if (String(args[0]).endsWith("/catalog-asset-uploads.json")) {
              throw new Error("SC04 upload history persistence failure");
            }
            return actual.writeFile(...args);
          } };
        });
      } else {
        vi.doMock("../semantic-assets", async () => ({
          ...await vi.importActual<typeof import("../semantic-assets")>("../semantic-assets"),
          closeContentBatch: async () => { throw new Error("SC04 terminal evidence failure"); }
        }));
      }
      const { uploadCatalogAsset } = await import("../catalog-assets");
      await expect(uploadCatalogAsset(projectRoot, payload)).rejects.toThrow(/SC04/);
      const journalApi = await import("../semantic-recovery-journal");
      const journals = await journalApi.listOpenRecoveryJournals(projectRoot);
      expect(journals).toHaveLength(1);
      expect(journals[0]?.phase).toBe("files_saved");
      expect(journals[0]?.status).toBe("open");
      const { readSemanticAssetRelease } = await import("../semantic-assets");
      expect((await readSemanticAssetRelease(projectRoot, journals[0]!.releaseId))?.activationStatus)
        .toBe("unconfirmed");
      // Startup follows durable bytes/phase, not the previous process's Promise outcome.
      const recovered = await journalApi.recoverPendingRecoveryJournals(projectRoot);
      expect(recovered.recovered).toEqual([]);
      expect(recovered.needsRepair).toEqual([]);
      expect(recovered.activationPending).toEqual([journals[0]!.journalId]);
      for (const prefix of ["config/", ""]) {
        expect(await readFile(path.join(projectRoot, prefix,
          "semantic-layer/demo-mysql/_schema/openclaw_db.yaml"), "utf8")).toBe(SAMPLE_MANIFEST);
      }
      expect((await journalApi.readRecoveryJournal(projectRoot, journals[0]!.journalId))?.phase)
        .toBe("activation_pending");
    }
  );

});
