# P170 TERM-only driver revision10 独立只读闭环

**APPROVED（限定辅助 fixture 资格）；revision9 清理口径 P2 CLOSED。** 本次差异范围内没有剩余 P1/P2，可由 M 授权 fresh TERM/failure。此结论不是实际 PASS；旧8TERM FAIL、旧9源码与 REQUEST CHANGES 均保留，未执行后段不能追补。

独立读取9→10全diff、实际hash/freeze/152离线日志，并承接9整体TERM helper生命周期审查。新增 cleanup attempt 在任何可能失败的 rm/inspect 之前，把最新absent设为None并落入history，因此后续异常不会复用旧true。完整清理严格要求原四资源清理===true，且没有创建helper或最新helper absence===true；unknown/false/非布尔truthy均不能签complete。main四资源清理独立必尝试，helper失败不截断它；最终重试成功虽可记录最终资源absence，原statusFAIL/错误仍保存，不能洗白。

前轮核实的正常TERM顺序、实际stop future/143/nonOOM/<=40，规范原503（transport单列GAP），原应用停止后才跑独立AE0/readonly-root/networknone/capdropALL/uid10001 helper、只挂精确本task卷、共享10s执行与absence、原backup+FIFO精确身份/metadata/bytes恢复或只读验证已恢复事实、拒绝覆盖合法新regular、WAL/lock前后只读hash不改均保留。semantic-control3c2956b2与oracles13e24128相对9逐字一致，未扩产品恢复能力。

原app/volume重新start后的sameToken／原问题、原预算票据/有效审计与业务SQL闭合仍must；normal/deadline/revoke/failure判据不因清理修改。作者152/152及四sourcecompile只作为已读离线证据，不替代实际helper、TERM、恢复与独立SQL核。

实际hash：

- `verify-semantic-read-docker.py` `530de7c0f763cedffaacd9f441a60293992944e70392494a665a832645998030`
- `semantic-oracles.py` `13e241280344def1c88dadcc76a48d6a28b837de854ed8265dc048177f0b9c05`
- `semantic-control.py` `3c2956b228922533191798045e338f871d6db7623e3dd3e98d93da7570098b81`
- `verify-semantic-read-docker.test.py` `befa6ac09553c73a7917b5b3119d899dcb62460ee6943a172210f71e720f8d2f`

Reviewer A 未改源、未运行 tests/Docker/SQL/监听。完整发布审计、模式/代次/后继owner及UAT/发布矩阵范围仍GAP，actual新跑完成后再核原始证据。
