# P170 辅助 driver revision8 独立只读复核

**APPROVED（限定 revoke 取证判据修正；实际新跑仍待 M 授权）。** 没有发现本次窄差异范围内剩余 P1/P2。不是产品修复或合同降低，不据此追认旧 revoke PASS，也不签完整 F70/UAT/发布矩阵。

独立读取 revision7→8 全 diff、真实旧7 revoke 原回执/DELETE收据/容器日志、冻结 proxy281 的取消接线与判断优先级，以及 Spec 决策二／三和工程事件定义。proxy `res.close` 会 abort，其 wait interrupted 先读 signal 再读 ACL；规范403响应终结后，同请求的内部 wait 因此可以记录 cancelled。Spec 明确取消源含 res.close，内部 endOutcome 为枚举，并未承诺 HTTP403 必须对应内部 authorization_revoked。旧7确有 DELETE200 written/revokedAt/双ack、原RPC403/-32003/精确authorization_revoked，原 owner registered→begin→cancelled→failed，辅助通用 closure 仅因期待另一个内部枚举而 FAIL；不能据此声称旧跑后段 SQL/审计/恢复已执行。

新函数只有 revoke 调用点使用，且固定已审 proxy281 hash。它同时要求真实已提交 DELETE200、唯一既定Token目标、written/两ack/policyVersion/revokedAt，规范原403/-32003/精确撤销原因、原服务端 operation header 与外层 rpcId，真实 held FIFO sourcefd/wchan/owner/WAL，再用未变通用 closure 校验 begin/end 相同 owner集合、ingress、原deadline与writer唯一真实终态。只允许内部 cancelled/authorization_revoked，保留原始 endOutcome；derivedAttribution单列规范响应原因。要求原 writer failed 晚于原 wait end，没有把读者取消冒充 writer 成功或提前退出。

实际规范拒绝 body.id=null，由外层receipt.rpcId=2、operation头与工程begin/end.rpcId精确绑定；新函数允许null，拒绝错误非null编号。捕获原始fixture与旧raw一致。负例确有 noncanonical403、transport0、DELETE404、泛cancel无action、错误owner/WAL、错误operation/外层RPC/bodyRPC、缺runtimeAck、非固定source、其他内部cause。作者135/135与四source compile记录已读；本review没有重跑。

通用wait_closure、normal/deadline/TERM/failure判据、SQL宽覆盖/独立SQL归因、修复/新合法写、预算有效审计与b身份2/30恢复路径未变。revoke没有绕过后置SQL计数、原身份拒绝、合法身份恢复及collect_audit；任一缺失仍FAIL/GAP。旧7 actual FAIL/cleanuptrue及未执行后段保持历史真值。仅新fresh revoke/term/failure使用revision8；7normal/deadline不因本修正需要重复。

实际源 SHA256：

- `verify-semantic-read-docker.py`：`3ae3d696e36b2013ca69b8577e00ea783f5e30f351270ba064e7f79d9ba34cce`
- `semantic-oracles.py`：`13e241280344def1c88dadcc76a48d6a28b837de854ed8265dc048177f0b9c05`
- `semantic-control.py`：`0ef4fae1d3780b1747a24986e3db3213eaa905e0fdbfdffc898d81acf2863023`
- `verify-semantic-read-docker.test.py`：`58b7d6d5c099a06573a01e26f4d5ce0275d2239b6706786e5f327ec0830a06fd`
- `driver-freeze.json`：`56ac89e58330711943ade3fdc163130d245648da24d78e89c35b7a2956a87e2e`
- `captured-revocation.json`：`cd013d66aedf53772d386dcd9a91026fca171d41ca6c6ad100253beabdf51709`

不修改任何源、旧输出、产品/镜像/预算/Spec；没有 tests/Docker/SQL/监听或重 I/O。实际新结果需另独立核原始证据；预算/有效审计仍待授权 SQL 核窗。
