import { EventEmitter } from "node:events";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import type { IncomingMessage, ServerResponse } from "node:http";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import * as coordinator from "../publish-coordinator.js";
import * as journal from "../semantic-recovery-journal.js";
import * as proxy from "../proxy/mcp-proxy.js";
import { markProcessServing, resetProcessDrainForTests } from "../runtime/process-drain.js";

const TARGET = "semantic-layer/shop/_schema/public.yaml";
const HINTS = ["shop", "orders"];
const NEW = "tables:\n  orders:\n    description: updated\n";
type Stage = { filesSaved(): void; failed(): void };
type Context = { waitDeadlineMonoMs: number; ingressId: string; signal: AbortSignal; close(): void };
type ReadApi = {
  createContext(req: IncomingMessage, res: ServerResponse, ingressId: string): Context;
  awaitRecovery(root: string, hints: string[], context: Context, rpcId: string): Promise<journal.SemanticRecoveryReadBlock | null>;
};
// The old-source adapter deliberately invokes the REAL original guard. The
// baseline red is its immediate semantic denial, never a missing-export error.
const readApi = (proxy as unknown as { __semanticReadWaitTest?: ReadApi }).__semanticReadWaitTest;
const register = (coordinator as unknown as {
  registerPublishWriteStage?: (holder: coordinator.PublishLockHolder, input: {
    projectRoot: string; journal: journal.RecoveryJournal
  }) => Stage
}).registerPublishWriteStage;

function deferred<T = void>() {
  let resolve!: (value: T | PromiseLike<T>) => void;
  const promise = new Promise<T>((done) => { resolve = done; });
  return { promise, resolve };
}

let root: string;
let previousContentRoot: string | undefined;
let events: Record<string, unknown>[];
const contexts: Context[] = [];
beforeEach(async () => {
  previousContentRoot = process.env.LUCY_CONTENT_ROOT;
  process.env.LUCY_CONTENT_ROOT = ".";
  root = await mkdtemp(path.join(os.tmpdir(), "lucy-read-write-settle-"));
  await mkdir(path.dirname(path.join(root, TARGET)), { recursive: true });
  await writeFile(path.join(root, TARGET), "tables:\n  orders: {}\n");
  resetProcessDrainForTests(); markProcessServing();
  events = [];
  vi.spyOn(console, "info").mockImplementation((prefix, value) => {
    if (prefix === "[lucy-semantic-write]") events.push(JSON.parse(value));
  });
});
afterEach(async () => {
  for (const context of contexts.splice(0)) context.close();
  vi.restoreAllMocks(); resetProcessDrainForTests();
  journal.resetSemanticRecoveryAdmissionForTests();
  if (previousContentRoot === undefined) delete process.env.LUCY_CONTENT_ROOT;
  else process.env.LUCY_CONTENT_ROOT = previousContentRoot;
  await rm(root, { recursive: true, force: true });
});

function context() {
  const req = new EventEmitter() as IncomingMessage;
  Object.assign(req, { aborted: false, socket: new EventEmitter() });
  const res = new EventEmitter() as ServerResponse;
  const ctx = readApi?.createContext(req, res, "ingress-test") ?? {
    ingressId: "ingress-test", waitDeadlineMonoMs: performance.now() + 20_000,
    signal: new AbortController().signal, close() {}
  };
  contexts.push(ctx);
  return { req, res, ctx };
}
async function read(ctx: Context) {
  return readApi ? readApi.awaitRecovery(root, HINTS, ctx, "rpc-1")
    : journal.semanticRecoveryReadBlock(root, HINTS);
}
async function normalWriter() {
  const ready = deferred<journal.RecoveryJournal>();
  const write = deferred();
  const done = coordinator.withPublishCoordinator("manifest_upload", async () => {
    let stage: Stage | undefined;
    const saved = await journal.createRecoveryJournal(root, {
      releaseId: "release-live", operationId: "release-live", actor: "admin", instanceId: "synthetic",
      targets: [{ targetPath: TARGET, identity: { connectionId: "shop", schema: "public", table: "public" }, newContent: NEW }],
      ...{ onBeforePersist: (value: journal.RecoveryJournal) => {
        if (register) stage = register(coordinator.currentProcessPublishHolder()!, { projectRoot: root, journal: value });
      } }
    });
    ready.resolve(saved);
    await write.promise;
    await writeFile(path.join(root, TARGET), NEW);
    await journal.markRecoveryJournalFilesSaved(root, saved.journalId);
    stage?.filesSaved();
  }, { projectRoot: root });
  return { journal: await ready.promise, write, done };
}

describe("P1-70 actual normal write admission", () => {
  it("waits on a real live WAL instead of immediately reporting semantic recovery failure", async () => {
    const writer = await normalWriter();
    const { ctx } = context();
    let settled = false;
    const result = read(ctx).then((value) => { settled = true; return value; });
    try {
      for (let turn = 0; turn < 1000 && !settled && !events.some((e) => e.event === "read_wait_begin"); turn++) {
        await new Promise<void>((resolve) => setImmediate(resolve));
      }
      expect(settled, "old real guard immediately returned semantic_recovery_required during normal actual write").toBe(false);
      expect((await journal.readRecoveryJournal(root, writer.journal.journalId))?.phase).toBe("write_in_progress");
    } finally { writer.write.resolve(); await writer.done; }
    expect(await result).toBeNull();
    expect(await readFile(path.join(root, TARGET), "utf8")).toBe(NEW);
  });

  it("keeps an orphan WAL fail closed even when its timestamps and local PID are fresh", async () => {
    await journal.createRecoveryJournal(root, {
      releaseId: "orphan", operationId: "orphan", actor: "admin", instanceId: "synthetic",
      targets: [{ targetPath: TARGET, newContent: NEW }]
    });
    expect((await read(context().ctx))?.code).toBe("semantic_recovery_required");
    expect(events.some((e) => e.event === "read_wait_begin")).toBe(false);
  });

  it("does not turn client cancellation into completion or cancellation of the writer", async () => {
    const writer = await normalWriter();
    const { ctx, res } = context();
    const result = read(ctx);
    for (let turn = 0; turn < 1000 && !events.some((e) => e.event === "read_wait_begin"); turn++) {
      await new Promise<void>((resolve) => setImmediate(resolve));
      if (!readApi) break;
    }
    res.emit("close");
    expect((await result)?.code).toBe("semantic_recovery_required");
    expect((await journal.readRecoveryJournal(root, writer.journal.journalId))?.phase).toBe("write_in_progress");
    expect(events.some((e) => e.event === "files_saved" || e.event === "failed")).toBe(false);
    writer.write.resolve(); await writer.done;
    expect(await journal.semanticRecoveryReadBlock(root, HINTS)).toBeNull();
  });
});
