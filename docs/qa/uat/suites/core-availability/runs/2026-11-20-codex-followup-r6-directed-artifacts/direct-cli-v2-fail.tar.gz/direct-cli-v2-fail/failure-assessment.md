# directCLI-v2 r6 原跑次失败只读核对

原summary保持FAIL，实际driver exit1；未重试、未改源码／driver，全部任务app/db/network/volume/private清理true，资源锁已交还M。本核对仅小回执、事件和冻结源码，没有再运行Docker、SQL或测试。

## 已证实际顺序（UTC）

| 事件 | 时间／结果 |
|---|---|
| driver开始／结束 | 12:03:29.250680／12:04:20.713117；actual-invocation记录PID91856、exit1 |
| 真实native daemon初始start | CLI事件12:03:55.408，real CLI exit0；实际Node v22.23.5 |
| 原生配置／loader前置 | /app/webui，tsx解析成功；真实connection核验verified/reachable，loaded包含uat-mysql |
| 显式管理员reload | 12:04:09.105，unsupported；CLI前后均只有同一初始start，实际listener代次无变化 |
| 原慢SQL已受理 | events的12:04:11.809207 MySQL PROCESSLIST User sleep=1见证 |
| automatic enabled-tables save发起／结束 | 12:04:11.827242／11.841385；服务端req-g为11.828–11.839、10.59ms |
| **实际save终态** | **HTTP404 CONNECTION_NOT_FOUND：Connection 'uat-mysql' not found in ktx.yaml**；见candidate/default-short10-automatic-save.json |
| 最终driver错误 | default-short10-actual-cli-owner witness not observed; [] |

因此8秒不是产品排空20秒／总60秒，也不是从原query受理算起的预算。它是snapshot driver `inflight_case` 在提交save future之后，`wait_for(...actual-cli-owner...,8)` 自己开启的观察窗口；其间save早已404终结，观察不到owner只是后续症状。不能按“8秒没有owner”判产品reload失败。

没有保存任何reload acquire/release/requestId；实际save在写入/触发自动reload前已失败。冻结index.ts在patchConnectionEnabledTablesYaml后才auditedWrite、Policy/Catalog/Execution流程，抛404不会走到CLI reload。**post-save的cli-events/PID未保存成独立artifact**，不能凭缺文件伪造后续PID不变证明；现有明确证据只覆盖bootstrap及显式unsupported的无副作用。

原10秒query只有真实User sleep受理证据，没有default-short10-old-query成功回执文件。失败后的fixture清理早于该受理后10秒的预期结束，连接因清容器中断不能倒推为产品reload截断，也不能签旧query已成功保全。

## 当前最小解释及证据边界

高置信是fixture配置序列化与该保存入口的格式不兼容，而非CLI生命周期：

- 冻结helper291 `Rig.seed`对ktx.yaml使用json.dumps。KTX及readProject的完整YAML parser能读它，实际native配置验证也确实找到uat-mysql。
- 冻结enabled-tables.ts使用byte-local patch；先将flow mapping转block，但随后正则要求无引号 `connections:` 与 `<connId>:`。JSON解析节点保留quoted scalar keys可能仍不匹配，产生完全相同CONNECTION_NOT_FOUND。
- B既有increment driver已在seed对JSON.parse配置调用全新YAML.stringify、输出标准block YAML，正是为保存入口避开这一夹具差异；directCLI-v2没有该步骤。
- 本跑次只保存了config指纹，未备份清理前实际ktx.yaml安全结构/原bytes，也没有异常栈。因此**不将确切404抛出分支或quoted-key原因写成已完成动态实证**。配置本身真实存在与API404并存已证，需新revision离线/前置反例核准具体格式后再跑。

## 建议限定新revision（待M派发；本次未实施）

1. 仅在独立driver的seed阶段将本任务合成配置经已有YAML.stringify(JSON.parse(...))规范化，不改产品parser／入口、r6镜像或共享helper；保留同卷、同Token、原配置语义。
2. 保存脱敏的结构/连接名与digest、必要安全格式证据；在启动慢SQL前对同一enabled-tables路径dryRun做真实前置，HTTP失败立即停止。不得输出DSN/password/token或读取原repo secrets。
3. owner观察期间若saveFuture已终态失败，立即按其原HTTP/code报告，不继续等8秒再误报owner超时；不增加任何原观察／产品时限。
4. 每次失败在bounded清理前留实际CLI事件、listener PID/startTicks、自动save回执与原query future真实终态；清理引起的query断开必须标cleanup-induced/未签，不充产品失败证据。
5. 新driver/test hash＋新out冻结、离线格式/早失败判定负例和非作者复核后，M再给唯一锁执行。原v2 FAIL及全部原文件保持不改；后续四场景本次NOT RUN。
