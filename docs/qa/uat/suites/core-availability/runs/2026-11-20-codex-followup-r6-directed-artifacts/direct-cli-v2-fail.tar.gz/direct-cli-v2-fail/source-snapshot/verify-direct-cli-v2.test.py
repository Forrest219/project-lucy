#!/usr/bin/env python3
"""Offline evidence-validator negatives; no Docker, no KTX UAT claims."""
import importlib.util, pathlib, subprocess, sys, unittest
sys.dont_write_bytecode=True
path=pathlib.Path(__file__).with_name('verify-direct-cli-v2.py')
spec=importlib.util.spec_from_file_location('sc11_direct',path);d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)


def facts(pid=10,ticks='123'):
    return {'listenerOwners':[{'pid':pid,'startTicks':ticks}]}


class DirectCliEvidenceRegressions(unittest.TestCase):
    def test_one_exact_real_listener_is_required(self):
        for sample in [{'listenerOwners':[]},{'listenerOwners':[{'pid':1,'startTicks':'2'},{'pid':3,'startTicks':'4'}]},{'listenerOwners':[{'pid':1}]}]:
            with self.assertRaises(AssertionError):d.listener_identity(sample)

    def test_unsupported_cannot_hide_stop_or_start(self):
        before=[{'operation':'start','atMs':1}]
        for extra in ['stop','start','other']:
            with self.assertRaises(AssertionError):d.assert_no_cli_effect(before,before+[{'operation':extra}],facts(),facts())

    def test_same_pid_with_different_start_ticks_is_not_noop(self):
        with self.assertRaises(AssertionError):d.assert_no_cli_effect([],[],facts(),facts(ticks='124'))

    def test_actual_reload_requires_stop_then_start_and_new_listener(self):
        before=[{'operation':'start','atMs':1}]
        for tail in [[],[{'operation':'start'}],[{'operation':'start'},{'operation':'stop'}],[{'operation':'stop'}]]:
            with self.assertRaises(AssertionError):d.assert_actual_cli_restart(before,before+tail,facts(),facts(11))
        with self.assertRaises(AssertionError):d.assert_actual_cli_restart(before,before+[{'operation':'stop'},{'operation':'start'}],facts(),facts())
        d.assert_actual_cli_restart(before,before+[{'operation':'stop'},{'operation':'start'}],facts(),facts(11))

    def refusal(self):
        owner={'requestId':'cli-actual-owner','deadlineAt':2000,'acquiredAt':'1970-01-01T00:00:01Z'}
        receipt={'httpStatus':503,'body':{'error':{'code':'EXECUTION_RUNTIME_RELOADING','requestId':'cli-actual-owner','deadlineAt':2000,'rejectedAt':1200}}}
        return receipt,owner

    def test_only_exact_owner_and_server_rejection_time_are_accepted(self):
        receipt,owner=self.refusal();d.assert_refusal(receipt,owner)
        for field,value in [('code','upstream_unavailable'),('requestId','other-owner'),('deadlineAt',3000),('rejectedAt',999),('rejectedAt',2001),('rejectedAt',None)]:
            receipt,owner=self.refusal();receipt['body']['error'][field]=value
            with self.assertRaises(AssertionError):d.assert_refusal(receipt,owner)

    def test_timeout_or_generic_unavailable_is_not_reload_refusal(self):
        receipt,owner=self.refusal();receipt['httpStatus']=504
        with self.assertRaises(AssertionError):d.assert_refusal(receipt,owner)

    def test_committed_and_policy_runtime_ack_are_required(self):
        response={'httpStatus':200,'body':{'ok':True,'data':{'written':True,'runtimeAck':True,'policyRuntimeAck':True}}}
        d.assert_auto_saved(response)
        for field in ['written','runtimeAck','policyRuntimeAck']:
            sample={'httpStatus':200,'body':{'ok':True,'data':dict(response['body']['data'])}};sample['body']['data'][field]=False
            with self.assertRaises(AssertionError):d.assert_auto_saved(sample)

    def test_expected_automatic_failure_is_exact_existing_error_code(self):
        d.assert_auto_failed({'httpStatus':503,'body':{'error':{'code':'EXECUTION_RUNTIME_NOT_LOADED'}}})
        for status,code in [(200,'EXECUTION_RUNTIME_NOT_LOADED'),(503,'upstream_unavailable'),(500,'EXECUTION_RUNTIME_NOT_LOADED')]:
            with self.assertRaises(AssertionError):d.assert_auto_failed({'httpStatus':status,'body':{'error':{'code':code}}})

    def test_bootstrap_js_and_native_shim_compile_without_running_them(self):
        compile(d.CLI_SHIM,'<transparent-cli-shim>','exec')
        result=subprocess.run(['node','--check'],input=d.BOOTSTRAP,text=True,capture_output=True)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_ts_loader_cwd_is_a_docker_option_before_container(self):
        command=d.ts_exec_command('owned-app','source','connection')
        self.assertEqual(command[:6],['docker','exec','-i','-w','/app/webui','owned-app'])
        self.assertEqual(command[6:10],['node','--import','tsx','--input-type=module'])
        self.assertEqual(command[-2:],['source','connection'])
        self.assertIn("cwd:'/app/webui'",d.BOOTSTRAP)

    def test_help_does_not_launch_fixture(self):
        result=subprocess.run([sys.executable,str(path),'--help'],text=True,capture_output=True)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn('fault-timeout-ms',result.stdout)

if __name__=='__main__':unittest.main()
