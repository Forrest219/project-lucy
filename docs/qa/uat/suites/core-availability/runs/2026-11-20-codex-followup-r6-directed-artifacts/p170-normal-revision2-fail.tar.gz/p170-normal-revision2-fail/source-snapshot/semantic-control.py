"""Task-owned remote controls. Executed only by an explicitly launched Docker driver."""
import gzip,hashlib,json,os,pathlib,signal,sqlite3,stat,sys,time
ROOT=pathlib.Path('/data/lucy');CONTROL=pathlib.Path('/tmp/uat-p170-control');MIRROR=ROOT/'semantic-layer/uat-mysql/_schema/uat.yaml';SOURCE=ROOT/'config/semantic-layer/uat-mysql/_schema/uat.yaml';BACKUP=ROOT/'.ktx-ui/uat-p170-mirror-backup.yaml'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for part in iter(lambda:f.read(1048576),b''):h.update(part)
 return h.hexdigest()
def read_json(p):
 try:return json.loads(p.read_text())
 except (OSError,ValueError):return None
def write_state(value):
 p=CONTROL/'state.json';t=p.with_suffix('.tmp');t.write_text(json.dumps({'at':time.time(),**value}));os.replace(t,p)
def inspect():
 lock=read_json(ROOT/'.ktx-ui/semantic-publish.lock');journals=[];nodes=[]
 for p in (ROOT/'.ktx-ui/semantic-recovery-journals').glob('*.json'):
  j=read_json(p)
  if j:journals.append({k:j.get(k) for k in ['journalId','releaseId','operationId','status','phase','recoveryRequired']})
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode();name=(p/'comm').read_text().strip()
   if name!='node' or 'server/index.ts' not in cmd:continue
   fields=(p/'stat').read_text().rsplit(')',1)[1].split();row={'pid':int(p.name),'startTicks':fields[19],'fds':[],'tasks':[]}
   for fd in (p/'fd').iterdir():
    try:
     target=os.readlink(fd)
     if target==str(SOURCE):row['fds'].append({'fd':fd.name,'target':target})
    except OSError:pass
   if lock and lock.get('pid')==int(p.name):
    for task in (p/'task').iterdir():
     try:row['tasks'].append({'tid':task.name,'wchan':(task/'wchan').read_text().strip()})
     except OSError:pass
   nodes.append(row)
  except (OSError,ValueError,IndexError):pass
 return {'at':time.time(),'lock':lock,'journals':journals,'nodes':nodes,'control':read_json(CONTROL/'state.json')}
def fifo():
 CONTROL.mkdir(exist_ok=True);os.chmod(CONTROL,0o777);deadline=time.monotonic()+100;reader=None;original=MIRROR.stat();assert stat.S_ISREG(original.st_mode) and not MIRROR.is_symlink();assert not BACKUP.exists()
 os.replace(MIRROR,BACKUP);os.mkfifo(MIRROR,stat.S_IMODE(original.st_mode));os.chown(MIRROR,original.st_uid,original.st_gid);write_state({'phase':'fifo_installed','pid':os.getpid(),'inode':MIRROR.stat().st_ino,'sourceRegular':SOURCE.is_file()})
 try:
  while time.monotonic()<deadline and not (CONTROL/'release').exists():time.sleep(.01)
  if time.monotonic()>=deadline:raise TimeoutError('owned FIFO control absolute100s deadline')
  reader=os.open(MIRROR,os.O_RDONLY|os.O_NONBLOCK);write_state({'phase':'reader_opened','pid':os.getpid(),'inode':os.fstat(reader).st_ino})
  while time.monotonic()<deadline and not (CONTROL/'restore').exists():
   try:os.read(reader,65536)
   except BlockingIOError:pass
   time.sleep(.01)
  if time.monotonic()>=deadline:raise TimeoutError('owned FIFO restore absolute100s deadline')
 finally:
  if reader is not None:os.close(reader)
  if MIRROR.exists() and stat.S_ISFIFO(MIRROR.stat().st_mode):MIRROR.unlink()
  if BACKUP.exists():os.replace(BACKUP,MIRROR)
  write_state({'phase':'restored','pid':os.getpid(),'mirrorRegular':MIRROR.is_file(),'mirrorSha256':digest(MIRROR)})
def capture():
 CONTROL.mkdir(exist_ok=True);path=CONTROL/'audit-evidence.sqlite';archive=CONTROL/'audit-evidence.sqlite.gz';deadline=time.monotonic()+20
 source=sqlite3.connect('file:/data/lucy/.ktx-ui/audit.sqlite?mode=ro',uri=True);dest=sqlite3.connect(path)
 try:source.backup(dest,pages=256,progress=lambda *args: (_ for _ in ()).throw(TimeoutError('backup deadline')) if time.monotonic()>=deadline else None)
 finally:dest.close();source.close()
 with path.open('rb') as src,gzip.open(archive,'wb',compresslevel=1) as dst:
  for part in iter(lambda:src.read(1048576),b''):
   if time.monotonic()>=deadline:raise TimeoutError('gzip deadline')
   dst.write(part)
 result={'source':'SQLite backup API from task-owned live DB; closed copy','sqliteBytes':path.stat().st_size,'sqliteSha256':digest(path),'gzipBytes':archive.stat().st_size,'gzipSha256':digest(archive),'path':str(archive)};path.unlink();print(json.dumps(result))
if __name__=='__main__':
 command=sys.argv[1]
 if command=='inspect':print(json.dumps(inspect()))
 elif command=='fifo':fifo()
 elif command=='signal':
  assert sys.argv[2] in ['release','restore'];(CONTROL/sys.argv[2]).touch()
 elif command=='capture':capture()
 else:raise ValueError('unknown control command')
