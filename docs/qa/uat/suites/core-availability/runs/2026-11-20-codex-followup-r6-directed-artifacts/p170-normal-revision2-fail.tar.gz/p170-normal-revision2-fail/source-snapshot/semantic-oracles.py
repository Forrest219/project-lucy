"""Independent P170 predicates; no runtime import, network or Docker side effects."""
import datetime,json,math,pathlib,re,sqlite3
from decimal import Decimal,InvalidOperation
SOURCE='uat_begin_zero_orders';CONNECTION='uat-mysql';PHYSICAL='uat.'+SOURCE
class PhaseGap(AssertionError):pass
def require(value,message):
 if not value:raise AssertionError(message)
def successful(receipt):
 body=receipt.get('body',{});result=body.get('result',{}) if isinstance(body,dict) else {}
 return receipt.get('httpStatus')==200 and isinstance(result,dict) and not body.get('error') and not result.get('isError')
def payload(receipt):
 result=receipt.get('body',{}).get('result',{})
 if not isinstance(result,dict):return None
 for item in result.get('content',[]):
  if item.get('type')=='text':
   try:return json.loads(item['text'])
   except (ValueError,KeyError):pass
 return result.get('structuredContent')
def aggregate_ok(receipt,expected=(4,100)):
 if not successful(receipt):return False
 data=payload(receipt)
 if not isinstance(data,dict) or not isinstance(data.get('rows'),list) or len(data['rows'])!=1:return False
 row=data['rows'][0];headers=data.get('headers');labels=list(row) if isinstance(row,dict) else headers
 if not isinstance(labels,list) or len(labels)!=2 or any(not isinstance(x,str) for x in labels):return False
 labels=[x[len(SOURCE)+1:] if x.startswith(SOURCE+'.') else x for x in labels]
 if len(set(labels))!=2 or set(labels)!={'order_count','amount_sum'}:return False
 if isinstance(row,dict) and headers is not None:
  if not isinstance(headers,list) or len(headers)!=2 or any(not isinstance(x,str) for x in headers):return False
  declared=[x[len(SOURCE)+1:] if x.startswith(SOURCE+'.') else x for x in headers]
  if len(set(declared))!=2 or set(declared)!=set(labels):return False
 if not isinstance(row,(dict,list)) or len(row)!=2:return False
 bound=dict(zip(labels,list(row.values()) if isinstance(row,dict) else row))
 try:
  values=[bound['order_count'],bound['amount_sum']]
  if any(isinstance(x,bool) or not isinstance(x,(int,float,str)) for x in values):return False
  return all(Decimal(str(x)).is_finite() and Decimal(str(x))==Decimal(str(want)) for x,want in zip(values,expected))
 except (InvalidOperation,TypeError):return False
def metadata_ok(receipt,parsed_yaml):
 data=payload(receipt)
 if not successful(receipt) or not isinstance(data,dict) or data.get('sourceName')!=SOURCE or not isinstance(data.get('yaml'),str):return False
 if not isinstance(parsed_yaml,dict) or parsed_yaml.get('name')!=SOURCE or parsed_yaml.get('table')!=PHYSICAL:return False
 columns=parsed_yaml.get('columns')
 return isinstance(columns,list) and {x.get('name') for x in columns if isinstance(x,dict)}>={'order_id','tenant','amount'}
def explain_ok(receipt):
 d=payload(receipt)
 if not successful(receipt) or not isinstance(d,dict):return False
 sources=d.get('requestedSources');expected={'connectionId':CONNECTION,'sourceName':SOURCE,'physicalTable':PHYSICAL}
 if not isinstance(sources,list) or len(sources)!=1 or not isinstance(sources[0],dict) or any(sources[0].get(k)!=v for k,v in expected.items()):return False
 policy=d.get('policy')
 return d.get('allowed') is True and d.get('executionMode')=='plan_only' and d.get('executed') is False and d.get('aggregateResults') is None and isinstance(policy,dict) and not policy.get('error') and isinstance(policy.get('capabilityDigest'),str) and bool(policy['capabilityDigest']) and policy.get('sourceMapVersion') is not None
def exact_revocation(receipt):
 error=receipt.get('body',{}).get('error',{});data=error.get('data',{}) if isinstance(error,dict) else {}
 return receipt.get('httpStatus')==403 and error.get('code')==-32003 and (error.get('message')=='Access denied: authorization_revoked' or isinstance(data,dict) and data.get('reason')=='authorization_revoked')
def same_node_identities(before,after):
 return bool(before) and before==after
def term_receipt_ok(receipt):
 body=receipt.get('body',{});error=body.get('error',{}) if isinstance(body,dict) else {}
 return receipt.get('httpStatus')==503 and isinstance(body,dict) and body.get('ok') is False and isinstance(error,dict) and error.get('code')=='SERVICE_DRAINING'
def external_term_ok(state,elapsed):
 return not state.get('Running') and state.get('ExitCode')==143 and not state.get('OOMKilled') and elapsed<=40
def machine_reason(receipt):
 body=receipt.get('body',{});error=body.get('error',{})
 if isinstance(error,dict) and error:return error.get('data',{}).get('reason',error.get('code')) if isinstance(error.get('data',{}),dict) else error.get('code')
 d=payload(receipt);return d.get('code',d.get('reason')) if isinstance(d,dict) else None
def parse_events(raw):
 events=[]
 for line in raw.splitlines():
  if '[lucy-semantic-write]' not in line:continue
  match=re.fullmatch(r'(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,9})?(?:Z|[+-]\d\d:\d\d)) \[lucy-semantic-write\] (\{.*\})',line)
  require(bool(match),'malformed original engineering log/prefix')
  stamp=match[1];zone=re.search(r'([+-])(\d\d):(\d\d)$',stamp)
  require(not zone or int(zone[2])<=23 and int(zone[3])<=59,'invalid RFC3339 offset')
  datetime.datetime.fromisoformat(re.sub(r'\.(\d{6})\d+',r'.\1',stamp).replace('Z','+00:00'))
  event=json.loads(match[2]);require(event.get('event') in ['registered','files_saved','failed','read_wait_begin','read_wait_end'],'unknown engineering event')
  for field in ['atMs','monoMs']:require(isinstance(event.get(field),(int,float)) and not isinstance(event[field],bool) and math.isfinite(event[field]),'invalid event clock')
  events.append(event)
 return events
def owner_key(event):return tuple(event.get(x) for x in ['holderOperationId','journalId','releaseId'])
def wait_begin(events,rpc):
 rows=[x for x in events if x.get('event')=='read_wait_begin' and str(x.get('rpcId'))==str(rpc)]
 if not rows:raise PhaseGap('original RPC actual read_wait_begin not observed')
 require(len(rows)==1,'duplicate/misbound read begin');begin=rows[0]
 for f in ['ingressMonoMs','fixedInitialWaitDeadlineMonoMs','waitDeadlineMonoMs']:require(isinstance(begin.get(f),(int,float)) and not isinstance(begin[f],bool) and math.isfinite(begin[f]),'missing/invalid trusted '+f)
 require(begin['fixedInitialWaitDeadlineMonoMs']==begin['ingressMonoMs']+20000,'fixed deadline not original ingress+20s')
 require(begin['waitDeadlineMonoMs']<=begin['fixedInitialWaitDeadlineMonoMs'] and begin['ingressMonoMs']<=begin['monoMs'],'effective deadline extended or ingress reversed')
 require(isinstance(begin.get('ingressOperationId'),str) and begin['ingressOperationId'],'missing original ingress identity')
 owners=begin.get('owners');require(isinstance(owners,list) and owners and len({owner_key(x) for x in owners})==len(owners),'empty/duplicate original owners')
 for owner in owners:
  require(all(isinstance(x,str) and x for x in owner_key(owner)),'unnamed owner')
  registration=[x for x in events if x['event']=='registered' and owner_key(x)==owner_key(owner)];require(len(registration)==1 and registration[0]['monoMs']<=begin['monoMs'],'missing/late/duplicate actual registration')
 return begin
def wait_closure(events,rpc,outcome,receipt=None):
 begin=wait_begin(events,rpc)
 if receipt is not None:require(receipt.get('correlationHeaders',{}).get('x-lucy-operation-id')==begin['ingressOperationId'] and str(receipt.get('rpcId'))==str(rpc),'receipt does not bind original server ingress/RPC')
 ends=[x for x in events if x['event']=='read_wait_end' and x.get('ingressOperationId')==begin['ingressOperationId']]
 require(len(ends)==1,'missing/duplicate original read end');end=ends[0]
 for f in ['rpcId','owners','ingressMonoMs','fixedInitialWaitDeadlineMonoMs','waitDeadlineMonoMs']:require(end.get(f)==begin.get(f),'reader identity/deadline/owner set changed')
 require(end.get('endOutcome')==outcome and end['monoMs']>=begin['monoMs'],'wrong/reversed wait terminal')
 stages=[]
 for owner in begin['owners']:
  terminal=[x for x in events if x['event'] in ['files_saved','failed'] and owner_key(x)==owner_key(owner)];require(len(terminal)==1,'missing/duplicate actual writer terminal');stages+=terminal
 if outcome=='owner_settled':require(all(x['event']=='files_saved' and x['monoMs']<=end['monoMs'] for x in stages) and end['monoMs']<end['waitDeadlineMonoMs'],'false or late normal stage success')
 if outcome=='timeout':require(end['monoMs']>=end['waitDeadlineMonoMs'] and all(x['monoMs']>end['monoMs'] for x in stages),'timeout did not precede real writer settlement')
 return {'begin':begin,'end':end,'stages':stages}
def actual_hold(facts,registration):
 lock=facts.get('lock') or {};nodes=facts.get('nodes',[]);journals=facts.get('journals',[])
 return lock.get('operationId')==registration['holderOperationId'] and any(j.get('journalId')==registration['journalId'] and j.get('releaseId')==registration['releaseId'] and j.get('operationId')==registration['releaseId'] and j.get('phase')=='write_in_progress' and j.get('status')=='open' for j in journals) and any(n.get('pid')==lock.get('pid') and any(fd.get('target')=='/data/lucy/config/semantic-layer/uat-mysql/_schema/uat.yaml' for fd in n.get('fds',[])) and any(t.get('wchan')=='wait_for_partner' for t in n.get('tasks',[])) for n in nodes)
def business_rows(lines):
 return [x for x in lines if x.get('commandType')=='Query' and SOURCE.lower() in x.get('sql','').lower() and re.match(r'^\s*SELECT\b',x.get('sql',''),re.I) and re.search(r'\bCOUNT\s*\(',x['sql'],re.I) and re.search(r'\bSUM\s*\(',x['sql'],re.I)]
def audit_scopes(database,scopes):
 c=sqlite3.connect(pathlib.Path(database).resolve().as_uri()+'?mode=ro&immutable=1',uri=True);c.row_factory=sqlite3.Row;result=[]
 try:
  for scope in scopes:
   state=c.execute('SELECT * FROM question_budget_state WHERE scope_key=?',(scope['scopeKey'],)).fetchone();rows=c.execute('SELECT * FROM access_log WHERE user_id=? AND lucy_session_id=? AND token_hash_prefix=? AND tool=?',(scope['userId'],scope['session'],scope['tokenPrefix'],scope['tool'])).fetchall();checks={'budgetSingleConsumes':bool(state and state['calls']==len(scope['rpcs']) and state['attempts']==len(scope['rpcs']) and state['current_concurrency']==0),'exactRpcAuditRows':len(rows)==len(scope['rpcs']) and sorted(str(x['request_id']) for x in rows)==sorted(str(x) for x in scope['rpcs'])}
   links=[]
   for row in rows:
    associations=c.execute('SELECT t.user_id FROM inferred_turn_access_logs l LEFT JOIN inferred_turns t ON t.inferred_turn_id=l.inferred_turn_id WHERE l.access_log_id=?',(row['id'],)).fetchall();links.append({'id':row['id'],'rpcId':row['request_id'],'outcome':row['outcome'],'links':len(associations),'validSameUser':len(associations)==1 and associations[0]['user_id']==scope['userId']})
   checks['effectiveAuditClosed']=len(links)==len(scope['rpcs']) and all(x['validSameUser'] for x in links)
   expected=scope.get('expected',{});checks['receiptAuditOutcomesAgree']=all(str(x['request_id']) in expected and (x['outcome']=='ok') is expected[str(x['request_id'])] for x in rows)
   if scope['tool']=='lucy_query':checks['executionAuditAgree']=all((bool(x['generated_sql']) and x['query_operation']=='SELECT') if expected.get(str(x['request_id'])) else not x['generated_sql'] and x['query_operation']!='SELECT' for x in rows)
   initial=scope.get('initialState');checks['originalGenerationPreserved']=not initial or bool(state and all(state[k]==initial[k] for k in ['round','window_id','started_at']))
   result.append({'scope':scope,'state':dict(state) if state else None,'rows':links,'checks':checks,'valid':all(checks.values())})
 finally:c.close()
 return result
