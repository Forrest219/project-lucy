#!/usr/bin/env python3
"""P170 scoped real Docker cases. Explicit final candidate/lock required; never patches runtime."""
import argparse,concurrent.futures,datetime,gzip,hashlib,importlib.util,json,os,pathlib,signal,sqlite3,subprocess,tempfile,threading,time,urllib.request,urllib.error
HERE=pathlib.Path(__file__).resolve().parent
PRODUCTS=['webui/server/publish-coordinator.ts','webui/server/semantic-recovery-journal.ts','webui/server/catalog-assets.ts','webui/server/proxy/mcp-proxy.ts']
TOOLS=['lucy_query','lucy_read_source','lucy_explain_query']
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
O=load(HERE/'semantic-oracles.py','p170_oracles');REMOTE=(HERE/'semantic-control.py').read_text()
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()

def verify_sources(context,manifest,event_contract,image):
 O.require(__import__('re').fullmatch(r'sha256:[0-9a-f]{64}',image) is not None and manifest.get('imageId')==image,'immutable image differs from frozen candidate')
 O.require(event_contract.get('status')=='FROZEN','engineering contract not explicitly frozen')
 O.require(event_contract.get('imageId')==image,'event contract bound to a different image')
 for path in PRODUCTS:
  actual=sha(context/path);O.require(actual==manifest.get('sourceHashes',{}).get(path)==event_contract.get('sourceHashes',{}).get(path),'runtime/event-contract source mismatch '+path)
 for path in ['scripts/uat/core-availability-1883-soak.py','scripts/uat/readyz-diagnostic-repro.py','scripts/uat/verify-begin-zero-binding.py']:
  O.require(sha(context/path)==manifest.get('toolHashes',{}).get(path)==event_contract.get('toolHashes',{}).get(path),'fixture tool not frozen in both candidate and event contract '+path)

def send_mcp(url,body,headers,timeout=180):
 started=time.monotonic();request=urllib.request.Request(url,data=json.dumps(body).encode(),headers={'Content-Type':'application/json',**headers},method='POST')
 try:response=urllib.request.urlopen(request,timeout=timeout)
 except urllib.error.HTTPError as error:response=error
 with response:
  raw=response.read().decode();status=response.status;correlation={k.lower():v for k,v in response.headers.items() if k.lower() in ['x-lucy-operation-id','x-lucy-event-id','x-lucy-attempt-id']}
 try:value=json.loads(raw)
 except ValueError:
  frames=[json.loads(line[6:]) for line in raw.splitlines() if line.startswith('data: ') and line[6:].strip()];value=next((x for x in reversed(frames) if 'result' in x or 'error' in x),{'unparsedBody':raw})
 return {'httpStatus':status,'elapsedMs':(time.monotonic()-started)*1000,'body':value,'correlationHeaders':correlation}

def main():
 p=argparse.ArgumentParser();p.add_argument('--case',required=True,choices=['normal','deadline','revoke','term','failure']);p.add_argument('--context',required=True);p.add_argument('--image',required=True);p.add_argument('--candidate-manifest',required=True);p.add_argument('--event-contract',required=True);p.add_argument('--out',required=True);p.add_argument('--overall-seconds',type=int,default=300);p.add_argument('--normal-upload-delay',type=float,default=1.0);a=p.parse_args()
 O.require(a.overall_seconds>0 and a.normal_upload_delay>=0,'invalid driver deadline/schedule');out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True);O.require(not (out/'summary.json').exists(),'fresh output required');context=pathlib.Path(a.context).resolve();manifest=json.loads(pathlib.Path(a.candidate_manifest).read_text());contract=json.loads(pathlib.Path(a.event_contract).read_text());verify_sources(context,manifest,contract,a.image);O.require(contract.get('candidateManifestSha256')==sha(a.candidate_manifest),'event contract not bound to exact candidate manifest bytes')
 s=load(context/'scripts/uat/core-availability-1883-soak.py','p170_soak');fx=s.fx
 class Rig(s.Rig):
  def start(self):self.mysql_deadline=time.monotonic()+90;self.mysql_proved=False;return super().start()
  def sql(self,sql):
   if not getattr(self,'mysql_proved',False):
    O.require(sql.startswith('CREATE DATABASE uat; CREATE TABLE uat.'+fx.SOURCE+'('),'unexpected SQL before initial readiness')
    attempts=[]
    while time.monotonic()<self.mysql_deadline:
     remaining=self.mysql_deadline-time.monotonic()
     if remaining<=0:break
     r=subprocess.run(['docker','exec',self.db,'sh','-c','MYSQL_PWD="$MYSQL_ROOT_PASSWORD" exec mysql --protocol=TCP -h127.0.0.1 -uroot -N -B -e "SELECT 1"'],capture_output=True,text=True,timeout=min(5,remaining));attempts.append({'at':fx.now(),'exit':r.returncode,'stdout':r.stdout.strip()})
     if time.monotonic()<self.mysql_deadline and r.returncode==0 and r.stdout.strip()=='1':self.mysql_proved=True;break
     time.sleep(min(.25,max(0,self.mysql_deadline-time.monotonic())))
    self.save('mysql-final-tcp-readiness',attempts);O.require(self.mysql_proved,'original90s final MySQL readiness failed')
   return super().sql(sql)
 rig=Rig(a.image,out/'candidate');pool=concurrent.futures.ThreadPoolExecutor(max_workers=4);records=[];scopes={};futures=[];event_lock=threading.Lock();deadline=time.monotonic()+a.overall_seconds
 result={'case':a.case,'status':'RUNNING','imageId':a.image,'startedAt':fx.now(),'scope':'P170 isolated real1883-table selected branches only; not completeSC/UAT/formal30min','gaps':[],'sourceHashes':{str(p):sha(p) for p in [pathlib.Path(__file__),HERE/'semantic-oracles.py',HERE/'semantic-control.py']},'candidateManifestSha256':sha(a.candidate_manifest),'eventContractSha256':sha(a.event_contract),'parameters':vars(a)}
 snapshot=out/'source-snapshot';snapshot.mkdir(exist_ok=True)
 for file in [pathlib.Path(__file__),HERE/'semantic-oracles.py',HERE/'semantic-control.py']:
  (snapshot/file.name).write_bytes(file.read_bytes())
 def event(kind,**data):
  row={'kind':kind,'at':fx.now(),'hostMonotonic':time.monotonic(),**data}
  with event_lock:
   with (out/'events.jsonl').open('a') as f:f.write(fx.scrub(json.dumps(row,ensure_ascii=False))+'\n')
 def save():(out/'summary.json').write_text(fx.scrub(json.dumps(result,ensure_ascii=False,indent=2))+'\n')
 def logtext():
  r=subprocess.run(['docker','logs','--timestamps',rig.app],capture_output=True,text=True,timeout=5);O.require(r.returncode==0,'original container logs unavailable');return r.stdout+'\n'+r.stderr
 def events():return O.parse_events(logtext())
 def control(command,*args,timeout=10):return rig.exec('python3','-c',REMOTE,command,*args,timeout=timeout)
 def facts():return json.loads(control('inspect',timeout=5))
 def wait(label,probe,predicate,seconds,phase=False):
  stop=min(deadline,time.monotonic()+seconds);rows=[]
  while time.monotonic()<stop:
   value=probe();rows.append({'at':fx.now(),'value':value})
   if predicate(value):rig.save(label+'-witness',rows);return value
   time.sleep(min(.1,max(0,stop-time.monotonic())))
  rig.save(label+'-witness',rows)
  if phase:raise O.PhaseGap(label+' actual phase not observed')
  raise AssertionError(label+' required terminal/postcondition not satisfied')
 def reader(tool,session,who='a'):
  with rig.rpc_lock:rig.rpc_id+=1;rpc=rig.rpc_id
  arguments={'connectionId':fx.CONN,'sourceName':fx.SOURCE} if tool=='lucy_read_source' else {'connectionId':fx.CONN,'measures':[fx.SOURCE+'.order_count',fx.SOURCE+'.amount_sum']};prefix=('sha256:'+fx.sha(rig.tokens[who]))[:19];scope={'scopeKey':'bq:uat_zb_'+who+'|'+prefix+':'+session,'userId':'uat_zb_'+who,'tokenPrefix':prefix,'session':session,'tool':tool,'rpcs':[],'expected':{}};key=(who,session,tool);scopes.setdefault(key,scope)['rpcs'].append(rpc)
  def perform():
   event('original-rpc-dispatched',tool=tool,session=session,identity=who,rpcId=rpc,arguments=arguments)
   try:
    r=send_mcp(rig.mcp+'/mcp',{'jsonrpc':'2.0','id':rpc,'method':'tools/call','params':{'name':tool,'arguments':arguments}},{'Authorization':'Bearer '+rig.tokens[who],'Accept':'application/json, text/event-stream','x-lucy-session-id':session},timeout=180);r['rpcId']=rpc;scopes[key]['expected'][str(rpc)]=O.successful(r);record={'tool':tool,'session':session,'who':who,'rpcId':rpc,'receipt':r};records.append(record);rig.save('rpc-'+str(rpc),record);event('original-rpc-terminal',**record);return r
   except Exception as error:
    scopes[key]['expected'][str(rpc)]=False;record={'tool':tool,'session':session,'who':who,'rpcId':rpc,'transportError':fx.scrub(str(error))};records.append(record);rig.save('rpc-'+str(rpc)+'-transport',record);event('original-rpc-transport-terminal',**record);raise
  future=pool.submit(perform);futures.append(future);return rpc,future
 def args_upload(content):return {'connectionId':fx.CONN,'schema':fx.SCHEMA,'assetKind':'schema_manifest','filename':'uat.yaml','content':content,'confirmOverwrite':True}
 def upload(content,name):
  r=rig.request(rig.web,'/api/catalog/assets/upload','POST',args_upload(content),timeout=180);rig.save(name,r);event('actual-upload-terminal',name=name,receipt=r);return r
 def upload_ok(r):return r.get('httpStatus')==200 and r.get('body',{}).get('ok') is True and r['body'].get('data',{}).get('uploaded') is True
 def yaml_oracle(receipt):
  data=O.payload(receipt);return json.loads(rig.exec('node','-e',"const Y=require('/app/webui/node_modules/yaml');let s='';process.stdin.on('data',x=>s+=x);process.stdin.on('end',()=>console.log(JSON.stringify(Y.parse(s))));",data=data['yaml'],timeout=5))
 def sql_log(name):
  raw=rig.sql("SELECT JSON_OBJECT('eventTime',CAST(event_time AS CHAR),'threadId',thread_id,'commandType',command_type,'sql',CONVERT(argument USING utf8mb4)) FROM mysql.general_log ORDER BY event_time,thread_id;");rows=[json.loads(x) for x in raw.splitlines() if x.strip()];rig.save(name,rows);return O.business_rows(rows)
 def node_identity(f):return sorted((x['pid'],x['startTicks']) for x in f.get('nodes',[]))
 def protocol(who,session):
  for method in ['initialize','tools/list']:
   r=rig.call(who+'-'+session+'-'+method.replace('/','-'),method=method,who=who,session=session);O.require(O.successful(r),'same Token protocol recovery failed '+method)
 def followup_query(who,session):
  protocol(who,session);rpc,future=reader('lucy_query',session,who);r=future.result(timeout=60);O.require(O.aggregate_ok(r,(2,30) if who=='b' else (4,100)),'same identity original problem oracle failed');return rpc,r
 def repair(original_nodes):
  f=facts();O.require(not f.get('lock'),'operator repair before actual writer lock release');result['beforeOperatorFacts']=f
  # Existing production function, under a real shared disk lock. No withPublishCoordinator,
  # reset latch, direct WAL mutation or fake release audit.
  program=r'''import {randomUUID} from 'node:crypto';import {acquirePublishCoordinatorLock,readPublishCoordinatorLock,releasePublishCoordinatorLock,publishLockOwnedBy} from './server/publish-coordinator.ts';import {recoverPendingRecoveryJournals} from './server/semantic-recovery-journal.ts';const root='/data/lucy';if(await readPublishCoordinatorLock(root))throw Error('previous writer still held');const {acquired,holder}=await acquirePublishCoordinatorLock(root,'semantic_restore',{}, {operationId:'p170-operator-'+randomUUID()});if(!acquired||!holder)throw Error('operator did not acquire actual disk lock');let outcome;try{const actual=await readPublishCoordinatorLock(root);if(!actual||!publishLockOwnedBy(actual,holder))throw Error('operator lock identity mismatch');outcome=await recoverPendingRecoveryJournals(root);}finally{await releasePublishCoordinatorLock(root,holder);}if(await readPublishCoordinatorLock(root))throw Error('operator exact lock not released');console.log(JSON.stringify({scope:'explicit fixture operator repair only; not public HTTP or published audit closure',holder,outcome,acquired:true,exactHolderReleased:true,originalAppLatch:'not inspected/cleared by this separate process'}));'''
  blocked=[j for j in f['journals'] if j.get('status') in ['open','recovery_required']]
  if blocked:
   raw=rig.exec('sh','-c','cd /app/webui && exec node --import tsx --input-type=module -e "$1"','sh',program,timeout=45);rig.save('actual-operator-function-result',raw);operator=json.loads(raw.splitlines()[-1]);O.require(operator.get('acquired') is True and operator.get('exactHolderReleased') is True and operator.get('holder',{}).get('kind')=='semantic_restore' and not operator.get('outcome',{}).get('needsRepair'),'real operator function failed/uncertain');O.require(result['actualMirrorHold']['registrations'][0]['journalId'] in operator['outcome'].get('recovered',[]),'original failed journal not actually recovered');result['operatorApplied']=True
  else:result['operatorApplied']=False;result['operatorNotNeeded']='Original writer actually restored/recovered its own journal'
  O.require(node_identity(facts())==original_nodes,'repair restarted/replaced original Lucy Node');followup_query('b' if a.case=='revoke' else 'a','legal-b' if a.case=='revoke' else 'original-query')
  current=rig.exec('cat','/data/lucy/config/semantic-layer/uat-mysql/_schema/uat.yaml',timeout=5);r=upload(current,'post-repair-real-new-write');O.require(upload_ok(r),'original app legitimate new write still blocked (possible original latch); no reset/restart permitted');result['postRepairOriginalPidFacts']=facts();O.require(O.same_node_identities(original_nodes,node_identity(result['postRepairOriginalPidFacts'])),'new lawful write restarted/replaced original Lucy Node')
  if a.case=='revoke':
   denied=rig.call('revoked-original-token-after-repair',method='initialize',who='a',session='original-query');error=denied.get('body',{}).get('error',{});O.require(denied.get('httpStatus')==401 and error.get('code')==-32001 and error.get('message')=='Unauthorized','revoked original Token reopened after repair')
 def collect_audit():
  attempts=[];until=min(deadline,time.monotonic()+25)
  while time.monotonic()<until:
   meta=json.loads(control('capture',timeout=23));archive=out/('audit-attempt-'+str(len(attempts))+'.sqlite.gz');s.run_owned_process(['docker','cp',rig.app+':'+meta['path'],str(archive)],timeout=15);O.require(archive.stat().st_size==meta['gzipBytes'] and sha(archive)==meta['gzipSha256'],'audit gzip size/hash differs')
   with tempfile.TemporaryDirectory(prefix='p170-audit-') as tmp:
    database=pathlib.Path(tmp)/'audit.sqlite'
    with gzip.open(archive,'rb') as src,database.open('wb') as dst:
     size=0
     for part in iter(lambda:src.read(1048576),b''):
      size+=len(part);O.require(size<=meta['sqliteBytes'],'audit expands past declared bound');dst.write(part)
    O.require(database.stat().st_size==meta['sqliteBytes'] and sha(database)==meta['sqliteSha256'],'closed SQLite size/hash differs');proof=O.audit_scopes(database,list(scopes.values()))
   attempts.append({'at':fx.now(),'manifest':meta,'archive':str(archive),'proof':proof});rig.save('audit-collection-attempts',attempts)
   if all(x['valid'] for x in proof):
    __import__('shutil').copyfile(archive,out/'audit-evidence.sqlite.gz');(out/'audit-evidence.json').write_text(json.dumps(meta,indent=2)+'\n');result['independentBudgetAudit']=proof;return
   time.sleep(.25)
  raise AssertionError('consistent backup original-budget/effective-audit closure incomplete')
 def alarm(number,_):raise TimeoutError('driver absolute deadline/signal '+str(number))
 handlers={sig:signal.signal(sig,alarm) for sig in [signal.SIGALRM,signal.SIGTERM,signal.SIGINT]};signal.setitimer(signal.ITIMER_REAL,a.overall_seconds)
 try:
  save();rig.start();result['actualNodeVersion']=rig.exec('node','--version',timeout=5).strip();O.require(result['actualNodeVersion'].startswith('v22.'),'FIFO control qualified only for Node22; requalify changed runtime');result['scale']=rig.scale_facts();O.require(all(result['scale'][k]>=1883 for k in ['physical','enabled','manifest']),'1883 scale fixture invalid');rig.query('warm-original',session='warm-only');initial=facts();original_nodes=node_identity(initial);O.require(original_nodes,'actual Lucy Node identity unavailable');result['initialFacts']=initial
  runtime_hashes=rig.exec('sha256sum',*['/app/'+name for name in PRODUCTS],timeout=8);result['actualImageRuntimeHashes']=runtime_hashes
  O.require(len(runtime_hashes.splitlines())==len(PRODUCTS),'incomplete actual runtime hash inventory')
  O.require(not manifest.get('runtime',{}).get('node') or manifest['runtime']['node']==result['actualNodeVersion'],'actual Node differs from frozen candidate runtime')
  for line in runtime_hashes.splitlines():
   digest,name=line.split(None,1);O.require(digest==manifest['sourceHashes'].get(name.strip().removeprefix('/app/')),'actual image runtime source mismatch')
  path=rig.project/'config/semantic-layer/uat-mysql/_schema/uat.yaml';manifest_data=json.loads(path.read_text());manifest_data['tables']['uat_p170_changed']=manifest_data['tables'].pop(s.TARGET);content=json.dumps(manifest_data)
  validation=rig.request(rig.web,'/api/catalog/assets/validate','POST',args_upload(content),timeout=180);rig.save('preflight-validate',validation);O.require(validation['httpStatus']==200 and validation['body'].get('data',{}).get('valid') is True,'legitimate manifest preflight invalid');rig.sql("SET GLOBAL log_output='TABLE'; SET GLOBAL general_log=ON; TRUNCATE TABLE mysql.general_log;")
  if a.case=='normal':
   for index,tool in enumerate(TOOLS):
    before=sql_log('before-'+tool);origin=time.monotonic();rpc,future=reader(tool,'normal-'+tool);time.sleep(max(0,origin+a.normal_upload_delay-time.monotonic()));event('fixed-upload-arrival',plannedHostMonotonic=origin+a.normal_upload_delay,tool=tool);up=pool.submit(upload,content,'normal-upload-'+str(index));futures.append(up);receipt=future.result(timeout=180);u=up.result(timeout=180);O.require(upload_ok(u),'natural manifest upload failed');ok=O.aggregate_ok(receipt) if tool=='lucy_query' else O.metadata_ok(receipt,yaml_oracle(receipt)) if tool=='lucy_read_source' and O.successful(receipt) else O.explain_ok(receipt);O.require(ok,'original '+tool+' incorrect/rejected');after=sql_log('after-'+tool);O.require(len(after)-len(before)==(1 if tool=='lucy_query' else 0),'wrong actual business SQL multiplicity '+tool)
    try:result.setdefault('actualWaitClosures',[]).append(O.wait_closure(events(),rpc,'owner_settled',receipt))
    except O.PhaseGap as error:result['gaps'].append(tool+': '+str(error))
  else:
   subprocess.run(['docker','exec','-d','--user','0',rig.app,'python3','-c',REMOTE,'fifo'],check=True,timeout=8);wait('actual-fifo-installed',facts,lambda f:(f.get('control') or {}).get('phase')=='fifo_installed',5,True);previous={O.owner_key(x) for x in events() if x['event']=='registered'};up=pool.submit(upload,content,'controlled-upload');futures.append(up)
   def original_wait_observations():
    es=events()
    if future.done() and not any(e['event']=='read_wait_begin' and str(e.get('rpcId'))==str(rpc) for e in es):
     es=events()
     if not any(e['event']=='read_wait_begin' and str(e.get('rpcId'))==str(rpc) for e in es):raise AssertionError('original RPC terminated while actual mirror/WAL held but no eligible wait evidence')
    return es
   def held():
    f=facts();registrations=[x for x in events() if x['event']=='registered' and O.owner_key(x) not in previous];return {'facts':f,'registrations':registrations}
   witness=wait('actual-mirror-hold',held,lambda w:len(w['registrations'])==1 and O.actual_hold(w['facts'],w['registrations'][0]),45,True);owner=witness['registrations'][0];result['actualMirrorHold']=witness;rpc,future=reader('lucy_query','original-query');begin=wait('actual-original-wait',original_wait_observations,lambda es:any(e['event']=='read_wait_begin' and str(e.get('rpcId'))==str(rpc) for e in es),25,True);O.wait_begin(begin,rpc);initial_budget=rig.snapshot('original-query');O.require(initial_budget is not None,'wait began without committed original budget');scopes[('a','original-query','lucy_query')]['initialState']=initial_budget;result['originalBudgetAtWait']=initial_budget
   if a.case=='deadline':
    receipt=future.result(timeout=35);O.require(not O.successful(receipt) and O.machine_reason(receipt)=='semantic_recovery_required','wait deadline not exact semantic denial');f=facts();O.require(not up.done() and O.actual_hold(f,owner),'reader expiry falsely retired original writer');result['writerStillHeldAtReadTerminal']=f
   elif a.case=='revoke':
    revoked=rig.request(rig.web,'/api/admin/agents/uat_zb_a/tokens/isolated-a','DELETE',timeout=15);rig.save('actual-wait-token-revoke',revoked);O.require(revoked['httpStatus']==200 and revoked['body'].get('ok') is True,'durable Token revoke failed');receipt=future.result(timeout=10);O.require(O.exact_revocation(receipt),'original wait not canonical committed revocation')
   elif a.case=='term':
    configured=json.loads(fx.run(['docker','inspect',rig.app,'--format','{{json .Config.StopSignal}}'],timeout=5)) or '';O.require(configured in ['', 'SIGTERM','15'],'external stop is not TERM');term_start=time.monotonic();stopping=pool.submit(lambda:fx.run(['docker','stop','--time','45',rig.app],timeout=50));futures.append(stopping);wait('actual-term-wait-end',events,lambda es:any(e['event']=='read_wait_end' and str(e.get('rpcId'))==str(rpc) and e.get('endOutcome')=='term' for e in es),5)
   control('signal','release',timeout=5);wait('actual-original-writer-failed',events,lambda es:any(e['event']=='failed' and O.owner_key(e)==O.owner_key(owner) for e in es),12);control('signal','restore',timeout=5);wait('actual-control-restored',facts,lambda f:(f.get('control') or {}).get('phase')=='restored',5)
   if a.case=='term':
    raw=logtext();rig.save('pre-stop-engineering-logs',raw);result['actualWaitClosure']=O.wait_closure(O.parse_events(raw),rpc,'term');stopping.result(timeout=45);state=json.loads(fx.run(['docker','inspect',rig.app,'--format','{{json .State}}'],timeout=5));elapsed=time.monotonic()-term_start;result['externalTerm']={'origin':'external_TERM','configuredStopSignal':configured,'elapsedSeconds':elapsed,'state':state};O.require(O.external_term_ok(state,elapsed),'externalTERM must preserve143 within40s withoutOOM');
    try:original_terminal=future.result(timeout=5)
    except Exception as error:result['originalTermClientTransport']=fx.scrub(str(error));result['gaps'].append('TERM original client transport closed; canonical503 response not proven')
    else:result['originalTermClientReceipt']=original_terminal;O.require(O.term_receipt_ok(original_terminal),'TERM waiter did not return canonical503 SERVICE_DRAINING')
    fx.run(['docker','start',rig.app],timeout=15);rig.web='http://'+fx.run(['docker','port',rig.app,'5174/tcp']);rig.mcp='http://'+fx.run(['docker','port',rig.app,'7879/tcp']);rig.ready();followup_query('a','original-query')
   else:
    u=up.result(timeout=20);O.require(not upload_ok(u),'real mirror failure claimed normal upload success');receipt=future.result(timeout=10);O.require(not O.successful(receipt),'failed mirror reader falsely succeeded');outcome='timeout' if a.case=='deadline' else 'authorization_revoked' if a.case=='revoke' else 'blocked';O.require(a.case=='revoke' or O.machine_reason(receipt)=='semantic_recovery_required','mirror failure disguised as unrelated rejection');result['actualWaitClosure']=O.wait_closure(events(),rpc,outcome,receipt);wait('actual-publish-lock-released',facts,lambda f:not f.get('lock'),8);repair(original_nodes)
   sqlrows=sql_log('all-business-sql');expected=1;O.require(len(sqlrows)==expected,'denied original query executed or recovery SQL duplicated')
  collect_audit();result['status']='NOT RUN: PHASE GAP' if result['gaps'] else 'SCOPED PASS WITH GAP';result['gaps']+=['Selected real branches only; budget mode/tighter deadlines/config generation/successor owner remain component or separate evidence','Not full publishing audit closure, allSC/UAT, formal30min or release readiness']
 except O.PhaseGap as error:result.update(status='NOT RUN: PHASE GAP',error=fx.scrub(str(error)))
 except BaseException as error:result.update(status='FAIL',error=fx.scrub(str(error)),errorType=type(error).__name__)
 finally:
  signal.setitimer(signal.ITIMER_REAL,0)
  try:(out/'final-container-log.txt').write_text(fx.scrub(logtext()))
  except Exception as error:result['logCollectionError']=fx.scrub(str(error))
  try:rig.close(deadline=time.monotonic()+60);result['cleanupComplete']=True
  except Exception as error:result.update(status='FAIL',cleanupComplete=False,cleanupError=fx.scrub(str(error)))
  pending=concurrent.futures.wait(futures,timeout=5).not_done;result['allHostOperationsSettled']=not pending
  if pending:result.update(status='FAIL',hostOperationError='HTTP/stop worker did not settle after owned-container cleanup')
  pool.shutdown(wait=False,cancel_futures=True);result['finishedAt']=fx.now();save()
  for sig,handler in handlers.items():signal.signal(sig,handler)
 print(fx.scrub(json.dumps({'case':a.case,'status':result['status'],'error':result.get('error'),'cleanupComplete':result.get('cleanupComplete')},ensure_ascii=False,indent=2)));return 0 if result['status']=='SCOPED PASS WITH GAP' else 1
if __name__=='__main__':raise SystemExit(main())
