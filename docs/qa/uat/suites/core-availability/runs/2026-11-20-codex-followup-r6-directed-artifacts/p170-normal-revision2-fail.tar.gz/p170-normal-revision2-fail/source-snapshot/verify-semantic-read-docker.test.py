"""Offline predicate adversaries only. These fixtures never certify a real process phase."""
import copy,importlib.util,json,pathlib,sqlite3,tempfile,unittest
HERE=pathlib.Path(__file__).resolve().parent
def load(name):
 p=HERE/name;s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
O=load('semantic-oracles.py');D=load('verify-semantic-read-docker.py')
def receipt(data,**result):return {'httpStatus':200,'body':{'result':{'content':[{'type':'text','text':json.dumps(data)}],**result}}}
def engineering():
 owner={'holderOperationId':'holder','journalId':'journal','releaseId':'release'}
 registered={'event':'registered',**owner,'atMs':1000,'monoMs':100}
 begin={'event':'read_wait_begin','ingressOperationId':'ingress','rpcId':7,'owners':[owner],'ingressMonoMs':50,'fixedInitialWaitDeadlineMonoMs':20050,'waitDeadlineMonoMs':20050,'atMs':1100,'monoMs':200}
 end={**begin,'event':'read_wait_end','monoMs':500,'endOutcome':'owner_settled'}
 stage={**registered,'event':'files_saved','monoMs':400};return [registered,begin,stage,end]
class Tools(unittest.TestCase):
 def test_query_correct_columns_and_strings(self):self.assertTrue(O.aggregate_ok(receipt({'headers':['order_count','amount_sum'],'rows':[['4','100']]})))
 def test_reordered_labeled_values_remain_correct(self):self.assertTrue(O.aggregate_ok(receipt({'headers':['amount_sum','order_count'],'rows':[['100','4']]})))
 def test_swapped_numbers_are_not_the_original_problem(self):self.assertFalse(O.aggregate_ok(receipt({'headers':['order_count','amount_sum'],'rows':[[100,4]]})))
 def test_wrong_or_missing_labels_fail(self):
  for headers in [None,['wrong','values'],['order_count','order_count']]:self.assertFalse(O.aggregate_ok(receipt({'headers':headers,'rows':[[4,100]]})))
 def test_dict_row_with_contradictory_headers_fails(self):self.assertFalse(O.aggregate_ok(receipt({'headers':['wrong','amount_sum'],'rows':[{'order_count':4,'amount_sum':100}]})))
 def test_precision_loss_does_not_create_success(self):self.assertFalse(O.aggregate_ok(receipt({'headers':['order_count','amount_sum'],'rows':[['4.000000000000000001','100']]})))
 def test_http200_iserror_is_not_success(self):self.assertFalse(O.aggregate_ok(receipt({'headers':['order_count','amount_sum'],'rows':[[4,100]]},isError=True)))
 def test_metadata_correct_authorized_source(self):self.assertTrue(O.metadata_ok(receipt({'sourceName':O.SOURCE,'yaml':'actual source'}),{'name':O.SOURCE,'table':O.PHYSICAL,'columns':[{'name':x} for x in ['order_id','tenant','amount']]}))
 def test_metadata_wrong_physical_scope_is_not_correct(self):self.assertFalse(O.metadata_ok(receipt({'sourceName':O.SOURCE,'yaml':'actual source'}),{'name':O.SOURCE,'table':'secret.other','columns':[]}))
 def explain(self):return {'allowed':True,'executionMode':'plan_only','executed':False,'aggregateResults':None,'policy':{'sourceMapVersion':'v1','capabilityDigest':'actual'},'requestedSources':[{'connectionId':O.CONNECTION,'sourceName':O.SOURCE,'physicalTable':O.PHYSICAL}]}
 def test_explain_is_plan_only_correct_scope(self):self.assertTrue(O.explain_ok(receipt(self.explain())))
 def test_explain_actual_execution_cannot_pass(self):
  d=self.explain();d['executed']=True;self.assertFalse(O.explain_ok(receipt(d)))
 def test_explain_wrong_source_cannot_pass(self):
  d=self.explain();d['requestedSources'][0]['physicalTable']='secret.other';self.assertFalse(O.explain_ok(receipt(d)))
 def test_explain_additional_source_is_not_original_scope(self):
  d=self.explain();d['requestedSources'].append({'connectionId':'other','sourceName':'secret','physicalTable':'secret.other'});self.assertFalse(O.explain_ok(receipt(d)))
 def test_explain_duplicate_source_is_not_exact_original_scope(self):
  d=self.explain();d['requestedSources']*=2;self.assertFalse(O.explain_ok(receipt(d)))
 def test_explain_empty_identity_field_fails(self):
  d=self.explain();d['requestedSources'][0]['physicalTable']='';self.assertFalse(O.explain_ok(receipt(d)))
 def test_generic_error_is_not_token_revocation(self):self.assertFalse(O.exact_revocation({'httpStatus':503,'body':{'error':{'code':-32003,'message':'upstream unavailable'}}}))
class Events(unittest.TestCase):
 def test_exact_owner_stage_reader_closure(self):self.assertEqual(O.wait_closure(engineering(),7,'owner_settled')['end']['endOutcome'],'owner_settled')
 def test_no_actual_wait_is_gap(self):
  with self.assertRaises(O.PhaseGap):O.wait_closure([engineering()[0]],7,'owner_settled')
 def test_writer_stage_signal_without_read_receipt_is_not_sql_success(self):
  self.assertFalse(O.aggregate_ok({'httpStatus':200,'body':{}}))
 def test_fake_registration_after_begin_fails(self):
  e=engineering();e[0]['monoMs']=201
  with self.assertRaises(AssertionError):O.wait_closure(e,7,'owner_settled')
 def test_begin_does_not_restart_20s_clock(self):
  e=engineering();e[1]['fixedInitialWaitDeadlineMonoMs']=20200
  with self.assertRaises(AssertionError):O.wait_begin(e,7)
 def test_budget_effective_deadline_cannot_extend(self):
  e=engineering();e[1]['waitDeadlineMonoMs']=21000
  with self.assertRaises(AssertionError):O.wait_begin(e,7)
 def test_deadline_fields_cannot_change_on_wake(self):
  e=engineering();e[-1]['waitDeadlineMonoMs']=30000
  with self.assertRaises(AssertionError):O.wait_closure(e,7,'owner_settled')
 def test_successor_owner_cannot_replace_original_set(self):
  e=engineering();e[-1]['owners']=[{'holderOperationId':'new','journalId':'new','releaseId':'new'}]
  with self.assertRaises(AssertionError):O.wait_closure(e,7,'owner_settled')
 def test_failed_or_late_stage_never_becomes_normal_success(self):
  for field,value in [('event','failed'),('monoMs',600)]:
   e=engineering();e[2][field]=value
   with self.assertRaises(AssertionError):O.wait_closure(e,7,'owner_settled')
 def test_duplicate_terminal_fails(self):
  e=engineering();e.append(copy.deepcopy(e[2]))
  with self.assertRaises(AssertionError):O.wait_closure(e,7,'owner_settled')
 def test_timeout_reader_never_retires_writer(self):
  e=engineering();e[2].update(event='failed',monoMs=21000);e[-1].update(endOutcome='timeout',monoMs=20060);self.assertEqual(O.wait_closure(e,7,'timeout')['end']['endOutcome'],'timeout')
 def test_writer_settled_before_timeout_not_held_evidence(self):
  e=engineering();e[2].update(event='failed',monoMs=19900);e[-1].update(endOutcome='timeout',monoMs=20060)
  with self.assertRaises(AssertionError):O.wait_closure(e,7,'timeout')
 def test_reader_identity_cannot_change(self):
  e=engineering();e[-1]['rpcId']=8
  with self.assertRaises(AssertionError):O.wait_closure(e,7,'owner_settled')
 def test_nano_logs_are_valid_and_bad_offsets_are_not(self):
  raw='2026-11-20T12:00:00.123456789Z [lucy-semantic-write] '+json.dumps(engineering()[0]);self.assertEqual(len(O.parse_events(raw)),1)
  with self.assertRaises(AssertionError):O.parse_events(raw.replace('Z [','+00:60 ['))
class TermAndIngress(unittest.TestCase):
 def test_external_term_preserves_exact_origin_code(self):self.assertTrue(O.external_term_ok({'Running':False,'ExitCode':143,'OOMKilled':False},20.5))
 def test_natural_zero_or_kill137_not_external143(self):
  for code in [0,137,23]:self.assertFalse(O.external_term_ok({'Running':False,'ExitCode':code,'OOMKilled':False},20))
 def test_oom_or_over40_cannot_pass(self):
  self.assertFalse(O.external_term_ok({'Running':False,'ExitCode':143,'OOMKilled':True},20));self.assertFalse(O.external_term_ok({'Running':False,'ExitCode':143,'OOMKilled':False},40.01))
 def test_term_requires_canonical503_service_draining(self):self.assertTrue(O.term_receipt_ok({'httpStatus':503,'body':{'ok':False,'error':{'code':'SERVICE_DRAINING'}}}))
 def test_unrelated200_failure_is_not_term_denial(self):self.assertFalse(O.term_receipt_ok(receipt({'code':'semantic_recovery_required'},isError=True)))
 def test_upstream503_is_not_term_denial(self):self.assertFalse(O.term_receipt_ok({'httpStatus':503,'body':{'ok':False,'error':{'code':'upstream_unavailable'}}}))
 def test_service_draining_without_false_ok_is_not_canonical(self):self.assertFalse(O.term_receipt_ok({'httpStatus':503,'body':{'error':{'code':'SERVICE_DRAINING'}}}))
 def test_new_lawful_write_requires_original_process_identity(self):self.assertTrue(O.same_node_identities([(1,'10')],[(1,'10')]))
 def test_restarted_pid_or_pid_reuse_after_write_cannot_pass(self):
  self.assertFalse(O.same_node_identities([(1,'10')],[(2,'10')])) ;self.assertFalse(O.same_node_identities([(1,'10')],[(1,'11')]))
 def test_real_receipt_binds_original_ingress(self):
  O.wait_closure(engineering(),7,'owner_settled',{'rpcId':7,'correlationHeaders':{'x-lucy-operation-id':'ingress'}})
 def test_wrong_receipt_ingress_is_not_same_rpc_proof(self):
  with self.assertRaises(AssertionError):O.wait_closure(engineering(),7,'owner_settled',{'rpcId':7,'correlationHeaders':{'x-lucy-operation-id':'different'}})

class KernelAndSql(unittest.TestCase):
 def facts(self):return {'lock':{'operationId':'holder','pid':123},'journals':[{'journalId':'journal','releaseId':'release','operationId':'release','phase':'write_in_progress','status':'open'}],'nodes':[{'pid':123,'fds':[{'fd':'18','target':'/data/lucy/config/semantic-layer/uat-mysql/_schema/uat.yaml'}],'tasks':[{'wchan':'wait_for_partner'}]}]}
 def test_actual_owned_fd_worker_and_wal_required(self):self.assertTrue(O.actual_hold(self.facts(),engineering()[0]))
 def test_timer_pending_without_kernel_is_not_a_phase(self):
  f=self.facts();f['nodes'][0]['tasks']=[];self.assertFalse(O.actual_hold(f,engineering()[0]))
 def test_wrong_holder_or_journal_never_qualifies(self):
  f=self.facts();f['lock']['operationId']='other';self.assertFalse(O.actual_hold(f,engineering()[0]))
 def test_unrelated_fd_does_not_prove_actual_mirror(self):
  f=self.facts();f['nodes'][0]['fds'][0]['target']='/unrelated';self.assertFalse(O.actual_hold(f,engineering()[0]))
 def test_actual_business_sql_only_not_log_reader(self):
  original={'commandType':'Query','sql':'SELECT COUNT(DISTINCT order_id),SUM(amount) FROM uat.'+O.SOURCE};reader={'commandType':'Query','sql':"SELECT JSON_OBJECT('sql',CONVERT(argument USING utf8mb4)) FROM mysql.general_log"};self.assertEqual(O.business_rows([reader,original]),[original])
class Audit(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.db=pathlib.Path(self.temp.name)/'closed.sqlite';self.c=sqlite3.connect(self.db);self.c.executescript("CREATE TABLE question_budget_state(scope_key TEXT,calls INT,attempts INT,current_concurrency INT,round INT,window_id INT,started_at INT);INSERT INTO question_budget_state VALUES('scope',1,1,0,0,0,100);CREATE TABLE access_log(id INT,user_id TEXT,lucy_session_id TEXT,token_hash_prefix TEXT,tool TEXT,request_id TEXT,outcome TEXT,generated_sql TEXT,query_operation TEXT);INSERT INTO access_log VALUES(1,'a','session','token','lucy_query','7','ok','SELECT COUNT(*),SUM(amount)','SELECT');CREATE TABLE inferred_turns(inferred_turn_id TEXT,user_id TEXT);INSERT INTO inferred_turns VALUES('turn','a');CREATE TABLE inferred_turn_access_logs(inferred_turn_id TEXT,access_log_id INT);INSERT INTO inferred_turn_access_logs VALUES('turn',1);");self.scope={'scopeKey':'scope','userId':'a','session':'session','tokenPrefix':'token','tool':'lucy_query','rpcs':[7],'expected':{'7':True},'initialState':{'round':0,'window_id':0,'started_at':100}}
 def tearDown(self):self.c.close();self.temp.cleanup()
 def verify(self):self.c.commit();return O.audit_scopes(self.db,[self.scope])[0]
 def test_single_original_budget_and_effective_audit(self):self.assertTrue(self.verify()['valid'])
 def test_double_consume_fails(self):self.c.execute('UPDATE question_budget_state SET calls=2');self.assertFalse(self.verify()['valid'])
 def test_same_session_generation_reset_fails(self):self.c.execute('UPDATE question_budget_state SET window_id=1');self.assertFalse(self.verify()['valid'])
 def test_orphan_or_wrong_user_link_fails(self):self.c.execute("UPDATE inferred_turns SET user_id='other'");self.assertFalse(self.verify()['valid'])
 def test_duplicate_actual_audit_fails(self):self.c.execute('INSERT INTO access_log SELECT * FROM access_log');self.assertFalse(self.verify()['valid'])
 def test_false_success_audit_fails(self):self.c.execute("UPDATE access_log SET outcome='error'");self.assertFalse(self.verify()['valid'])
 def test_success_receipt_without_execution_audit_fails(self):self.c.execute('UPDATE access_log SET generated_sql=NULL,query_operation=NULL');self.assertFalse(self.verify()['valid'])
 def test_missing_or_duplicate_effective_link_fails(self):self.c.execute("INSERT INTO inferred_turn_access_logs VALUES('turn',1)");self.assertFalse(self.verify()['valid'])
class Freeze(unittest.TestCase):
 def test_exact_source_pins_accept_and_changed_tool_is_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=pathlib.Path(tmp);products={};tools={};image='sha256:'+'a'*64
   for name in D.PRODUCTS+['scripts/uat/core-availability-1883-soak.py','scripts/uat/readyz-diagnostic-repro.py','scripts/uat/verify-begin-zero-binding.py']:
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(name);(products if name in D.PRODUCTS else tools)[name]=D.sha(p)
   manifest={'imageId':image,'sourceHashes':products,'toolHashes':tools};contract={'status':'FROZEN','imageId':image,'sourceHashes':copy.deepcopy(products),'toolHashes':copy.deepcopy(tools)};D.verify_sources(root,manifest,contract,image)
   contract['toolHashes']['scripts/uat/verify-begin-zero-binding.py']='wrong'
   with self.assertRaises(AssertionError):D.verify_sources(root,manifest,contract,image)
 def test_unfrozen_schema_cannot_start_docker(self):
  with self.assertRaises(AssertionError):D.verify_sources(pathlib.Path('.'),{'imageId':'sha256:'+'a'*64},{'status':'NOT FROZEN'},'sha256:'+'a'*64)
 def test_event_contract_wrong_image_cannot_start_docker(self):
  with self.assertRaises(AssertionError):D.verify_sources(pathlib.Path('.'),{'imageId':'sha256:'+'a'*64},{'status':'FROZEN','imageId':'sha256:'+'b'*64},'sha256:'+'a'*64)
 def test_mutable_tag_cannot_start_docker(self):
  with self.assertRaises(AssertionError):D.verify_sources(pathlib.Path('.'),{'imageId':'latest'},{'status':'FROZEN'},'latest')
if __name__=='__main__':unittest.main()
