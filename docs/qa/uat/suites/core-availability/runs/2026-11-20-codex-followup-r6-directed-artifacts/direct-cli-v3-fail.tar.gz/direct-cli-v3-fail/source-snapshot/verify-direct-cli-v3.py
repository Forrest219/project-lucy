#!/usr/bin/env python3
"""SC11 scoped REAL KTX CLI fixture, not a supported deployment. Never edits product code.

Standard entrypoint initializes the synthetic instance first. Then a task-owned
bootstrap runs the same Node22 app and real daemon CLI WITHOUT a supervisor.
The transparent CLI shim logs only operation/time then execs the real binary.
"""
from __future__ import annotations
import argparse, concurrent.futures, datetime, hashlib, importlib.util, json, os
import pathlib, signal, subprocess, threading, time

CLI_SHIM = """#!/usr/bin/env python3
import json,os,sys,time
args=sys.argv[1:]
index=args.index('mcp') if 'mcp' in args else -1
operation=args[index+1] if index>=0 and index+1<len(args) else None
if operation in ['stop','start']:
 with open('/tmp/sc11/cli-events.jsonl','a') as f:f.write(json.dumps({'atMs':time.time()*1000,'pid':os.getpid(),'operation':operation})+'\\n')
os.execv(os.environ['SC11_REAL_KTX'],[os.environ['SC11_REAL_KTX']]+args)
"""

BOOTSTRAP = r'''
const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto');
const dir='/tmp/sc11';fs.mkdirSync(dir,{recursive:true});
const token=fs.readFileSync('/data/lucy/.ktx-ui/ktx-internal-token','utf8').trim();
if(token.length<32)throw Error('fixture instance token absent');
const located=cp.spawnSync('/bin/sh',['-c','command -v ktx'],{encoding:'utf8'});
if(located.status!==0)throw Error('real bundled KTX CLI absent');
const real=fs.realpathSync(located.stdout.trim());
fs.mkdirSync(dir+'/bin',{recursive:true});
fs.writeFileSync(dir+'/bin/ktx',__SC11_SHIM_SOURCE__,{mode:0o755});
Object.assign(process.env,{KTX_INTERNAL_TOKEN:token,KTX_MCP_TOKEN:token,SC11_REAL_KTX:real,PATH:dir+'/bin:'+process.env.PATH});
for(const name of ['ktx-reload.capability','ktx-reload.request','ktx-reload.result','ktx-supervisor.pid','ktx-ready','ktx.pid','lucy-process-drain.request','lucy-process-drain.ack'])fs.rmSync('/data/lucy/.ktx-ui/'+name,{force:true});
const start=cp.spawnSync('ktx',['--project-dir','/data/lucy','mcp','start','--host','127.0.0.1','--port','7878','--token',token],{encoding:'utf8',timeout:20000,killSignal:'SIGKILL'});
fs.writeFileSync(dir+'/bootstrap-facts.json',JSON.stringify({node:process.version,realCli:real,realCliSha256:crypto.createHash('sha256').update(fs.readFileSync(real)).digest('hex'),initialCliExitCode:start.status,initialCliStarted:/daemon started/i.test(start.stdout||''),mode:'synthetic direct CLI fixture; no supervisor; not a deployment support claim'}));
if(start.status!==0||!/daemon started/i.test(start.stdout||''))throw Error('real direct daemon start did not succeed');
const app=cp.spawn(process.execPath,['--import','tsx','server/index.ts'],{cwd:'/app/webui',env:process.env,stdio:['ignore','pipe','pipe']});
// Internal fixture token stays in process memory and is never printed, even if
// one native child line happens to contain it. JSON owner records remain intact.
function relay(stream,target){let pending='';stream.on('data',c=>{pending+=c.toString();const lines=pending.split('\n');pending=lines.pop();for(const line of lines)target.write(line.split(token).join('[redacted]')+'\n');});stream.on('end',()=>{if(pending)target.write(pending.split(token).join('[redacted]'));});}
relay(app.stdout,process.stdout);relay(app.stderr,process.stderr);
process.on('SIGTERM',()=>app.kill('SIGTERM'));process.on('SIGINT',()=>app.kill('SIGINT'));
app.on('exit',code=>process.exit(code===null?1:code));
'''.replace('__SC11_SHIM_SOURCE__',json.dumps(CLI_SHIM))

LISTENER_FACTS=r'''
import pathlib,json,time
root=pathlib.Path('/proc');inodes=set()
for filename in ['net/tcp','net/tcp6']:
 try:
  for line in (root/filename).read_text().splitlines()[1:]:
   fields=line.split()
   if fields[1].split(':')[-1].upper()==format(7878,'04X') and fields[3]=='0A':inodes.add(fields[9])
 except OSError:pass
owners=[]
for p in root.iterdir():
 if not p.name.isdigit():continue
 try:
  if not any(fd.readlink().as_posix() in {'socket:['+inode+']' for inode in inodes} for fd in (p/'fd').iterdir()):continue
  stat=(p/'stat').read_text().rsplit(')',1)[1].split()
  owners.append({'pid':int(p.name),'startTicks':stat[19],'comm':(p/'comm').read_text().strip()})
 except (OSError,PermissionError):pass
print(json.dumps({'atMs':time.time()*1000,'port':7878,'listenerOwners':owners,'capabilityExists':pathlib.Path('/data/lucy/.ktx-ui/ktx-reload.capability').exists()}))
'''

VERIFY_LOADED=r'''
import fs from 'node:fs';
process.env.KTX_INTERNAL_TOKEN=fs.readFileSync('/data/lucy/.ktx-ui/ktx-internal-token','utf8').trim();
const {readProject}=await import('/app/webui/server/project.ts');
const {verifyConfigLoaded}=await import('/app/webui/server/admin/mcp-runtime-reload.ts');
const p=await readProject('/data/lucy');const r=await verifyConfigLoaded(p.connections.map(c=>c.id),process.argv[1],Date.now()+10000);
console.log(JSON.stringify({state:r.state,reachable:r.reachable,loadedConnectionIds:r.loadedConnectionIds,missingConnectionIds:r.missingConnectionIds}));
'''


TS_PREFLIGHT = "console.log(JSON.stringify({cwd:process.cwd(),tsx:import.meta.resolve('tsx'),node:process.version}))"

# Executed only in the same immutable image, before the synthetic instance is
# copied into its own volume. Secret values are compared IN MEMORY, never logged.
NORMALIZE_SEED = r'''
const Y=require('yaml'),crypto=require('node:crypto'),util=require('node:util');
function shape(value){if(value===null)return 'null';if(Array.isArray(value))return value.map(shape);if(typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(k=>[k,shape(value[k])]));return typeof value;}
function digest(value){return crypto.createHash('sha256').update(JSON.stringify(shape(value))).digest('hex');}
let raw='';process.stdin.setEncoding('utf8');process.stdin.on('data',c=>raw+=c);
process.stdin.on('end',()=>{const before=JSON.parse(raw),yaml=Y.stringify(before),after=Y.parse(yaml);
 if(!util.isDeepStrictEqual(before,after))throw Error('seed normalization changed a value or type');
 process.stdout.write(JSON.stringify({yaml,proof:{allValuesEqual:true,redactedStructureSha256Before:digest(before),redactedStructureSha256After:digest(after),connectionIds:Object.keys(before.connections||{}),format:'fresh YAML.stringify from parsed synthetic JSON'}}));});
'''

CHECK_SAVE_TARGET = r'''
import fs from 'node:fs';import path from 'node:path';import {isDeepStrictEqual} from 'node:util';import {parse} from 'yaml';
const {resolveProjectRoot,readProject}=await import('/app/webui/server/project.ts');
const {patchConnectionEnabledTablesYaml}=await import('/app/webui/server/enabled-tables.ts');
const root=await resolveProjectRoot(),connectionId=process.argv[1],table=process.argv[2];
const project=await readProject(root),connection=project.connections.find(c=>c.id===connectionId);
if(!connection)throw Error('configured synthetic connection missing');
const before=fs.readFileSync(path.join(root,'ktx.yaml'),'utf8');
const candidate=patchConnectionEnabledTablesYaml(before,connectionId,[table]).proposedYaml;
if(!isDeepStrictEqual(parse(before),parse(candidate)))throw Error('same-enabled-table pure patch changed configuration values');
console.log(JSON.stringify({connectionId,connectionExists:true,requestedEnabledTables:[table],existingEnabledTables:connection.enabledTables,purePatchParses:true,allValuesPreserved:true,written:false}));
'''


def seed_normalizer_command(image,container):
    return ['docker','run','--rm','-i','--name',container,'--network','none','--read-only',
            '--workdir','/app/webui','--entrypoint','node',image,'-e',NORMALIZE_SEED]


def seed_normalizer_result(raw):
    value=json.loads(raw);proof=value.get('proof',{})
    if not isinstance(value.get('yaml'),str) or proof.get('allValuesEqual') is not True:
        raise AssertionError('seed normalization did not prove exact value/type preservation')
    digest=proof.get('redactedStructureSha256Before')
    if not isinstance(digest,str) or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):
        raise AssertionError('seed normalization structure proof missing')
    if digest!=proof.get('redactedStructureSha256After'):
        raise AssertionError('seed normalization changed redacted structure')
    return value['yaml'],proof


def completed_save_failure(future):
    if future is None or not future.done():return None
    value=future.result()
    if value.get('httpStatus',500)>=400 or value.get('body',{}).get('ok') is False:return value
    return None


def future_state(future):
    if not future.done():return {'state':'IN_FLIGHT','cleanupMayAbort':True}
    try:return {'state':'FINISHED','result':future.result()}
    except BaseException as error:return {'state':'FAILED','errorType':type(error).__name__,'error':str(error)}


def ts_exec_command(container,source,*arguments):
    # Docker option precedes the container; Node's bare --import resolves from this cwd.
    return ['docker','exec','-i','-w','/app/webui',container,'node','--import','tsx','--input-type=module','-e',source,*arguments]


def stamp(value):
    result=datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
    if result.tzinfo is None:raise ValueError('explicit timezone required')
    return result.timestamp()*1000


def listener_identity(facts):
    owners=facts.get('listenerOwners',[])
    if len(owners)!=1:raise AssertionError('exactly one actual 7878 listener identity is required')
    item=owners[0]
    if not isinstance(item.get('pid'),int) or not str(item.get('startTicks','')).isdigit():raise AssertionError('actual PID/startTicks witness absent')
    return item['pid'],str(item['startTicks'])


def assert_no_cli_effect(before_events,after_events,before_pid,after_pid):
    if before_events!=after_events:raise AssertionError('native CLI start/stop invocation changed')
    if listener_identity(before_pid)!=listener_identity(after_pid):raise AssertionError('real KTX listener identity changed')


def assert_actual_cli_restart(before_events,after_events,before_pid,after_pid):
    if after_events[:len(before_events)]!=before_events:raise AssertionError('CLI evidence prefix changed')
    if [e.get('operation') for e in after_events[len(before_events):]]!=['stop','start']:raise AssertionError('automatic direct reload did not execute exactly real stop then start')
    if listener_identity(before_pid)==listener_identity(after_pid):raise AssertionError('real KTX listener did not change')


def assert_refusal(receipt,owner):
    error=receipt.get('body',{}).get('error',{})
    if receipt.get('httpStatus')!=503 or error.get('code')!='EXECUTION_RUNTIME_RELOADING':raise AssertionError('not an explicit P1-69 refusal')
    if error.get('requestId')!=owner.get('requestId') or error.get('deadlineAt')!=owner.get('deadlineAt'):raise AssertionError('wrong real reload owner')
    rejected=error.get('rejectedAt')
    if type(rejected) not in [int,float] or not stamp(owner['acquiredAt'])<=rejected<=owner['deadlineAt']:raise AssertionError('server rejection timestamp outside exact owner budget')


def assert_auto_saved(receipt):
    data=receipt.get('body',{}).get('data',{})
    if receipt.get('httpStatus')!=200 or receipt.get('body',{}).get('ok') is not True or data.get('written') is not True:raise AssertionError('automatic save not committed and acknowledged')
    if data.get('runtimeAck') is not True or data.get('policyRuntimeAck') is not True:raise AssertionError('original policy/runtime ack not true')


def assert_auto_failed(receipt):
    if receipt.get('httpStatus')!=503 or receipt.get('body',{}).get('error',{}).get('code')!='EXECUTION_RUNTIME_NOT_LOADED':raise AssertionError('automatic execution-layer failure was hidden or misclassified')


def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--context',required=True);p.add_argument('--image',required=True);p.add_argument('--out',required=True)
    p.add_argument('--overall-seconds',type=int,default=900);p.add_argument('--fault-timeout-ms',type=int,default=1500)
    args=p.parse_args()
    if args.overall_seconds<=0:p.error('overall-seconds must be positive')
    if not 500<=args.fault_timeout_ms<=10000:p.error('fault-timeout-ms is a declared tighter test profile (500..10000), not default60s proof')
    context=pathlib.Path(args.context).resolve();out=pathlib.Path(args.out).resolve();out.mkdir(parents=True,exist_ok=True)
    if (out/'summary.json').exists():raise SystemExit('choose a fresh output directory')
    base=load_module(context/'scripts/uat/readyz-diagnostic-repro.py','sc11_base');fx=base.fx
    reference_path=pathlib.Path(__file__).with_name('verify-reload-docker.py');reference=load_module(reference_path,'sc11_sql_oracle')
    class Rig(base.Rig):
        def request(self,base_url,route,method='GET',body=None,headers=None,timeout=180,admin=True):return fx.Rig.request(self,base_url,route,method,body,headers,timeout,admin)
        def seed(self):
            boot,env=super().seed();target=self.project/'ktx.yaml';mode=target.stat().st_mode&0o7777
            self.normalizer=self.tag+'-yaml-preflight'
            try:
                normalized,proof=seed_normalizer_result(fx.run(seed_normalizer_command(self.image,self.normalizer),target.read_text(),timeout=20))
                if fx.CONN not in proof.get('connectionIds',[]):raise AssertionError('required synthetic seed connection missing')
                target.write_text(normalized);os.chmod(target,mode)
                proof.update(fileModeBefore=mode,fileModeAfter=target.stat().st_mode&0o7777)
                if proof['fileModeBefore']!=proof['fileModeAfter']:raise AssertionError('seed file mode changed')
                self.save('seed-normalization-proof',proof)
            finally:
                removed=subprocess.run(['docker','rm','-fv',self.normalizer],capture_output=True,text=True,timeout=5)
                if removed.returncode and 'no such' not in removed.stderr.lower():
                    raise AssertionError('owned seed normalizer cleanup did not finish')
            return boot,env
    rig=Rig(args.image,out/'candidate','sc11-direct');pool=concurrent.futures.ThreadPoolExecutor(max_workers=3);futures=[];observed_futures={}
    result={'driverRevision':'v3-canonical-seed-and-failure-evidence','status':'RUNNING','startedAt':fx.now(),'image':args.image,'scope':'SC11 real existing direct CLI fallback; synthetic test topology only, not new deployment support','driverSha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'bootstrapSha256':hashlib.sha256(BOOTSTRAP.encode()).hexdigest(),'sqlOracleSha256':hashlib.sha256(reference_path.read_bytes()).hexdigest(),'cases':{},'defaultProductBudget':{'reloadTotalMs':60000,'drainMs':20000,'startupCombinedMs':20000},'tighterFaultProfileMs':args.fault_timeout_ms}
    lock=threading.Lock()
    def save(): (out/'summary.json').write_text(fx.scrub(json.dumps(result,ensure_ascii=False,indent=2))+'\n')
    def event(kind,**data):
        row={'kind':kind,'at':fx.now(),'monotonic':time.monotonic(),**data}
        with lock:
            with (out/'events.jsonl').open('a') as f:f.write(fx.scrub(json.dumps(row,ensure_ascii=False))+'\n')
        return row
    def interrupt(signum,_):raise InterruptedError('SC11 overall/signal '+str(signum))
    prior={s:signal.signal(s,interrupt) for s in [signal.SIGALRM,signal.SIGINT,signal.SIGTERM]};signal.setitimer(signal.ITIMER_REAL,args.overall_seconds)
    def logs():
        r=subprocess.run(['docker','logs','--timestamps',rig.app],capture_output=True,text=True,timeout=8);return fx.scrub(r.stdout+r.stderr)
    def owners():
        found=[]
        for line in logs().splitlines():
            if '[lucy-reload] ' not in line:continue
            try:
                item,end=json.JSONDecoder().raw_decode(line.split('[lucy-reload] ',1)[1])
                if item.get('event') in ['acquire','release']:found.append(item)
            except (ValueError,TypeError):pass
        return found
    def cli_events():
        raw=rig.exec('cat','/tmp/sc11/cli-events.jsonl',timeout=5)
        return [json.loads(line) for line in raw.splitlines() if line.strip()]
    def facts():return json.loads(rig.exec('python3','-c',LISTENER_FACTS,timeout=5))
    def query_rows(session):return rig.audit("SELECT id,request_id,outcome,user_id,lucy_session_id FROM access_log WHERE user_id='uat_zb_a' AND lucy_session_id="+repr(session)+" AND tool='lucy_query' ORDER BY id")
    def actual_queries(since):
        sql="SELECT JSON_OBJECT('at',CAST(event_time AS CHAR),'user',user_host,'sql',CONVERT(argument USING utf8mb4),'rawArgument',argument) FROM mysql.general_log WHERE command_type='Query' AND user_host LIKE 'lucy[lucy]%' AND event_time >= '"+since+"' ORDER BY event_time;"
        return reference.decode_query_log_rows(rig.sql(sql),fx.SOURCE)
    def wait_for(name,probe,predicate,seconds,operation=None):
        deadline=time.monotonic()+seconds;last=None
        while time.monotonic()<deadline:
            last=probe()
            if predicate(last):event('witness',name=name,value=last);return last
            failed=completed_save_failure(operation)
            if failed is not None:
                rig.save(name+'-failed-save',failed)
                error=failed.get('body',{}).get('error',{})
                code=error.get('code') if isinstance(error,dict) else None
                raise AssertionError('%s: automatic save already ended HTTP%s %s before required owner witness; reload phase NOT OBSERVED'%(name,failed.get('httpStatus'),code))
            time.sleep(.1)
        raise AssertionError(name+' witness not observed; '+fx.scrub(str(last))[:500])
    def loaded(name):
        value=json.loads(fx.run(ts_exec_command(rig.app,VERIFY_LOADED,fx.CONN),timeout=15));rig.save(name,value)
        fx.require(value.get('state')=='verified','real native KTX connection-level verification failed');return value
    def launch_direct(label,timeout_ms=None):
        # This is an explicitly owned fixture replacement, never the user's demo.
        fx.run(['docker','stop','-t','45',rig.app],timeout=55);fx.run(['docker','rm','-fv',rig.app],timeout=15)
        bootstrap=rig.private/'sc11-bootstrap.cjs';bootstrap.write_text(BOOTSTRAP);os.chmod(bootstrap,0o644)
        command=['docker','run','-d','--name',rig.app,'--network',rig.network,'--cpus','2','--memory','2g','-p','127.0.0.1::5174','-p','127.0.0.1::7879','-v',rig.data_volume+':/data/lucy','-v',str(bootstrap)+':/sc11-bootstrap.cjs:ro','--entrypoint','node']
        env=['KTX_PROJECT_ROOT=/data/lucy','LUCY_CONTENT_ROOT=/data/lucy/config','LUCY_DEPLOYMENT_MODE=development','LUCY_WEBUI_AUTH=required','LUCY_WEBUI_TEST_PROFILE=1','LUCY_WEBUI_COOKIE_SECURE=0','LUCY_UPSTREAM_FORCED_PREDICATE_PROVEN=true','LUCY_QUESTION_BUDGET=on','LUCY_KTX_MCP_RELOAD=1','LUCY_PROXY_UPSTREAM_HOST=127.0.0.1','LUCY_PROXY_UPSTREAM_PORT=7878','LUCY_WEBUI_HOST=0.0.0.0','LUCY_WEBUI_PORT=5174','LUCY_PROXY_HOST=0.0.0.0','LUCY_PROXY_PORT=7879','POSTHOG_DISABLED=1']
        if timeout_ms is not None:env.append('LUCY_KTX_RELOAD_TIMEOUT_MS='+str(timeout_ms))
        for setting in env:command+=['-e',setting]
        fx.run(command+[args.image,'/sc11-bootstrap.cjs'],timeout=25);rig.ready()
        login=rig.request(rig.web,'/api/auth/login','POST',{'adminId':'uat_owner','password':rig.password},timeout=15)
        fx.require(login['httpStatus']==200,'same-volume original administrator login failed')
        observed=facts();fx.require(not observed['capabilityExists'],'direct fixture accidentally retained supervisor capability');listener_identity(observed)
        boot=json.loads(rig.exec('cat','/tmp/sc11/bootstrap-facts.json',timeout=5));fx.require(boot['initialCliExitCode']==0 and boot['initialCliStarted'],'native daemon bootstrap failed');fx.require(boot['node'].startswith('v22.'),'fixture is not the frozen Node22 runtime')
        rig.save(label+'-bootstrap',{'facts':boot,'listener':observed,'appContainer':fx.run(['docker','inspect',rig.app,'--format','{{.Id}}']),'runtimeImage':fx.run(['docker','inspect',rig.app,'--format','{{.Image}}']),'actualEntrypoint':fx.run(['docker','inspect',rig.app,'--format','{{json .Config.Entrypoint}} {{json .Config.Cmd}}']),'productSourceSha256':rig.exec('sha256sum','/app/webui/server/ktx-mcp-reload.ts','/app/webui/server/admin/mcp-runtime-reload.ts','/app/webui/server/runtime/mcp-process-work.ts','/app/webui/server/security/response-commit.ts','/app/webui/server/proxy/mcp-proxy.ts','/app/scripts/runtime/docker-entrypoint.sh',timeout=5),'configuredTotalMs':timeout_ms or 60000})
        preflight=json.loads(fx.run(ts_exec_command(rig.app,TS_PREFLIGHT),timeout=10));rig.save(label+'-tsx-preflight',preflight)
        fx.require(preflight.get('cwd')=='/app/webui' and str(preflight.get('tsx','')).startswith('file:'),'native TS loader cwd/resolve preflight failed')
        loaded(label+'-native-config-proof')
        target=json.loads(fx.run(ts_exec_command(rig.app,CHECK_SAVE_TARGET,fx.CONN,fx.SCHEMA+'.'+fx.SOURCE),timeout=15))
        rig.save(label+'-pure-save-target-preflight',target)
        fx.require(target.get('connectionExists') is True and target.get('purePatchParses') is True
                   and target.get('allValuesPreserved') is True and target.get('written') is False,
                   'actual enabled-tables pure patch preflight failed')
    def auto_save(label):
        event('automatic-save-start',case=label)
        r=rig.request(rig.web,'/api/connections/'+fx.CONN+'/enabled-tables','PUT',{'enabledTables':[fx.SCHEMA+'.'+fx.SOURCE],'dryRun':False},timeout=70)
        event('automatic-save-end',case=label,receipt=r);rig.save(label+'-automatic-save',r);return r
    def recovery(label,session):
        init=rig.call(label+'-init',method='initialize',session=session);tools=rig.call(label+'-tools',method='tools/list',session=session)
        fx.require(fx.successful(init) and fx.successful(tools),'same Token protocol recovery failed')
        query=rig.query(label+'-query',session=session);budget=rig.snapshot(session);rows=query_rows(session)
        fx.require(budget and budget['calls']==1 and budget['attempts']==1,'rejected/recovered original problem has wrong persisted budget')
        fx.require(len(rows)==1 and rows[0]['outcome']=='ok','original rejected session did not have exactly one successful explicit query')
        return {'initialize':init,'toolsList':tools,'query':query,'budget':budget,'queryAudit':rows}
    def inflight_case(label,sleep_seconds,success,profile_ms=60000):
        case={'profileTotalMs':profile_ms,'sleepSeconds':sleep_seconds,'expectedSaveSuccess':success};result['cases'][label]=case;save()
        rig.sql('RENAME TABLE uat.'+fx.SOURCE+' TO uat.sc11_original; CREATE VIEW uat.'+fx.SOURCE+' AS SELECT order_id,tenant,amount+IF(order_id=1,SLEEP('+str(sleep_seconds)+'),0) AS amount FROM uat.sc11_original;')
        since=rig.sql('SELECT NOW(6);').strip();session='sc11-'+label+'-rejected';old_session='sc11-'+label+'-old'
        before_cli=cli_events();before_pid=facts();before_budget=rig.snapshot(session);fx.require(before_budget is None,'fresh problem budget is not absent')
        old=pool.submit(lambda:rig.query(label+'-old-query',session=old_session));futures.append(old)
        observed_futures[label+':old-query']=old
        wait_for(label+'-actual-mysql-sleep',lambda:rig.sql("SELECT COUNT(*) FROM information_schema.PROCESSLIST WHERE STATE='User sleep' AND USER='lucy';"),lambda n:int(n)>0,10)
        prior_owners={o.get('requestId') for o in owners() if o.get('event')=='acquire'}
        saving=pool.submit(auto_save,label);futures.append(saving)
        observed_futures[label+':automatic-save']=saving
        owner=wait_for(label+'-actual-cli-owner',owners,lambda rows:any(r.get('event')=='acquire' and r.get('requestId') not in prior_owners for r in rows),8,operation=saving)
        owner=[r for r in owner if r.get('event')=='acquire' and r.get('requestId') not in prior_owners][-1]
        fx.require(owner['requestId'].startswith('cli-'),'automatic no-capability save did not use existing CLI owner')
        refused=rig.call(label+'-refused-query','lucy_query',{'connectionId':fx.CONN,'measures':[fx.SOURCE+'.order_count',fx.SOURCE+'.amount_sum']},session=session);assert_refusal(refused,owner)
        after_budget=rig.snapshot(session);rows=query_rows(session);fx.require(after_budget is None and not rows,'refused RPC consumed budget or executed audit row')
        running_sql=actual_queries(since);reference.require_business_count(running_sql,1,label+' refusal zero additional SQL')
        case.update(owner=owner,refusal=refused,budgetBefore=before_budget,budgetAfter=after_budget,refusedQueryAudit=rows,blockedSql=running_sql)
        reply=saving.result(timeout=72);case['automaticSave']=reply;after_pid=facts();after_cli=cli_events()
        if success:
            assert_auto_saved(reply);case['oldQuery']=old.result(timeout=15);assert_actual_cli_restart(before_cli,after_cli,before_pid,after_pid);case['nativeLoadedProof']=loaded(label+'-native-loaded')
        else:
            assert_auto_failed(reply);fx.require(not old.done(),'old query already ended before declared timeout witness');assert_no_cli_effect(before_cli,after_cli,before_pid,after_pid)
            case['oldQuery']=old.result(timeout=sleep_seconds+10)
        case.update(cliBefore=before_cli,cliAfter=after_cli,listenerBefore=before_pid,listenerAfter=after_pid)
        rig.sql('DROP VIEW uat.'+fx.SOURCE+'; RENAME TABLE uat.sc11_original TO uat.'+fx.SOURCE+';')
        case['sameTokenSameProblemRecovery']=recovery(label+'-recovery',session)
        final_sql=actual_queries(since);reference.require_business_count(final_sql,2,label+' old plus explicit recovery');case['finalSql']=final_sql
        lease=wait_for(label+'-owner-release',owners,lambda rows:any(o.get('event')=='release' and o.get('requestId')==owner['requestId'] for o in rows),5)
        release=[o for o in lease if o.get('event')=='release' and o.get('requestId')==owner['requestId']][-1];case['ownerRelease']=release
        if profile_ms==60000:fx.require(stamp(release['releasedAt'])<=owner['deadlineAt'],'normal default-budget CLI owner exceeded60s')
        else:case['tightProfileIsNotDefault60sProof']=True
        case['verdict']='SCOPED PASS';save()
    try:
        save();rig.start();rig.save('standard-initialized',rig.mcp_check('standard-before-direct'))
        launch_direct('default')
        rig.sql("SET GLOBAL log_output='TABLE'; SET GLOBAL general_log=ON;")
        before=facts();commands=cli_events();manual=rig.request(rig.web,'/api/admin/mcp-runtime/reload','POST',{'connectionId':fx.CONN,'reason':'SC11 explicit endpoint unsupported'},timeout=10)
        rig.save('direct-manual-unsupported',manual);fx.require(manual['httpStatus']==200 and manual['body'].get('data',{}).get('reloadStatus')=='unsupported','explicit API did not preserve unsupported contract')
        assert_no_cli_effect(commands,cli_events(),before,facts());result['cases']['explicitUnsupported']={'verdict':'SCOPED PASS','receipt':manual,'listener':before,'cliBefore':commands,'cliAfter':cli_events()};save()
        inflight_case('default-short10',10,True)
        inflight_case('default-long25',25,False)
        rig.save('default-native-log',logs())
        launch_direct('tight-fault',args.fault_timeout_ms)
        inflight_case('tight-deadline',max(10,args.fault_timeout_ms/1000+5),False,args.fault_timeout_ms)
        # An explicitly fault-injected private capability advertises a live
        # process, but there is deliberately NO consumer. It is not a supervisor mock success.
        before=facts();commands=cli_events();cap={'protocol':'lucy-ktx-reload/1','supervisorPid':1,'startedAt':fx.now(),'heartbeatAt':fx.now(),'state':'idle','currentRequestId':''}
        rig.write('.ktx-ui/ktx-reload.capability',json.dumps(cap));reply=auto_save('capability-no-consumer');assert_auto_failed(reply)
        assert_no_cli_effect(commands,cli_events(),before,facts());result['cases']['capabilityFailureNoFallback']={'verdict':'SCOPED PASS','profileTotalMs':args.fault_timeout_ms,'receipt':reply,'capabilityFault':cap,'cliBefore':commands,'cliAfter':cli_events(),'listenerBefore':before,'listenerAfter':facts(),'scope':'private channel no-consumer failure; not full startup failure/default60s proof'};save()
        result['status']='SCOPED PASS WITH GAP';result['uncovered']=['default60s exact failure deadline','direct CLI startup failure/stop stuck/kernel IO matrix','arbitrary original transport session preservation','full SC11/F61/F62/F63/R-CAV','30min same-candidate soak (separate owner/run)']
    except BaseException as error:result.update(status='FAIL',error=fx.scrub(str(error)),errorType=type(error).__name__)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        deadline=time.monotonic()+60
        result['beforeCleanupFutureStates']={name:future_state(future) for name,future in observed_futures.items()}
        for name,probe in [('final-cli-events',cli_events),('final-listener',facts)]:
            try:rig.save(name,probe())
            except Exception as error:result.setdefault('finalEvidenceErrors',{})[name]=fx.scrub(str(error))
        try:rig.save('final-direct-native-log',logs())
        except Exception as error:result['logError']=fx.scrub(str(error))
        cleanup={}
        for command in [['docker','rm','-fv',getattr(rig,'normalizer',rig.tag+'-yaml-preflight')],['docker','rm','-fv',rig.app],['docker','rm','-fv',rig.db],['docker','network','rm',rig.network],['docker','volume','rm',rig.data_volume]]:
            try:
                r=subprocess.run(command,capture_output=True,text=True,timeout=max(.1,min(12,deadline-time.monotonic())));cleanup[' '.join(command[1:])]=r.returncode==0 or 'no such' in r.stderr.lower()
            except Exception:cleanup[' '.join(command[1:])]=False
        fx.shutil.rmtree(rig.private,ignore_errors=True);cleanup['privateRemoved']=not rig.private.exists();result['cleanup']=cleanup
        result['afterCleanupFutureStates']={name:future_state(future) for name,future in observed_futures.items()}
        for name,state in result['afterCleanupFutureStates'].items():
            if result['beforeCleanupFutureStates'][name]['state']=='IN_FLIGHT':
                state['failureAttribution']='not established before fixture cleanup; do not infer product truncation'
        if not all(cleanup.values()):result['status']='FAIL'
        pool.shutdown(wait=False,cancel_futures=True);result['finishedAt']=fx.now();save()
        for sig,handler in prior.items():signal.signal(sig,handler)
    print(fx.scrub(json.dumps({'status':result['status'],'error':result.get('error'),'cleanup':result.get('cleanup')},indent=2)),flush=True)
    return int(result['status']=='FAIL')
if __name__=='__main__':raise SystemExit(main())
