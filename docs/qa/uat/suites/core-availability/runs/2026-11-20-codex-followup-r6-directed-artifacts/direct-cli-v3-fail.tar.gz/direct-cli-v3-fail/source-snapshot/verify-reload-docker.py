#!/usr/bin/env python3
"""Scoped real KTX reload regression. Synthetic own Docker/MySQL only; no product patches."""
import argparse, base64, concurrent.futures, datetime, hashlib, importlib.util, json, pathlib, signal, subprocess, threading, time

WATCH=r'''
import ctypes,json,os,pathlib,struct,time
root=pathlib.Path('/tmp/uat-ca06-watch');root.mkdir(exist_ok=True)
libc=ctypes.CDLL(None,use_errno=True);fd=libc.inotify_init1(os.O_NONBLOCK)
if fd<0:raise OSError(ctypes.get_errno(),'inotify_init1')
wd=libc.inotify_add_watch(fd,b'/data/lucy/.ktx-ui',0x100|0x80|0x2|0x200|0x40|0x8)
if wd<0:raise OSError(ctypes.get_errno(),'inotify_add_watch')
(root/'ready').write_text('kernel inotify watch active')
with (root/'events.jsonl').open('w') as f:
 while not (root/'stop').exists():
  try:chunk=os.read(fd,65536)
  except BlockingIOError:time.sleep(.02);continue
  offset=0
  while offset+16<=len(chunk):
   watch,mask,cookie,length=struct.unpack_from('iIII',chunk,offset);offset+=16
   name=chunk[offset:offset+length].rstrip(b'\0').decode();offset+=length
   if name.startswith('ktx-reload.request'):
    f.write(json.dumps({'at':time.time(),'mask':mask,'name':name,'cookie':cookie})+'\n');f.flush()
os.close(fd);(root/'done').write_text('watch process closed')
'''

PID_FACTS=r'''
import pathlib,json,time,hashlib
root=pathlib.Path('/data/lucy/.ktx-ui');pidfile=root/'ktx.pid'
r={'at':time.time(),'ktxPid':pidfile.read_text().strip() if pidfile.exists() else None}
if r['ktxPid']:
 try:r['startTicks']=(pathlib.Path('/proc')/r['ktxPid']/'stat').read_text().rsplit(')',1)[1].split()[19]
 except OSError:r['startTicks']=None
for name in ['ktx-reload.request','ktx-reload.result']:
 p=root/name;r[name]={'exists':p.exists(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None}
print(json.dumps(r))
'''

def decode_sql_payload(value):
    if not isinstance(value,str):raise ValueError('MySQL general_log SQL payload is not text')
    if not value.startswith('base64:type'):
        return value,'utf8mb4-text'
    prefix,payload=value.split(':',2)[1:]
    if not prefix.startswith('type') or not prefix[4:].isdigit():raise ValueError('unknown MySQL binary JSON encoding')
    # mysql -B can quote line breaks as literal backslash-n in native JSON's
    # base64 representation. Preserve the raw payload before normalizing it.
    payload=''.join(payload.replace('\\n','').replace('\\r','').split())
    try:return base64.b64decode(payload,validate=True).decode('utf8'),'mysql-binary-json-decoded'
    except (ValueError,UnicodeDecodeError) as error:raise ValueError('invalid MySQL binary JSON SQL payload') from error


def decode_query_log_rows(raw,source_name):
    rows=[]
    for line in raw.splitlines():
        if not line.strip():continue
        record=json.loads(line);text,encoding=decode_sql_payload(record['sql'])
        rows.append({**record,'rawSql':record['sql'],'sql':text,'sqlEncoding':encoding})
    business=[r for r in rows if source_name in r['sql'] and 'COUNT(DISTINCT' in r['sql'].upper() and 'SUM(' in r['sql'].upper()]
    return {'allLucyQueryRows':rows,'businessQueries':business,'businessQueryCount':len(business)}


def require_business_count(facts,expected,phase):
    actual=facts['businessQueryCount']
    if actual!=expected:
        raise AssertionError('%s: actual business SQL execution count=%d; expected=%d. Inspect raw/decoded query-log evidence before attributing the mismatch.'%(phase,actual,expected))


def main():
    p=argparse.ArgumentParser();p.add_argument('--context',required=True);p.add_argument('--image',required=True);p.add_argument('--out',required=True);p.add_argument('--overall-seconds',type=int,default=600);a=p.parse_args()
    context=pathlib.Path(a.context);target=context/'scripts/uat/readyz-diagnostic-repro.py';spec=importlib.util.spec_from_file_location('reload_base',target);base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);fx=base.fx
    out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True);fx.require(not(out/'summary.json').exists(),'choose fresh output')
    class Rig(base.Rig):
        def request(self,base_url,route,method='GET',body=None,headers=None,timeout=180,admin=True):return fx.Rig.request(self,base_url,route,method,body,headers,timeout,admin)
    rig=Rig(a.image,out/'candidate','reload-docker');records=[];write_lock=threading.Lock();stop=threading.Event();pool=concurrent.futures.ThreadPoolExecutor(max_workers=3);futures=[]
    result={'scope':'P1-69 SC-01/03/04 scoped real Docker default10s and25s in-flight; not full SC/UAT/production release','startedAt':fx.now(),'status':'RUNNING','image':a.image,'driverSha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'helperSha256':hashlib.sha256(target.read_bytes()).hexdigest(),'budgets':{'clientRpcSeconds':180,'reloadClientSeconds':65,'productDrainSeconds':20,'productReloadTotalSeconds':60},'cases':{}}
    def save(): (out/'summary.json').write_text(fx.scrub(json.dumps(result,ensure_ascii=False,indent=2))+'\n')
    def event(kind,**fields):
        record={'kind':kind,'at':fx.now(),'mono':time.monotonic(),**fields}
        with write_lock:
            records.append(record)
            with(out/'events.jsonl').open('a') as f:f.write(fx.scrub(json.dumps(record,ensure_ascii=False))+'\n')
        return record
    def interrupt(number,_):stop.set();raise InterruptedError('CA06 overall/signal interruption '+str(number))
    previous={s:signal.signal(s,interrupt) for s in [signal.SIGALRM,signal.SIGTERM,signal.SIGINT]};signal.setitimer(signal.ITIMER_REAL,a.overall_seconds)
    def logs():
        r=subprocess.run(['docker','logs','--timestamps',rig.app],capture_output=True,text=True,timeout=5);return fx.scrub(r.stdout+r.stderr)
    def owners(text):
        rows=[]
        for line in text.splitlines():
            if '[lucy-reload]' not in line:continue
            try:row,_=json.JSONDecoder().raw_decode(line.split('[lucy-reload]',1)[1].strip())
            except ValueError:continue
            if isinstance(row,dict):rows.append(row)
        return rows
    def pidfacts():return json.loads(rig.exec('python3','-c',PID_FACTS,timeout=5))
    def actual_queries(since):
        raw=rig.sql("SELECT JSON_OBJECT('at',CAST(event_time AS CHAR),'user',user_host,'sql',CONVERT(argument USING utf8mb4),'rawArgument',argument) FROM mysql.general_log WHERE command_type='Query' AND user_host LIKE 'lucy[lucy]%' AND event_time >= '"+since+"' ORDER BY event_time;")
        return decode_query_log_rows(raw,fx.SOURCE)
    def scope_rows(session):return rig.audit("SELECT id,request_id,outcome,generated_sql,user_id,lucy_session_id FROM access_log WHERE user_id='uat_zb_a' AND lucy_session_id="+repr(session)+" AND tool='lucy_query' ORDER BY id")
    def monitor():
        while not stop.is_set():
            try:event('pid-observation',facts=pidfacts())
            except Exception as e:event('pid-observation',error=fx.scrub(str(e)))
            stop.wait(.25)
    observer=None
    try:
        save();rig.start();rig.save('mcp-before',rig.mcp_check('before-reload'))
        rig.sql("SET GLOBAL log_output='TABLE'; SET GLOBAL general_log=ON;")
        fx.run(['docker','exec','-d',rig.app,'python3','-c',WATCH],timeout=10)
        ready=False
        for _ in range(30):
            # An actual marker confirms the kernel watch, not an empty command output.
            try:ready='active' in rig.exec('cat','/tmp/uat-ca06-watch/ready',timeout=5)
            except Exception:ready=False
            if ready:break
            time.sleep(.1)
        fx.require(ready,'inotify witness not ready');observer=threading.Thread(target=monitor,daemon=True);observer.start()
        for label,sleep_seconds,should_succeed in [('short10',10,True),('long25',25,False)]:
            case={'sleepSeconds':sleep_seconds,'expectedReloadSuccess':should_succeed};result['cases'][label]=case;save()
            rig.sql('RENAME TABLE uat.'+fx.SOURCE+' TO uat.uat_ca06_base; CREATE VIEW uat.'+fx.SOURCE+' AS SELECT order_id,tenant,amount+IF(order_id=1,SLEEP('+str(sleep_seconds)+'),0) AS amount FROM uat.uat_ca06_base;')
            since=rig.sql('SELECT NOW(6);').strip();case_start_epoch=time.time();before=pidfacts();case['pidBefore']=before
            old_session='ca06-'+label+'-old';new_session='ca06-'+label+'-new';before_budget=rig.snapshot(new_session);fx.require(before_budget is None,'new session unexpectedly has budget')
            def query_original():
                event('original-query-start',case=label,session=old_session)
                try:r=rig.query(label+'-original-query',session=old_session);event('original-query-end',case=label,ok=True,receipt=r);return r
                except Exception as e:event('original-query-end',case=label,ok=False,error=fx.scrub(str(e)));raise
            query=pool.submit(query_original);futures.append(query);sleeping=False
            for _ in range(80):
                rows=rig.sql("SELECT COUNT(*) FROM information_schema.PROCESSLIST WHERE STATE='User sleep' AND USER='lucy';")
                if rows.strip()!='0':sleeping=True;break
                if query.done():break
                time.sleep(.1)
            case['mysqlSleepWitness']={'observed':sleeping,'at':fx.now(),'count':rows};rig.save(label+'-mysql-sleep',case['mysqlSleepWitness']);fx.require(sleeping,'real MySQL User sleep never observed')
            previous_owners={x.get('requestId') for x in owners(logs()) if x.get('event')=='acquire'}
            def reload_request():
                event('reload-http-start',case=label)
                r=rig.request(rig.web,'/api/admin/mcp-runtime/reload','POST',{'connectionId':fx.CONN,'reason':'CA06 '+label+' actual admitted query'},timeout=65)
                event('reload-http-end',case=label,receipt=r);rig.save(label+'-reload-receipt',r);return r
            reloading=pool.submit(reload_request);futures.append(reloading);owner=None;owner_until=time.monotonic()+8
            while time.monotonic()<owner_until:
                rows=[x for x in owners(logs()) if x.get('event')=='acquire' and x.get('requestId') not in previous_owners]
                if rows:owner=rows[-1];break
                if reloading.done():break
                time.sleep(.1)
            fx.require(owner is not None,'actual owner acquire not witnessed');case['owner']=owner;rig.save(label+'-owner-acquired',owner)
            new=rig.call(label+'-new-rpc','lucy_query',{'connectionId':fx.CONN,'measures':[fx.SOURCE+'.order_count',fx.SOURCE+'.amount_sum']},session=new_session)
            rig.save(label+'-new-rpc',new);error=new['body'].get('error',{});fx.require(new['httpStatus']==503 and error.get('code')=='EXECUTION_RUNTIME_RELOADING','new RPC was not structured reload refusal')
            fx.require(error.get('requestId')==owner['requestId'],'refusal owner mismatch');case['newRefusal']=new
            after_budget=rig.snapshot(new_session);case['refusedBudgetBefore']=before_budget;case['refusedBudgetAfter']=after_budget;fx.require(after_budget is None,'refused RPC consumed budget')
            case['refusedAuditRows']=scope_rows(new_session);fx.require(not case['refusedAuditRows'],'refused RPC produced executed query audit')
            actual=actual_queries(since);rig.save(label+'-query-log-while-blocked',actual);require_business_count(actual,1,'during reload refusal')
            reply=reloading.result(timeout=66);case['reloadResponse']=reply;data=reply['body'].get('data',{});fx.require(data.get('reloadStatus')==('succeeded' if should_succeed else 'failed'),'unexpected reload terminal')
            fx.require(reply['elapsedMs']<=60000,'reload exceeded default product total deadline')
            current=pidfacts();case['pidAtReloadTerminal']=current
            if should_succeed:
                old=query.result(timeout=12);fx.require(current['ktxPid']!=before['ktxPid'],'successful reload did not switch KTX PID');case['oldQuery']=old
            else:
                fx.require(not query.done(),'long task finished before20s drain refusal; negative proof invalid')
                fx.require(current['ktxPid']==before['ktxPid'] and current.get('startTicks')==before.get('startTicks'),'drain timeout stopped/replaced real KTX')
                fx.require(current['ktx-reload.result']==before['ktx-reload.result'],'drain timeout consumed a supervisor request')
                fx.require(not current['ktx-reload.request']['exists'],'drain timeout left a pending destructive request')
                watch=rig.exec('cat','/tmp/uat-ca06-watch/events.jsonl',timeout=5);events=[json.loads(line) for line in watch.splitlines() if line.strip()];request_events=[r for r in events if r['at']>=case_start_epoch]
                rig.save(label+'-request-file-events',request_events);fx.require(not request_events,'drain timeout published/changed reload.request')
                case['oldQuery']=query.result(timeout=15)
            rig.sql('DROP VIEW uat.'+fx.SOURCE+'; RENAME TABLE uat.uat_ca06_base TO uat.'+fx.SOURCE+';')
            if not should_succeed:
                retry=rig.request(rig.web,'/api/admin/mcp-runtime/reload','POST',{'connectionId':fx.CONN,'reason':'CA06 original owner explicit retry after old query settled'},timeout=65);rig.save(label+'-explicit-retry',retry)
                fx.require(retry['body'].get('data',{}).get('reloadStatus')=='succeeded','same-owner-path explicit retry did not recover')
            initialized=rig.call(label+'-new-init',method='initialize',session=new_session);listed=rig.call(label+'-new-tools',method='tools/list',session=new_session)
            fx.require(fx.successful(initialized) and fx.successful(listed),'same Token protocol reconnection failed')
            recovery=rig.query(label+'-new-recovered',session=new_session);case['sameTokenRecovery']=recovery
            budget=rig.snapshot(new_session);case['recoveredBudget']=budget;fx.require(budget and budget['calls']==1 and budget['attempts']==1,'refusal/recovery charged wrong number of calls')
            case['finalQueryAudit']=scope_rows(new_session);fx.require(len(case['finalQueryAudit'])==1 and case['finalQueryAudit'][0]['outcome']=='ok','same-session recovery executed more than once')
            final=actual_queries(since);rig.save(label+'-actual-query-log-final',final);require_business_count(final,2,'old-query plus same-Token recovery')
            case['verdict']='SCOPED PASS';save()
        result['status']='SCOPED PASS WITH GAP';result['uncovered']=['full SC01 race100','SC02 disconnect/durable response edge matrix','SC05/06 CLI/supervisor late-consumption/default deadline faults','SC07 authorization tightening/two identities','SC08 three TERM phase races','SC09 startup/storage/digest failures','full SC10/11 mode matrix','formal FUP hour']
    except BaseException as e:
        result.update(status='FAIL',error=fx.scrub(str(e)),errorType=type(e).__name__)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0);stop.set()
        if observer:observer.join(timeout=6)
        try:
            rig.exec('touch','/tmp/uat-ca06-watch/stop',timeout=5)
            rig.save('reload-request-inotify',rig.exec('cat','/tmp/uat-ca06-watch/events.jsonl',timeout=5))
        except Exception as e:result['watchCollectionError']=fx.scrub(str(e))
        try:rig.save('final-container-log',logs())
        except Exception as e:result['logError']=fx.scrub(str(e))
        clean={};deadline=time.monotonic()+60
        for args in [['docker','rm','-fv',rig.app],['docker','rm','-fv',rig.db],['docker','network','rm',rig.network],['docker','volume','rm',rig.data_volume]]:
            try:
                response=subprocess.run(args,capture_output=True,text=True,timeout=max(.1,min(12,deadline-time.monotonic())));clean[' '.join(args[1:])]=response.returncode==0 or 'no such' in response.stderr.lower()
            except Exception as e:clean[' '.join(args[1:])]=False
        fx.shutil.rmtree(rig.private,ignore_errors=True);clean['privateRemoved']=not rig.private.exists();result['cleanup']=clean
        if not all(clean.values()):result['status']='FAIL'
        pool.shutdown(wait=False,cancel_futures=True);result['finishedAt']=fx.now();save()
        for sig,handler in previous.items():signal.signal(sig,handler)
    print(fx.scrub(json.dumps({'status':result['status'],'error':result.get('error'),'cleanup':result.get('cleanup')},indent=2)),flush=True)
    return int(result['status']=='FAIL')
if __name__=='__main__':raise SystemExit(main())
