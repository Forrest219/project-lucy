# directCLI v3 实际失败只读复核

状态：实际 FAIL 保留；原始回执/日志未改，资源已全清并返锁。此次复核没有运行 Docker、测试或修改源码。v4 仅为待授权夹具方案，不是已验证根因或 PASS。

## 实际时序与出口

所有时间 UTC，2026-11-20；东八区加 8 小时。

| 实际证据 | 事实 |
| --- | --- |
| default-bootstrap.json | AE0 镜像、Node v22.23.5；原生 CLI 启动 exit 0 / daemon started；原监听 PID 26、startTicks 7096681；capability 不存在；配置加载核验已通过。 |
| default-pure-save-target-preflight.json | 真实连接 uat-mysql 存在；同值 enabled-tables 纯 patch 可解析且结构/全部值保持；未写文件。不是 v2 的连接 404。 |
| summary.json / User sleep witness | 原查询实际 MySQL 已受理，12:16:18.108864 见证后才触发保存。 |
| final-direct-native-log.json | owner `cli-18e3ddbd-6073-4de3-9dde-bf13a946ca7e` 12:16:18.163 acquire，activeRpcCount=1，deadlineAt=1795177038162（Unix epoch ms，约 12:17:18.162）。 |
| summary.json / cases.default-short10.refusal | 新 RPC HTTP 503 EXECUTION_RUNTIME_RELOADING；requestId/deadlineAt 匹配，rejectedAt=1795176978278；预算前后均 null、拒绝 query audit=[]；general_log 只有原业务 SQL 1 次。 |
| default-short10-old-query.json | 原 10 秒查询 HTTP 200，11.660294 秒完成，4/100、totalRows=1，无 result.isError；在清理前已 FINISHED。没有证据支持旧查询被本次重载截断。 |
| final-cli-events.json | 初始 start 12:16:02.093447；本次 stop 12:16:28.057366；没有本次 restart/start。 |
| final-direct-native-log.json | 同 owner 12:16:38.058 release，activeRpcCount=0；错误 detail 只有 `Project: /data/lucy`。 |
| default-short10-automatic-save.json | 保存 HTTP 503、19.934382 秒；ok=false、EXECUTION_RUNTIME_NOT_LOADED、配置已保存但执行层未加载。不是 owner 8 秒观测窗口超时。 |
| final-listener.json | 12:16:38.322197，7878 无 listener，capability 仍不存在。只能证明最终 socket 消失，不能单独证明原 PID 已消亡/已回收。 |
| summary cleanup | normalizer/app/db/network/volume/private 全部 true；后续 default25/tight1500/capability-failure 未执行，同身份恢复/成功 SQL2 未验证。显式管理员 API unsupported 独立 case 已 SCOPED PASS。 |

拒绝响应及 SQL 事实在 summary.json 中自足；没有重新读取审计数据库或大 raw。

## 可以下的结论

保存确实进入无 supervisor 的真实 CLI 路径，等原在途完成后调用 stop，但 stop 未取得正常成功，因此没有继续 start 和加载校验。当前场景的可用性出口没有完成，SC11 不能签 PASS。原请求受保、新拒绝零预算/零新增业务 SQL 是已取得的局部证据，不能替代恢复验收。

冻结 `ktx-mcp-reload.ts` 的 stop 调用是 `runKtx(..., remainingReloadMs(deadlineAt, 10_000))`。runKtx 使用 execFile timeout 和 SIGKILL；非数值 error.code 映射 exitCode=1，stop 非 0 即返回 failed，不执行 start。本次 stop→release 约 10.001 秒，尚未触及 owner 总 60 秒截止，也不是 20 秒排空超时。现有透明 shim 仅记录调用种类/时间/PID 后 exec 真 CLI，未记录 callback error.signal/killed/exit；因而不能仅凭耗时断言已捕获原生 CLI timeout/SIGKILL，更不能断言其内部等待实现。

## PID 1 回收假说：有窄依据，缺最终实证

`verify-direct-cli-v3.py` 的 BOOTSTRAP（22–43 行）以 Node 启动真实 daemon CLI，再只对子进程 app 注册 exit/signal 处理。launch_direct（263 行）使用 `docker run ... --entrypoint node IMAGE /sc11-bootstrap.cjs`，没有 `--init`。这让 bootstrap Node 成为该测试容器 PID 1，源码中没有通用 adopted-orphan 回收器。原监听进程为 PID 26，但本次留存的 LISTENER_FACTS 只查持有监听 socket 的 PID；stop 之后无 socket 的僵尸进程会被过滤，因此现有证据不能证实或排除 PID26=Z。

原 daemon 脱离启动 CLI 后若被收养且未回收，原生 stop 若使用进程存在性等待，便可出现 socket 已关、进程标识仍可见、CLI 等待到 10 秒的现象。这与此次时序相容。我们没有保存原生 stop 源码内部循环或 stop 后 PID26 stat，不能把该推论登记为已证产品根因/已证夹具根因。

## 最窄新 v4 夹具方案（尚未实施）

1. 仅在 launch_direct 创建替换 app 容器的 docker run 参数加入 `--init`，由 Docker 的标准微型 init 回收被收养进程。保留 entrypoint Node、原 daemon CLI、应用 cwd /app/webui、同卷配置、同 Token、无 Lucy supervisor/capability/request consumer。normalizer 不运行 daemon，不必改变。
2. 增加安全进程拓扑取证：初始记录 PID1 的 comm、bootstrap/app/daemon 的 pid/ppid/state/startTicks；stop 失败或终态前记录原 daemon 的同组字段/absent、socket事实。禁止 cmdline/environ（包含 Token 的风险），不打印凭据/问句/DSN。检查 HostConfig.Init=true，而非把 init 误称 supervisor。
3. 全部原产品预算保持 20/60/阶段 stop10/startReady20，owner 观测8秒、fault1500和overall900不变；不扩执行时间、不把 stop 失败改成功，不替换/模拟 native CLI 回执。
4. 先做可选的 <=10 秒、无 MySQL/无产品启动资格探针：同 AE0、Node PID1 与 --init 各建立一个短生命周期孤儿，记录已知 PID 的 stat/PPid 对照并清理，只证明拓扑是否回收；不能代签真实 KTX UAT。须 M 授唯一资源锁后才运行。
5. 静态/offline 反例应锁定 --init 仅替换容器、原预算和原生 CLI argv 未变，以及进程取证不含 cmdline/environ。A/M 复核新 hash 后另行授权真实 v4 新 out；v2/v3 FAIL 全保留，失败后不得自动修/重跑。

当前不主张生产修复。若加 init 仍在原 stop10 内失败，保留真实 native stderr/状态及进程事实再判断，不能靠放大预算或接纳 503 使判定通过。

## 后续资格探针（不覆盖上述 v3 事实）

M 另授唯一短锁后，已执行 AE0 两容器纯 orphan 探针，不启动 Lucy/KTX/MySQL。总 1.066864 秒：无 init 时 PID1=node，原 orphan pid20/startTicks7126759 从 R/PPid1 变为 Z/PPid1；有 init 时 PID1=docker-init、bootstrap pid7/PPid1，原 orphan pid21/startTicks7126764 先 R/PPid1 后 /proc absent。此为拓扑资格化的实际证据，仍不是旧 v3 PID26 的终态证据。

原 probe wrapper exit1 必须保留：清理判断写死大写 `No such object`，实际 Docker 返回小写 `error: no such object`，导致 cleanupConfirmed=false。两次 rm -fv 均 exit0、后续精确 inspect 均 exit1 且明确不存在，资源确已清理。原 result.json 未改；独立 cleanup-interpretation-addendum.json 记录纠正。没有重跑探针来覆盖失败。

v4 已按授权仅补夹具 --init、安全 process 事实和离线反例；20/20 offline+compile PASS，actual SC11 NOT RUN。所有资源锁已返 M。
