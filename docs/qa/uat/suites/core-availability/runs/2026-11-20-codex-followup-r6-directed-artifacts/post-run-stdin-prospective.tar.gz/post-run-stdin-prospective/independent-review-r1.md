# CA01 prospective stdin 候选：独立静态复核 r1

结论：**REQUEST CHANGES，2项P2；未见新增P1。** 仅针对首次送审候选core `a4b0389b…`、test `f2a17314…`、diff `9e4a3fda…`。A收到具名问题后已在此私有候选目录修订，后续hash不能自动沿用本审查结论；需新freeze后复核关闭。未compile、未跑测试/Docker/SQL，canonical、AE0和旧结果未改。

## P2-01：成功exec后的JSON解析失败丢失唯一ticket

触发：`Rig.audit_facts` 对 `self.exec(...)` 返回值执行 `json.loads`；远端进程exit0但stdout非JSON。此时Rig.exec已持久化hostOutcome=success并返回，JSONDecodeError发生在它的try之外。ArrivalLedger只有RemoteExecError才附remoteExec，所以该audit-progress-n错误终态仍没有ticket。新测试仅覆盖run_owned_process抛错，没有覆盖成功exec/后置parse失败。

影响：失败仍是失败，未洗白，但本补丁承诺的audit逻辑请求到远端ticket在错误路径的唯一映射不完整，后续仍无法从terminal直接关联确切远端工作。

最小修复：audit解析失败只在可证明本次调用确实生成了新binding、logicalRequestId一致、ticket非调用前旧值、hostOutcome=success时附同ticket；保留remote exec成功与logical parse_error的不同真值。缺本次binding不能从thread-local旧值猜关联。新增非JSON→原scheduler错误terminal具同ticket，以及stale-binding拒绝负例。不能把解析失败变成功或从分母移除。

## P2-02：新增绑定文件I/O跨原绝对截止后仍可启动

触发：Rig.exec先读取既有operation_deadline、计算timeout，随后新增folder.mkdir/path.write_text。若这段有限慢I/O跨过原operation绝对截止，launch前没有重核，仍把旧timeout全部传远端并开始host timeout+4。

影响：remote guard内部“输入+执行同deadline”本身正确，但新增取证I/O位于原operation剩余预算handoff之外；原已到期工作仍可启动，不能以timeout数字未变声称原预算没有扩张。

最小修复：真正launch前重新核原已存在的绝对operation截止/固定本次额度，只取更紧剩余，不从I/O完成时重开原秒数。到期不启动Docker/child；已有本地计划binding必须真实标not_launched，不能假称远端ticket文件或group已存在。补有限延迟的绑定持久化跨截止、run_owned_process调用次数0的反例；不要添加新产品或全局预算。

## 其余主路径静态判断

- EXEC_GUARD在输入前建一次remote monotonic deadline；select+os.read而非BufferedReader readEOF，EOF前不spawn；完成输入后communicate只用同deadline剩余。None data不传docker -i、stdinExpected=false跳过输入，方向正确。
- 输入超时且p=None明确childStarted=false、无pid/groupTermination=null；不会用未启动的child伪造回收证明。真实子进程timeout/orphan沿旧group算法，exit23仍非成功。
- OWNED_GROUP_PROGRAM逐字文本hash对before38a和当前修订副本均为 `750a5d906315db7eb8b45ce82cb1f691713a0df0c359e28e63a777645ce66b86`；原2秒清理grace和PGID/parentReaped/groupAbsent逻辑未改。
- scheduler计划/到达/容量missed与自然分母算法未改；missed无远端ticket符合真实未启动。新metadata仅附证据，不得改变failure expected分类、性能门槛或产品接口。
- stdin内容未写入ticket/binding；只保存字节数、kind、关联ID。保留原scrub和args0窄字段，不能进一步记录完整argv/stdin/凭据。

## 验证与范围限制

首次送审10新草案tests/compile均NOT RUN；不能用静态合理性签红绿。后续须按M资源锁在保留before38a与新freeze下做真实stdin未EOF、partial、EOF后剩余不足、child真实失败和上述两个负例；原57项保留。旧guard先给EOF/必要时仅清测试自有PGID的finally方向合理，真实清理仍要证据。

本候选仅为可审阅后续修复，不是canonical或AE0来源。即便未来通过，也不能反推audit-progress-214的旧超时是stdin所致，不能补旧缺失ticket因果、改写r6 strict FAIL，或把新工具成功当旧功能/UAT PASS。
