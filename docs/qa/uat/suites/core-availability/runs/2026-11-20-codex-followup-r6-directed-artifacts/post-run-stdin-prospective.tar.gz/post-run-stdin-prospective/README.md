# CA-01 remote stdin + audit-ticket 静态修复候选

状态：**静态草案待 M/B review，编译／红绿／Docker 全部 NOT RUN**。仅此目录可评审副本，未改 canonical/worktree、07上下文、任何旧r6来源／结果，不追签旧FAIL。

## 两个已核工程问题与窄方案

1. 旧 EXEC_GUARD 在 communicate(timeout=seconds) 参数求值时先无界 readEOF，远端原seconds没有覆盖输入阶段。新guard一开始建立唯一monotonic deadline，通过 select + os.read等真实EOF，每次按同一剩余时间阻塞；输入完成后才启动child，communicate仅拿原截止剩余，不重置seconds。data=None调用docker exec不加-i，并传stdinExpected=false，guard完全不读wrapperstdin；需stdin仍-i并受原截止。输入阶段超时124明确childStarted=false/groupTermination=null/inputComplete=false，pid字段不存在，绝不伪造child已回收；complete只指无child的guard终态。

2. 旧 audit-progress logical requestId 与随机远端ticket无唯一映射。新Rig.exec在docker启动前写candidate/exec-bindings/<ticket>.json，含唯一logicalRequestId/ticket/remoteTicketPath与输入字节数和是否预期EOF，不存args内容/stdin/凭据。audit(n)明确传audit-progress-n，远端ticket同字段，成功terminal remoteExec带关联；错误RemoteExecError也在原scheduler request-terminal.remoteExec保留同关联，host绑定文件同时存错误终态。失败不计成功、不改原到达分母，missed不发起远端ticket。未启动docker的deadline拒绝不伪造ticket。

child真正启动后的timeout与orphan处理仍用原 OWNED_GROUP_PROGRAM，原真实PGID parentReaped+groupAbsent与独立2s cleanup grace不变，host原timeout+4封顶不扩大。输入收集放child启动前，故“child先退出但stdin仍开”不再能使一个未启动/无EOF任务假报已回收；输入timeout与执行timeout分相记录。

## 待资格化反例（仅源码）

14项新增草案：真实openstdin无EOF、partial输入无EOF且日志不含内容、child本会先退但EOF前不得启动、no-data即使wrapperstdin开也能结束、合法EOF字节透明/unique ticket、靠近截止EOF后sleep不能拿新完整seconds、child真实exit23不洗白；以及-i条件/启动前绑定、错误ticket与逻辑ID持久且无输入内容、scheduler失败terminal保留同一唯一绑定。真实guard测试的finally独立给旧red EOF使其现有child watchdog能完成，必要时仅杀测试自有PGID，避免红例泄漏。

现有57项测试原样保留；新14项尚未执行，不能宣称71通过。新测试与候选本身均尚未compile，不用语法错或mock缺接口冒充实际red。后续M给短窗口时先把相同新测试用于before38a源码的真实缺陷red，保存输出/实际进程清理，再对候选green。对应2依赖base182/helper291只是字节复制供离线导入，未编辑。

## Review 边界

请重点查：输入阶段与执行同绝对截止；select不通过BufferedReader引入第二阻塞；inputtimeout没有假group proof；已有子进程故障不洗白；host/remote ticket/同logical requestId在错误路径也可关联；没有input/secret输出；原性能/自然窗/分母/审计要求/产品预算不变。若批准并通过真实红绿，是否合回canonical、进入新candidate由M决定。本目录不是新正式入口，不声称修复了旧214超时根因；旧r6 ticket缺唯一绑定与stdin死等因果仍GAP。

C静态review已指出exec成功后的JSON parse失败也需关联；已在prospective草案修正：只有本次new ticket且logicalID匹配/hostOutcome=success才加logicalResult=parse_error并抛带同ticket错误，不把旧threadlocal当本次证据。新增nonJSON error terminal及stale binding负例，仍全部NOTRUN。

C第二项静态预算边界已窄修：binding落盘后、真正启动前重读并clamp既有operation_deadline；过期不调用run_owned_process，host绑定明确remoteLaunchAttempted=false/remoteTicketExistence=not_created_by_this_call，不能声称容器ticket已存在。未启动也有host逻辑请求失败记录；剩余变少则remote seconds与host既有+4同步收紧。新增跨截止不launch／剩余扣减不重置2草案负例。原a4b/f2a包存revision1，e56/d532包存revision2，当前revision3含两项CR修正，均未执行。
