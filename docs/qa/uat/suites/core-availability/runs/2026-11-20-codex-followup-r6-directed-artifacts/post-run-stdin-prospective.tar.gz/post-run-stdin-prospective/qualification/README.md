# remote stdin + audit ticket 离线资格结果

**QUALIFICATION PASS，canonical仍未合回，Docker/UAT NOT RUN。** M唯一短窗内实际执行，结束已立即返锁。

- 固定revision3 core c45a530d / test b88721e9；四Python文本builtin compile通过。
- 原38a在独立red副本运行5个真实输入/执行反例，7.685秒exit1：openEOF、partialEOF、child本会先退、no-data wrapper stdin仍开四例均实际超过1.5秒guard未退；near-deadlineEOF例原程序误返回0而非124。不是语法/缺导出伪红。red finally实际给EOF、等待其旧watchdog收尾，必要时仅回收测试自有PGID。
- 候选原57+新增14合计71：普通沙箱首次因原PGID核查需要/bin/ps而PermissionError，日志原样保留；授权require_escalated同源码重跑9.842秒71/71 PASS/exit0，没有代码修改绕失败。
- 新证据覆盖真实输入deadline（未启动child不伪造group proof）、EOF字节透明、剩余执行时间不重置、原child23错误不洗白、no-data不-i、本地预绑定与失败ticket关联、parse后置失败与stale binding拒绝、binding I/O耗时不能跨原operation budget再启动。
- 原真实fork/重定向/ignoreTERM子孙进程测试仍验证actual owned identity消失，remote groupAbsent/parentReaped不靠parent EOF；新正常/执行超时用同一真实proof，输入超时无child。全部测试fixture finally收尾，qualified green没有测试清理异常；未额外扫描全系统进程。

完整证据见result.json及compile/red/green/green-escalated。禁止据此修改旧r6的producer/independent结果，不能把旧214超时归因为已证EOF根因；旧ticket缺关联事实保留。是否合回canonical/进新候选仍由M决定。
