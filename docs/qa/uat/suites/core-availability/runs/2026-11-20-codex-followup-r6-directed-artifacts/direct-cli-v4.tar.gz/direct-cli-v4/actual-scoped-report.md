# SC11 directCLI v4 实际范围验收

结论：SCOPED PASS WITH GAP，实际 exit0。AE0 原冻结镜像/源未变，driver227dfe89、test51594、SQLoracle2f56 和 r6 base/helper/manifest 均在运行前后核验一致。2026-11-20 UTC 12:25:43.896–12:27:35.069；默认20/60、owner8和独立fault1500保持。actual-invocation.json记录driver PID1466、完整argv；requestedCwd为旧兼容路径，resolved/actualCwd为ROOT/.worktrees/core-availability-followup-20261120。

| 场景 | 实际证据与结论 |
| --- | --- |
| 无supervisor的显式管理员API | reloadStatus=unsupported；CLI调用/监听身份不变。SCOPED PASS。 |
| 默认预算10秒在途+自动保存 | save HTTP200/11.093s，written/runtimeAck/policyRuntimeAck/executionRuntimeAck为真；真实stop→start；原PID26/startTicks7157416在保存后/proc absent，新listener PID444/startTicks7160071；连接级加载核验通过。原查询HTTP200/4与100，同Token/原问题显式恢复成功。SCOPED PASS。 |
| 默认预算25秒在途 | 20.036s后save503 NOT_LOADED；owner20秒终结时activeRpc1，原查询仍在途；未调用新stop/start，原PID444/startTicks7160071仍stateS、同身份；原查询25.419s成功4/100，显式恢复成功。SCOPED PASS。 |
| fault1500更紧截止 | save503/1.536s，owner1.5秒终结时activeRpc1；未stop/start，原PID27/startTicks7163003保持S/同身份；原10秒查询11.760s成功4/100，显式恢复成功。仅更紧profile，不是默认60秒精确失败证明。 |
| 有capability但无真实consumer | 受控私有channel故障，save503/1.451s；CLI没有新增调用，PID27/startTicks保持；没有偷偷切CLI。仅该失败分支，不是全部supervisor/startup故障。 |

三个在途场景的新拒绝均为真实HTTP503 EXECUTION_RUNTIME_RELOADING，requestId/deadlineAt绑定同owner，server rejectedAt严格位于实际acquire/release闭区间。拒绝前后预算均不存在、拒绝query audit0、实际原SQL1；同Token/原问题显式恢复后calls=attempts=1、唯一有效query audit行、实际业务SQL总数2。没有自动重放。只读逐条重算保存于readonly-postrun-verification.json，未重跑负载。

两个direct实例均记录HostConfig.Init=true，PID1=docker-init；Node bootstrap为其子进程、app为bootstrap子进程、原生daemon为init收养进程。正常10秒重载的原daemon在/proc实际消失，证据超出仅换listenerPID；25秒与fault1500在停前失败时原daemon仍S/同startTicks。安全process证据不读取cmdline/environ。final-original-process.json是fault实例保持中的PID27，不应误用为正常重载PID26的终态。

所有owned normalizer/app/db/network/volume/private清理结果true，session41612结束后已立即返还资源锁。原v2/v3 FAIL和纯orphan probe原exit1保留，不重写；本轮支持--init夹具规范化有效，仍不能把旧v3未捕获的PID26终态写成已证Z。

剩余缺口：默认60秒精确失效；directCLI启动失败/stop卡住/内核IO完整矩阵；任意原transport session保持；完整SC11/F61/F62/F63/R-CAV。30分钟同候选长跑由M独立run和严格判定，本轮不能替它签PASS。结果不是全功能合同闭口、整套UAT PASS或可上线。
