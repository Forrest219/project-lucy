#!/usr/bin/env python3
"""Offline evidence-validator negatives; no Docker, no KTX UAT claims."""
import concurrent.futures, importlib.util, json, pathlib, subprocess, sys, unittest
sys.dont_write_bytecode=True
path=pathlib.Path(__file__).with_name('verify-direct-cli-v4.py')
spec=importlib.util.spec_from_file_location('sc11_direct',path);d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)


def facts(pid=10,ticks='123'):
    return {'listenerOwners':[{'pid':pid,'startTicks':ticks}]}


class DirectCliEvidenceRegressions(unittest.TestCase):
    def yaml_cwd(self):
        for base in [pathlib.Path.cwd(),*path.parents]:
            for folder in [base,base/'webui',base/'worktree/webui']:
                if (folder/'node_modules/yaml/package.json').is_file():return folder
        raise AssertionError('installed local yaml dependency missing; no install or Docker fallback')

    def normalized(self,value):
        result=subprocess.run(['node','-e',d.NORMALIZE_SEED],input=json.dumps(value),text=True,
                              capture_output=True,cwd=self.yaml_cwd(),timeout=5)
        self.assertEqual(result.returncode,0,result.stderr)
        return d.seed_normalizer_result(result.stdout)

    def test_normalization_preserves_all_values_and_types_but_proof_contains_no_secret_values(self):
        config={'connections':{'uat-mysql':{'driver':'mysql','host':'owned-db','port':3306,
                'password':'canary-secret\n: [quoted]','schemas':['uat'],'enabled_tables':['uat.source'],
                'readonly':True,'optional':None}},'storage':{'state':'sqlite'}}
        yaml,proof=self.normalized(config)
        self.assertTrue(yaml.startswith('connections:\n  uat-mysql:\n'))
        self.assertTrue(proof['allValuesEqual'])
        self.assertNotIn('canary-secret',json.dumps(proof))
        self.assertNotIn('owned-db',json.dumps(proof))
        self.assertNotIn('3306',json.dumps(proof))
        config['connections']['uat-mysql']['password']='a completely different secret'
        _,changed=self.normalized(config)
        self.assertEqual(proof['redactedStructureSha256Before'],changed['redactedStructureSha256Before'])

    def test_normalization_proof_cannot_omit_value_equality_or_stable_structure_hash(self):
        for proof in [{},{'allValuesEqual':False},{'allValuesEqual':True},
                      {'allValuesEqual':True,'redactedStructureSha256Before':'a'*64,'redactedStructureSha256After':'b'*64}]:
            with self.assertRaises(AssertionError):d.seed_normalizer_result(json.dumps({'yaml':'connections: {}\n','proof':proof}))

    def test_seed_normalizer_runs_only_owned_frozen_image_foreground_without_network(self):
        command=d.seed_normalizer_command('sha256:frozen','owned-yaml')
        self.assertEqual(command[:6],['docker','run','--rm','-i','--name','owned-yaml'])
        self.assertIn('--read-only',command)
        self.assertEqual(command[command.index('--network')+1],'none')
        self.assertEqual(command[command.index('--workdir')+1],'/app/webui')
        self.assertEqual(command[-3:],['sha256:frozen','-e',d.NORMALIZE_SEED])

    def test_completed_404_is_reported_before_any_owner_wait_timeout(self):
        failed=concurrent.futures.Future();receipt={'httpStatus':404,'body':{'ok':False,'error':{'code':'CONNECTION_NOT_FOUND'}}}
        failed.set_result(receipt)
        self.assertIs(d.completed_save_failure(failed),receipt)
        pending=concurrent.futures.Future()
        self.assertIsNone(d.completed_save_failure(pending))
        success=concurrent.futures.Future();success.set_result({'httpStatus':200,'body':{'ok':True}})
        self.assertIsNone(d.completed_save_failure(success))

    def test_failure_future_observation_does_not_wait_or_turn_cleanup_interruption_into_product_failure(self):
        pending=concurrent.futures.Future()
        self.assertEqual(d.future_state(pending),{'state':'IN_FLIGHT','cleanupMayAbort':True})
        pending.set_exception(ConnectionError('closed during fixture cleanup'))
        self.assertEqual(d.future_state(pending)['state'],'FAILED')

    def test_new_node_programs_compile_without_running_image_or_product(self):
        for source,mode in [(d.NORMALIZE_SEED,'commonjs'),(d.CHECK_SAVE_TARGET,'module')]:
            result=subprocess.run(['node','--check','--input-type='+mode],input=source,text=True,capture_output=True)
            self.assertEqual(result.returncode,0,result.stderr)

    def test_one_exact_real_listener_is_required(self):
        for sample in [{'listenerOwners':[]},{'listenerOwners':[{'pid':1,'startTicks':'2'},{'pid':3,'startTicks':'4'}]},{'listenerOwners':[{'pid':1}]}]:
            with self.assertRaises(AssertionError):d.listener_identity(sample)

    def test_unsupported_cannot_hide_stop_or_start(self):
        before=[{'operation':'start','atMs':1}]
        for extra in ['stop','start','other']:
            with self.assertRaises(AssertionError):d.assert_no_cli_effect(before,before+[{'operation':extra}],facts(),facts())

    def test_same_pid_with_different_start_ticks_is_not_noop(self):
        with self.assertRaises(AssertionError):d.assert_no_cli_effect([],[],facts(),facts(ticks='124'))

    def test_actual_reload_requires_stop_then_start_and_new_listener(self):
        before=[{'operation':'start','atMs':1}]
        for tail in [[],[{'operation':'start'}],[{'operation':'start'},{'operation':'stop'}],[{'operation':'stop'}]]:
            with self.assertRaises(AssertionError):d.assert_actual_cli_restart(before,before+tail,facts(),facts(11))
        with self.assertRaises(AssertionError):d.assert_actual_cli_restart(before,before+[{'operation':'stop'},{'operation':'start'}],facts(),facts())
        d.assert_actual_cli_restart(before,before+[{'operation':'stop'},{'operation':'start'}],facts(),facts(11))

    def refusal(self):
        owner={'requestId':'cli-actual-owner','deadlineAt':2000,'acquiredAt':'1970-01-01T00:00:01Z'}
        receipt={'httpStatus':503,'body':{'error':{'code':'EXECUTION_RUNTIME_RELOADING','requestId':'cli-actual-owner','deadlineAt':2000,'rejectedAt':1200}}}
        return receipt,owner

    def test_only_exact_owner_and_server_rejection_time_are_accepted(self):
        receipt,owner=self.refusal();d.assert_refusal(receipt,owner)
        for field,value in [('code','upstream_unavailable'),('requestId','other-owner'),('deadlineAt',3000),('rejectedAt',999),('rejectedAt',2001),('rejectedAt',None)]:
            receipt,owner=self.refusal();receipt['body']['error'][field]=value
            with self.assertRaises(AssertionError):d.assert_refusal(receipt,owner)

    def test_timeout_or_generic_unavailable_is_not_reload_refusal(self):
        receipt,owner=self.refusal();receipt['httpStatus']=504
        with self.assertRaises(AssertionError):d.assert_refusal(receipt,owner)

    def test_committed_and_policy_runtime_ack_are_required(self):
        response={'httpStatus':200,'body':{'ok':True,'data':{'written':True,'runtimeAck':True,'policyRuntimeAck':True}}}
        d.assert_auto_saved(response)
        for field in ['written','runtimeAck','policyRuntimeAck']:
            sample={'httpStatus':200,'body':{'ok':True,'data':dict(response['body']['data'])}};sample['body']['data'][field]=False
            with self.assertRaises(AssertionError):d.assert_auto_saved(sample)

    def test_expected_automatic_failure_is_exact_existing_error_code(self):
        d.assert_auto_failed({'httpStatus':503,'body':{'error':{'code':'EXECUTION_RUNTIME_NOT_LOADED'}}})
        for status,code in [(200,'EXECUTION_RUNTIME_NOT_LOADED'),(503,'upstream_unavailable'),(500,'EXECUTION_RUNTIME_NOT_LOADED')]:
            with self.assertRaises(AssertionError):d.assert_auto_failed({'httpStatus':status,'body':{'error':{'code':code}}})

    def test_bootstrap_js_and_native_shim_compile_without_running_them(self):
        compile(d.CLI_SHIM,'<transparent-cli-shim>','exec')
        result=subprocess.run(['node','--check'],input=d.BOOTSTRAP,text=True,capture_output=True)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_ts_loader_cwd_is_a_docker_option_before_container(self):
        command=d.ts_exec_command('owned-app','source','connection')
        self.assertEqual(command[:6],['docker','exec','-i','-w','/app/webui','owned-app'])
        self.assertEqual(command[6:10],['node','--import','tsx','--input-type=module'])
        self.assertEqual(command[-2:],['source','connection'])
        self.assertIn("cwd:'/app/webui'",d.BOOTSTRAP)

    def test_only_direct_app_command_adds_init_without_replacing_native_entrypoint(self):
        argv=d.direct_container_command('owned-app','owned-net','owned-volume',pathlib.Path('/private/owned/bootstrap'))
        self.assertEqual(argv[:4],['docker','run','-d','--init'])
        self.assertEqual(argv[-2:],['--entrypoint','node'])
        self.assertEqual(argv.count('--init'),1)
        self.assertNotIn('--init',d.seed_normalizer_command('frozen','owned-normalizer'))
        self.assertNotIn('supervisor',argv)
        self.assertIn("cp.spawnSync('ktx',['--project-dir','/data/lucy','mcp','start'",d.BOOTSTRAP)

    def test_topology_requires_real_init_and_complete_parent_and_daemon_identity(self):
        good={'pid1':{'pid':1,'comm':'docker-init','state':'S'},'bootstrap':{'pid':7,'ppid':1},'app':{'pid':30,'ppid':7},'originalDaemon':{'sameIdentity':True}}
        d.assert_init_topology(True,good)
        import copy
        for init,field,key,value in [(False,'pid1','comm','docker-init'),(True,'pid1','comm','node'),(True,'bootstrap','pid',1),(True,'bootstrap','ppid',99),(True,'app','ppid',99),(True,'originalDaemon','sameIdentity',False)]:
            bad=copy.deepcopy(good);bad[field][key]=value
            with self.assertRaises(AssertionError):d.assert_init_topology(init,bad)

    def test_terminal_process_probe_can_see_nonlistener_zombie_without_sensitive_process_data(self):
        compile(d.PROCESS_FACTS,'<safe-process-facts>','exec')
        for word in ['cmdline','environ','socket','net/tcp']:
            self.assertNotIn(word,d.PROCESS_FACTS)
        for field in ['state','ppid','startTicks','comm','originalDaemon','expectedStartTicks','sameIdentity']:
            self.assertIn(field,d.PROCESS_FACTS)
        source=path.read_text()
        self.assertIn("('final-original-process',process_facts)",source)
        self.assertLess(source.index("rig.save(label+'-original-process-after-save'"),source.index('assert_auto_saved(reply)'))
        self.assertIn(',8,operation=saving)',source)
        self.assertIn("'reloadTotalMs':60000,'drainMs':20000,'startupCombinedMs':20000",source)

    def test_help_does_not_launch_fixture(self):
        result=subprocess.run([sys.executable,str(path),'--help'],text=True,capture_output=True)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn('fault-timeout-ms',result.stdout)

if __name__=='__main__':unittest.main()
