import pathlib,json,hashlib,datetime,os,subprocess
p=pathlib.Path(__file__).with_name('command-plan.json');plan=json.loads(p.read_text());dest=p.parent
if (dest/'actual-invocation.json').exists() or (dest/'summary.json').exists():raise SystemExit('never retry same output')
for key,d in plan['dependencies'].items():
 for field in ['actualPath','snapshotPath']:
  assert hashlib.sha256(pathlib.Path(d[field]).read_bytes()).hexdigest()==d['sha256'],key+field
assert pathlib.Path(plan['requestedCwd']).resolve()==pathlib.Path(plan['resolvedCwd'])
record={'status':'RUNNING','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':plan['argv'],'requestedCwd':plan['requestedCwd'],'resolvedCwd':plan['resolvedCwd'],'actualCwd':plan['resolvedCwd'],'image':plan['image'],'wrapperPid':os.getpid(),'planSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'actualDependencies':plan['dependencies']}
def save(): (dest/'actual-invocation.json').write_text(json.dumps(record,indent=2)+'\n')
save()
with open(plan['stdoutLog'],'x') as log:
 proc=subprocess.Popen(plan['argv'],cwd=plan['resolvedCwd'],env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 record['actualDriverPid']=proc.pid;save();print(json.dumps({'status':'STARTED','driverPid':proc.pid,'out':str(dest)}),flush=True)
 code=proc.wait()
record.update(status='EXITED',exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
print(json.dumps({'status':'EXITED','exitCode':code,'out':str(dest)}),flush=True)
raise SystemExit(code)
