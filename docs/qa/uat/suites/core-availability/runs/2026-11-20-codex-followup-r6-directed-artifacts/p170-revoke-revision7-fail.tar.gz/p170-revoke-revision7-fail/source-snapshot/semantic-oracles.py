"""Independent P170 predicates; no runtime import, network or Docker side effects."""
import datetime,json,math,pathlib,re,sqlite3
from decimal import Decimal,InvalidOperation
SOURCE='uat_begin_zero_orders';CONNECTION='uat-mysql';PHYSICAL='uat.'+SOURCE
class PhaseGap(AssertionError):pass
def require(value,message):
 if not value:raise AssertionError(message)
def successful(receipt):
 body=receipt.get('body',{});result=body.get('result',{}) if isinstance(body,dict) else {}
 return receipt.get('httpStatus')==200 and isinstance(result,dict) and not body.get('error') and not result.get('isError')
def payload(receipt):
 result=receipt.get('body',{}).get('result',{})
 if not isinstance(result,dict):return None
 for item in result.get('content',[]):
  if item.get('type')=='text':
   try:return json.loads(item['text'])
   except (ValueError,KeyError):pass
 return result.get('structuredContent')
def aggregate_ok(receipt,expected=(4,100)):
 if not successful(receipt):return False
 data=payload(receipt)
 if not isinstance(data,dict) or not isinstance(data.get('rows'),list) or len(data['rows'])!=1:return False
 row=data['rows'][0];headers=data.get('headers');labels=list(row) if isinstance(row,dict) else headers
 if not isinstance(labels,list) or len(labels)!=2 or any(not isinstance(x,str) for x in labels):return False
 labels=[x[len(SOURCE)+1:] if x.startswith(SOURCE+'.') else x for x in labels]
 if len(set(labels))!=2 or set(labels)!={'order_count','amount_sum'}:return False
 if isinstance(row,dict) and headers is not None:
  if not isinstance(headers,list) or len(headers)!=2 or any(not isinstance(x,str) for x in headers):return False
  declared=[x[len(SOURCE)+1:] if x.startswith(SOURCE+'.') else x for x in headers]
  if len(set(declared))!=2 or set(declared)!=set(labels):return False
 if not isinstance(row,(dict,list)) or len(row)!=2:return False
 bound=dict(zip(labels,list(row.values()) if isinstance(row,dict) else row))
 try:
  values=[bound['order_count'],bound['amount_sum']]
  if any(isinstance(x,bool) or not isinstance(x,(int,float,str)) for x in values):return False
  return all(Decimal(str(x)).is_finite() and Decimal(str(x))==Decimal(str(want)) for x,want in zip(values,expected))
 except (InvalidOperation,TypeError):return False
def metadata_ok(receipt,parsed_yaml):
 data=payload(receipt)
 if not successful(receipt) or not isinstance(data,dict) or data.get('sourceName')!=SOURCE or not isinstance(data.get('yaml'),str):return False
 if not isinstance(parsed_yaml,dict) or parsed_yaml.get('name')!=SOURCE or parsed_yaml.get('table')!=PHYSICAL:return False
 columns=parsed_yaml.get('columns')
 return isinstance(columns,list) and {x.get('name') for x in columns if isinstance(x,dict)}>={'order_id','tenant','amount'}
def explain_ok(receipt):
 d=payload(receipt)
 if not successful(receipt) or not isinstance(d,dict):return False
 sources=d.get('requestedSources');expected={'connectionId':CONNECTION,'sourceName':SOURCE,'physicalTable':PHYSICAL}
 if not isinstance(sources,list) or len(sources)!=1 or not isinstance(sources[0],dict) or any(sources[0].get(k)!=v for k,v in expected.items()):return False
 policy=d.get('policy')
 return d.get('allowed') is True and d.get('executionMode')=='plan_only' and d.get('executed') is False and d.get('aggregateResults') is None and isinstance(policy,dict) and not policy.get('error') and isinstance(policy.get('capabilityDigest'),str) and bool(policy['capabilityDigest']) and policy.get('sourceMapVersion') is not None
def exact_revocation(receipt):
 error=receipt.get('body',{}).get('error',{});data=error.get('data',{}) if isinstance(error,dict) else {}
 return receipt.get('httpStatus')==403 and error.get('code')==-32003 and (error.get('message')=='Access denied: authorization_revoked' or isinstance(data,dict) and data.get('reason')=='authorization_revoked')
def same_node_identities(before,after):
 return bool(before) and before==after
def term_receipt_ok(receipt):
 body=receipt.get('body',{});error=body.get('error',{}) if isinstance(body,dict) else {}
 return receipt.get('httpStatus')==503 and isinstance(body,dict) and body.get('ok') is False and isinstance(error,dict) and error.get('code')=='SERVICE_DRAINING'
def external_term_ok(state,elapsed):
 return not state.get('Running') and state.get('ExitCode')==143 and not state.get('OOMKilled') and elapsed<=40
def machine_reason(receipt):
 body=receipt.get('body',{});error=body.get('error',{})
 if isinstance(error,dict) and error:return error.get('data',{}).get('reason',error.get('code')) if isinstance(error.get('data',{}),dict) else error.get('code')
 d=payload(receipt);return d.get('code',d.get('reason')) if isinstance(d,dict) else None
def parse_events(raw):
 events=[]
 for line in raw.splitlines():
  if '[lucy-semantic-write]' not in line:continue
  match=re.fullmatch(r'(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,9})?(?:Z|[+-]\d\d:\d\d)) \[lucy-semantic-write\] (\{.*\})',line)
  require(bool(match),'malformed original engineering log/prefix')
  stamp=match[1];zone=re.search(r'([+-])(\d\d):(\d\d)$',stamp)
  require(not zone or int(zone[2])<=23 and int(zone[3])<=59,'invalid RFC3339 offset')
  datetime.datetime.fromisoformat(re.sub(r'\.(\d{6})\d+',r'.\1',stamp).replace('Z','+00:00'))
  event=json.loads(match[2]);require(event.get('event') in ['registered','files_saved','failed','read_wait_begin','read_wait_end'],'unknown engineering event')
  for field in ['atMs','monoMs']:require(isinstance(event.get(field),(int,float)) and not isinstance(event[field],bool) and math.isfinite(event[field]),'invalid event clock')
  events.append(event)
 return events
def owner_key(event):return tuple(event.get(x) for x in ['holderOperationId','journalId','releaseId'])
def wait_begin(events,rpc):
 rows=[x for x in events if x.get('event')=='read_wait_begin' and str(x.get('rpcId'))==str(rpc)]
 if not rows:raise PhaseGap('original RPC actual read_wait_begin not observed')
 require(len(rows)==1,'duplicate/misbound read begin');begin=rows[0]
 for f in ['ingressMonoMs','fixedInitialWaitDeadlineMonoMs','waitDeadlineMonoMs']:require(isinstance(begin.get(f),(int,float)) and not isinstance(begin[f],bool) and math.isfinite(begin[f]),'missing/invalid trusted '+f)
 require(begin['fixedInitialWaitDeadlineMonoMs']==begin['ingressMonoMs']+20000,'fixed deadline not original ingress+20s')
 require(begin['waitDeadlineMonoMs']<=begin['fixedInitialWaitDeadlineMonoMs'] and begin['ingressMonoMs']<=begin['monoMs'],'effective deadline extended or ingress reversed')
 require(isinstance(begin.get('ingressOperationId'),str) and begin['ingressOperationId'],'missing original ingress identity')
 owners=begin.get('owners');require(isinstance(owners,list) and owners and len({owner_key(x) for x in owners})==len(owners),'empty/duplicate original owners')
 for owner in owners:
  require(all(isinstance(x,str) and x for x in owner_key(owner)),'unnamed owner')
  registration=[x for x in events if x['event']=='registered' and owner_key(x)==owner_key(owner)];require(len(registration)==1 and registration[0]['monoMs']<=begin['monoMs'],'missing/late/duplicate actual registration')
 return begin
def wait_closure(events,rpc,outcome,receipt=None):
 begin=wait_begin(events,rpc)
 if receipt is not None:require(receipt.get('correlationHeaders',{}).get('x-lucy-operation-id')==begin['ingressOperationId'] and str(receipt.get('rpcId'))==str(rpc),'receipt does not bind original server ingress/RPC')
 ends=[x for x in events if x['event']=='read_wait_end' and x.get('ingressOperationId')==begin['ingressOperationId']]
 require(len(ends)==1,'missing/duplicate original read end');end=ends[0]
 for f in ['rpcId','owners','ingressMonoMs','fixedInitialWaitDeadlineMonoMs','waitDeadlineMonoMs']:require(end.get(f)==begin.get(f),'reader identity/deadline/owner set changed')
 require(end.get('endOutcome')==outcome and end['monoMs']>=begin['monoMs'],'wrong/reversed wait terminal')
 stages=[]
 for owner in begin['owners']:
  terminal=[x for x in events if x['event'] in ['files_saved','failed'] and owner_key(x)==owner_key(owner)];require(len(terminal)==1,'missing/duplicate actual writer terminal');stages+=terminal
 if outcome=='owner_settled':require(all(x['event']=='files_saved' and x['monoMs']<=end['monoMs'] for x in stages) and end['monoMs']<end['waitDeadlineMonoMs'],'false or late normal stage success')
 if outcome=='timeout':require(end['monoMs']>=end['waitDeadlineMonoMs'] and all(x['monoMs']>end['monoMs'] for x in stages),'timeout did not precede real writer settlement')
 return {'begin':begin,'end':end,'stages':stages}
def actual_hold(facts,registration):
 lock=facts.get('lock') or {};nodes=facts.get('nodes',[]);journals=facts.get('journals',[])
 return lock.get('operationId')==registration['holderOperationId'] and any(j.get('journalId')==registration['journalId'] and j.get('releaseId')==registration['releaseId'] and j.get('operationId')==registration['releaseId'] and j.get('phase')=='write_in_progress' and j.get('status')=='open' for j in journals) and any(n.get('pid')==lock.get('pid') and any(fd.get('target')=='/data/lucy/config/semantic-layer/uat-mysql/_schema/uat.yaml' for fd in n.get('fds',[])) and any(t.get('wchan')=='wait_for_partner' for t in n.get('tasks',[])) for n in nodes)
def valid_lease_break_time(value):
 return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>10
def exact_lease_holder_rows(rows,control):
 device=control.get('device');pid=control.get('pid');inode=control.get('inode')
 if not isinstance(device,dict) or any(not isinstance(device.get(k),int) or isinstance(device[k],bool) or device[k]<0 for k in ['raw','major','minor']) or not isinstance(pid,int) or isinstance(pid,bool) or pid<=0 or not isinstance(inode,int) or isinstance(inode,bool) or inode<=0:return []
 matches=[]
 for line in rows:
  if not isinstance(line,str):continue
  parts=line.split()
  if len(parts)<8 or '->' in parts or parts[1:4]!=['LEASE','BREAKING','UNLCK']:continue
  try:
   major,minor,row_inode=parts[5].split(':')
   if int(parts[4])==pid and int(major,16)==device['major'] and int(minor,16)==device['minor'] and int(row_inode)==inode:matches.append(line)
  except ValueError:continue
 return matches
def actual_regular_lease_hold(facts,registration):
 lock=facts.get('lock') or {};control=facts.get('control') or {};rows=facts.get('leaseRows',[])
 wal=any(j.get('journalId')==registration['journalId'] and j.get('releaseId')==registration['releaseId'] and j.get('operationId')==registration['releaseId'] and j.get('phase')=='write_in_progress' and j.get('status')=='open' for j in facts.get('journals',[]))
 node=any(n.get('pid')==lock.get('pid') and any(fd.get('target')=='/data/lucy/config/semantic-layer/uat-mysql/_schema/uat.yaml' for fd in n.get('fds',[])) and any(t.get('wchan')=='__break_lease' for t in n.get('tasks',[])) for n in facts.get('nodes',[]))
 return lock.get('operationId')==registration['holderOperationId'] and wal and node and control.get('kind')=='regular_lease' and control.get('phase')=='lease_breaking' and control.get('leaseSet') is True and control.get('uid')==control.get('targetUid')==10001 and control.get('targetRegular') is True and bool(control.get('signals')) and facts.get('controlAlive') is True and valid_lease_break_time(control.get('breakTimeSeconds')) and len(exact_lease_holder_rows(rows,control))==1
def normal_lease_release_ok(control):
 return control.get('kind')=='regular_lease' and control.get('phase')=='lease_closed' and control.get('releaseReason')=='manual_after_actual_wait_begin' and control.get('releasedWithin10') is True and control.get('signals') and isinstance(control.get('releasedMono'),(int,float)) and 0<=control['releasedMono']-control['signals'][0]['mono']<=10 and control.get('targetMetadataChangedByControl') is False and control.get('targetBytesWrittenByControl') is False
class SqlCoverageError(ValueError):pass
def _sql_tokens(sql):
 # Fixed MySQL fixture lexer, not a general SQL parser. Literals/comments never
 # become table identifiers; backtick identifiers remain distinguishable.
 tokens=[];i=0
 while i<len(sql):
  ch=sql[i]
  if ch.isspace():i+=1;continue
  if ch=='#' or sql.startswith('--',i) and (i+2==len(sql) or sql[i+2].isspace()):
   end=sql.find('\n',i);i=len(sql) if end<0 else end+1;continue
  if sql.startswith('/*',i):
   end=sql.find('*/',i+2)
   if end<0:raise SqlCoverageError('unterminated SQL log comment')
   if sql.startswith('/*!',i):
    inner=re.sub(r'^\d+\s*','',sql[i+3:end]);tokens.append(('conditional',''));tokens.extend(_sql_tokens(inner))
   i=end+2;continue
  if ch in ["'",'"','`']:
   quote=ch;value=[];i+=1;closed=False
   while i<len(sql):
    if sql[i]==quote:
     if i+1<len(sql) and sql[i+1]==quote:value.append(quote);i+=2;continue
     i+=1;closed=True;break
    if sql[i]=='\\' and quote!='`' and i+1<len(sql):value.append(sql[i+1]);i+=2;continue
    value.append(sql[i]);i+=1
   if not closed:raise SqlCoverageError('unterminated SQL log quoted value')
   tokens.append(('quoted' if quote=='`' else 'literal',''.join(value).lower() if quote=='`' else ''.join(value)));continue
  if ch.isalnum() or ch in ['_','$']:
   end=i+1
   while end<len(sql) and (sql[end].isalnum() or sql[end] in ['_','$']):end+=1
   tokens.append(('word',sql[i:end].lower()));i=end;continue
  tokens.append(('symbol',ch));i+=1
 return tokens
def _keyword(token,name):return token[0]=='word' and token[1]==name
def _cte_aliases(tokens):
 if not tokens or not _keyword(tokens[0],'with'):return set()
 aliases=set();i=1
 if i<len(tokens) and _keyword(tokens[i],'recursive'):i+=1
 def skip_group(index):
  depth=0
  while index<len(tokens):
   if tokens[index]==('symbol','('):depth+=1
   elif tokens[index]==('symbol',')'):
    depth-=1
    if depth==0:return index+1
   index+=1
  raise SqlCoverageError('unterminated CTE group')
 while i<len(tokens) and tokens[i][0] in ['word','quoted']:
  name=tokens[i][1];i+=1
  if i<len(tokens) and tokens[i]==('symbol','('):i=skip_group(i)
  if i>=len(tokens) or not _keyword(tokens[i],'as'):break
  i+=1
  if i>=len(tokens) or tokens[i]!=('symbol','('):break
  aliases.add(name);i=skip_group(i)
  if i>=len(tokens) or tokens[i]!=('symbol',','):break
  i+=1
 return aliases
def _statement_reads_fixture(tokens,tables,schema):
 conditional=any(t[0]=='conditional' for t in tokens);tokens=[t for t in tokens if t[0]!='conditional']
 if not tokens:return False
 if any(_keyword(tokens[0],x) for x in ['explain','describe','desc']):
  query=next((i for i,t in enumerate(tokens) if _keyword(t,'select') or _keyword(t,'with')),None)
  if query is None or not any(_keyword(t,'analyze') for t in tokens[1:query]):return False
  tokens=tokens[query:]
 prefix=next((t for t in tokens if t!=('symbol','(')),None)
 if prefix is None:return False
 if not (_keyword(prefix,'select') or _keyword(prefix,'with')):
  has_read=any(_keyword(t,'select') or _keyword(t,'with') for t in tokens)
  if not has_read and any(_keyword(prefix,k) for k in ['set','show','use','begin','start','commit','rollback','savepoint','release']):return False
  if tokens==[('word','truncate'),('word','table'),('word','mysql'),('symbol','.'),('word','general_log')]:return False
  raise SqlCoverageError('execution statement outside fixed fixture SELECT/CTE/metadata coverage')
 aliases=_cte_aliases(tokens)
 if aliases & tables:raise SqlCoverageError('fixture table shadowed by CTE alias; explicit coverage required')
 depth=0;contexts={};i=0;found=False
 while i<len(tokens):
  token=tokens[i]
  if token==('symbol','('):
   if depth in contexts:
    if contexts[depth]['expect'] and not (i+1<len(tokens) and any(_keyword(tokens[i+1],k) for k in ['select','with'])):raise SqlCoverageError('unsupported parenthesized FROM/JOIN factor; only derived SELECT/WITH covered')
    contexts[depth]['expect']=False
   depth+=1;i+=1;continue
  if token==('symbol',')'):
   contexts.pop(depth,None);depth-=1
   if depth<0:raise SqlCoverageError('unbalanced SQL log parenthesis')
   i+=1;continue
  if _keyword(token,'select'):contexts[depth]={'from':False,'expect':False};i+=1;continue
  context=contexts.get(depth)
  if context is None:i+=1;continue
  if any(_keyword(token,k) for k in ['where','group','having','order','limit','union','except','intersect','window','for','into']):context['from']=False;context['expect']=False;i+=1;continue
  if _keyword(token,'from') or _keyword(token,'join'):context['from']=True;context['expect']=True;i+=1;continue
  if token==('symbol',',') and context['from']:context['expect']=True;i+=1;continue
  if not context['expect']:i+=1;continue
  if _keyword(token,'lateral'):i+=1;continue
  if token[0]=='literal':raise SqlCoverageError('quoted FROM target is ambiguous for fixture SQL mode')
  if token[0] not in ['word','quoted']:raise SqlCoverageError('unsupported FROM/JOIN table-factor token')
  parts=[token[1]];i+=1
  while i+1<len(tokens) and tokens[i]==('symbol','.') and tokens[i+1][0] in ['word','quoted']:parts.append(tokens[i+1][1]);i+=2
  if i+1<len(tokens) and tokens[i]==('symbol','.') and tokens[i+1][0]=='literal':raise SqlCoverageError('qualified quoted FROM target requires explicit SQL mode coverage')
  if len(parts)>2:raise SqlCoverageError('FROM/JOIN target outside one/two-part MySQL fixture coverage')
  context['expect']=False
  if len(parts)==1 and parts[0] in tables and parts[0] not in aliases:found=True
  elif len(parts)==2 and parts[0]==schema and parts[1] in tables:found=True
 if depth!=0:raise SqlCoverageError('unbalanced SQL log statement')
 if found and conditional:raise SqlCoverageError('version-conditioned business SQL requires explicit fixture coverage')
 return found
def _sql_statements(sql):
 tokens=_sql_tokens(sql);statements=[];current=[];depth=0
 for token in tokens:
  if token==('symbol','('):depth+=1
  elif token==('symbol',')'):depth-=1
  if token==('symbol',';') and depth==0:
   if current:statements.append(current)
   current=[]
  else:current.append(token)
 if current:statements.append(current)
 return statements
def business_rows(lines,tables=None,schema='uat'):
 tables={x.lower() for x in (tables if tables is not None else [SOURCE])};result=[]
 for row in lines:
  if str(row.get('commandType','')).lower() not in ['query','execute']:continue
  sql=row.get('sql')
  if not isinstance(sql,str):raise SqlCoverageError('non-text SQL execution record')
  for statement in _sql_statements(sql):
   if _statement_reads_fixture(statement,tables,schema.lower()):result.append(row)
 return result
def sql_text(text):return text.strip().rstrip(';').strip() if isinstance(text,str) else None
def expected_business_sql_matches(rows,receipt):
 data=payload(receipt);expected=data.get('sql') if isinstance(data,dict) else None
 if not (len(rows)==1 and isinstance(expected,str) and bool(expected.strip()) and isinstance(rows[0].get('sql'),str) and len(_sql_statements(expected))==len(_sql_statements(rows[0]['sql']))==1):return False
 # Exact whole-statement equality, plus only the single-layer wire wrapper
 # captured from this fixture's KTX sl_query. Inner compiled SQL stays byte-exact
 # after the same boundary trim used for audit evidence; no substring matching.
 compiled=sql_text(expected);wire=sql_text(rows[0]['sql'])
 return wire==compiled or wire=='select * from ('+compiled+') as ktx_query_result limit 100'

def audit_scopes(database,scopes):
 c=sqlite3.connect(pathlib.Path(database).resolve().as_uri()+'?mode=ro&immutable=1',uri=True);c.row_factory=sqlite3.Row;result=[]
 try:
  for scope in scopes:
   state=c.execute('SELECT * FROM question_budget_state WHERE scope_key=?',(scope['scopeKey'],)).fetchone();rows=c.execute('SELECT * FROM access_log WHERE user_id=? AND lucy_session_id=? AND token_hash_prefix=? AND tool=?',(scope['userId'],scope['session'],scope['tokenPrefix'],scope['tool'])).fetchall();checks={'budgetSingleConsumes':bool(state and state['calls']==len(scope['rpcs']) and state['attempts']==len(scope['rpcs']) and state['current_concurrency']==0),'exactRpcAuditRows':len(rows)==len(scope['rpcs']) and sorted(str(x['request_id']) for x in rows)==sorted(str(x) for x in scope['rpcs'])}
   links=[]
   for row in rows:
    associations=c.execute('SELECT t.user_id FROM inferred_turn_access_logs l LEFT JOIN inferred_turns t ON t.inferred_turn_id=l.inferred_turn_id WHERE l.access_log_id=?',(row['id'],)).fetchall();links.append({'id':row['id'],'rpcId':row['request_id'],'outcome':row['outcome'],'links':len(associations),'validSameUser':len(associations)==1 and associations[0]['user_id']==scope['userId']})
   checks['effectiveAuditClosed']=len(links)==len(scope['rpcs']) and all(x['validSameUser'] for x in links)
   expected=scope.get('expected',{});checks['receiptAuditOutcomesAgree']=all(str(x['request_id']) in expected and (x['outcome']=='ok') is expected[str(x['request_id'])] for x in rows)
   if scope['tool'] in ['lucy_read_source','lucy_explain_query']:checks['zeroBusinessExecutionAudit']=all(not x['generated_sql'] and x['query_operation'] is None for x in rows)
   if scope['tool']=='lucy_query':checks['executionAuditAgree']=all((bool(x['generated_sql']) and x['query_operation']=='select' and bool(scope.get('expectedSql',{}).get(str(x['request_id']))) and sql_text(x['generated_sql'])==sql_text(scope['expectedSql'][str(x['request_id'])])) if expected.get(str(x['request_id'])) else not x['generated_sql'] and x['query_operation']!='select' for x in rows)
   initial=scope.get('initialState');checks['originalGenerationPreserved']=not initial or bool(state and all(state[k]==initial[k] for k in ['round','window_id','started_at']))
   result.append({'scope':scope,'state':dict(state) if state else None,'rows':links,'checks':checks,'valid':all(checks.values())})
 finally:c.close()
 return result
