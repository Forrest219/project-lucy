"""Offline predicate adversaries only. These fixtures never certify a real process phase."""
import copy,importlib.util,json,pathlib,sqlite3,tempfile,unittest
HERE=pathlib.Path(__file__).resolve().parent
def load(name):
 p=HERE/name;s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
O=load('semantic-oracles.py');D=load('verify-semantic-read-docker.py')
def receipt(data,**result):return {'httpStatus':200,'body':{'result':{'content':[{'type':'text','text':json.dumps(data)}],**result}}}
def engineering():
 owner={'holderOperationId':'holder','journalId':'journal','releaseId':'release'}
 registered={'event':'registered',**owner,'atMs':1000,'monoMs':100}
 begin={'event':'read_wait_begin','ingressOperationId':'ingress','rpcId':7,'owners':[owner],'ingressMonoMs':50,'fixedInitialWaitDeadlineMonoMs':20050,'waitDeadlineMonoMs':20050,'atMs':1100,'monoMs':200}
 end={**begin,'event':'read_wait_end','monoMs':500,'endOutcome':'owner_settled'}
 stage={**registered,'event':'files_saved','monoMs':400};return [registered,begin,stage,end]
class Tools(unittest.TestCase):
 def test_query_correct_columns_and_strings(self):self.assertTrue(O.aggregate_ok(receipt({'headers':['order_count','amount_sum'],'rows':[['4','100']]})))
 def test_reordered_labeled_values_remain_correct(self):self.assertTrue(O.aggregate_ok(receipt({'headers':['amount_sum','order_count'],'rows':[['100','4']]})))
 def test_swapped_numbers_are_not_the_original_problem(self):self.assertFalse(O.aggregate_ok(receipt({'headers':['order_count','amount_sum'],'rows':[[100,4]]})))
 def test_wrong_or_missing_labels_fail(self):
  for headers in [None,['wrong','values'],['order_count','order_count']]:self.assertFalse(O.aggregate_ok(receipt({'headers':headers,'rows':[[4,100]]})))
 def test_dict_row_with_contradictory_headers_fails(self):self.assertFalse(O.aggregate_ok(receipt({'headers':['wrong','amount_sum'],'rows':[{'order_count':4,'amount_sum':100}]})))
 def test_precision_loss_does_not_create_success(self):self.assertFalse(O.aggregate_ok(receipt({'headers':['order_count','amount_sum'],'rows':[['4.000000000000000001','100']]})))
 def test_http200_iserror_is_not_success(self):self.assertFalse(O.aggregate_ok(receipt({'headers':['order_count','amount_sum'],'rows':[[4,100]]},isError=True)))
 def test_metadata_correct_authorized_source(self):self.assertTrue(O.metadata_ok(receipt({'sourceName':O.SOURCE,'yaml':'actual source'}),{'name':O.SOURCE,'table':O.PHYSICAL,'columns':[{'name':x} for x in ['order_id','tenant','amount']]}))
 def test_metadata_wrong_physical_scope_is_not_correct(self):self.assertFalse(O.metadata_ok(receipt({'sourceName':O.SOURCE,'yaml':'actual source'}),{'name':O.SOURCE,'table':'secret.other','columns':[]}))
 def explain(self):return {'allowed':True,'executionMode':'plan_only','executed':False,'aggregateResults':None,'policy':{'sourceMapVersion':'v1','capabilityDigest':'actual'},'requestedSources':[{'connectionId':O.CONNECTION,'sourceName':O.SOURCE,'physicalTable':O.PHYSICAL}]}
 def test_explain_is_plan_only_correct_scope(self):self.assertTrue(O.explain_ok(receipt(self.explain())))
 def test_explain_actual_execution_cannot_pass(self):
  d=self.explain();d['executed']=True;self.assertFalse(O.explain_ok(receipt(d)))
 def test_explain_wrong_source_cannot_pass(self):
  d=self.explain();d['requestedSources'][0]['physicalTable']='secret.other';self.assertFalse(O.explain_ok(receipt(d)))
 def test_explain_additional_source_is_not_original_scope(self):
  d=self.explain();d['requestedSources'].append({'connectionId':'other','sourceName':'secret','physicalTable':'secret.other'});self.assertFalse(O.explain_ok(receipt(d)))
 def test_explain_duplicate_source_is_not_exact_original_scope(self):
  d=self.explain();d['requestedSources']*=2;self.assertFalse(O.explain_ok(receipt(d)))
 def test_explain_empty_identity_field_fails(self):
  d=self.explain();d['requestedSources'][0]['physicalTable']='';self.assertFalse(O.explain_ok(receipt(d)))
 def test_generic_error_is_not_token_revocation(self):self.assertFalse(O.exact_revocation({'httpStatus':503,'body':{'error':{'code':-32003,'message':'upstream unavailable'}}}))
class Events(unittest.TestCase):
 def test_exact_owner_stage_reader_closure(self):self.assertEqual(O.wait_closure(engineering(),7,'owner_settled')['end']['endOutcome'],'owner_settled')
 def test_no_actual_wait_is_gap(self):
  with self.assertRaises(O.PhaseGap):O.wait_closure([engineering()[0]],7,'owner_settled')
 def test_writer_stage_signal_without_read_receipt_is_not_sql_success(self):
  self.assertFalse(O.aggregate_ok({'httpStatus':200,'body':{}}))
 def test_fake_registration_after_begin_fails(self):
  e=engineering();e[0]['monoMs']=201
  with self.assertRaises(AssertionError):O.wait_closure(e,7,'owner_settled')
 def test_begin_does_not_restart_20s_clock(self):
  e=engineering();e[1]['fixedInitialWaitDeadlineMonoMs']=20200
  with self.assertRaises(AssertionError):O.wait_begin(e,7)
 def test_budget_effective_deadline_cannot_extend(self):
  e=engineering();e[1]['waitDeadlineMonoMs']=21000
  with self.assertRaises(AssertionError):O.wait_begin(e,7)
 def test_deadline_fields_cannot_change_on_wake(self):
  e=engineering();e[-1]['waitDeadlineMonoMs']=30000
  with self.assertRaises(AssertionError):O.wait_closure(e,7,'owner_settled')
 def test_successor_owner_cannot_replace_original_set(self):
  e=engineering();e[-1]['owners']=[{'holderOperationId':'new','journalId':'new','releaseId':'new'}]
  with self.assertRaises(AssertionError):O.wait_closure(e,7,'owner_settled')
 def test_failed_or_late_stage_never_becomes_normal_success(self):
  for field,value in [('event','failed'),('monoMs',600)]:
   e=engineering();e[2][field]=value
   with self.assertRaises(AssertionError):O.wait_closure(e,7,'owner_settled')
 def test_duplicate_terminal_fails(self):
  e=engineering();e.append(copy.deepcopy(e[2]))
  with self.assertRaises(AssertionError):O.wait_closure(e,7,'owner_settled')
 def test_timeout_reader_never_retires_writer(self):
  e=engineering();e[2].update(event='failed',monoMs=21000);e[-1].update(endOutcome='timeout',monoMs=20060);self.assertEqual(O.wait_closure(e,7,'timeout')['end']['endOutcome'],'timeout')
 def test_writer_settled_before_timeout_not_held_evidence(self):
  e=engineering();e[2].update(event='failed',monoMs=19900);e[-1].update(endOutcome='timeout',monoMs=20060)
  with self.assertRaises(AssertionError):O.wait_closure(e,7,'timeout')
 def test_reader_identity_cannot_change(self):
  e=engineering();e[-1]['rpcId']=8
  with self.assertRaises(AssertionError):O.wait_closure(e,7,'owner_settled')
 def test_nano_logs_are_valid_and_bad_offsets_are_not(self):
  raw='2026-11-20T12:00:00.123456789Z [lucy-semantic-write] '+json.dumps(engineering()[0]);self.assertEqual(len(O.parse_events(raw)),1)
  with self.assertRaises(AssertionError):O.parse_events(raw.replace('Z [','+00:60 ['))
class TermAndIngress(unittest.TestCase):
 def test_external_term_preserves_exact_origin_code(self):self.assertTrue(O.external_term_ok({'Running':False,'ExitCode':143,'OOMKilled':False},20.5))
 def test_natural_zero_or_kill137_not_external143(self):
  for code in [0,137,23]:self.assertFalse(O.external_term_ok({'Running':False,'ExitCode':code,'OOMKilled':False},20))
 def test_oom_or_over40_cannot_pass(self):
  self.assertFalse(O.external_term_ok({'Running':False,'ExitCode':143,'OOMKilled':True},20));self.assertFalse(O.external_term_ok({'Running':False,'ExitCode':143,'OOMKilled':False},40.01))
 def test_term_requires_canonical503_service_draining(self):self.assertTrue(O.term_receipt_ok({'httpStatus':503,'body':{'ok':False,'error':{'code':'SERVICE_DRAINING'}}}))
 def test_unrelated200_failure_is_not_term_denial(self):self.assertFalse(O.term_receipt_ok(receipt({'code':'semantic_recovery_required'},isError=True)))
 def test_upstream503_is_not_term_denial(self):self.assertFalse(O.term_receipt_ok({'httpStatus':503,'body':{'ok':False,'error':{'code':'upstream_unavailable'}}}))
 def test_service_draining_without_false_ok_is_not_canonical(self):self.assertFalse(O.term_receipt_ok({'httpStatus':503,'body':{'error':{'code':'SERVICE_DRAINING'}}}))
 def test_new_lawful_write_requires_original_process_identity(self):self.assertTrue(O.same_node_identities([(1,'10')],[(1,'10')]))
 def test_restarted_pid_or_pid_reuse_after_write_cannot_pass(self):
  self.assertFalse(O.same_node_identities([(1,'10')],[(2,'10')])) ;self.assertFalse(O.same_node_identities([(1,'10')],[(1,'11')]))
 def test_real_receipt_binds_original_ingress(self):
  O.wait_closure(engineering(),7,'owner_settled',{'rpcId':7,'correlationHeaders':{'x-lucy-operation-id':'ingress'}})
 def test_wrong_receipt_ingress_is_not_same_rpc_proof(self):
  with self.assertRaises(AssertionError):O.wait_closure(engineering(),7,'owner_settled',{'rpcId':7,'correlationHeaders':{'x-lucy-operation-id':'different'}})

class KernelAndSql(unittest.TestCase):
 def facts(self):return {'lock':{'operationId':'holder','pid':123},'journals':[{'journalId':'journal','releaseId':'release','operationId':'release','phase':'write_in_progress','status':'open'}],'nodes':[{'pid':123,'fds':[{'fd':'18','target':'/data/lucy/config/semantic-layer/uat-mysql/_schema/uat.yaml'}],'tasks':[{'wchan':'wait_for_partner'}]}]}
 def test_actual_owned_fd_worker_and_wal_required(self):self.assertTrue(O.actual_hold(self.facts(),engineering()[0]))
 def test_timer_pending_without_kernel_is_not_a_phase(self):
  f=self.facts();f['nodes'][0]['tasks']=[];self.assertFalse(O.actual_hold(f,engineering()[0]))
 def test_wrong_holder_or_journal_never_qualifies(self):
  f=self.facts();f['lock']['operationId']='other';self.assertFalse(O.actual_hold(f,engineering()[0]))
 def test_unrelated_fd_does_not_prove_actual_mirror(self):
  f=self.facts();f['nodes'][0]['fds'][0]['target']='/unrelated';self.assertFalse(O.actual_hold(f,engineering()[0]))
 def test_actual_business_sql_only_not_log_reader(self):
  original={'commandType':'Query','sql':'SELECT COUNT(DISTINCT order_id),SUM(amount) FROM uat.'+O.SOURCE};reader={'commandType':'Query','sql':"SELECT JSON_OBJECT('sql',CONVERT(argument USING utf8mb4)) FROM mysql.general_log"};self.assertEqual(O.business_rows([reader,original]),[original])
class RegularLeasePredicates(unittest.TestCase):
 def held(self):
  f=KernelAndSql().facts();f['nodes'][0]['tasks']=[{'wchan':'__break_lease'}];f['control']={'kind':'regular_lease','phase':'lease_breaking','leaseSet':True,'uid':10001,'targetUid':10001,'targetRegular':True,'signals':[{'mono':1}],'inode':99,'pid':344,'device':{'raw':96,'major':0,'minor':96},'breakTimeSeconds':45};f['controlAlive']=True;f['leaseRows']=['5: LEASE BREAKING UNLCK 344 00:60:99 0 EOF'];return f
 def released(self):return {'kind':'regular_lease','phase':'lease_closed','releaseReason':'manual_after_actual_wait_begin','releasedWithin10':True,'signals':[{'mono':1}],'releasedMono':2,'targetMetadataChangedByControl':False,'targetBytesWrittenByControl':False}
 def test_real_owner_wal_fd_lease_break_and_sigio_required(self):self.assertTrue(O.actual_regular_lease_hold(self.held(),engineering()[0]))
 def test_no_sigio_marker_is_not_real_lease_phase(self):
  f=self.held();f['control']['signals']=[];self.assertFalse(O.actual_regular_lease_hold(f,engineering()[0]))
 def test_fifo_wait_is_not_regular_lease_control(self):
  f=self.held();f['nodes'][0]['tasks']=[{'wchan':'wait_for_partner'}];self.assertFalse(O.actual_regular_lease_hold(f,engineering()[0]))
 def test_missing_or_wrong_inode_lease_row_fails(self):
  f=self.held();f['leaseRows']=['5: LEASE BREAKING UNLCK 344 00:60:100 0 EOF'];self.assertFalse(O.actual_regular_lease_hold(f,engineering()[0]))
 def test_different_file_owner_not_allowed(self):
  f=self.held();f['control']['targetUid']=0;self.assertFalse(O.actual_regular_lease_hold(f,engineering()[0]))
 def test_unrelated_holder_pid_cannot_certify_target(self):
  f=self.held();f['leaseRows']=['5: LEASE BREAKING UNLCK 999 00:60:99 0 EOF'];self.assertFalse(O.actual_regular_lease_hold(f,engineering()[0]))
 def test_other_device_same_inode_cannot_certify_target(self):
  f=self.held();f['leaseRows']=['5: LEASE BREAKING UNLCK 344 00:61:99 0 EOF'];self.assertFalse(O.actual_regular_lease_hold(f,engineering()[0]))
 def test_waiter_arrow_is_not_holder_row(self):
  f=self.held();f['leaseRows']=['5: -> LEASE BREAKING UNLCK 344 00:60:99 0 EOF'];self.assertFalse(O.actual_regular_lease_hold(f,engineering()[0]))
 def test_dead_or_unknown_lease_controller_cannot_certify_hold(self):
  for value in [False,None]:
   f=self.held();f['controlAlive']=value;self.assertFalse(O.actual_regular_lease_hold(f,engineering()[0]))
 def test_nonqualified_lease_wchan_is_not_real_open_hold(self):
  f=self.held();f['nodes'][0]['tasks']=[{'wchan':'unrelated_lease_wait'}];self.assertFalse(O.actual_regular_lease_hold(f,engineering()[0]))
 def test_break_time_must_be_known_finite_and_strictly_over10(self):
  remote=load('semantic-control.py')
  for value in [None,False,0,9,10,float('nan'),float('inf'),'45']:
   self.assertFalse(O.valid_lease_break_time(value));self.assertFalse(remote.valid_lease_break_time(value));f=self.held();f['control']['breakTimeSeconds']=value;self.assertFalse(O.actual_regular_lease_hold(f,engineering()[0]))
  self.assertTrue(O.valid_lease_break_time(45));self.assertTrue(remote.valid_lease_break_time(45))
 def test_actual_manual_release_within_original_bound(self):self.assertTrue(O.normal_lease_release_ok(self.released()))
 def test_automatic_release_never_becomes_normal_wait_pass(self):
  f=self.released();f['releaseReason']='auto_deadline';self.assertFalse(O.normal_lease_release_ok(f))
 def test_late_release_cannot_claim_self_reported_within10(self):
  f=self.released();f['releasedMono']=11.01;self.assertFalse(O.normal_lease_release_ok(f))
 def test_old_bytes_restoration_is_forbidden_in_normal_control(self):
  f=self.released();f['targetBytesWrittenByControl']=True;self.assertFalse(O.normal_lease_release_ok(f))
 def test_actual_normal_lease_function_has_no_target_mutation_calls(self):
  import ast
  tree=ast.parse((HERE/'semantic-control.py').read_text());node=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='lease')
  for call in (x for x in ast.walk(node) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr in ['write_bytes','write_text','replace','unlink','chmod','chown']):
   self.assertFalse(any(isinstance(x,ast.Name) and x.id=='MIRROR' for x in ast.walk(call)),ast.dump(call))

class WideSqlExecutionNegatives(unittest.TestCase):
 def rows(self,sql,command='Query',tables=None):return O.business_rows([{'commandType':command,'sql':sql}],tables)
 def test_real_select_star_is_business_even_without_aggregates(self):self.assertEqual(len(self.rows('SELECT * FROM uat.'+O.SOURCE+' LIMIT 1')),1)
 def test_count_only_is_business(self):self.assertEqual(len(self.rows('SELECT COUNT(*) FROM '+O.SOURCE)),1)
 def test_sum_only_is_business(self):self.assertEqual(len(self.rows('SELECT SUM(amount) FROM uat.'+O.SOURCE)),1)
 def test_backtick_and_case_qualified_identifiers(self):self.assertEqual(len(self.rows('SELECT * FROM `uat`.`'+O.SOURCE.upper()+'`')),1)
 def test_cte_inner_business_read_is_counted_once(self):self.assertEqual(len(self.rows('WITH q AS (SELECT * FROM uat.'+O.SOURCE+') SELECT COUNT(*) FROM q')),1)
 def test_nested_wrapper_business_read_is_counted_once(self):self.assertEqual(len(self.rows('SELECT * FROM (SELECT * FROM uat.'+O.SOURCE+') q')),1)
 def test_root_parenthesized_select_is_not_missed(self):self.assertEqual(len(self.rows('(SELECT * FROM uat.'+O.SOURCE+')')),1)
 def test_join_and_comma_from_find_real_business_tables(self):
  self.assertEqual(len(self.rows('SELECT * FROM information_schema.tables t JOIN uat.'+O.SOURCE+' s ON 1=1')),1);self.assertEqual(len(self.rows('SELECT * FROM information_schema.tables t,uat.'+O.SOURCE+' s')),1)
 def test_pure_log_reader_never_counts_quoted_business_text(self):self.assertFalse(self.rows("SELECT argument FROM mysql.general_log WHERE argument LIKE '%SELECT * FROM uat."+O.SOURCE+"%'"))
 def test_info_schema_literal_mentions_are_not_business_scan(self):self.assertFalse(self.rows("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_NAME='"+O.SOURCE+"'"))
 def test_ordinary_comments_cannot_fake_business_from(self):self.assertFalse(self.rows('SELECT 1 /* FROM uat.'+O.SOURCE+' */ -- FROM '+O.SOURCE+'\n'))
 def test_comments_between_real_from_tokens_keep_actual_scan(self):self.assertEqual(len(self.rows('/* tagged */ SELECT * FROM /* same table */ `uat` . `'+O.SOURCE+'`')),1)
 def test_string_escaped_quotes_and_comment_markers_are_not_identifiers(self):self.assertFalse(self.rows("SELECT 'quote '' FROM uat."+O.SOURCE+"', '/* fake */' FROM information_schema.tables"))
 def test_function_from_keyword_is_not_a_table_clause(self):self.assertFalse(self.rows('SELECT EXTRACT(YEAR FROM '+O.SOURCE+') FROM information_schema.tables'))
 def test_explain_plan_only_is_zero_execution(self):self.assertFalse(self.rows('EXPLAIN FORMAT=JSON SELECT * FROM uat.'+O.SOURCE))
 def test_explain_analyze_really_executes_and_counts(self):self.assertEqual(len(self.rows('EXPLAIN ANALYZE SELECT * FROM uat.'+O.SOURCE)),1)
 def test_prepare_is_not_execution_but_execute_is(self):
  self.assertFalse(self.rows('SELECT * FROM uat.'+O.SOURCE,'Prepare'));self.assertEqual(len(self.rows('SELECT * FROM uat.'+O.SOURCE,'Execute')),1)
 def test_execute_metadata_without_business_table_is_zero(self):self.assertFalse(self.rows("SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_NAME='"+O.SOURCE+"'",'Execute'))
 def test_double_quoted_table_identifier_cannot_silently_claim_zero(self):
  with self.assertRaises(O.SqlCoverageError):self.rows('SELECT * FROM uat."'+O.SOURCE+'"')
 def test_two_business_statements_cannot_collapse_to_one(self):self.assertEqual(len(self.rows('SELECT * FROM uat.'+O.SOURCE+';SELECT COUNT(*) FROM uat.'+O.SOURCE)),2)
 def test_other_fixture_business_table_is_also_counted(self):self.assertEqual(len(self.rows('SELECT * FROM uat.uat_t0001',tables=[O.SOURCE,'uat_t0001'])),1)
 def test_other_schema_same_table_is_not_this_fixture(self):self.assertFalse(self.rows('SELECT * FROM another_schema.'+O.SOURCE))
 def test_metadata_only_cte_is_not_business(self):self.assertFalse(self.rows("WITH q AS (SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_NAME='"+O.SOURCE+"') SELECT * FROM q"))
 def test_version_conditional_business_is_unsupported_not_silent_zero(self):
  with self.assertRaises(O.SqlCoverageError):self.rows('/*!80000 SELECT * FROM uat.'+O.SOURCE+' */')
 def test_unknown_dynamic_execution_cannot_prove_zero(self):
  with self.assertRaises(O.SqlCoverageError):self.rows('CALL opaque_procedure()')
 def test_mixed_multistatement_never_matches_unique_expected_sql(self):
  statement='SELECT 1;SELECT COUNT(*),SUM(amount) FROM uat.'+O.SOURCE;r=receipt({'headers':['order_count','amount_sum'],'rows':[[4,100]],'sql':statement});self.assertFalse(O.expected_business_sql_matches(self.rows(statement),r))
 def test_extra_execution_and_wrong_unique_sql_fail_query_oracle(self):
  expected='SELECT COUNT(*),SUM(amount) FROM uat.'+O.SOURCE;r=receipt({'headers':['order_count','amount_sum'],'rows':[[4,100]],'sql':expected});rows=self.rows(expected);self.assertTrue(O.expected_business_sql_matches(rows,r));self.assertFalse(O.expected_business_sql_matches(rows+self.rows('SELECT * FROM uat.'+O.SOURCE),r));self.assertFalse(O.expected_business_sql_matches(self.rows('SELECT * FROM uat.'+O.SOURCE),r))
class UnsupportedSqlFactors(unittest.TestCase):
 def reject(self,sql):
  with self.assertRaises(O.SqlCoverageError):O.business_rows([{'commandType':'Query','sql':sql}])
 def test_bare_parenthesized_business_table_is_not_silent_zero(self):self.reject('SELECT * FROM (uat.'+O.SOURCE+')')
 def test_join_bare_parenthesized_table_is_not_silent_zero(self):self.reject('SELECT * FROM information_schema.tables JOIN (uat.'+O.SOURCE+') ON 1=1')
 def test_unknown_from_symbol_is_not_silent_zero(self):
  for factor in ['?','@unknown','*']:self.reject('SELECT * FROM '+factor)
 def test_unknown_prefix_with_select_cannot_bypass_coverage(self):
  for sql in ['INSERT INTO uat.spare SELECT 1','CREATE TABLE uat.spare AS SELECT 1','DELETE FROM uat.spare WHERE id IN (SELECT 1)']:self.reject(sql)
 def test_non_mysql_three_part_target_is_not_silent_zero(self):self.reject('SELECT * FROM catalog.uat.'+O.SOURCE)
 def test_supported_derived_select_and_with_keep_real_business_read(self):
  for sql in ['SELECT * FROM (SELECT * FROM uat.'+O.SOURCE+') q','SELECT * FROM (WITH q AS (SELECT * FROM uat.'+O.SOURCE+') SELECT * FROM q) derived']:self.assertEqual(len(O.business_rows([{'commandType':'Query','sql':sql}])),1)
 def test_known_no_read_metadata_and_exact_log_truncate_remain_zero(self):
  for sql in ["SET NAMES utf8mb4",'SHOW TABLES','START TRANSACTION','COMMIT','TRUNCATE TABLE mysql.general_log']:self.assertFalse(O.business_rows([{'commandType':'Query','sql':sql}]))
 def test_read_inside_set_is_not_known_no_read_metadata(self):self.reject('SET @x=(SELECT 1)')
class CapturedKtxWrapper(unittest.TestCase):
 def setUp(self):
  self.captured=json.loads((HERE/'captured-ktx-wrapper.json').read_text());self.row=self.captured['row'];self.receipt=self.captured['receipt'];self.inner=O.payload(self.receipt)['sql']
 def match(self,sql):return O.expected_business_sql_matches([{**self.row,'sql':sql}],self.receipt)
 def test_actual_oldnormal_wire_matches_exact_compiled_inner(self):self.assertTrue(self.match(self.row['sql']))
 def test_changed_inner_is_not_accepted(self):self.assertFalse(self.match(self.row['sql'].replace('LIMIT 100)','LIMIT 99)')))
 def test_extra_outer_where_is_not_accepted(self):self.assertFalse(self.match(self.row['sql'].replace(' limit 100',' WHERE 1=1 limit 100')))
 def test_other_outer_alias_is_not_accepted(self):self.assertFalse(self.match(self.row['sql'].replace('ktx_query_result','other_alias')))
 def test_changed_effective_limit_is_not_accepted(self):
  for n in ['99','101','1000']:self.assertFalse(self.match(self.row['sql'][:-3]+n))
 def test_extra_statement_is_not_accepted(self):self.assertFalse(self.match(self.row['sql']+'; SELECT 1'))
 def test_two_executions_are_not_accepted(self):self.assertFalse(O.expected_business_sql_matches([self.row,self.row],self.receipt))
 def test_nested_wrapper_is_not_accepted(self):self.assertFalse(self.match('select * from ('+self.row['sql']+') as ktx_query_result limit 100'))
class Audit(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.db=pathlib.Path(self.temp.name)/'closed.sqlite';self.c=sqlite3.connect(self.db);self.c.executescript("CREATE TABLE question_budget_state(scope_key TEXT,calls INT,attempts INT,current_concurrency INT,round INT,window_id INT,started_at INT);INSERT INTO question_budget_state VALUES('scope',1,1,0,0,0,100);CREATE TABLE access_log(id INT,user_id TEXT,lucy_session_id TEXT,token_hash_prefix TEXT,tool TEXT,request_id TEXT,outcome TEXT,generated_sql TEXT,query_operation TEXT);INSERT INTO access_log VALUES(1,'a','session','token','lucy_query','7','ok','SELECT COUNT(*),SUM(amount)','select');CREATE TABLE inferred_turns(inferred_turn_id TEXT,user_id TEXT);INSERT INTO inferred_turns VALUES('turn','a');CREATE TABLE inferred_turn_access_logs(inferred_turn_id TEXT,access_log_id INT);INSERT INTO inferred_turn_access_logs VALUES('turn',1);");self.scope={'scopeKey':'scope','userId':'a','session':'session','tokenPrefix':'token','tool':'lucy_query','rpcs':[7],'expected':{'7':True},'expectedSql':{'7':'SELECT COUNT(*),SUM(amount)'},'initialState':{'round':0,'window_id':0,'started_at':100}}
 def tearDown(self):self.c.close();self.temp.cleanup()
 def verify(self):self.c.commit();return O.audit_scopes(self.db,[self.scope])[0]
 def test_single_original_budget_and_effective_audit(self):self.assertTrue(self.verify()['valid'])
 def test_real_captured_lowercase_operation_is_the_contract(self):
  captured=json.loads((HERE.parent/'audit-operation-contract-evidence.json').read_text())['actualQueryRow'];self.assertEqual(captured['query_operation'],'select');self.scope['expectedSql']['7']=captured['generated_sql'];self.c.execute('UPDATE access_log SET query_operation=?,generated_sql=?',(captured['query_operation'],captured['generated_sql']));self.assertTrue(self.verify()['valid'])
 def test_wrong_or_missing_success_classification_fails(self):
  for value in ['SELECT','unknown','with',None]:
   self.c.execute('UPDATE access_log SET query_operation=?',(value,));self.assertFalse(self.verify()['valid'])
 def test_zero_execution_receipt_rejects_select_audit_marker(self):
  self.scope['expected']['7']=False;self.c.execute("UPDATE access_log SET outcome='error',generated_sql=NULL,query_operation='select'");self.assertFalse(self.verify()['valid'])
 def test_true_zero_sql_failed_row_remains_valid(self):
  self.scope['expected']['7']=False;self.c.execute("UPDATE access_log SET outcome='error',generated_sql=NULL,query_operation=NULL");self.assertTrue(self.verify()['valid'])
 def test_metadata_and_explain_require_zero_execution_audit(self):
  for tool in ['lucy_read_source','lucy_explain_query']:
   self.scope['tool']=tool;self.c.execute('UPDATE access_log SET tool=?,generated_sql=NULL,query_operation=NULL',(tool,));self.assertTrue(self.verify()['valid']);self.c.execute("UPDATE access_log SET generated_sql='SELECT COUNT(*),SUM(amount)',query_operation='select'");self.assertFalse(self.verify()['valid'])
 def test_double_consume_fails(self):self.c.execute('UPDATE question_budget_state SET calls=2');self.assertFalse(self.verify()['valid'])
 def test_same_session_generation_reset_fails(self):self.c.execute('UPDATE question_budget_state SET window_id=1');self.assertFalse(self.verify()['valid'])
 def test_orphan_or_wrong_user_link_fails(self):self.c.execute("UPDATE inferred_turns SET user_id='other'");self.assertFalse(self.verify()['valid'])
 def test_duplicate_actual_audit_fails(self):self.c.execute('INSERT INTO access_log SELECT * FROM access_log');self.assertFalse(self.verify()['valid'])
 def test_false_success_audit_fails(self):self.c.execute("UPDATE access_log SET outcome='error'");self.assertFalse(self.verify()['valid'])
 def test_success_receipt_without_execution_audit_fails(self):self.c.execute('UPDATE access_log SET generated_sql=NULL,query_operation=NULL');self.assertFalse(self.verify()['valid'])
 def test_missing_or_duplicate_effective_link_fails(self):self.c.execute("INSERT INTO inferred_turn_access_logs VALUES('turn',1)");self.assertFalse(self.verify()['valid'])
class Freeze(unittest.TestCase):
 def test_exact_source_pins_accept_and_changed_tool_is_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=pathlib.Path(tmp);products={};tools={};image='sha256:'+'a'*64
   for name in D.PRODUCTS+['scripts/uat/core-availability-1883-soak.py','scripts/uat/readyz-diagnostic-repro.py','scripts/uat/verify-begin-zero-binding.py']:
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(name);(products if name in D.PRODUCTS else tools)[name]=D.sha(p)
   manifest={'imageId':image,'sourceHashes':products,'toolHashes':tools};contract={'status':'FROZEN','imageId':image,'sourceHashes':copy.deepcopy(products),'toolHashes':copy.deepcopy(tools)};D.verify_sources(root,manifest,contract,image)
   contract['toolHashes']['scripts/uat/verify-begin-zero-binding.py']='wrong'
   with self.assertRaises(AssertionError):D.verify_sources(root,manifest,contract,image)
 def test_unfrozen_schema_cannot_start_docker(self):
  with self.assertRaises(AssertionError):D.verify_sources(pathlib.Path('.'),{'imageId':'sha256:'+'a'*64},{'status':'NOT FROZEN'},'sha256:'+'a'*64)
 def test_event_contract_wrong_image_cannot_start_docker(self):
  with self.assertRaises(AssertionError):D.verify_sources(pathlib.Path('.'),{'imageId':'sha256:'+'a'*64},{'status':'FROZEN','imageId':'sha256:'+'b'*64},'sha256:'+'a'*64)
 def test_mutable_tag_cannot_start_docker(self):
  with self.assertRaises(AssertionError):D.verify_sources(pathlib.Path('.'),{'imageId':'latest'},{'status':'FROZEN'},'latest')
if __name__=='__main__':unittest.main()
