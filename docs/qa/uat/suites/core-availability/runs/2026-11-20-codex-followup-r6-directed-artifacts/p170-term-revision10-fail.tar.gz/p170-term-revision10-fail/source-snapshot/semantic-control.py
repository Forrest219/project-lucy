"""Task-owned remote controls. Executed only by an explicitly launched Docker driver."""
import gzip,hashlib,json,math,os,pathlib,signal,sqlite3,stat,sys,time
ROOT=pathlib.Path('/data/lucy');CONTROL=pathlib.Path('/tmp/uat-p170-control');MIRROR=ROOT/'semantic-layer/uat-mysql/_schema/uat.yaml';SOURCE=ROOT/'config/semantic-layer/uat-mysql/_schema/uat.yaml';BACKUP=ROOT/'.ktx-ui/uat-p170-mirror-backup.yaml'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for part in iter(lambda:f.read(1048576),b''):h.update(part)
 return h.hexdigest()
def read_json(p):
 try:return json.loads(p.read_text())
 except (OSError,ValueError):return None
def write_state(value):
 p=CONTROL/'state.json';t=p.with_suffix('.tmp');t.write_text(json.dumps({'at':time.time(),**value}));os.replace(t,p)
def valid_lease_break_time(value):
 return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>10
def matching_lease_rows(control):
 rows=[];device=control['device']
 for line in pathlib.Path('/proc/locks').read_text().splitlines():
  parts=line.split()
  if len(parts)<8 or '->' in parts or parts[1]!='LEASE':continue
  try:
   major,minor,inode=parts[5].split(':')
   if int(parts[4])==control['pid'] and int(major,16)==device['major'] and int(minor,16)==device['minor'] and int(inode)==control['inode']:rows.append(line)
  except (ValueError,KeyError):continue
 return rows
def inspect():
 lock=read_json(ROOT/'.ktx-ui/semantic-publish.lock');journals=[];nodes=[]
 for p in (ROOT/'.ktx-ui/semantic-recovery-journals').glob('*.json'):
  j=read_json(p)
  if j:journals.append({k:j.get(k) for k in ['journalId','releaseId','operationId','status','phase','recoveryRequired']})
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode();name=(p/'comm').read_text().strip()
   if name!='node' or 'server/index.ts' not in cmd:continue
   fields=(p/'stat').read_text().rsplit(')',1)[1].split();row={'pid':int(p.name),'startTicks':fields[19],'fds':[],'tasks':[]}
   for fd in (p/'fd').iterdir():
    try:
     target=os.readlink(fd)
     if target==str(SOURCE):row['fds'].append({'fd':fd.name,'target':target})
    except OSError:pass
   if lock and lock.get('pid')==int(p.name):
    for task in (p/'task').iterdir():
     try:row['tasks'].append({'tid':task.name,'wchan':(task/'wchan').read_text().strip()})
     except OSError:pass
   nodes.append(row)
  except (OSError,ValueError,IndexError):pass
 control=read_json(CONTROL/'state.json');lease_rows=[];alive=False
 if control and control.get('kind')=='regular_lease':
  lease_rows=matching_lease_rows(control)
  try:alive=(pathlib.Path('/proc')/str(control['pid'])/'stat').read_text().rsplit(')',1)[1].split()[19]==control['startTicks']
  except FileNotFoundError:alive=False
  except (OSError,IndexError):alive=None
 return {'at':time.time(),'lock':lock,'journals':journals,'nodes':nodes,'control':control,'leaseRows':lease_rows,'controlAlive':alive,'leaseRemainingSeconds':max(0,(control or {}).get('guardDeadlineMono',0)-time.monotonic())}
def fifo():
 CONTROL.mkdir(exist_ok=True);os.chmod(CONTROL,0o777);deadline=time.monotonic()+100;reader=None;original=MIRROR.stat();assert stat.S_ISREG(original.st_mode) and not MIRROR.is_symlink();assert not BACKUP.exists()
 os.replace(MIRROR,BACKUP);os.mkfifo(MIRROR,stat.S_IMODE(original.st_mode));os.chown(MIRROR,original.st_uid,original.st_gid);write_state({'phase':'fifo_installed','pid':os.getpid(),'inode':MIRROR.stat().st_ino,'sourceRegular':SOURCE.is_file()})
 try:
  while time.monotonic()<deadline and not (CONTROL/'release').exists():time.sleep(.01)
  if time.monotonic()>=deadline:raise TimeoutError('owned FIFO control absolute100s deadline')
  reader=os.open(MIRROR,os.O_RDONLY|os.O_NONBLOCK);write_state({'phase':'reader_opened','pid':os.getpid(),'inode':os.fstat(reader).st_ino})
  while time.monotonic()<deadline and not (CONTROL/'restore').exists():
   try:os.read(reader,65536)
   except BlockingIOError:pass
   time.sleep(.01)
  if time.monotonic()>=deadline:raise TimeoutError('owned FIFO restore absolute100s deadline')
 finally:
  if reader is not None:os.close(reader)
  if MIRROR.exists() and stat.S_ISFIFO(MIRROR.stat().st_mode):MIRROR.unlink()
  if BACKUP.exists():os.replace(BACKUP,MIRROR)
  write_state({'phase':'restored','pid':os.getpid(),'mirrorRegular':MIRROR.is_file(),'mirrorSha256':digest(MIRROR)})
def file_identity(path,regular=True):
 info=path.lstat()
 if path.is_symlink() or (not stat.S_ISREG(info.st_mode) if regular else not stat.S_ISFIFO(info.st_mode)):raise ValueError('unexpected private fixture file kind')
 proof={'dev':info.st_dev,'inode':info.st_ino,'mode':stat.S_IMODE(info.st_mode),'uid':info.st_uid,'gid':info.st_gid,'nlink':info.st_nlink,'noSymlink':True}
 if regular:proof.update(size=info.st_size,sha256=digest(path))
 if proof['nlink']!=1:raise ValueError('private fixture file has unexpected hard links')
 return proof
def semantic_wal_inventory():
 paths=sorted((ROOT/'.ktx-ui/semantic-recovery-journals').glob('*.json'));lock=ROOT/'.ktx-ui/semantic-publish.lock'
 if lock.exists():paths.append(lock)
 return {str(p.relative_to(ROOT)):digest(p) for p in paths}
def restore_stopped_fifo(expected):
 if expected.get('originalAppStopped') is not True or expected.get('mirrorPath')!=str(MIRROR) or expected.get('backupPath')!=str(BACKUP):raise ValueError('missing stopped app/exact paths evidence')
 original=expected['original'];injected=expected['injected'];before=semantic_wal_inventory()
 if BACKUP.exists() or BACKUP.is_symlink():
  if file_identity(BACKUP)!=original or injected.get('backup')!=original:raise ValueError('private backup identity mismatch')
  if file_identity(MIRROR,regular=False)!=injected.get('fifo'):raise ValueError('injected FIFO identity mismatch')
  MIRROR.unlink();os.replace(BACKUP,MIRROR);action='restored_private_backup'
 else:
  if file_identity(MIRROR)!=original:raise ValueError('absent backup without exact already-restored original')
  action='already_restored_exact_original'
 restored=file_identity(MIRROR);after=semantic_wal_inventory()
 if restored!=original or before!=after or BACKUP.exists() or BACKUP.is_symlink():raise ValueError('restoration identity/WAL invariant failed')
 return {'action':action,'originalAppStoppedEvidence':'host docker inspect before helper launch','restored':restored,'backupAbsent':True,'walBefore':before,'walAfter':after,'walUnchanged':True,'productProcessStarted':False}
def capture():
 CONTROL.mkdir(exist_ok=True);path=CONTROL/'audit-evidence.sqlite';archive=CONTROL/'audit-evidence.sqlite.gz';deadline=time.monotonic()+20
 source=sqlite3.connect('file:/data/lucy/.ktx-ui/audit.sqlite?mode=ro',uri=True);dest=sqlite3.connect(path)
 try:source.backup(dest,pages=256,progress=lambda *args: (_ for _ in ()).throw(TimeoutError('backup deadline')) if time.monotonic()>=deadline else None)
 finally:dest.close();source.close()
 with path.open('rb') as src,gzip.open(archive,'wb',compresslevel=1) as dst:
  for part in iter(lambda:src.read(1048576),b''):
   if time.monotonic()>=deadline:raise TimeoutError('gzip deadline')
   dst.write(part)
 result={'source':'SQLite backup API from task-owned live DB; closed copy','sqliteBytes':path.stat().st_size,'sqliteSha256':digest(path),'gzipBytes':archive.stat().st_size,'gzipSha256':digest(archive),'path':str(archive)};path.unlink();print(json.dumps(result))
def lease():
 # Normal control only: never write/replace/chmod/chown the real target.
 import fcntl
 CONTROL.mkdir(exist_ok=True);os.chmod(CONTROL,0o777);info=MIRROR.lstat();assert stat.S_ISREG(info.st_mode) and info.st_uid==os.geteuid();fd=None;signals=[];released=False;reason=None;released_at=None;started=time.monotonic();reported_break=False
 identity={'kind':'regular_lease','pid':os.getpid(),'startTicks':pathlib.Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],'uid':os.geteuid(),'targetUid':info.st_uid,'inode':info.st_ino,'device':{'raw':info.st_dev,'major':os.major(info.st_dev),'minor':os.minor(info.st_dev)},'targetModeBefore':stat.S_IMODE(info.st_mode),'sourceRegular':SOURCE.is_file(),'targetRegular':True,'breakTimeSeconds':float(pathlib.Path('/proc/sys/fs/lease-break-time').read_text().strip())}
 if not valid_lease_break_time(identity['breakTimeSeconds']):raise RuntimeError('normal control requires finite kernel lease-break-time >10s; no lease acquired')
 def sigio(number,frame):signals.append({'number':number,'at':time.time(),'mono':time.monotonic()})
 signal.signal(signal.SIGIO,sigio)
 try:
  fd=os.open(MIRROR,os.O_RDONLY);opened=os.fstat(fd);assert opened.st_ino==info.st_ino and opened.st_dev==info.st_dev;fcntl.fcntl(fd,fcntl.F_SETOWN,os.getpid());fcntl.fcntl(fd,fcntl.F_SETLEASE,fcntl.F_RDLCK);identity['leaseSet']=True;write_state({**identity,'phase':'lease_ready','signals':[]})
  while True:
   now=time.monotonic()
   if signals:
    # A9s guard leaves scheduling margin; actual release must still prove <=10s.
    limit=min(started+25,signals[0]['mono']+9)
    if not reported_break:
     write_state({**identity,'phase':'lease_breaking','signals':signals,'releaseDeadlineMono':signals[0]['mono']+10,'guardDeadlineMono':limit});reported_break=True
    if (CONTROL/'lease-release').exists():reason='manual_after_actual_wait_begin';break
    if now>=limit:reason='auto_deadline';break
   elif now>=started+25:reason='auto_no_break';break
   time.sleep(.005)
  fcntl.fcntl(fd,fcntl.F_SETLEASE,fcntl.F_UNLCK);released_at=time.monotonic();released=True
 finally:
  if fd is not None:
   if not released:
    try:fcntl.fcntl(fd,fcntl.F_SETLEASE,fcntl.F_UNLCK);released_at=time.monotonic()
    except OSError:pass
   os.close(fd)
  write_state({**identity,'phase':'lease_closed','signals':signals,'releaseReason':reason or 'exception_cleanup','releasedMono':released_at,'releasedWithin10':bool(signals and released_at is not None and released_at-signals[0]['mono']<=10),'targetMetadataChangedByControl':False,'targetBytesWrittenByControl':False})

if __name__=='__main__':
 command=sys.argv[1]
 if command=='inspect':print(json.dumps(inspect()))
 elif command=='fifo':fifo()
 elif command=='lease':lease()
 elif command=='lease-digests':
  value=inspect();assert value['control']['phase']=='lease_closed' and not value['leaseRows'];print(json.dumps({'sourceSha256':digest(SOURCE),'mirrorSha256':digest(MIRROR),'mirrorInode':MIRROR.stat().st_ino,'mirrorUid':MIRROR.stat().st_uid,'mirrorMode':stat.S_IMODE(MIRROR.stat().st_mode),'control':value['control'],'leaseRows':value['leaseRows'],'controlAlive':value['controlAlive']}))
 elif command=='lease-cleanup':
  value=inspect();assert value['control']['phase']=='lease_closed' and not value['leaseRows'] and value['controlAlive'] is False;__import__('shutil').rmtree(CONTROL);print(json.dumps({'privateControlRemoved':not CONTROL.exists(),'targetTouchedByCleanup':False}))
 elif command=='signal':
  assert sys.argv[2] in ['release','restore','lease-release'];(CONTROL/sys.argv[2]).touch()
 elif command=='term-restore-preimage':print(json.dumps({'mirrorPath':str(MIRROR),'backupPath':str(BACKUP),'original':file_identity(MIRROR)}))
 elif command=='term-restore-injected':print(json.dumps({'backup':file_identity(BACKUP),'fifo':file_identity(MIRROR,regular=False)}))
 elif command=='term-restore-stopped':print(json.dumps(restore_stopped_fifo(json.loads(sys.argv[2]))))
 elif command=='capture':capture()
 else:raise ValueError('unknown control command')
