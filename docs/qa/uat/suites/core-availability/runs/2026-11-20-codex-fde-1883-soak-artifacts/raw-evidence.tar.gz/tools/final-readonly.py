"""Observe only this named fixture; never change its DB/config/process state."""
import datetime,json,pathlib,subprocess,time
root=pathlib.Path('inbox/core1883-20261120/run-3')
name='lucy-core1883-cb41c2-app'
code=r'''
const D=require('/app/webui/node_modules/better-sqlite3');const d=new D('/data/lucy/.ktx-ui/audit.sqlite',{readonly:true});d.pragma('busy_timeout=5000');
const at=new Date().toISOString();
const perUser=d.prepare(`SELECT a.user_id AS userId, COUNT(DISTINCT a.id) AS rawRows,
 COUNT(l.access_log_id) AS linkRows,
 COUNT(DISTINCT CASE WHEN t.inferred_turn_id IS NOT NULL AND t.user_id=a.user_id THEN a.id END) AS uniqueValidRows,
 SUM(CASE WHEN l.access_log_id IS NOT NULL AND t.inferred_turn_id IS NULL THEN 1 ELSE 0 END) AS orphanLinks,
 SUM(CASE WHEN t.inferred_turn_id IS NOT NULL AND t.user_id<>a.user_id THEN 1 ELSE 0 END) AS wrongUserLinks
 FROM access_log a LEFT JOIN inferred_turn_access_logs l ON a.id=l.access_log_id
 LEFT JOIN inferred_turns t ON t.inferred_turn_id=l.inferred_turn_id
 WHERE a.client='uat-core1883-history' GROUP BY a.user_id ORDER BY a.user_id`).all();
const watermarks=d.prepare("SELECT user_id,status,watermark,updated_at FROM inferred_rebuild_state WHERE user_id LIKE 'uat-core1883-history-%' ORDER BY user_id").all();
console.log(JSON.stringify({at,fixtureOnly:true,readonly:true,perUser,watermarks,
 totals:{users:perUser.length,rawRows:perUser.reduce((n,x)=>n+x.rawRows,0),linkRows:perUser.reduce((n,x)=>n+x.linkRows,0),uniqueValidRows:perUser.reduce((n,x)=>n+x.uniqueValidRows,0),
 orphanLinks:perUser.reduce((n,x)=>n+x.orphanLinks,0),wrongUserLinks:perUser.reduce((n,x)=>n+x.wrongUserLinks,0)},
 integrityCheck:d.pragma('quick_check',{simple:true})}));d.close();
'''
seen=set()
while len(seen)<2:
    path=root/'events.jsonl'
    if path.exists():
        # Tail covers this control's markers while ordinary producers are stopped.
        text=path.read_bytes()[-50000:].decode(errors='replace')
        for marker in ['io-control-start','io-control-end']:
            if marker in seen or '"kind": "'+marker+'"' not in text:continue
            seen.add(marker);r=subprocess.run(['docker','exec',name,'node','-e',code],capture_output=True,text=True,timeout=90)
            record={'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'marker':marker,'returncode':r.returncode}
            if r.returncode==0:record['facts']=json.loads(r.stdout)
            else:record['error']=r.stderr[-1200:]
            (root/('audit-validity-'+marker+'.json')).write_text(json.dumps(record,indent=2)+chr(10))
            state=subprocess.run(['docker','inspect',name,'--format','{{json .State}}'],capture_output=True,text=True,timeout=20)
            (root/('container-state-'+marker+'.json')).write_text(state.stdout)
            print(marker+' captured',flush=True)
    if (root/'summary.json').exists():
        s=json.loads((root/'summary.json').read_text())
        if s.get('finishedAt'):break
        start=datetime.datetime.fromisoformat(s['soakStartedAt']).timestamp()
        time.sleep(2 if time.time()-start>=7150 else 45)
    else:time.sleep(5)
