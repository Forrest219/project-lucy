"""Read-only post-analysis; raw samples remain authoritative."""
import argparse, collections, datetime, hashlib, json, math, pathlib, statistics

def epoch(x):
    if isinstance(x,(float,int)):return x
    return datetime.datetime.fromisoformat(x.replace('Z','+00:00')).timestamp()

def read_lines(path):
    if not path.exists():return []
    rows=[]
    for line in path.read_text().splitlines():
        try:rows.append(json.loads(line))
        except ValueError:pass # live snapshots may end in an incomplete write
    return rows

def stat(rows):
    xs=sorted(x['ms'] for x in rows)
    return {'count':len(xs),'non200':sum(x.get('status')!=200 for x in rows),
            'p50Ms':xs[math.ceil(len(xs)*.5)-1] if xs else None,
            'p99Ms':xs[math.ceil(len(xs)*.99)-1] if xs else None,
            'maxMs':max(xs,default=None)}

def main():
    p=argparse.ArgumentParser();p.add_argument('run');p.add_argument('--observations');p.add_argument('--out');a=p.parse_args()
    root=pathlib.Path(a.run);obs=pathlib.Path(a.observations) if a.observations else root/'observations'
    s=json.loads((root/'summary.json').read_text());all_events=read_lines(root/'events.jsonl')
    lo=epoch(s['soakStartedAt']);hi=epoch(s['soakFinishedAt']) if s.get('soakFinishedAt') else float('inf')
    natural=lambda x:lo<=epoch(x['at'])<=hi
    events=[x for x in all_events if natural(x)]
    probes=[x for x in read_lines(obs/'probes.jsonl') if natural(x)]
    proc=[x for x in read_lines(obs/'proc.jsonl') if natural(x) and 'cpuTicks' in x]
    out={'sourceSummarySha256':hashlib.sha256((root/'summary.json').read_bytes()).hexdigest(),
         'period':{'start':s['soakStartedAt'],'end':s.get('soakFinishedAt'),'requiredSeconds':s['secondsRequired']},
         'probes':{path:stat([x for x in probes if x['path']==path]) for path in sorted({x['path'] for x in probes})},
         'business':{kind:stat([x for x in events if x['kind']==kind and 'status' in x]) for kind in ['http','mcp']},
         'errors':[x for x in events if x.get('error')],
         'postStopEventsRetained':len([x for x in all_events if epoch(x['at'])>hi]),
         'inflightAtUserStop':[x for x in all_events if x['kind'] in ['http','mcp','mutation'] and epoch(x['at'])>hi and epoch(x['at'])-x.get('ms',0)/1000<=hi],
         'mainPidValues':sorted({x['pid'] for x in proc}),
         'procSamples':len(proc),'mainStateCounts':dict(collections.Counter(x['state'] for x in proc)),
         'mainWchanCounts':dict(collections.Counter(x['mainWchan'] for x in proc))}
    cpu=[]
    for x,y in zip(proc,proc[1:]):
        dt=y['mono']-x['mono']
        if dt>0 and x['pid']==y['pid']:
            cpu.append({'at':y['at'],'elapsedSeconds':dt,'mainCpuSeconds':(y['cpuTicks']-x['cpuTicks'])/y['hz'],
                        'fraction':(y['cpuTicks']-x['cpuTicks'])/y['hz']/dt})
    out['mainCpu']={'totalObservedCpuSeconds':sum(x['mainCpuSeconds'] for x in cpu),
                    'observedWallSeconds':sum(x['elapsedSeconds'] for x in cpu),
                    'binsOver80Percent':sum(x['fraction']>=.8 for x in cpu),
                    'topBins':sorted(cpu,key=lambda x:x['fraction'],reverse=True)[:20]}
    workers={}
    for x in proc:
        for w in x.get('workers',[]):
            v=workers.setdefault(w['pid'],{'pid':w['pid'],'firstAt':x['at'],'lastAt':x['at'],'samples':0,'pipeReadSamples':0})
            v['lastAt']=x['at'];v['samples']+=1
            v['pipeReadSamples']+=any('pipe_read' in t['wchan'] or 'wait_for_partner' in t['wchan'] for t in w.get('threads',[]))
    out['naturalDiagnosticWorkers']={'observedCount':len(workers),
        'maxSimultaneous':max((len(x.get('workers',[])) for x in proc),default=0),
        'pipeReadSamples':sum(x['pipeReadSamples'] for x in workers.values()),
        'maxObservedLifetimeSeconds':max((x['lastAt']-x['firstAt'] for x in workers.values()),default=0)}
    out['cgroup']={'maxObservedMemoryBytes':max((int(x.get('memory.current',0)) for x in proc),default=0),
        'lastMemoryEvents':next((x['memory.events'] for x in reversed(proc) if 'memory.events' in x),None),
        'firstCpuStat':next((x['cpu.stat'] for x in proc if 'cpu.stat' in x),None),
        'lastCpuStat':next((x['cpu.stat'] for x in reversed(proc) if 'cpu.stat' in x),None)}
    health=[x for x in probes if x['path']=='/api/health']
    out['eventLoop']={'maxMs':max((x.get('eventLoop',{}).get('maxMs',0) for x in health),default=None),
                      'topWindows':sorted(health,key=lambda x:x.get('eventLoop',{}).get('maxMs',0),reverse=True)[:10]}
    out['diagnosticFreshness']=dict(collections.Counter(x.get('diagnostics',{}).get('freshness','missing') for x in health))
    audits=[x for x in events if x['kind']=='audit-progress' and 'linked' in x]
    mutations=[]
    for start in [x for x in events if x['kind']=='mutation-start']:
        n=start['iteration'];end=next((x for x in events if x['kind']=='mutation-end' and x['iteration']==n),None)
        if not end:mutations.append({'iteration':n,'complete':False});continue
        t0,t1=epoch(start['at']),epoch(end['at'])
        points=[x for x in audits if t0<=epoch(x['at'])<=t1]
        bins=[x for x in cpu if t0<=x['at']<=t1]
        mutations.append({'iteration':n,'complete':True,'start':start['at'],'end':end['at'],'seconds':t1-t0,
            'enabled':end['scale']['enabled'],'shortName':end['shortName'],
            'auditObservations':len(points),'auditStatesInProgress':sum(any(z['status']=='in_progress' for z in x['states']) for x in points),
            'auditLinkedDeltaInsideWindow':points[-1]['linked']['uniqueN']-points[0]['linked']['uniqueN'] if len(points)>1 else None,
            'mainCpuSecondsInSampleBins':sum(x['mainCpuSeconds'] for x in bins),
            'probeStats':{path:stat([x for x in probes if x['path']==path and t0<=epoch(x['at'])<=t1]) for path in out['probes']}})
    out['mutations']=mutations
    receipts=[]
    for cycle in mutations:
        if not cycle.get('complete'):continue
        n=cycle['iteration'];prefix=root/'candidate'/('cycle-%d-'%n)
        def receipt(name):return json.loads(pathlib.Path(str(prefix)+name+'.json').read_text())
        read=receipt('renamed-read');query=receipt('recovery-query');saved=receipt('enabled-tables')
        content=read['body']['result']['structuredContent'];q=query['body']['result']['structuredContent']
        sources=read['body']['result']['_meta']['lucy']['sources']
        checks={'shortNameMatches':content['sourceName']==cycle['shortName'],
            'physicalTableMatches':any(x.get('physicalTable')=='uat.uat_t1882' for x in sources),
            'mysqlOracleMatches':q['rows']==[[4,'100']] or q['rows']==[[4,100]],
            'saveRuntimeAck':all(saved['body']['data'].get(k) is True for k in ['written','policyRuntimeAck','runtimeAck']),
            'enabledCountMatches':len(saved['body']['data']['newEnabledTables'])==cycle['enabled']}
        receipts.append({'iteration':n,**checks,'allPassed':all(checks.values())})
    out['receiptVerification']=receipts
    stages={}
    for label,suffix in [('validate','validate'),('upload','upload'),('save','enabled-tables'),('reload','reload'),('newShortNameRead','renamed-read'),('queryAfterReload','recovery-query')]:
        seen=[]
        for start in [x for x in events if x['kind']=='mutation-start']:
            n=start['iteration'];path=root/'candidate'/('cycle-%d-%s.json'%(n,suffix))
            if not path.exists():continue
            x=json.loads(path.read_text());b=x['body'];ok=x['httpStatus']==200 and not b.get('error') and not b.get('result',{}).get('isError')
            if label in ['validate','upload','save']:ok=ok and b.get('ok') is True
            if label=='reload':ok=ok and b.get('data',{}).get('reloadStatus')=='succeeded'
            seen.append({'iteration':n,'status':x['httpStatus'],'passed':bool(ok),'ms':x['elapsedMs'],
                         'error':b.get('error') or (b.get('result') if b.get('result',{}).get('isError') else None)})
        stages[label]={'attempted':len(seen),'passed':sum(x['passed'] for x in seen),'failed':[x for x in seen if not x['passed']],
                       'p99Ms':stat([{'status':x['status'],'ms':x['ms']} for x in seen])['p99Ms']}
    out['operationStages']=stages
    out['actualAuditOverlapProven']=any((x.get('auditLinkedDeltaInsideWindow') or 0)>0 for x in mutations)
    out['realReloads']=[x for x in events if x['kind']=='reload-end']
    out['auditSeeds']=[x for x in events if x['kind']=='audit-seed']
    # Weighted leaf and inclusive function stacks. Native profiler data is a
    # sample, not an exact duration trace or proof every function is synchronous.
    leaf=collections.Counter();inclusive=collections.Counter();total=0;profiles=[]
    offsets=[x['at']-x['mono'] for x in proc if 'mono' in x]
    offset=statistics.median(offsets) if offsets else None
    for path in sorted(obs.glob('cpu-*.cpuprofile')):
        x=json.loads(path.read_text());nodes={n['id']:n for n in x['nodes']};parents={}
        for n in x['nodes']:
            for child in n.get('children',[]):parents[child]=n['id']
        # V8 profile times and Linux monotonic share the clock. Client `at` /
        # `finishedAt` include CDP queue / serialization delays and are not a
        # valid exact time anchor under a blocked event loop.
        anchored=x['startTime']/1e6+offset if offset is not None else epoch(x['at'])
        if abs(anchored-epoch(x['at']))>10:raise ValueError('V8 monotonic clock mapping differs >10s; do not infer exact spans')
        clock=anchored;used=0
        for node_id,delta in zip(x.get('samples',[]),x.get('timeDeltas',[])):
            clock+=delta/1e6
            if not lo<=clock<=hi:continue
            used+=delta;total+=delta
            def key(i):
                f=nodes[i]['callFrame'];return f.get('functionName','')+' @ '+f.get('url','')+':'+str(f.get('lineNumber',-1)+1)
            leaf[key(node_id)]+=delta
            seen=set()
            while node_id in nodes:
                k=key(node_id)
                if k not in seen:inclusive[k]+=delta;seen.add(k)
                if node_id not in parents:break
                node_id=parents[node_id]
        profiles.append({'file':path.name,'at':x['at'],'finishedAt':x['finishedAt'],'usedSeconds':used/1e6,'samples':len(x.get('samples',[])),
                         'anchoredStartEpoch':anchored,'anchoredEndEpoch':x['endTime']/1e6+offset if offset is not None else None,
                         'stopResponseLagSeconds':epoch(x['finishedAt'])-(x['endTime']/1e6+offset) if offset is not None else None})
    def top(counter):return [{'frame':k,'sampledSeconds':v/1e6,'percentOfObservedWall':v/total*100 if total else 0} for k,v in counter.most_common(35)]
    out['cpuProfile']={'files':profiles,'weightedObservedSeconds':total/1e6,'leafTop':top(leaf),'inclusiveTop':top(inclusive),
                        'done':(obs/'profile-done').exists(),'error':(obs/'profile-error').read_text() if (obs/'profile-error').exists() else None}
    out['cpuProfile']['monotonicEpochOffset']=offset
    out['cpuProfile']['monotonicOffsetRangeSeconds']=max(offsets)-min(offsets) if offsets else None
    marker=obs/'observer-profile-stopped.json'
    if marker.exists():
        transition=json.loads(marker.read_text());cut=transition['at'];out['profilerControl']=transition
        phases={}
        for label,a0,a1 in [('profiled',lo,cut),('observer-transition',cut,cut+30),('no-profiler-client',cut+30,hi)]:
            if a0>=hi:continue
            rows=[x for x in probes if a0<=epoch(x['at'])<a1]
            ps=[x for x in proc if a0<=x['at']<a1]
            phases[label]={'startEpoch':a0,'endEpoch':min(a1,hi) if math.isfinite(min(a1,hi)) else None,
                'probes':{path:stat([x for x in rows if x['path']==path]) for path in out['probes']},
                'errors':[x for x in out['errors'] if a0<=epoch(x['at'])<a1],
                'mainStateCounts':dict(collections.Counter(x['state'] for x in ps)),
                'mainWchanCounts':dict(collections.Counter(x['mainWchan'] for x in ps)),
                'maxRollingEventLoopDelayMs':max((x.get('eventLoop',{}).get('maxMs',0) for x in rows if x['path']=='/api/health'),default=0)}
        out['observerPhases']=phases
    out['samplingCaveats']=['Profiler is passive native sampling at 100Hz; not exact span tracing.',
      'Main-thread /proc snapshots are 250ms nominal; CPU totals exclude boundary bins.',
      'Health eventLoop max is a rolling 60-second value, not a new stall on every row.',
      'Live partial captures cannot establish completion; final raw files determine verdict.']
    text=json.dumps(out,ensure_ascii=False,indent=2)+chr(10)
    if a.out:pathlib.Path(a.out).write_text(text)
    else:print(text)

if __name__=='__main__':main()
