"""User-requested stop: freeze only the load generator, retain RO evidence, clean."""
import ast,datetime,json,os,pathlib,signal,subprocess,time
root=pathlib.Path('inbox/core1883-20261120/run-3');name='lucy-core1883-cb41c2-app'
ps=subprocess.check_output(['ps','-axo','pid=,command='],text=True,errors='replace')
found=[int(x.strip().split(None,1)[0]) for x in ps.splitlines() if 'scripts/uat/core-availability-1883-soak.py --image' in x and '--out inbox/core1883-20261120/run-3 --seconds 7200' in x]
assert len(found)==1,found
pid=found[0];os.kill(pid,signal.SIGSTOP)
at=datetime.datetime.now(datetime.timezone.utc).isoformat()
start=json.loads((root/'summary.json').read_text())['soakStartedAt']
stop={'reason':'User explicitly ended the test at about one hour and requested convergence; no 7200s claim',
      'naturalEndedAt':at,'loadGeneratorPid':pid,'onlyLoadGeneratorPaused':True,'appPidUnchangedExpected':'5971',
      'elapsedSeconds':datetime.datetime.fromisoformat(at).timestamp()-datetime.datetime.fromisoformat(start).timestamp()}
(root/'user-stop.json').write_text(json.dumps(stop,indent=2)+chr(10))
def command(args,timeout=60):return subprocess.run(args,capture_output=True,text=True,timeout=timeout)
try:
    tree=ast.parse(pathlib.Path('inbox/core1883-20261120/final-readonly.py').read_text())
    code=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='code' for t in n.targets))
    r=command(['docker','exec',name,'node','-e',code])
    rec={'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':r.returncode,'phase':'user-requested-end'}
    if r.returncode==0:rec['facts']=json.loads(r.stdout)
    else:rec['error']=r.stderr[-1500:]
    (root/'audit-validity-user-stop.json').write_text(json.dumps(rec,indent=2)+chr(10))
    r=command(['docker','inspect',name,'--format','{{json .State}}'])
    (root/'container-state-user-stop.json').write_text(r.stdout)
    code2="const fs=require('fs'),Y=require('/app/webui/node_modules/yaml');const c=Y.parse(fs.readFileSync('/data/lucy/ktx.yaml','utf8')),m=Y.parse(fs.readFileSync('/data/lucy/config/semantic-layer/uat-mysql/_schema/uat.yaml','utf8'));console.log(JSON.stringify({at:new Date().toISOString(),enabled:c.connections['uat-mysql'].enabled_tables.length,manifest:Object.keys(m.tables).length,mainPidAlive:fs.existsSync('/proc/5971'),profilerClientAlive:fs.existsSync('/proc/6518')}));"
    r=command(['docker','exec',name,'node','-e',code2]);(root/'scale-user-stop.json').write_text(r.stdout)
    command(['docker','exec',name,'touch','/tmp/lucy-core1883/stop']);time.sleep(2)
    r=command(['docker','cp',name+':/tmp/lucy-core1883',str(root/'observations')]);stop['observationsCopyReturncode']=r.returncode
    if r.returncode:stop['copyError']=r.stderr[-1000:]
except Exception as e:stop['captureError']=str(e)
finally:
    (root/'user-stop.json').write_text(json.dumps(stop,indent=2)+chr(10))
    os.kill(pid,signal.SIGCONT);os.kill(pid,signal.SIGTERM)
print(json.dumps(stop,indent=2),flush=True)
