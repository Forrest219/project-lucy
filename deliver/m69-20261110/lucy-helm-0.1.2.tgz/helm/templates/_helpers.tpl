{{- define "lucy-compat.fullname" -}}
{{- required "fullnameOverride must name the existing Deployment" .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "lucy-compat.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "lucy-compat.selectorLabels" -}}
{{- if not .Values.selectorLabelsOverride -}}
{{- fail "selectorLabelsOverride is required to preserve the existing immutable Deployment selector" -}}
{{- end -}}
{{- toYaml .Values.selectorLabelsOverride -}}
{{- end -}}

{{- define "lucy-compat.labels" -}}
helm.sh/chart: {{ include "lucy-compat.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/name: lucy
app.kubernetes.io/part-of: lucy
{{- end -}}

{{- define "lucy-compat.image" -}}
{{- printf "%s:%s" .Values.image.repository .Values.image.tag -}}
{{- end -}}
