# Lucy Helm compatibility chart — m69k8s

This is a **site-specific compatibility chart**, derived from the Lucy 2.0 / Chart 0.2.6 deployment contract. It exists because the live workload is not Helm-managed and has an immutable selector:

```yaml
app: lucy
```

It intentionally renders only these existing resources:

- `Deployment/lucy`
- `Service/lucy-admin` on 5174
- `Service/lucy-mcp` on 7879

The first adoption deliberately leaves these resources external to Helm:

- `PersistentVolumeClaim/lucy-data-pvc` and `PersistentVolume/lucy-data-pv`
- `Secret/lucy-doris` and `Secret/mjhub-cred`
- `ConfigMap/lucy-ktx-config`
- Ingresses `lucy-admin` and `lucy-mcp`

No template emits port `7878`.

## Site values

`values.m69.yaml` pins the existing resource topology:

- selector and Service selectors: `app=lucy`
- existing PVC: `lucy-data-pvc`
- data node: `m-69-219`
- HTTPS WebUI and MCP URL
- external Secret `lucy-doris`, mapping `password` to the PVC file `doris-main-password`
- one replica with `Recreate`
- runtime UID/GID `10001:10001` and `HOME=/home/lucy`

`project-migrate` changes ownership of legacy PVC files to UID/GID `10001:10001`; `secrets-sync` copies the external Secret into the writable PVC password directory. Both are intentional r4 workload changes, so use only after the separately completed PVC backup has been verified.

## Render-only validation

```bash
helm lint . -f values.m69.yaml
helm template lucy . --namespace lucy-system -f values.m69.yaml > /tmp/lucy-rendered.yaml
kubectl --context m69k8s apply --dry-run=client --validate=false -f /tmp/lucy-rendered.yaml
```

Confirm that the rendered Deployment selector is exactly `app: lucy`, that only `lucy-admin` and `lucy-mcp` Services are present, `lucy-data-pvc` is referenced, and no PVC, Ingress, ConfigMap or Secret is rendered.

## First Helm adoption

This chart does not make the vendor's signed r4 `scripts/deploy.sh` use this local chart. Before a production upgrade, either obtain a provider-signed r4 bundle containing these compatibility changes or use an approved local Helm adoption procedure. Do **not** edit the checksummed vendor package.

After render review and a successful server dry-run, the only resources to annotate for the first release are the three rendered existing resources: `Deployment/lucy`, `Service/lucy-admin`, and `Service/lucy-mcp`. Do not adopt the PVC, PV, Secrets, ConfigMap or Ingresses. Keep the full node-level PVC backup and `../k8s/` snapshot for recovery.

Never run `helm uninstall` against the adoption release without a reviewed recovery plan.
